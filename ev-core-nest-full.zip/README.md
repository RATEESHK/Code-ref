# ev-core-nest-full

A comprehensive **NestJS/TypeScript** port of the uploaded **EV.Core** codebase.
It preserves the original responsibilities (API client/handlers/builders, Logging, AWS adapters for DynamoDB/S3/Secrets, Validators, Version provider, and DI setup) in idiomatic Nest.

> Install as a library in your services or copy as a bootstrap repo.

## Quick start

```bash
npm i
npm run build
npm run sample
# visit http://localhost:3010/health and /version
```

## Structure
- `src/api/*` — ApiService, HttpRequestBuilder, retry policy, handlers, exceptions, models, auth
- `src/aws/*` — DynamoDB, S3, Secrets, AWS URL provider and exceptions
- `src/logging/*` — LogEntry equivalent, LoggerService with enrichers & Pino sink, Nest module
- `src/http/*` — correlation-id middleware, global exception filter, logging interceptor, idempotency middleware
- `src/validation/*` — Guid and AirEvent* validators
- `src/version/*` — IVersionProvider, VersionService
- `src/setup/*` — `CoreModule.forRoot()` similar to SetupDi* patterns with sensible provider exports
- `samples/app` — small app wiring global middlewares/filters/modules

This is a functional core you can import into any Nest service.
