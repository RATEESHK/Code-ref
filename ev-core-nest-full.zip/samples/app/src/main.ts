import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { Module, Controller, Get } from '@nestjs/common';
import { CoreModule } from '../../../src/setup';
import { AllExceptionsFilter, LoggingInterceptor, CorrelationIdMiddleware } from '../../../src/http';
import { APP_FILTER, APP_INTERCEPTOR } from '@nestjs/core';
import { VersionService } from '../../../src/version';
import { LoggingService } from '../../../src/logging';

@Controller('health')
class HealthController { @Get() ok() { return { ok: true }; } }

@Controller('version')
class VersionController { constructor(private readonly v: VersionService) {} @Get() get() { return { version: this.v.getVersion() }; } }

@Module({
  imports: [CoreModule.forRoot({ serviceName: 'ev-core-sample', serviceVersion: '0.2.0' })],
  controllers: [HealthController, VersionController],
  providers: [
    VersionService,
    { provide: APP_FILTER, useClass: AllExceptionsFilter },
    { provide: APP_INTERCEPTOR, useClass: LoggingInterceptor }
  ]
})
class AppModule {}

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { logger: false });
  app.use(new CorrelationIdMiddleware().use);
  await app.listen(3010);
  const logger = app.get(LoggingService);
  logger.info('sample_started', { message_number: 1 });
}
bootstrap();
