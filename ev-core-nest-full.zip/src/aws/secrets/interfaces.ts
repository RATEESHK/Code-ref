export interface ISecretsProvider {
  getSecret<T=any>(secretId: string): Promise<T>;
}
