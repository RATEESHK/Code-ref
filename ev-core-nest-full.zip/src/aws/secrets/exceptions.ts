export class SecretsProviderException extends Error { constructor(message: string, public code?: string, public status?: number) { super(message); } }
export enum SecretsProviderStatusCode { BadRequest=400, Unauthorized=401, Forbidden=403, NotFound=404, Conflict=409, InternalServerError=500 }
