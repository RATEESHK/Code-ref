import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';
import { ISecretsProvider } from './interfaces';
import { SecretsProviderException } from './exceptions';

const cache: Record<string, any> = {};

export class SecretsProvider implements ISecretsProvider {
  private readonly sm: SecretsManagerClient;
  constructor(cfg?: { region?: string }) {
    this.sm = new SecretsManagerClient({ region: cfg?.region || process.env.AWS_REGION || 'us-east-1' });
  }
  async getSecret<T=any>(secretId: string): Promise<T> {
    if (cache[secretId]) return cache[secretId];
    try {
      const res = await this.sm.send(new GetSecretValueCommand({ SecretId: secretId }));
      const val = res.SecretString ? JSON.parse(res.SecretString) : {};
      cache[secretId] = val;
      return val as T;
    } catch (e:any) { throw new SecretsProviderException(e.message, e.name, e.$metadata?.httpStatusCode); }
  }
}
