export class AwsUrlProvider {
  apiUrl(service: 'apigw'|'apigw2'|'sns'|'sqs'|'s3', region: string) {
    switch(service) {
      case 'apigw': return `https://apigateway.${region}.amazonaws.com`;
      case 'apigw2': return `https://apigateway-v2.${region}.amazonaws.com`;
      case 'sns': return `https://sns.${region}.amazonaws.com`;
      case 'sqs': return `https://sqs.${region}.amazonaws.com`;
      case 's3': return `https://s3.${region}.amazonaws.com`;
    }
  }
}
