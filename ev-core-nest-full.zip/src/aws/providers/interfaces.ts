export interface IAwsUrlProvider { apiUrl(service: 'apigw'|'apigw2'|'sns'|'sqs'|'s3', region: string): string | undefined; }
