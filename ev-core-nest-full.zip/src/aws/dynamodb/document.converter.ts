// Placeholder to mirror EV.Core AwsDocumentConverter responsibilities. Extend as needed.
export class AwsDocumentConverter {
  static toDb<T>(obj: T): Record<string, any> { return obj as any; }
  static fromDb<T>(item: Record<string, any>): T { return item as unknown as T; }
}
