export interface IDynamoDbReaderWriter {
  get<T>(table: string, key: Record<string, any>): Promise<T | null>;
  put<T>(table: string, item: T): Promise<void>;
  query<T>(table: string, keyExpr: string, values: Record<string, any>): Promise<T[]>;
  scan<T>(table: string, limit?: number): Promise<T[]>;
  delete(table: string, key: Record<string, any>): Promise<void>;
  update(table: string, key: Record<string, any>, updateExpr: string, values: Record<string, any>): Promise<void>;
}
