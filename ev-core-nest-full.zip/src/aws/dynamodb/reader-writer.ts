import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand, GetCommand, QueryCommand, DeleteCommand, UpdateCommand, ScanCommand } from '@aws-sdk/lib-dynamodb';
import { IDynamoDbReaderWriter } from './interfaces';
import { DynamoDbDeleteItemException, DynamoDbGetItemException, DynamoDbInternalServerErrorException, DynamoDbPutItemException, DynamoDbQueryException, DynamoDbScanException } from './exceptions';

export class DynamoDbReaderWriter implements IDynamoDbReaderWriter {
  private readonly doc: DynamoDBDocumentClient;
  constructor(cfg?: { region?: string }) {
    const client = new DynamoDBClient({ region: cfg?.region || process.env.AWS_REGION || 'us-east-1' });
    this.doc = DynamoDBDocumentClient.from(client);
  }
  async get<T>(table: string, key: Record<string, any>): Promise<T | null> {
    try { const res = await this.doc.send(new GetCommand({ TableName: table, Key: key })); return (res.Item as T) || null; }
    catch (e:any) { throw new DynamoDbGetItemException(e.message, e.name); }
  }
  async put<T>(table: string, item: T): Promise<void> {
    try { await this.doc.send(new PutCommand({ TableName: table, Item: item as any })); }
    catch (e:any) { throw new DynamoDbPutItemException(e.message, e.name); }
  }
  async query<T>(table: string, keyExpr: string, values: Record<string, any>): Promise<T[]> {
    try { const res = await this.doc.send(new QueryCommand({ TableName: table, KeyConditionExpression: keyExpr, ExpressionAttributeValues: values })); return (res.Items as T[]) || []; }
    catch (e:any) { throw new DynamoDbQueryException(e.message, e.name); }
  }
  async scan<T>(table: string, limit = 100): Promise<T[]> {
    try { const res = await this.doc.send(new ScanCommand({ TableName: table, Limit: limit })); return (res.Items as T[]) || []; }
    catch (e:any) { throw new DynamoDbScanException(e.message, e.name); }
  }
  async delete(table: string, key: Record<string, any>): Promise<void> {
    try { await this.doc.send(new DeleteCommand({ TableName: table, Key: key })); }
    catch (e:any) { throw new DynamoDbDeleteItemException(e.message, e.name); }
  }
  async update(table: string, key: Record<string, any>, updateExpr: string, values: Record<string, any>): Promise<void> {
    try { await this.doc.send(new UpdateCommand({ TableName: table, Key: key, UpdateExpression: updateExpr, ExpressionAttributeValues: values })); }
    catch (e:any) { throw new DynamoDbInternalServerErrorException(e.message, e.name); }
  }
}
