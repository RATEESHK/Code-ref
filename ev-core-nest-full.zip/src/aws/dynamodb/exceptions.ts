export class DynamoDbException extends Error { constructor(message: string, public code?: string) { super(message); } }
export class DynamoDbGetItemException extends DynamoDbException {}
export class DynamoDbPutItemException extends DynamoDbException {}
export class DynamoDbQueryException extends DynamoDbException {}
export class DynamoDbScanException extends DynamoDbException {}
export class DynamoDbDeleteItemException extends DynamoDbException {}
export class DynamoDbInternalServerErrorException extends DynamoDbException {}
