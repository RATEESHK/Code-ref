export class S3Exception extends Error { constructor(message: string, public code?: string, public status?: number) { super(message); } }
export class S3BadResponseException extends S3Exception {}
export class S3CantCommunicateException extends S3Exception {}
export enum S3ExceptionStatusCode { BadRequest=400, Unauthorized=401, Forbidden=403, NotFound=404, Conflict=409, InternalServerError=500 }
