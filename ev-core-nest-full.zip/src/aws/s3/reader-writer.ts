import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { IS3ReaderWriter } from './interfaces';
import { S3BadResponseException, S3CantCommunicateException } from './exceptions';

export class S3ReaderWriter<T=any> implements IS3ReaderWriter<T> {
  private readonly s3: S3Client;
  constructor(cfg?: { region?: string }) {
    this.s3 = new S3Client({ region: cfg?.region || process.env.AWS_REGION || 'us-east-1' });
  }
  async putObject(bucket: string, key: string, body: Buffer | string, contentType?: string): Promise<void> {
    try { await this.s3.send(new PutObjectCommand({ Bucket: bucket, Key: key, Body: body, ContentType: contentType })); }
    catch (e:any) { throw new S3CantCommunicateException(e.message, e.name, e.$metadata?.httpStatusCode); }
  }
  async getObject(bucket: string, key: string): Promise<Buffer> {
    try {
      const res = await this.s3.send(new GetObjectCommand({ Bucket: bucket, Key: key }));
      // @ts-ignore - Body is a stream; bufferify
      const stream = await res.Body?.transformToByteArray?.();
      if (!stream) throw new S3BadResponseException('No body', 'NoBody', res.$metadata?.httpStatusCode);
      return Buffer.from(stream);
    } catch (e:any) { throw new S3CantCommunicateException(e.message, e.name, e.$metadata?.httpStatusCode); }
  }
}
