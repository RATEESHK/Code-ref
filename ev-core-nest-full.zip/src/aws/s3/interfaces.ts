export interface IS3ReaderWriter<T=any> {
  putObject(bucket: string, key: string, body: Buffer | string, contentType?: string): Promise<void>;
  getObject(bucket: string, key: string): Promise<Buffer>;
}
