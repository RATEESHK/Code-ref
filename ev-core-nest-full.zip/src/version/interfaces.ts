export interface IVersionProvider { getVersion(): string; }
