import { IVersionProvider } from './interfaces';
export class VersionService implements IVersionProvider {
  constructor(private readonly version: string = process.env.SERVICE_VERSION || '0.1.0') {}
  getVersion(): string { return this.version; }
}
