export interface AirEvent {
  schema: string;
  data: Record<string, any>;
  timestampUtc?: string;
}

