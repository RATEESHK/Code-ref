export class AirEventUrlValidator {
  static isValid(url: string): boolean {
    try { const u = new URL(url); return !!u.protocol && !!u.host; } catch { return false; }
  }
}
