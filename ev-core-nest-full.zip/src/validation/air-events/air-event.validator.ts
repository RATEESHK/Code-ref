export class AirEventValidator {
  static isValid(evt: any): evt is { schema: string; data: any } {
    if (!evt || typeof evt !== 'object') return false;
    if (typeof evt.schema !== 'string') return false;
    if (typeof evt.data !== 'object') return false;
    return true;
  }
}
