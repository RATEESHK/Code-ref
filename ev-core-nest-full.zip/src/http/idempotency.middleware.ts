import { Injectable, NestMiddleware, BadRequestException } from '@nestjs/common';
import IORedis from 'ioredis';
@Injectable()
export class IdempotencyMiddleware implements NestMiddleware {
  private redis = new IORedis(process.env.REDIS_URL || 'redis://localhost:6379');
  async use(req: any, res: any, next: () => void) {
    if (req.method !== 'POST') return next();
    const key = req.headers['idempotency-key'];
    const tenant = req.headers['x-tenant-id'] || req.headers['x-merchant-id'] || 'default';
    if (!key) throw new BadRequestException('Missing idempotency-key');
    const cacheKey = `idemp:${tenant}:${key}`;
    const exists = await this.redis.set(cacheKey, '1', 'NX', 'EX', 3600);
    if (exists !== 'OK') {
      res.status(409).json({ error: { code: 'idempotency_conflict', message: 'Duplicate idempotency key' } });
      return;
    }
    next();
  }
}
