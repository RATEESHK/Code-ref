import { HttpException, HttpStatus } from '@nestjs/common';
export enum ErrorCode {
  VALIDATION_FAILED = 'validation_failed',
  UNAUTHORIZED = 'unauthorized',
  FORBIDDEN = 'forbidden',
  NOT_FOUND = 'not_found',
  CONFLICT = 'conflict',
  INTERNAL = 'internal',
  DOMAIN = 'domain_invariant',
  IDEMPOTENCY = 'idempotency_conflict'
}
export class DomainException extends HttpException {
  constructor(code: ErrorCode, message: string, status = HttpStatus.BAD_REQUEST, meta?: any) {
    super({ error: { code, message, meta } }, status);
  }
}
