import { ExceptionFilter, Catch, ArgumentsHost, HttpException, HttpStatus } from '@nestjs/common';
import { Response } from 'express';
import { requestContext } from './correlation.context';
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const res = ctx.getResponse<Response>();
    const status = exception instanceof HttpException ? exception.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR;
    const message = exception instanceof HttpException ? exception.message : 'Internal Server Error';
    const rc = requestContext.getStore();
    const body = exception instanceof HttpException ? exception.getResponse() : { error: { code: 'internal', message } };
    res.status(status).json({ correlationId: rc?.correlationId, ...(typeof body === 'string' ? { error: { code: 'error', message: body } } : body) });
  }
}
