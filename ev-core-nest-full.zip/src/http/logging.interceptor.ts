import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable, tap } from 'rxjs';
import { requestContext } from './correlation.context';
import { LoggingService } from '../logging';
@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  constructor(private readonly logger: LoggingService) {}
  intercept(ctx: ExecutionContext, next: CallHandler): Observable<any> {
    const http = ctx.switchToHttp();
    const req = http.getRequest();
    const { method, url } = req;
    const rc = requestContext.getStore();
    const correlationId = rc?.correlationId || req.correlationId;
    const start = Date.now();
    return next.handle().pipe(
      tap({
        next: () => this.logger.info('request_ok', { correlation_id: correlationId, method_name: `${method} ${url}`, method_arguments: { ms: Date.now()-start } }),
        error: (e) => this.logger.error('request_error', { correlation_id: correlationId, method_name: `${method} ${url}`, method_arguments: { ms: Date.now()-start }, exception: { name: e?.name, message: e?.message, stack: e?.stack } })
      })
    );
  }
}
