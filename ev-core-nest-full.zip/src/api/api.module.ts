import { DynamicModule, Module } from '@nestjs/common';
import { ApiService } from './api.service';
@Module({})
export class ApiModule {
  static forRoot(): DynamicModule {
    return { module: ApiModule, providers: [ApiService], exports: [ApiService] };
  }
}
