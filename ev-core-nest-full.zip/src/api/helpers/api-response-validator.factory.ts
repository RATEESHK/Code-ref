export type ResponseValidator = (status: number, data: any) => boolean;
export const ApiResponseValidatorFactory = {
  jsonOk: (): ResponseValidator => (status, data) => status >= 200 && status < 300 && data !== undefined,
};
