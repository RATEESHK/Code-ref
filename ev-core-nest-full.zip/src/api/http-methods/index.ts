export type HttpVerb = 'GET'|'POST'|'PUT'|'PATCH'|'DELETE';
export const Get: HttpVerb = 'GET';
export const Post: HttpVerb = 'POST';
export const Put: HttpVerb = 'PUT';
export const Patch: HttpVerb = 'PATCH';
export const Delete: HttpVerb = 'DELETE';
