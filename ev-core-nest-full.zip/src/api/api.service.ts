import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import axiosRetry from 'axios-retry';
import { requestContext } from '../http/correlation.context';
import { buildRetryPolicy } from './builders/retry-policy.builder';
import { IApiAuthProvider } from './interfaces';

export class ApiService<TConnector=any> {
  private readonly client: AxiosInstance;
  private preCall?: (req: AxiosRequestConfig) => Promise<void>;
  private postSuccess?: (status:number, data:any) => Promise<void>;
  private postFailure?: (status:number, data:any) => Promise<void>;
  private auth?: IApiAuthProvider;

  constructor(client?: AxiosInstance) {
    this.client = client ?? axios.create({ timeout: 30000 });
    axiosRetry(this.client, buildRetryPolicy());
  }

  withAuth(provider: IApiAuthProvider): this { this.auth = provider; return this; }
  onPreCall(handler: (req: AxiosRequestConfig) => Promise<void>): this { this.preCall = handler; return this; }
  onSuccess(handler: (status:number, data:any) => Promise<void>): this { this.postSuccess = handler; return this; }
  onFailure(handler: (status:number, data:any) => Promise<void>): this { this.postFailure = handler; return this; }

  private async withCorrelation(cfg: AxiosRequestConfig) {
    const rc = requestContext.getStore();
    const headers = { 'x-correlation-id': rc?.correlationId, ...(cfg.headers || {}) };
    return { ...cfg, headers };
  }

  async request<T=any>(cfg: AxiosRequestConfig): Promise<T> {
    const prepared = await this.withCorrelation(cfg);
    if (this.auth) await this.auth.configureRequest(prepared);
    if (this.preCall) await this.preCall(prepared);
    try {
      const res = await this.client.request(prepared);
      if (this.postSuccess) await this.postSuccess(res.status, res.data);
      return res.data as T;
    } catch (e:any) {
      const status = e?.response?.status ?? 0;
      const data = e?.response?.data;
      if (this.postFailure) await this.postFailure(status, data);
      throw e;
    }
  }
}
