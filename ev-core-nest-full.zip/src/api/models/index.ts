export interface ApiAuthData { token?: string; expiresAt?: string; headers?: Record<string,string>; }
export interface ApiOAuthConnector { tokenEndpoint: string; clientId: string; clientSecret: string; scope?: string; }
export interface ApiRequestOptions { timeoutMs?: number; baseUrl?: string; headers?: Record<string,string>; }
export interface AzureAdToken { token_type: string; scope?: string; expires_in: number; ext_expires_in?: number; access_token: string; }
