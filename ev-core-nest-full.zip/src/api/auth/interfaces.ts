export interface IApiGwSettings { baseUrl: string; apiKey?: string; tenantId?: string; }
export interface IApiGatewayAuthSettings {
  assetManagement?: IApiGwSettings;
  billing?: IApiGwSettings;
  cpo?: IApiGwSettings;
  customerManagement?: IApiGwSettings;
  ocpi?: IApiGwSettings;
  shared?: IApiGwSettings;
}
