import { AxiosRequestConfig } from 'axios';
import { IApiAuthProvider } from '../interfaces';
import { IApiGatewayAuthSettings } from './interfaces';

export class ApiGatewayAuthProvider implements IApiAuthProvider {
  constructor(private readonly settings: IApiGatewayAuthSettings, private readonly service: keyof IApiGatewayAuthSettings = 'shared') {}
  async configureRequest(cfg: AxiosRequestConfig): Promise<void> {
    const s: any = (this.settings as any)[this.service] || (this.settings as any).shared;
    if (!s) return;
    cfg.baseURL = s.baseUrl || cfg.baseURL;
    cfg.headers = { ...(cfg.headers||{}), 'x-api-key': s.apiKey || '', 'x-tenant-id': s.tenantId || '' };
  }
}
