import { IApiGwSettings, IApiGatewayAuthSettings } from './interfaces';
export class ApiGwSettings implements IApiGwSettings { constructor(public baseUrl: string, public apiKey?: string, public tenantId?: string) {} }
export class ApiGwSharedSettings extends ApiGwSettings {}
export class ApiGwAssetManagementSettings extends ApiGwSettings {}
export class ApiGwBillingSettings extends ApiGwSettings {}
export class ApiGwCpoSettings extends ApiGwSettings {}
export class ApiGwCustomerManagementSettings extends ApiGwSettings {}
export class ApiGwOcpiSettings extends ApiGwSettings {}
export class ApiGatewayAuthSettings implements IApiGatewayAuthSettings {
  constructor(public shared?: IApiGwSettings, public assetManagement?: IApiGwSettings, public billing?: IApiGwSettings, public cpo?: IApiGwSettings, public customerManagement?: IApiGwSettings, public ocpi?: IApiGwSettings) {}
}
