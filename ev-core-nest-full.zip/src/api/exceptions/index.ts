export class ApiServiceException extends Error { constructor(message: string, public status?: number, public body?: any) { super(message); } }
export class ApiAuthorisationException extends ApiServiceException {}
export class ApiServiceBadRequestException extends ApiServiceException {}
export class ApiServiceUnauthorisedException extends ApiServiceException {}
export class ApiServiceForbiddenException extends ApiServiceException {}
export class ApiServiceNotFoundException extends ApiServiceException {}
export class ApiServiceConflictException extends ApiServiceException {}
export class ApiServiceInternalServerErrorException extends ApiServiceException {}
export enum ApiServiceExceptionStatusCode { BadRequest=400, Unauthorized=401, Forbidden=403, NotFound=404, Conflict=409, InternalServerError=500 }
