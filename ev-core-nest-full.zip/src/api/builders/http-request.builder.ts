export interface HttpRequestParts {
  baseUrl?: string;
  path?: string;
  headers?: Record<string, string>;
  query?: Record<string, string | number | boolean | undefined>;
  body?: any;
  method?: 'GET'|'POST'|'PUT'|'PATCH'|'DELETE';
}

export class HttpRequestBuilder {
  private parts: HttpRequestParts = { method: 'GET', headers: {}, query: {} };
  baseUrl(url: string) { this.parts.baseUrl = url; return this; }
  path(p: string) { this.parts.path = p; return this; }
  header(k: string, v: string) { this.parts.headers = { ...(this.parts.headers||{}), [k]: v }; return this; }
  query(k: string, v: any) { this.parts.query = { ...(this.parts.query||{}), [k]: v }; return this; }
  method(m: HttpRequestParts['method']) { this.parts.method = m; return this; }
  body(b: any) { this.parts.body = b; return this; }
  build() {
    const query = Object.entries(this.parts.query || {}).filter(([,v]) => v !== undefined).map(([k,v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`).join('&');
    const url = `${this.parts.baseUrl || ''}${this.parts.path || ''}${query ? `?${query}` : ''}`;
    return { method: this.parts.method, url, headers: this.parts.headers, data: this.parts.body };
  }
}
