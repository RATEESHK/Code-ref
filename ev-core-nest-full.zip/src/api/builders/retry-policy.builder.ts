import { IAxiosRetryConfig } from 'axios-retry';
export function buildRetryPolicy(): IAxiosRetryConfig {
  return {
    retries: 3,
    retryDelay: (c) => Math.min(1000 * Math.pow(2, c), 4000),
    retryCondition: (error) => {
      const status = error.response?.status;
      return !status || (status >= 500 && status < 600);
    }
  }
}
