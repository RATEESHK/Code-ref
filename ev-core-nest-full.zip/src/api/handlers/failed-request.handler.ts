export type FailedRequestHandler = (status:number, data:any) => Promise<void>;
