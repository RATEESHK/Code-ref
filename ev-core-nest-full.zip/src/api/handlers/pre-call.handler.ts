import { AxiosRequestConfig } from 'axios';
export type PreCallHandler = (req: AxiosRequestConfig) => Promise<void>;
