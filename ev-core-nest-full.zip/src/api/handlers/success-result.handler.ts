export type SuccessResultHandler = (status:number, data:any) => Promise<void>;
