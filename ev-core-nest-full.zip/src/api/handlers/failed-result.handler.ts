export type FailedResultHandler = (status:number, data:any) => Promise<void>;
