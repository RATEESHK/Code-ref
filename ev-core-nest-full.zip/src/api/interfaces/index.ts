import { AxiosRequestConfig } from 'axios';
export interface IApiAuthProvider { configureRequest(cfg: AxiosRequestConfig): Promise<void>; }
export interface IApiService<T=any> { request<T=any>(cfg: AxiosRequestConfig): Promise<T>; }
export interface IHttpConnector {} // placeholder to mirror interface
export interface IRetryPolicyBuilder {} // policy provided via axios-retry
export interface IPreCallHandler { (req: AxiosRequestConfig): Promise<void> }
export interface ISuccessResultHandler { (status:number, data:any): Promise<void> }
export interface IFailedRequestHandler { (status:number, data:any): Promise<void> }
export interface IFailedResultHandler { (status:number, data:any): Promise<void> }
