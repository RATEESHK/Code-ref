import { DynamicModule, Module } from '@nestjs/common';
import { LoggingService, LoggerOptions } from './logging.service';

@Module({})
export class LoggingModule {
  static forRoot(opts: LoggerOptions): DynamicModule {
    const provider = { provide: LoggingService, useFactory: () => new LoggingService(opts) };
    return { module: LoggingModule, providers: [provider], exports: [LoggingService] };
  }
}
