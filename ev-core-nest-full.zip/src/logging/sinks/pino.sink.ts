import pino from 'pino';
import { LogEntry } from '../log.entry';

const logger = pino({ level: 'trace', transport: process.env.NODE_ENV === 'development' ? { target: 'pino-pretty', options: { colorize: true } } : undefined });

export class PinoSink {
  write(entry: LogEntry) {
    const method = entry.level ?? 'info';
    (logger as any)[method](entry, entry.message ?? '');
  }
}
