export interface LogEntry {
  instrumentation_datetime_utc: string;
  environment?: string;
  application_name?: string;
  application_version?: string;
  container_name?: string;
  method_name?: string;
  method_arguments?: Record<string, unknown>;
  correlation_id?: string;
  message_number?: number;
  message?: string;
  exception?: { name: string; message: string; stack?: string; code?: string };
  level?: 'trace'|'debug'|'info'|'warn'|'error'|'fatal';
  tags?: string[];
}
