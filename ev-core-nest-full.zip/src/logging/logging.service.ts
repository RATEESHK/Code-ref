import { Injectable } from '@nestjs/common';
import { LogEntry } from './log.entry';
import { PinoSink } from './sinks/pino.sink';
import { CorrelationEnricher } from './enrichers/correlation.enricher';
import { OtelIdsEnricher } from './enrichers/otel.enricher';

export interface LoggerOptions {
  application_name: string;
  application_version: string;
  environment?: string;
  minLevel?: 'trace'|'debug'|'info'|'warn'|'error'|'fatal';
}

const order = ['trace','debug','info','warn','error','fatal'] as const;

@Injectable()
export class LoggingService<T=any> {
  constructor(
    private readonly opts: LoggerOptions,
    private readonly sink = new PinoSink(),
    private readonly enrichers = [new CorrelationEnricher(), new OtelIdsEnricher()]
  ) {}

  private emit(level: LogEntry['level'], entry: Omit<LogEntry,'instrumentation_datetime_utc'|'level'>) {
    const log: LogEntry = {
      instrumentation_datetime_utc: new Date().toISOString(),
      level,
      ...entry
    };
    const enriched = this.enrichers.reduce((acc,e)=>e.enrich(acc), log);
    this.sink.write(enriched);
  }

  info(message: string, extra: Partial<LogEntry> = {}) {
    this.emit('info', { application_name: this.opts.application_name, application_version: this.opts.application_version, environment: this.opts.environment, message, ...extra });
  }
  error(message: string, extra: Partial<LogEntry> = {}) {
    this.emit('error', { application_name: this.opts.application_name, application_version: this.opts.application_version, environment: this.opts.environment, message, ...extra });
  }
  warn(message: string, extra: Partial<LogEntry> = {}) { this.emit('warn', { ...extra, application_name: this.opts.application_name, application_version: this.opts.application_version, environment: this.opts.environment, message }); }
  debug(message: string, extra: Partial<LogEntry> = {}) { this.emit('debug', { ...extra, application_name: this.opts.application_name, application_version: this.opts.application_version, environment: this.opts.environment, message }); }
  trace(message: string, extra: Partial<LogEntry> = {}) { this.emit('trace', { ...extra, application_name: this.opts.application_name, application_version: this.opts.application_version, environment: this.opts.environment, message }); }
  fatal(message: string, extra: Partial<LogEntry> = {}) { this.emit('fatal', { ...extra, application_name: this.opts.application_name, application_version: this.opts.application_version, environment: this.opts.environment, message }); }
}
