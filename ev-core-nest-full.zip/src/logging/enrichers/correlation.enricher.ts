import { LogEntry } from '../log.entry';
import { requestContext } from '../../http/correlation.context';
export class CorrelationEnricher {
  enrich(entry: LogEntry): LogEntry {
    const rc = requestContext.getStore();
    return { correlation_id: rc?.correlationId || entry.correlation_id, ...entry };
  }
}
