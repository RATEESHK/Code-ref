import { context, trace } from '@opentelemetry/api';
import { LogEntry } from '../log.entry';
export class OtelIdsEnricher {
  enrich(entry: LogEntry): LogEntry {
    const span = trace.getSpan(context.active());
    const sc = span?.spanContext();
    if (!sc) return entry;
    return { ...entry, tags: [...(entry.tags||[]), `trace:${sc.traceId}`, `span:${sc.spanId}`] };
  }
}
