import { DynamicModule, Module } from '@nestjs/common';
import { LoggingModule, LoggingService } from '../logging';
import { ApiModule, ApiService } from '../api';

export interface CoreOptions {
  serviceName: string;
  serviceVersion: string;
  environment?: string;
}

@Module({})
export class CoreModule {
  static forRoot(opts: CoreOptions): DynamicModule {
    return {
      module: CoreModule,
      imports: [LoggingModule.forRoot({ application_name: opts.serviceName, application_version: opts.serviceVersion, environment: opts.environment }) , ApiModule.forRoot()],
      exports: [LoggingModule, ApiModule, LoggingService, ApiService]
    };
  }
}
