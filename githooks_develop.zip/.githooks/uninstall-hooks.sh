#!/usr/bin/env bash
# Git Hooks Uninstaller
# Removes hooks and restores original configuration
# Version: 2.0.0

set -euo pipefail

# Colors
readonly COLOR_RESET='\033[0m'
readonly COLOR_GREEN='\033[0;32m'
readonly COLOR_YELLOW='\033[0;33m'
readonly COLOR_RED='\033[0;31m'
readonly COLOR_CYAN='\033[0;36m'
readonly COLOR_BOLD='\033[1m'

# Emoji
readonly EMOJI_SUCCESS="✓"
readonly EMOJI_WARNING="⚠"
readonly EMOJI_INFO="ℹ"

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GIT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo ""
echo -e "${COLOR_YELLOW}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo -e "${COLOR_YELLOW}${COLOR_BOLD}  Git Hooks Uninstallation${COLOR_RESET}"
echo -e "${COLOR_YELLOW}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo ""

# ==============================================================================
# CONFIRMATION PROMPT
# ==============================================================================

echo -e "${COLOR_YELLOW}${EMOJI_WARNING} This will remove all hook configurations and archive logs.${COLOR_RESET}"
echo ""
read -p "Are you sure you want to uninstall? (y/N): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${COLOR_CYAN}${EMOJI_INFO} Uninstallation cancelled.${COLOR_RESET}"
    exit 0
fi

echo ""

# ==============================================================================
# ARCHIVE LOGS
# ==============================================================================

LOG_DIR="$GIT_ROOT/.git/hook-logs"

if [[ -d "$LOG_DIR" ]]; then
    echo -e "${COLOR_CYAN}${EMOJI_INFO} Archiving logs...${COLOR_RESET}"
    
    ARCHIVE_NAME="hook-logs-$(date +%Y%m%d-%H%M%S).tar.gz"
    ARCHIVE_PATH="$GIT_ROOT/.git/$ARCHIVE_NAME"
    
    if tar -czf "$ARCHIVE_PATH" -C "$GIT_ROOT/.git" hook-logs 2>/dev/null; then
        echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Logs archived to: $ARCHIVE_PATH${COLOR_RESET}"
    else
        echo -e "${COLOR_YELLOW}${EMOJI_WARNING} Could not archive logs (continuing anyway)${COLOR_RESET}"
    fi
    
    # Remove log directory
    rm -rf "$LOG_DIR"
    echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Log directory removed${COLOR_RESET}"
else
    echo -e "${COLOR_CYAN}${EMOJI_INFO} No logs to archive${COLOR_RESET}"
fi

# ==============================================================================
# RESTORE GIT CONFIGURATION
# ==============================================================================

echo ""
echo -e "${COLOR_CYAN}${EMOJI_INFO} Restoring Git configuration...${COLOR_RESET}"

# Unset hooks path (restore default)
git config --unset core.hooksPath 2>/dev/null || true
echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Restored default hooks path${COLOR_RESET}"

# Optionally remove other configurations (keeping them for now)
# git config --unset rebase.autosquash 2>/dev/null || true
# git config --unset fetch.prune 2>/dev/null || true

# Remove hook-specific configurations
git config --remove-section hooks 2>/dev/null || true
echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Removed hook configurations${COLOR_RESET}"

# ==============================================================================
# CLEANUP
# ==============================================================================

echo ""
echo -e "${COLOR_CYAN}${EMOJI_INFO} Cleaning up...${COLOR_RESET}"

# Remove hook-logs from git exclude
EXCLUDE_FILE="$GIT_ROOT/.git/info/exclude"
if [[ -f "$EXCLUDE_FILE" ]]; then
    sed -i.bak '/hook-logs/d' "$EXCLUDE_FILE" 2>/dev/null || \
    sed -i '' '/hook-logs/d' "$EXCLUDE_FILE" 2>/dev/null || true
    rm -f "${EXCLUDE_FILE}.bak" 2>/dev/null || true
    echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Cleaned up .git/info/exclude${COLOR_RESET}"
fi

# ==============================================================================
# SUMMARY
# ==============================================================================

echo ""
echo -e "${COLOR_GREEN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo -e "${COLOR_GREEN}${COLOR_BOLD}  Uninstallation Complete${COLOR_RESET}"
echo -e "${COLOR_GREEN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo ""
echo -e "${COLOR_CYAN}${EMOJI_INFO} The following were removed:${COLOR_RESET}"
echo -e "  - Hooks path configuration"
echo -e "  - Hook-specific configurations"
echo -e "  - Log directory (archived)"
echo ""
echo -e "${COLOR_CYAN}${EMOJI_INFO} The following were preserved:${COLOR_RESET}"
echo -e "  - Hook files in .githooks/"
echo -e "  - rebase.autosquash setting"
echo -e "  - fetch.prune setting"
echo ""
echo -e "${COLOR_CYAN}${EMOJI_INFO} To reinstall:${COLOR_RESET}"
echo -e "  .githooks/install-hooks.sh"
echo ""

exit 0
