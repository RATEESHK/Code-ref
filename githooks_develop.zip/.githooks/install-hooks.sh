#!/usr/bin/env bash
# Git Hooks Installer
# Sets up all hooks with proper configuration
# Version: 2.0.0

set -euo pipefail

# Colors
readonly COLOR_RESET='\033[0m'
readonly COLOR_GREEN='\033[0;32m'
readonly COLOR_YELLOW='\033[0;33m'
readonly COLOR_CYAN='\033[0;36m'
readonly COLOR_BOLD='\033[1m'

# Emoji
readonly EMOJI_SUCCESS="✓"
readonly EMOJI_INFO="ℹ"
readonly EMOJI_ROCKET="🚀"

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GIT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo ""
echo -e "${COLOR_CYAN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo -e "${COLOR_CYAN}${COLOR_BOLD}  Git Hooks Installation${COLOR_RESET}"
echo -e "${COLOR_CYAN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo ""

# ==============================================================================
# CHECK PREREQUISITES
# ==============================================================================

echo -e "${COLOR_CYAN}${EMOJI_INFO} Checking prerequisites...${COLOR_RESET}"

if ! git rev-parse --git-dir >/dev/null 2>&1; then
    echo -e "${COLOR_YELLOW}ERROR: Not in a git repository${COLOR_RESET}"
    exit 1
fi

echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Git repository found${COLOR_RESET}"

# ==============================================================================
# CONFIGURE GIT
# ==============================================================================

echo ""
echo -e "${COLOR_CYAN}${EMOJI_INFO} Configuring Git...${COLOR_RESET}"

# Set hooks path
git config core.hooksPath .githooks
echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Set core.hooksPath to .githooks${COLOR_RESET}"

# Enable autosquash for interactive rebases
git config rebase.autosquash true
echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Enabled rebase.autosquash${COLOR_RESET}"

# Enable automatic pruning of deleted remote branches
git config fetch.prune true
echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Enabled fetch.prune${COLOR_RESET}"

# Set default log level if not already set
if ! git config hooks.logLevel >/dev/null 2>&1; then
    git config hooks.logLevel 6  # INFO level
    echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Set hooks.logLevel to 6 (INFO)${COLOR_RESET}"
fi

# Set max commits if not already set
if ! git config hooks.maxCommits >/dev/null 2>&1; then
    git config hooks.maxCommits 5
    echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Set hooks.maxCommits to 5${COLOR_RESET}"
fi

# Set auto-add after fix if not already set
if ! git config hooks.autoAddAfterFix >/dev/null 2>&1; then
    git config hooks.autoAddAfterFix false
    echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Set hooks.autoAddAfterFix to false${COLOR_RESET}"
fi

# Set parallel execution if not already set
if ! git config hooks.parallelExecution >/dev/null 2>&1; then
    git config hooks.parallelExecution false
    echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Set hooks.parallelExecution to false${COLOR_RESET}"
fi

# Set default branch if not already set
if ! git config hooks.defaultBranch >/dev/null 2>&1; then
    if git rev-parse --verify origin/main >/dev/null 2>&1; then
        git config hooks.defaultBranch main
        echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Set hooks.defaultBranch to main${COLOR_RESET}"
    elif git rev-parse --verify origin/master >/dev/null 2>&1; then
        git config hooks.defaultBranch master
        echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Set hooks.defaultBranch to master${COLOR_RESET}"
    else
        git config hooks.defaultBranch main
        echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Set hooks.defaultBranch to main (default)${COLOR_RESET}"
    fi
fi

# ==============================================================================
# MAKE HOOKS EXECUTABLE
# ==============================================================================

echo ""
echo -e "${COLOR_CYAN}${EMOJI_INFO} Making hooks executable...${COLOR_RESET}"

chmod +x "$SCRIPT_DIR"/* 2>/dev/null || true
chmod +x "$SCRIPT_DIR"/lib/* 2>/dev/null || true

echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} All hooks are now executable${COLOR_RESET}"

# ==============================================================================
# CREATE LOG DIRECTORY
# ==============================================================================

echo ""
echo -e "${COLOR_CYAN}${EMOJI_INFO} Setting up logging...${COLOR_RESET}"

LOG_DIR="$GIT_ROOT/.git/hook-logs"
mkdir -p "$LOG_DIR" 2>/dev/null || true

echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Log directory created: $LOG_DIR${COLOR_RESET}"

# Add logs to git exclude
EXCLUDE_FILE="$GIT_ROOT/.git/info/exclude"
if ! grep -q "hook-logs" "$EXCLUDE_FILE" 2>/dev/null; then
    echo "hook-logs/" >> "$EXCLUDE_FILE"
    echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Added hook-logs to .git/info/exclude${COLOR_RESET}"
fi

# ==============================================================================
# CREATE SAMPLE COMMANDS.CONF
# ==============================================================================

echo ""
echo -e "${COLOR_CYAN}${EMOJI_INFO} Setting up commands configuration...${COLOR_RESET}"

COMMANDS_CONF="$SCRIPT_DIR/commands.conf"
if [[ ! -f "$COMMANDS_CONF" ]]; then
    cat > "$COMMANDS_CONF" << 'EOF'
# Git Hooks Custom Commands Configuration
# Format: HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
#
# HOOK        - Hook name (pre-commit, commit-msg, pre-push)
# PRIORITY    - Execution order (lower numbers run first)
# MANDATORY   - true/false (if true, failure blocks commit/push)
# TIMEOUT     - Maximum execution time in seconds
# COMMAND     - Shell command to execute
# DESCRIPTION - Human-readable description
#
# Placeholders:
#   {staged}  - Replaced with list of staged files
#
# Examples:
#
# Node.js/TypeScript Project:
# pre-commit:1:true:30:npx lint-staged:Lint staged files
# pre-commit:2:false:60:npx tsc --noEmit --skipLibCheck:Type checking
# pre-commit:3:true:30:npm run lint:fix:Auto-fix linting
# pre-push:1:true:300:npm test:Run test suite
# pre-push:2:false:600:npm run build:Build project
#
# Python Project:
# pre-commit:1:true:30:black {staged}:Format Python files
# pre-commit:2:true:30:flake8 {staged}:Lint Python files
# pre-commit:3:false:60:mypy {staged}:Type checking
# pre-push:1:true:300:pytest:Run tests
#
# Add your custom commands below:
EOF
    echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Created sample commands.conf${COLOR_RESET}"
else
    echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} commands.conf already exists${COLOR_RESET}"
fi

# ==============================================================================
# DISPLAY CONFIGURATION SUMMARY
# ==============================================================================

echo ""
echo -e "${COLOR_CYAN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo -e "${COLOR_CYAN}${COLOR_BOLD}  Configuration Summary${COLOR_RESET}"
echo -e "${COLOR_CYAN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo ""
echo -e "${COLOR_BOLD}Git Configuration:${COLOR_RESET}"
echo -e "  core.hooksPath       = $(git config core.hooksPath)"
echo -e "  rebase.autosquash    = $(git config rebase.autosquash)"
echo -e "  fetch.prune          = $(git config fetch.prune)"
echo ""
echo -e "${COLOR_BOLD}Hook Configuration:${COLOR_RESET}"
echo -e "  hooks.logLevel       = $(git config hooks.logLevel) (0=EMERGENCY, 6=INFO, 8=TRACE)"
echo -e "  hooks.maxCommits     = $(git config hooks.maxCommits)"
echo -e "  hooks.defaultBranch  = $(git config hooks.defaultBranch)"
echo -e "  hooks.autoAddAfterFix = $(git config hooks.autoAddAfterFix)"
echo -e "  hooks.parallelExecution = $(git config hooks.parallelExecution)"
echo ""
echo -e "${COLOR_BOLD}Directories:${COLOR_RESET}"
echo -e "  Hooks directory      = $SCRIPT_DIR"
echo -e "  Log directory        = $LOG_DIR"
echo ""

# ==============================================================================
# DISPLAY ACTIVE HOOKS
# ==============================================================================

echo -e "${COLOR_BOLD}Active Hooks:${COLOR_RESET}"
for hook in pre-commit prepare-commit-msg commit-msg applypatch-msg pre-push pre-rebase post-rewrite post-checkout; do
    if [[ -f "$SCRIPT_DIR/$hook" ]]; then
        echo -e "  ${COLOR_GREEN}${EMOJI_SUCCESS}${COLOR_RESET} $hook"
    fi
done
echo ""

# ==============================================================================
# DISPLAY TEST COMMANDS
# ==============================================================================

echo -e "${COLOR_CYAN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo -e "${COLOR_CYAN}${COLOR_BOLD}  Testing & Usage${COLOR_RESET}"
echo -e "${COLOR_CYAN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo ""
echo -e "${COLOR_BOLD}Test the installation:${COLOR_RESET}"
echo -e "  ${COLOR_CYAN}# Create a test branch${COLOR_RESET}"
echo -e "  git checkout -b feat-TEST-123-test-hooks"
echo ""
echo -e "  ${COLOR_CYAN}# Make a test commit${COLOR_RESET}"
echo -e "  echo 'test' > test.txt"
echo -e "  git add test.txt"
echo -e "  git commit -m 'feat: TEST-123 Test hooks'"
echo ""
echo -e "${COLOR_BOLD}Configure custom commands:${COLOR_RESET}"
echo -e "  Edit .githooks/commands.conf and add your commands"
echo ""
echo -e "${COLOR_BOLD}Adjust configuration:${COLOR_RESET}"
echo -e "  git config hooks.maxCommits <number>       # Change commit limit"
echo -e "  git config hooks.logLevel <0-8>            # Change log verbosity"
echo -e "  git config hooks.autoAddAfterFix true      # Enable auto-restaging"
echo -e "  git config hooks.parallelExecution true    # Enable parallel commands"
echo ""
echo -e "${COLOR_BOLD}Bypass hooks (emergency only):${COLOR_RESET}"
echo -e "  BYPASS_HOOKS=1 git commit                  # Bypass all hooks"
echo -e "  ALLOW_DIRECT_PROTECTED=1 git commit        # Allow protected branch commits"
echo ""
echo -e "${COLOR_BOLD}View logs:${COLOR_RESET}"
echo -e "  tail -f .git/hook-logs/complete.log        # All hooks"
echo -e "  tail -f .git/hook-logs/pre-commit.log      # Specific hook"
echo ""
echo -e "${COLOR_BOLD}Clean old logs:${COLOR_RESET}"
echo -e "  .githooks/clean.sh                         # Clean logs older than 21 days"
echo ""
echo -e "${COLOR_BOLD}Uninstall:${COLOR_RESET}"
echo -e "  .githooks/uninstall-hooks.sh               # Remove hooks and configuration"
echo ""

# ==============================================================================
# SUCCESS MESSAGE
# ==============================================================================

echo -e "${COLOR_GREEN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo -e "${COLOR_GREEN}${COLOR_BOLD}${EMOJI_ROCKET} Installation Complete!${COLOR_RESET}"
echo -e "${COLOR_GREEN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo ""
echo -e "${COLOR_GREEN}Git hooks are now active and will run automatically.${COLOR_RESET}"
echo ""

exit 0
