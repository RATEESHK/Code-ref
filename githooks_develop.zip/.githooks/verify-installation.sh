#!/usr/bin/env bash
# Git Hooks Verification Script
# Validates that all components are correctly installed and working
# Version: 2.0.0

set -euo pipefail

# Colors
readonly COLOR_RESET='\033[0m'
readonly COLOR_GREEN='\033[0;32m'
readonly COLOR_RED='\033[0;31m'
readonly COLOR_YELLOW='\033[0;33m'
readonly COLOR_CYAN='\033[0;36m'
readonly COLOR_BOLD='\033[1m'

# Emoji
readonly EMOJI_SUCCESS="✓"
readonly EMOJI_ERROR="✗"
readonly EMOJI_WARNING="⚠"
readonly EMOJI_INFO="ℹ"

# Test counters
CHECKS_RUN=0
CHECKS_PASSED=0
CHECKS_FAILED=0
CHECKS_WARNING=0

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GIT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo ""
echo -e "${COLOR_CYAN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo -e "${COLOR_CYAN}${COLOR_BOLD}  Git Hooks Verification${COLOR_RESET}"
echo -e "${COLOR_CYAN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo ""

# ==============================================================================
# CHECK FUNCTIONS
# ==============================================================================

check_pass() {
    ((CHECKS_RUN++))
    ((CHECKS_PASSED++))
    echo -e "${COLOR_GREEN}  ${EMOJI_SUCCESS} PASS${COLOR_RESET}"
}

check_fail() {
    ((CHECKS_RUN++))
    ((CHECKS_FAILED++))
    echo -e "${COLOR_RED}  ${EMOJI_ERROR} FAIL${COLOR_RESET}"
    if [[ -n "${1:-}" ]]; then
        echo -e "${COLOR_RED}     $1${COLOR_RESET}"
    fi
}

check_warning() {
    ((CHECKS_RUN++))
    ((CHECKS_WARNING++))
    echo -e "${COLOR_YELLOW}  ${EMOJI_WARNING} WARNING${COLOR_RESET}"
    if [[ -n "${1:-}" ]]; then
        echo -e "${COLOR_YELLOW}     $1${COLOR_RESET}"
    fi
}

# ==============================================================================
# VERIFICATION CHECKS
# ==============================================================================

echo -e "${COLOR_CYAN}${COLOR_BOLD}Repository Information${COLOR_RESET}"
echo -e "  Location: $GIT_ROOT"
echo ""

# Check 1: Git repository
echo -e "${COLOR_CYAN}${EMOJI_INFO} Checking git repository...${COLOR_RESET}"
if git -C "$GIT_ROOT" rev-parse --git-dir >/dev/null 2>&1; then
    check_pass
else
    check_fail "Not a git repository"
fi

# Check 2: Hooks path configuration
echo -e "${COLOR_CYAN}${EMOJI_INFO} Checking hooks path configuration...${COLOR_RESET}"
HOOKS_PATH=$(git -C "$GIT_ROOT" config core.hooksPath 2>/dev/null || echo "")
if [[ "$HOOKS_PATH" == ".githooks" ]]; then
    check_pass
else
    check_fail "core.hooksPath is not set to .githooks (current: '$HOOKS_PATH')"
fi

# Check 3: Required files exist
echo -e "${COLOR_CYAN}${EMOJI_INFO} Checking required files...${COLOR_RESET}"
REQUIRED_FILES=(
    "lib/common.sh"
    "lib/runner.sh"
    "pre-commit"
    "prepare-commit-msg"
    "commit-msg"
    "applypatch-msg"
    "pre-push"
    "pre-rebase"
    "post-rewrite"
    "post-checkout"
    "install-hooks.sh"
    "uninstall-hooks.sh"
    "clean.sh"
)

ALL_FILES_EXIST=true
for file in "${REQUIRED_FILES[@]}"; do
    if [[ ! -f "$SCRIPT_DIR/$file" ]]; then
        ALL_FILES_EXIST=false
        echo -e "${COLOR_RED}     Missing: $file${COLOR_RESET}"
    fi
done

if [[ "$ALL_FILES_EXIST" == "true" ]]; then
    check_pass
else
    check_fail "Some required files are missing"
fi

# Check 4: Files are executable
echo -e "${COLOR_CYAN}${EMOJI_INFO} Checking file permissions...${COLOR_RESET}"
ALL_EXECUTABLE=true
for file in "${REQUIRED_FILES[@]}"; do
    if [[ -f "$SCRIPT_DIR/$file" ]] && [[ ! -x "$SCRIPT_DIR/$file" ]]; then
        ALL_EXECUTABLE=false
        echo -e "${COLOR_YELLOW}     Not executable: $file${COLOR_RESET}"
    fi
done

if [[ "$ALL_EXECUTABLE" == "true" ]]; then
    check_pass
else
    check_warning "Some files are not executable (may work on Windows)"
fi

# Check 5: Log directory exists
echo -e "${COLOR_CYAN}${EMOJI_INFO} Checking log directory...${COLOR_RESET}"
LOG_DIR="$GIT_ROOT/.git/hook-logs"
if [[ -d "$LOG_DIR" ]]; then
    check_pass
else
    check_fail "Log directory does not exist: $LOG_DIR"
fi

# Check 6: Git configuration
echo -e "${COLOR_CYAN}${EMOJI_INFO} Checking git configuration...${COLOR_RESET}"
CONFIG_OK=true

# Check maxCommits
MAX_COMMITS=$(git -C "$GIT_ROOT" config hooks.maxCommits 2>/dev/null || echo "")
if [[ -z "$MAX_COMMITS" ]]; then
    echo -e "${COLOR_YELLOW}     hooks.maxCommits not set${COLOR_RESET}"
    CONFIG_OK=false
fi

# Check logLevel
LOG_LEVEL=$(git -C "$GIT_ROOT" config hooks.logLevel 2>/dev/null || echo "")
if [[ -z "$LOG_LEVEL" ]]; then
    echo -e "${COLOR_YELLOW}     hooks.logLevel not set${COLOR_RESET}"
    CONFIG_OK=false
fi

if [[ "$CONFIG_OK" == "true" ]]; then
    check_pass
else
    check_warning "Some configurations are missing (will use defaults)"
fi

# Check 7: Documentation exists
echo -e "${COLOR_CYAN}${EMOJI_INFO} Checking documentation...${COLOR_RESET}"
DOC_FILES=(
    "README.md"
    "COMMANDS.md"
    "TROUBLESHOOTING.md"
    "CONTRIBUTING.md"
    "QUICK_START.md"
)

ALL_DOCS_EXIST=true
for doc in "${DOC_FILES[@]}"; do
    if [[ ! -f "$SCRIPT_DIR/$doc" ]]; then
        ALL_DOCS_EXIST=false
        echo -e "${COLOR_YELLOW}     Missing: $doc${COLOR_RESET}"
    fi
done

if [[ "$ALL_DOCS_EXIST" == "true" ]]; then
    check_pass
else
    check_warning "Some documentation files are missing"
fi

# Check 8: Test suite exists
echo -e "${COLOR_CYAN}${EMOJI_INFO} Checking test suite...${COLOR_RESET}"
if [[ -f "$SCRIPT_DIR/test/test-suite.sh" ]]; then
    check_pass
else
    check_warning "Test suite not found"
fi

# Check 9: Commands configuration
echo -e "${COLOR_CYAN}${EMOJI_INFO} Checking commands configuration...${COLOR_RESET}"
if [[ -f "$SCRIPT_DIR/commands.conf" ]]; then
    check_pass
else
    check_warning "commands.conf not found (will be created on install)"
fi

# Check 10: Bash version
echo -e "${COLOR_CYAN}${EMOJI_INFO} Checking bash version...${COLOR_RESET}"
BASH_VERSION_NUM="${BASH_VERSINFO[0]}"
if [[ "$BASH_VERSION_NUM" -ge 4 ]]; then
    check_pass
else
    check_fail "Bash version 4.0+ required (current: $BASH_VERSION)"
fi

# ==============================================================================
# FUNCTIONAL TESTS
# ==============================================================================

echo ""
echo -e "${COLOR_CYAN}${COLOR_BOLD}Functional Tests${COLOR_RESET}"
echo ""

# Test 11: Common library loads
echo -e "${COLOR_CYAN}${EMOJI_INFO} Testing common library...${COLOR_RESET}"
if bash -c "source '$SCRIPT_DIR/lib/common.sh' && echo 'OK'" >/dev/null 2>&1; then
    check_pass
else
    check_fail "Cannot load lib/common.sh"
fi

# Test 12: Runner library loads
echo -e "${COLOR_CYAN}${EMOJI_INFO} Testing runner library...${COLOR_RESET}"
if bash -c "source '$SCRIPT_DIR/lib/common.sh' && source '$SCRIPT_DIR/lib/runner.sh' && echo 'OK'" >/dev/null 2>&1; then
    check_pass
else
    check_fail "Cannot load lib/runner.sh"
fi

# Test 13: Hook syntax check
echo -e "${COLOR_CYAN}${EMOJI_INFO} Checking hook syntax...${COLOR_RESET}"
HOOKS=(
    "pre-commit"
    "prepare-commit-msg"
    "commit-msg"
    "applypatch-msg"
    "pre-push"
    "pre-rebase"
    "post-rewrite"
    "post-checkout"
)

SYNTAX_OK=true
for hook in "${HOOKS[@]}"; do
    if ! bash -n "$SCRIPT_DIR/$hook" 2>/dev/null; then
        SYNTAX_OK=false
        echo -e "${COLOR_RED}     Syntax error in: $hook${COLOR_RESET}"
    fi
done

if [[ "$SYNTAX_OK" == "true" ]]; then
    check_pass
else
    check_fail "Some hooks have syntax errors"
fi

# ==============================================================================
# CONFIGURATION SUMMARY
# ==============================================================================

echo ""
echo -e "${COLOR_CYAN}${COLOR_BOLD}Configuration Summary${COLOR_RESET}"
echo ""

echo -e "${COLOR_BOLD}Git Settings:${COLOR_RESET}"
echo -e "  core.hooksPath       = $(git -C "$GIT_ROOT" config core.hooksPath 2>/dev/null || echo 'NOT SET')"
echo -e "  rebase.autosquash    = $(git -C "$GIT_ROOT" config rebase.autosquash 2>/dev/null || echo 'NOT SET')"
echo -e "  fetch.prune          = $(git -C "$GIT_ROOT" config fetch.prune 2>/dev/null || echo 'NOT SET')"
echo ""

echo -e "${COLOR_BOLD}Hook Settings:${COLOR_RESET}"
echo -e "  hooks.maxCommits     = $(git -C "$GIT_ROOT" config hooks.maxCommits 2>/dev/null || echo 'NOT SET (default: 5)')"
echo -e "  hooks.logLevel       = $(git -C "$GIT_ROOT" config hooks.logLevel 2>/dev/null || echo 'NOT SET (default: 6)')"
echo -e "  hooks.defaultBranch  = $(git -C "$GIT_ROOT" config hooks.defaultBranch 2>/dev/null || echo 'NOT SET (auto-detect)')"
echo ""

# ==============================================================================
# RESULTS SUMMARY
# ==============================================================================

echo -e "${COLOR_CYAN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo -e "${COLOR_CYAN}${COLOR_BOLD}  Verification Results${COLOR_RESET}"
echo -e "${COLOR_CYAN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo ""

echo -e "${COLOR_BOLD}Total Checks:${COLOR_RESET}    $CHECKS_RUN"
echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Passed:${COLOR_RESET}       $CHECKS_PASSED"
echo -e "${COLOR_RED}${EMOJI_ERROR} Failed:${COLOR_RESET}       $CHECKS_FAILED"
echo -e "${COLOR_YELLOW}${EMOJI_WARNING} Warnings:${COLOR_RESET}     $CHECKS_WARNING"
echo ""

if [[ $CHECKS_FAILED -eq 0 ]] && [[ $CHECKS_WARNING -eq 0 ]]; then
    echo -e "${COLOR_GREEN}${COLOR_BOLD}${EMOJI_SUCCESS} All checks passed! Git hooks are properly installed.${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_CYAN}Next steps:${COLOR_RESET}"
    echo -e "  1. Read QUICK_START.md for usage guide"
    echo -e "  2. Configure custom commands in commands.conf (if needed)"
    echo -e "  3. Test with: git checkout -b feat-TEST-1-test"
    echo ""
    exit 0
elif [[ $CHECKS_FAILED -eq 0 ]]; then
    echo -e "${COLOR_YELLOW}${COLOR_BOLD}${EMOJI_WARNING} Verification completed with warnings.${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}Hooks should work, but review warnings above.${COLOR_RESET}"
    echo ""
    exit 0
else
    echo -e "${COLOR_RED}${COLOR_BOLD}${EMOJI_ERROR} Verification failed with $CHECKS_FAILED errors.${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_CYAN}To fix:${COLOR_RESET}"
    echo -e "  1. Run: .githooks/install-hooks.sh"
    echo -e "  2. Ensure all files are present"
    echo -e "  3. Run this verification again"
    echo ""
    exit 1
fi
