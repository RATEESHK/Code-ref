#!/usr/bin/env bash
# Command Runner Framework for Git Hooks
# Executes custom commands with priority ordering, timeouts, and error handling
# Version: 2.0.0

# Source common library
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./common.sh
source "$SCRIPT_DIR/common.sh" 2>/dev/null || { echo "ERROR: Cannot load common.sh" >&2; exit 1; }

# ==============================================================================
# COMMAND STRUCTURE
# ==============================================================================

# Command format: HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
# Example: pre-commit:1:true:30:npx lint-staged:Lint staged files

declare -a COMMANDS=()

# ==============================================================================
# CONFIGURATION
# ==============================================================================

# Commands configuration file
COMMANDS_CONF="${GIT_ROOT}/.githooks/commands.conf"

# Temporary directory for command output
COMMAND_OUTPUT_DIR=""

# ==============================================================================
# COMMAND PARSING
# ==============================================================================

# Load commands from configuration file
load_commands() {
    local hook_name="$1"
    
    COMMANDS=()
    
    if [[ ! -f "$COMMANDS_CONF" ]]; then
        log_debug "No commands.conf file found at: $COMMANDS_CONF"
        return 0
    fi
    
    log_debug "Loading commands from: $COMMANDS_CONF"
    
    local line_num=0
    while IFS= read -r line || [[ -n "$line" ]]; do
        ((line_num++))
        
        # Skip empty lines and comments
        line=$(trim "$line")
        if [[ -z "$line" ]] || [[ "$line" =~ ^# ]]; then
            continue
        fi
        
        # Parse command line
        if ! parse_command_line "$line" "$hook_name" "$line_num"; then
            log_warning "Skipping invalid command at line $line_num: $line"
        fi
    done < "$COMMANDS_CONF"
    
    log_info "Loaded ${#COMMANDS[@]} commands for hook '$hook_name'"
}

# Parse a single command line
parse_command_line() {
    local line="$1"
    local target_hook="$2"
    local line_num="$3"
    
    # Split by colon (handle up to 6 fields)
    IFS=':' read -r hook priority mandatory timeout command description <<< "$line"
    
    # Validate fields
    if [[ -z "$hook" ]] || [[ -z "$priority" ]] || [[ -z "$mandatory" ]] || [[ -z "$timeout" ]] || [[ -z "$command" ]]; then
        log_error "Invalid command format at line $line_num: missing required fields"
        return 1
    fi
    
    # Check if this command is for the current hook
    if [[ "$hook" != "$target_hook" ]]; then
        return 0
    fi
    
    # Validate priority (must be a number)
    if ! [[ "$priority" =~ ^[0-9]+$ ]]; then
        log_error "Invalid priority at line $line_num: must be a number"
        return 1
    fi
    
    # Validate mandatory (must be true or false)
    if [[ "$mandatory" != "true" ]] && [[ "$mandatory" != "false" ]]; then
        log_error "Invalid mandatory flag at line $line_num: must be 'true' or 'false'"
        return 1
    fi
    
    # Validate timeout (must be a number)
    if ! [[ "$timeout" =~ ^[0-9]+$ ]]; then
        log_error "Invalid timeout at line $line_num: must be a number"
        return 1
    fi
    
    # Add command to array (format: priority|mandatory|timeout|command|description)
    COMMANDS+=("${priority}|${mandatory}|${timeout}|${command}|${description:-No description}")
    
    return 0
}

# ==============================================================================
# COMMAND EXECUTION
# ==============================================================================

# Execute all commands for the current hook
run_commands() {
    local hook_name="$1"
    
    # Load commands
    load_commands "$hook_name"
    
    if [[ ${#COMMANDS[@]} -eq 0 ]]; then
        log_debug "No commands configured for hook '$hook_name'"
        return 0
    fi
    
    # Create temporary directory for output
    COMMAND_OUTPUT_DIR=$(mktemp -d 2>/dev/null || mktemp -d -t 'githooks')
    
    # Sort commands by priority
    local sorted_commands=()
    while IFS= read -r cmd; do
        sorted_commands+=("$cmd")
    done < <(printf '%s\n' "${COMMANDS[@]}" | sort -t'|' -k1 -n)
    
    # Group commands by priority for parallel execution
    local current_priority=""
    local priority_group=()
    local all_passed=true
    local failed_commands=()
    local passed_commands=()
    
    local total_commands=${#sorted_commands[@]}
    local current_index=0
    
    print_header "Running Custom Commands for $hook_name"
    
    for cmd_spec in "${sorted_commands[@]}"; do
        ((current_index++))
        
        IFS='|' read -r priority mandatory timeout command description <<< "$cmd_spec"
        
        # If priority changed and parallel execution is enabled, execute previous group
        if [[ -n "$current_priority" ]] && [[ "$priority" != "$current_priority" ]] && is_parallel_execution_enabled; then
            if ! execute_command_group "${priority_group[@]}"; then
                all_passed=false
            fi
            priority_group=()
        fi
        
        current_priority="$priority"
        
        # Add to priority group
        if is_parallel_execution_enabled; then
            priority_group+=("$cmd_spec")
        else
            # Execute immediately if not parallel
            print_progress "$current_index" "$total_commands" "$description"
            
            if execute_single_command "$priority" "$mandatory" "$timeout" "$command" "$description"; then
                passed_commands+=("$description")
            else
                failed_commands+=("$description")
                if [[ "$mandatory" == "true" ]]; then
                    all_passed=false
                fi
            fi
        fi
    done
    
    # Execute remaining commands in group (if parallel)
    if is_parallel_execution_enabled && [[ ${#priority_group[@]} -gt 0 ]]; then
        if ! execute_command_group "${priority_group[@]}"; then
            all_passed=false
        fi
    fi
    
    # Clean up
    rm -rf "$COMMAND_OUTPUT_DIR" 2>/dev/null || true
    
    # Report results
    print_command_results "$all_passed" "${failed_commands[@]}" -- "${passed_commands[@]}"
    
    if [[ "$all_passed" == "false" ]]; then
        return 1
    fi
    
    return 0
}

# Execute a group of commands (parallel execution)
execute_command_group() {
    local commands=("$@")
    local pids=()
    local results=()
    
    # Start all commands in background
    for cmd_spec in "${commands[@]}"; do
        IFS='|' read -r priority mandatory timeout command description <<< "$cmd_spec"
        
        (
            execute_single_command "$priority" "$mandatory" "$timeout" "$command" "$description"
            echo $? > "$COMMAND_OUTPUT_DIR/exit_${priority}_$$"
        ) &
        
        pids+=($!)
    done
    
    # Wait for all commands to complete
    for pid in "${pids[@]}"; do
        wait "$pid" 2>/dev/null || true
    done
    
    # Check results
    local all_passed=true
    for cmd_spec in "${commands[@]}"; do
        IFS='|' read -r priority mandatory timeout command description <<< "$cmd_spec"
        
        local exit_file="$COMMAND_OUTPUT_DIR/exit_${priority}_*"
        if [[ -f $exit_file ]]; then
            local exit_code
            exit_code=$(cat "$exit_file")
            if [[ $exit_code -ne 0 ]] && [[ "$mandatory" == "true" ]]; then
                all_passed=false
            fi
            rm -f "$exit_file" 2>/dev/null || true
        fi
    done
    
    if [[ "$all_passed" == "false" ]]; then
        return 1
    fi
    
    return 0
}

# Execute a single command
execute_single_command() {
    local priority="$1"
    local mandatory="$2"
    local timeout="$3"
    local command="$4"
    local description="$5"
    
    log_info "Executing command (priority=$priority, mandatory=$mandatory, timeout=${timeout}s): $command"
    
    # Prepare environment variables
    export GIT_HOOK_NAME="$HOOK_NAME"
    export GIT_USER_NAME="$GIT_USER_NAME"
    export GIT_USER_EMAIL="$GIT_USER_EMAIL"
    
    # Get staged files
    local staged_files
    staged_files=$(get_staged_files | tr '\n' ' ')
    export STAGED_FILES="$staged_files"
    
    # Replace placeholders in command
    command="${command//\{staged\}/$staged_files}"
    
    # Create output file
    local output_file="$COMMAND_OUTPUT_DIR/output_${priority}_$$"
    
    # Execute command with timeout
    local start_time
    start_time=$(date +%s)
    
    local exit_code=0
    if run_with_timeout "$timeout" bash -c "$command" >"$output_file" 2>&1; then
        exit_code=0
    else
        exit_code=$?
    fi
    
    local end_time
    end_time=$(date +%s)
    local duration=$((end_time - start_time))
    
    # Log result
    if [[ $exit_code -eq 0 ]]; then
        log_info "Command succeeded: $description (duration: ${duration}s)"
        print_success "$description"
        
        # Check for auto-restage
        if is_auto_add_enabled && [[ -s "$output_file" ]]; then
            auto_restage_files "$output_file"
        fi
    else
        if [[ $exit_code -eq 124 ]] || [[ $exit_code -eq 143 ]]; then
            log_error "Command timed out after ${timeout}s: $description"
            print_error "$description (TIMEOUT after ${timeout}s)"
        else
            log_error "Command failed with exit code $exit_code: $description"
            print_error "$description (exit code: $exit_code)"
            
            # Show output for failed commands
            if [[ -s "$output_file" ]]; then
                echo -e "\n${COLOR_DIM}Command output:${COLOR_RESET}" >&2
                head -20 "$output_file" >&2
                local line_count
                line_count=$(wc -l < "$output_file")
                if [[ $line_count -gt 20 ]]; then
                    echo -e "${COLOR_DIM}... (output truncated, showing first 20 lines of $line_count)${COLOR_RESET}" >&2
                fi
            fi
        fi
    fi
    
    # Clean up output file
    rm -f "$output_file" 2>/dev/null || true
    
    return $exit_code
}

# Auto-restage files that were modified by commands
auto_restage_files() {
    local output_file="$1"
    
    log_debug "Checking for files to auto-restage"
    
    # Look for common patterns indicating files were modified
    local modified_files=()
    
    # Parse output for file paths (simple heuristic)
    while IFS= read -r line; do
        # Look for lines that might contain file paths
        if [[ "$line" =~ [[:space:]]([a-zA-Z0-9_/.-]+\.(js|ts|jsx|tsx|py|java|go|rs|c|cpp|h|css|scss|html|json|yaml|yml|md))[[:space:]] ]]; then
            local file="${BASH_REMATCH[1]}"
            if [[ -f "$GIT_ROOT/$file" ]]; then
                modified_files+=("$file")
            fi
        fi
    done < "$output_file"
    
    # Re-stage modified files
    if [[ ${#modified_files[@]} -gt 0 ]]; then
        log_info "Auto-restaging ${#modified_files[@]} modified files"
        for file in "${modified_files[@]}"; do
            git add "$file" 2>/dev/null || true
            log_debug "Re-staged: $file"
        done
        print_info "Auto-restaged ${#modified_files[@]} files after fixes"
    fi
}

# ==============================================================================
# RESULT REPORTING
# ==============================================================================

# Print command execution results
print_command_results() {
    local all_passed="$1"
    shift
    
    local failed_commands=()
    local passed_commands=()
    local parsing_failed=true
    
    # Parse arguments (failed commands before --, passed commands after)
    for arg in "$@"; do
        if [[ "$arg" == "--" ]]; then
            parsing_failed=false
            continue
        fi
        
        if [[ "$parsing_failed" == "true" ]]; then
            failed_commands+=("$arg")
        else
            passed_commands+=("$arg")
        fi
    done
    
    echo "" >&2
    print_header "Command Execution Results"
    
    if [[ ${#failed_commands[@]} -gt 0 ]]; then
        echo -e "${COLOR_RED}${COLOR_BOLD}Failed Checks:${COLOR_RESET}" >&2
        for cmd in "${failed_commands[@]}"; do
            echo -e "  ${EMOJI_ERROR} $cmd" >&2
        done
        echo "" >&2
    fi
    
    if [[ ${#passed_commands[@]} -gt 0 ]]; then
        echo -e "${COLOR_GREEN}${COLOR_BOLD}Passed Checks:${COLOR_RESET}" >&2
        for cmd in "${passed_commands[@]}"; do
            echo -e "  ${EMOJI_SUCCESS} $cmd" >&2
        done
        echo "" >&2
    fi
    
    if [[ "$all_passed" == "false" ]]; then
        echo -e "${COLOR_YELLOW}To bypass (emergency only): ${COLOR_BOLD}BYPASS_HOOKS=1 git <command>${COLOR_RESET}" >&2
        echo "" >&2
    fi
}

# ==============================================================================
# LINT-STAGED INTEGRATION
# ==============================================================================

# Check if lint-staged is configured
has_lint_staged_config() {
    [[ -f "$GIT_ROOT/.lintstagedrc.json" ]] || \
    [[ -f "$GIT_ROOT/.lintstagedrc.js" ]] || \
    [[ -f "$GIT_ROOT/.lintstagedrc.cjs" ]] || \
    grep -q "lint-staged" "$GIT_ROOT/package.json" 2>/dev/null
}

# Run lint-staged if configured
run_lint_staged() {
    if ! has_lint_staged_config; then
        log_debug "No lint-staged configuration found"
        return 0
    fi
    
    if ! command_exists npx; then
        log_warning "npx not found, skipping lint-staged"
        return 0
    fi
    
    log_info "Running lint-staged"
    print_info "Running lint-staged..."
    
    local output_file
    output_file=$(mktemp)
    
    if npx lint-staged >"$output_file" 2>&1; then
        log_info "lint-staged completed successfully"
        print_success "Lint-staged"
        rm -f "$output_file"
        return 0
    else
        local exit_code=$?
        log_error "lint-staged failed with exit code $exit_code"
        print_error "Lint-staged failed"
        
        echo -e "\n${COLOR_DIM}lint-staged output:${COLOR_RESET}" >&2
        cat "$output_file" >&2
        
        rm -f "$output_file"
        return $exit_code
    fi
}

# ==============================================================================
# EXPORT FUNCTIONS
# ==============================================================================

export -f load_commands parse_command_line run_commands
export -f execute_command_group execute_single_command auto_restage_files
export -f print_command_results has_lint_staged_config run_lint_staged

# Prevent direct execution
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    echo "runner.sh should be sourced, not executed directly" >&2
    exit 1
fi
