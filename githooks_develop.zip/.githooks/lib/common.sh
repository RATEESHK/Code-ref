#!/usr/bin/env bash
# Common library for Git hooks
# Provides logging, utilities, validation functions, and cross-platform support
# Version: 2.0.0

# ==============================================================================
# CONSTANTS AND CONFIGURATION
# ==============================================================================

# Log levels (syslog-compatible)
readonly LOG_EMERGENCY=0  # System is unusable
readonly LOG_FATAL=1      # Fatal error, must abort
readonly LOG_CRITICAL=2   # Critical conditions
readonly LOG_ERROR=3      # Error conditions
readonly LOG_WARNING=4    # Warning conditions
readonly LOG_NOTICE=5     # Normal but significant
readonly LOG_INFO=6       # Informational messages
readonly LOG_DEBUG=7      # Debug-level messages
readonly LOG_TRACE=8      # Trace-level messages

# Log level names (for output)
readonly -A LOG_LEVEL_NAMES=(
    [0]="EMERGENCY"
    [1]="FATAL"
    [2]="CRITICAL"
    [3]="ERROR"
    [4]="WARNING"
    [5]="NOTICE"
    [6]="INFO"
    [7]="DEBUG"
    [8]="TRACE"
)

# ANSI color codes
readonly COLOR_RESET='\033[0m'
readonly COLOR_RED='\033[0;31m'
readonly COLOR_GREEN='\033[0;32m'
readonly COLOR_YELLOW='\033[0;33m'
readonly COLOR_BLUE='\033[0;34m'
readonly COLOR_MAGENTA='\033[0;35m'
readonly COLOR_CYAN='\033[0;36m'
readonly COLOR_WHITE='\033[0;37m'
readonly COLOR_BOLD='\033[1m'
readonly COLOR_DIM='\033[2m'

# Emoji indicators (cross-platform safe)
readonly EMOJI_ERROR="✗"
readonly EMOJI_WARNING="⚠"
readonly EMOJI_INFO="ℹ"
readonly EMOJI_SUCCESS="✓"
readonly EMOJI_DEBUG="🔍"
readonly EMOJI_ROCKET="🚀"
readonly EMOJI_LOCK="🔒"
readonly EMOJI_KEY="🔑"
readonly EMOJI_FIRE="🔥"
readonly EMOJI_PACKAGE="📦"
readonly EMOJI_GEAR="⚙"

# Git hook names
readonly HOOK_PRE_COMMIT="pre-commit"
readonly HOOK_COMMIT_MSG="commit-msg"
readonly HOOK_PREPARE_COMMIT_MSG="prepare-commit-msg"
readonly HOOK_PRE_PUSH="pre-push"
readonly HOOK_PRE_REBASE="pre-rebase"
readonly HOOK_POST_REWRITE="post-rewrite"
readonly HOOK_POST_CHECKOUT="post-checkout"
readonly HOOK_APPLYPATCH_MSG="applypatch-msg"

# Branch patterns
readonly BRANCH_PATTERN_LONG_LIVED='^(main|develop|release($|/.*))$'
readonly BRANCH_PATTERN_SHORT_LIVED='^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$'

# Commit message pattern
readonly COMMIT_MSG_PATTERN='^(feat|fix|chore|break|tests): [A-Z]{2,10}-[0-9]+ .+'

# Protected branches
readonly -a PROTECTED_BRANCHES=("main" "master" "develop")

# Sensitive file patterns
readonly -a SENSITIVE_FILE_PATTERNS=(
    '\.env$'
    '\.env\.'
    '\.pem$'
    '\.p12$'
    '\.pfx$'
    '_rsa$'
    '_dsa$'
    '_ecdsa$'
    '_ed25519$'
    '\.key$'
    '\.cert$'
    '\.crt$'
    'credentials$'
    'secrets\.json$'
    'secrets\.ya?ml$'
)

# Secret patterns (regex)
readonly -a SECRET_PATTERNS=(
    'AKIA[0-9A-Z]{16}'                                    # AWS Access Key
    'gh[ps]_[a-zA-Z0-9]{36}'                             # GitHub PAT
    'xox[baprs]-[0-9]{10,12}-[a-zA-Z0-9]{24}'           # Slack
    'AIza[0-9A-Za-z_-]{35}'                              # Google API Key
    'sk_(test_|live_)[0-9a-zA-Z]{24}'                   # Stripe
    '-----BEGIN.*PRIVATE KEY'                            # Private Keys
    'password\s*=\s*["'"'"'][^"'"'"']+'                 # Password
    'api[_-]?key\s*[:=]\s*["'"'"']?[a-zA-Z0-9_-]{20,}' # API Keys
)

# ==============================================================================
# GLOBAL VARIABLES
# ==============================================================================

# Git repository root
GIT_ROOT=""

# Hook logs directory
HOOK_LOGS_DIR=""

# Complete log file
COMPLETE_LOG_FILE=""

# Current hook log file
HOOK_LOG_FILE=""

# Current hook name
HOOK_NAME=""

# Git user info
GIT_USER_NAME=""
GIT_USER_EMAIL=""

# Current branch
CURRENT_BRANCH=""

# Current commit (if applicable)
CURRENT_COMMIT=""

# Process ID
PROCESS_ID=$$

# Log level (default INFO)
LOG_LEVEL=${LOG_LEVEL:-$LOG_INFO}

# Platform detection
PLATFORM=""

# ==============================================================================
# INITIALIZATION
# ==============================================================================

# Initialize the common library
# Must be called at the start of each hook
init_common() {
    local hook_name="${1:-unknown}"
    HOOK_NAME="$hook_name"
    
    # Detect platform
    detect_platform
    
    # Get Git root
    GIT_ROOT=$(git rev-parse --show-toplevel 2>/dev/null)
    if [[ -z "$GIT_ROOT" ]]; then
        echo "ERROR: Not in a git repository" >&2
        exit 1
    fi
    
    # Set up log directory
    HOOK_LOGS_DIR="$GIT_ROOT/.git/hook-logs"
    mkdir -p "$HOOK_LOGS_DIR" 2>/dev/null || true
    
    # Set log files
    COMPLETE_LOG_FILE="$HOOK_LOGS_DIR/complete.log"
    HOOK_LOG_FILE="$HOOK_LOGS_DIR/${HOOK_NAME}.log"
    
    # Get Git user info
    GIT_USER_NAME=$(git config user.name || echo "unknown")
    GIT_USER_EMAIL=$(git config user.email || echo "unknown")
    
    # Get current branch
    CURRENT_BRANCH=$(git symbolic-ref --short HEAD 2>/dev/null || echo "detached")
    
    # Get current commit
    CURRENT_COMMIT=$(git rev-parse HEAD 2>/dev/null || echo "none")
    
    # Set log level from config
    local config_log_level
    config_log_level=$(git config hooks.logLevel || echo "")
    if [[ -n "$config_log_level" ]]; then
        LOG_LEVEL=$config_log_level
    fi
    
    # Check for global bypass
    if [[ "${BYPASS_HOOKS:-0}" == "1" ]]; then
        log_warning "BYPASS_HOOKS is set - hook execution bypassed by user"
        exit 0
    fi
    
    # Log hook start
    log_info "Hook '$HOOK_NAME' started"
}

# ==============================================================================
# PLATFORM DETECTION
# ==============================================================================

detect_platform() {
    case "$(uname -s)" in
        Linux*)     PLATFORM="linux" ;;
        Darwin*)    PLATFORM="macos" ;;
        CYGWIN*)    PLATFORM="windows" ;;
        MINGW*)     PLATFORM="windows" ;;
        MSYS*)      PLATFORM="windows" ;;
        *)          PLATFORM="unknown" ;;
    esac
}

# Check if running on Windows
is_windows() {
    [[ "$PLATFORM" == "windows" ]]
}

# Check if running on macOS
is_macos() {
    [[ "$PLATFORM" == "macos" ]]
}

# Check if running on Linux
is_linux() {
    [[ "$PLATFORM" == "linux" ]]
}

# ==============================================================================
# LOGGING FUNCTIONS
# ==============================================================================

# Get timestamp in ISO 8601 format
get_timestamp() {
    if is_macos; then
        date -u +"%Y-%m-%dT%H:%M:%S.000Z"
    else
        date -u +"%Y-%m-%dT%H:%M:%S.%3NZ" 2>/dev/null || date -u +"%Y-%m-%dT%H:%M:%SZ"
    fi
}

# Get stack trace (simplified)
get_stack_trace() {
    local frame=0
    local trace=""
    while caller $frame >/dev/null 2>&1; do
        local line=$(caller $frame)
        trace="${trace}${trace:+|}${line}"
        ((frame++))
    done
    echo "$trace"
}

# Core logging function
log_message() {
    local level=$1
    shift
    local message="$*"
    
    # Skip if level is above configured level
    if [[ $level -gt $LOG_LEVEL ]]; then
        return 0
    fi
    
    local timestamp
    timestamp=$(get_timestamp)
    
    local level_name="${LOG_LEVEL_NAMES[$level]}"
    
    local stack_trace=""
    if [[ $level -le $LOG_ERROR ]]; then
        stack_trace=$(get_stack_trace)
    fi
    
    # Format: [timestamp] [level] [hook] [PID] [user] [email] [branch] [commit] [stack_trace] message
    local log_entry="[$timestamp] [$level_name] [$HOOK_NAME] [$PROCESS_ID] [$GIT_USER_NAME] [$GIT_USER_EMAIL] [$CURRENT_BRANCH] [$CURRENT_COMMIT] [$stack_trace] $message"
    
    # Write to complete log
    echo "$log_entry" >> "$COMPLETE_LOG_FILE" 2>/dev/null || true
    
    # Write to hook-specific log
    echo "$log_entry" >> "$HOOK_LOG_FILE" 2>/dev/null || true
    
    # Rotate logs if needed
    rotate_logs_if_needed
}

# Log level functions
log_emergency() { log_message $LOG_EMERGENCY "$@"; }
log_fatal() { log_message $LOG_FATAL "$@"; }
log_critical() { log_message $LOG_CRITICAL "$@"; }
log_error() { log_message $LOG_ERROR "$@"; }
log_warning() { log_message $LOG_WARNING "$@"; }
log_notice() { log_message $LOG_NOTICE "$@"; }
log_info() { log_message $LOG_INFO "$@"; }
log_debug() { log_message $LOG_DEBUG "$@"; }
log_trace() { log_message $LOG_TRACE "$@"; }

# ==============================================================================
# LOG ROTATION
# ==============================================================================

# Rotate logs if they exceed size limit
rotate_logs_if_needed() {
    local max_size=$((256 * 1024))  # 256KB
    local keep_archives=2
    
    # Rotate complete log
    if [[ -f "$COMPLETE_LOG_FILE" ]]; then
        local size
        size=$(stat_file_size "$COMPLETE_LOG_FILE")
        if [[ $size -gt $max_size ]]; then
            rotate_log_file "$COMPLETE_LOG_FILE" $keep_archives
        fi
    fi
    
    # Rotate hook log
    if [[ -f "$HOOK_LOG_FILE" ]]; then
        local size
        size=$(stat_file_size "$HOOK_LOG_FILE")
        if [[ $size -gt $max_size ]]; then
            rotate_log_file "$HOOK_LOG_FILE" $keep_archives
        fi
    fi
}

# Get file size (cross-platform)
stat_file_size() {
    local file="$1"
    if is_macos; then
        stat -f%z "$file" 2>/dev/null || echo "0"
    else
        stat -c%s "$file" 2>/dev/null || echo "0"
    fi
}

# Rotate a log file
rotate_log_file() {
    local file="$1"
    local keep=$2
    
    # Remove oldest archive
    local oldest="${file}.$keep"
    rm -f "$oldest" 2>/dev/null || true
    
    # Shift archives
    for ((i=keep-1; i>=1; i--)); do
        local current="${file}.$i"
        local next="${file}.$((i+1))"
        if [[ -f "$current" ]]; then
            mv "$current" "$next" 2>/dev/null || true
        fi
    done
    
    # Archive current log
    if [[ -f "$file" ]]; then
        mv "$file" "${file}.1" 2>/dev/null || true
    fi
}

# Clean old logs (older than specified days)
clean_old_logs() {
    local days=${1:-21}
    
    if [[ ! -d "$HOOK_LOGS_DIR" ]]; then
        return 0
    fi
    
    log_info "Cleaning logs older than $days days"
    
    if is_macos; then
        find "$HOOK_LOGS_DIR" -name "*.log*" -mtime +${days} -delete 2>/dev/null || true
    else
        find "$HOOK_LOGS_DIR" -name "*.log*" -mtime +${days} -delete 2>/dev/null || true
    fi
}

# ==============================================================================
# OUTPUT FORMATTING
# ==============================================================================

# Print colored message to stderr
print_color() {
    local color="$1"
    shift
    echo -e "${color}$*${COLOR_RESET}" >&2
}

# Print error message
print_error() {
    print_color "$COLOR_RED" "${EMOJI_ERROR} ERROR: $*"
}

# Print warning message
print_warning() {
    print_color "$COLOR_YELLOW" "${EMOJI_WARNING} WARNING: $*"
}

# Print info message
print_info() {
    print_color "$COLOR_CYAN" "${EMOJI_INFO} $*"
}

# Print success message
print_success() {
    print_color "$COLOR_GREEN" "${EMOJI_SUCCESS} $*"
}

# Print section header
print_header() {
    echo -e "\n${COLOR_BOLD}${COLOR_CYAN}=======================================${COLOR_RESET}" >&2
    echo -e "${COLOR_BOLD}${COLOR_CYAN}$*${COLOR_RESET}" >&2
    echo -e "${COLOR_BOLD}${COLOR_CYAN}=======================================${COLOR_RESET}\n" >&2
}

# Print progress indicator
print_progress() {
    local current=$1
    local total=$2
    local message="$3"
    echo -e "${COLOR_CYAN}[$current/$total]${COLOR_RESET} $message" >&2
}

# ==============================================================================
# GIT UTILITIES
# ==============================================================================

# Get current branch name
get_current_branch() {
    git symbolic-ref --short HEAD 2>/dev/null || echo ""
}

# Get default branch (main or master)
get_default_branch() {
    local default_branch
    default_branch=$(git config hooks.defaultBranch 2>/dev/null)
    if [[ -n "$default_branch" ]]; then
        echo "$default_branch"
        return 0
    fi
    
    # Try to detect from remote
    if git rev-parse --verify origin/main >/dev/null 2>&1; then
        echo "main"
    elif git rev-parse --verify origin/master >/dev/null 2>&1; then
        echo "master"
    else
        echo "main"  # Default to main
    fi
}

# Check if branch exists locally
branch_exists_local() {
    local branch="$1"
    git rev-parse --verify "$branch" >/dev/null 2>&1
}

# Check if branch exists on remote
branch_exists_remote() {
    local branch="$1"
    git rev-parse --verify "origin/$branch" >/dev/null 2>&1
}

# Check if branch is protected
is_protected_branch() {
    local branch="${1:-$(get_current_branch)}"
    
    for protected in "${PROTECTED_BRANCHES[@]}"; do
        if [[ "$branch" == "$protected" ]]; then
            return 0
        fi
    done
    
    return 1
}

# Get staged files
get_staged_files() {
    git diff --cached --name-only --diff-filter=ACM
}

# Get staged file content
get_staged_content() {
    local file="$1"
    git show ":$file" 2>/dev/null || echo ""
}

# Count commits between base and HEAD
count_commits_since_base() {
    local base="$1"
    git rev-list --count "${base}..HEAD" 2>/dev/null || echo "0"
}

# Check if HEAD is ancestor of base (i.e., rebased on base)
is_rebased_on() {
    local base="$1"
    git merge-base --is-ancestor "$base" HEAD 2>/dev/null
}

# Check for merge commits in branch
has_merge_commits() {
    local base="$1"
    local merge_count
    merge_count=$(git rev-list --merges --count "${base}..HEAD" 2>/dev/null || echo "0")
    [[ $merge_count -gt 0 ]]
}

# Fetch remote branch if not present locally
fetch_remote_branch() {
    local remote_branch="$1"
    
    if ! git rev-parse --verify "$remote_branch" >/dev/null 2>&1; then
        log_info "Fetching remote branch: $remote_branch"
        git fetch origin "${remote_branch#origin/}" 2>/dev/null || true
    fi
}

# ==============================================================================
# VALIDATION FUNCTIONS
# ==============================================================================

# Validate branch name
validate_branch_name() {
    local branch="$1"
    
    # Check long-lived pattern
    if [[ "$branch" =~ $BRANCH_PATTERN_LONG_LIVED ]]; then
        return 0
    fi
    
    # Check short-lived pattern
    if [[ "$branch" =~ $BRANCH_PATTERN_SHORT_LIVED ]]; then
        return 0
    fi
    
    return 1
}

# Extract JIRA ID from branch name
extract_jira_id() {
    local branch="$1"
    
    if [[ "$branch" =~ -([A-Z]{2,10}-[0-9]+)- ]]; then
        echo "${BASH_REMATCH[1]}"
        return 0
    fi
    
    return 1
}

# Validate commit message format
validate_commit_message() {
    local message="$1"
    
    # Allow merge and revert messages
    if [[ "$message" =~ ^(Merge|Revert) ]]; then
        return 0
    fi
    
    # Check format
    if [[ "$message" =~ $COMMIT_MSG_PATTERN ]]; then
        return 0
    fi
    
    return 1
}

# Get base branch for current branch
get_base_branch() {
    local branch="${1:-$(get_current_branch)}"
    
    # Check if configured
    local configured_base
    configured_base=$(git config "hooks.branch.${branch}.base" 2>/dev/null)
    if [[ -n "$configured_base" ]]; then
        echo "$configured_base"
        return 0
    fi
    
    # Determine from branch prefix
    if [[ "$branch" =~ ^hotfix- ]]; then
        echo "origin/main"
    elif [[ "$branch" =~ ^(feature|feat|bugfix|fix|techdebt)- ]]; then
        echo "origin/develop"
    else
        # Default to develop
        echo "origin/develop"
    fi
}

# Get required source branch for branch creation
get_required_source_branch() {
    local branch="$1"
    
    # develop must be created from main
    if [[ "$branch" == "develop" ]]; then
        echo "main"
        return 0
    fi
    
    # release branches must be created from develop
    if [[ "$branch" =~ ^release($|/.*) ]]; then
        echo "develop"
        return 0
    fi
    
    # hotfix branches must be created from main
    if [[ "$branch" =~ ^hotfix- ]]; then
        echo "main"
        return 0
    fi
    
    # Short-lived branches must be created from develop
    if [[ "$branch" =~ ^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test)- ]]; then
        echo "develop"
        return 0
    fi
    
    # No specific requirement for other branches
    return 1
}

# Validate branch was created from correct source
validate_branch_source() {
    local branch="$1"
    local source_branch="${2:-}"
    
    # Get required source
    local required_source
    if ! required_source=$(get_required_source_branch "$branch"); then
        # No specific requirement, allow any source
        return 0
    fi
    
    # If source not provided, we can't validate
    if [[ -z "$source_branch" ]]; then
        log_warning "Cannot validate branch source: source branch not provided"
        return 0
    fi
    
    # Normalize branch names (remove origin/ prefix for comparison)
    local normalized_source="${source_branch#origin/}"
    local normalized_required="${required_source#origin/}"
    
    # Check if source matches required
    if [[ "$normalized_source" == "$normalized_required" ]]; then
        return 0
    fi
    
    # Branch was created from wrong source
    log_error "Branch '$branch' was created from '$source_branch' but should be created from '$required_source'"
    return 1
}

# Check if current branch follows creation rules
check_branch_creation_rules() {
    local branch="${1:-$(get_current_branch)}"
    
    # Get required source
    local required_source
    if ! required_source=$(get_required_source_branch "$branch"); then
        # No specific requirement
        return 0
    fi
    
    # Normalize required source
    local normalized_required="${required_source#origin/}"
    
    # Check if branch has the required source in its history
    # We check if the required branch is an ancestor of current branch
    local check_branch="$normalized_required"
    
    # Try local branch first
    if ! git rev-parse --verify "$check_branch" >/dev/null 2>&1; then
        # Try remote branch
        check_branch="origin/$normalized_required"
        if ! git rev-parse --verify "$check_branch" >/dev/null 2>&1; then
            log_warning "Cannot validate branch creation: '$required_source' not found"
            return 0
        fi
    fi
    
    # Check if required source is an ancestor of current branch
    if git merge-base --is-ancestor "$check_branch" HEAD 2>/dev/null; then
        return 0
    fi
    
    # Branch doesn't have required source in history
    log_error "Branch '$branch' does not have '$required_source' in its history"
    return 1
}

# ==============================================================================
# SECURITY SCANNING
# ==============================================================================

# Scan for secrets in staged content
scan_for_secrets() {
    local file="$1"
    local content="$2"
    local issues=()
    
    for pattern in "${SECRET_PATTERNS[@]}"; do
        if echo "$content" | grep -qE "$pattern"; then
            local matches
            matches=$(echo "$content" | grep -nE "$pattern" | head -5)
            issues+=("Secret pattern detected in $file:")
            while IFS= read -r line; do
                issues+=("  Line: $line")
            done <<< "$matches"
        fi
    done
    
    if [[ ${#issues[@]} -gt 0 ]]; then
        printf '%s\n' "${issues[@]}"
        return 1
    fi
    
    return 0
}

# Check if file is sensitive
is_sensitive_file() {
    local file="$1"
    
    for pattern in "${SENSITIVE_FILE_PATTERNS[@]}"; do
        if [[ "$file" =~ $pattern ]]; then
            return 0
        fi
    done
    
    return 1
}

# ==============================================================================
# CONFIGURATION
# ==============================================================================

# Get configuration value with default
get_config() {
    local key="$1"
    local default="${2:-}"
    
    local value
    value=$(git config "$key" 2>/dev/null || echo "")
    
    if [[ -n "$value" ]]; then
        echo "$value"
    else
        echo "$default"
    fi
}

# Get max commits limit
get_max_commits() {
    get_config "hooks.maxCommits" "5"
}

# Check if auto-add after fix is enabled
is_auto_add_enabled() {
    local value
    value=$(get_config "hooks.autoAddAfterFix" "false")
    [[ "$value" == "true" ]]
}

# Check if parallel execution is enabled
is_parallel_execution_enabled() {
    local value
    value=$(get_config "hooks.parallelExecution" "false")
    [[ "$value" == "true" ]]
}

# ==============================================================================
# ERROR HANDLING
# ==============================================================================

# Exit with error
die() {
    local exit_code="${1:-1}"
    shift
    local message="$*"
    
    log_fatal "$message"
    print_error "$message"
    exit "$exit_code"
}

# Exit with success
exit_success() {
    local message="${1:-Hook completed successfully}"
    log_info "$message"
    exit 0
}

# ==============================================================================
# HELPER FUNCTIONS
# ==============================================================================

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Run command with timeout
run_with_timeout() {
    local timeout=$1
    shift
    local cmd=("$@")
    
    if command_exists timeout; then
        timeout "$timeout" "${cmd[@]}"
    elif command_exists gtimeout; then
        gtimeout "$timeout" "${cmd[@]}"
    else
        # No timeout command available, run without timeout
        "${cmd[@]}"
    fi
}

# Trim whitespace
trim() {
    local var="$1"
    # Remove leading whitespace
    var="${var#"${var%%[![:space:]]*}"}"
    # Remove trailing whitespace
    var="${var%"${var##*[![:space:]]}"}"
    echo "$var"
}

# Check if value is in array
in_array() {
    local needle="$1"
    shift
    local haystack=("$@")
    
    for item in "${haystack[@]}"; do
        if [[ "$item" == "$needle" ]]; then
            return 0
        fi
    done
    
    return 1
}

# ==============================================================================
# HOOK COMPLETION
# ==============================================================================

# Finalize hook execution
finalize_hook() {
    local exit_code="${1:-0}"
    local message="${2:-}"
    
    if [[ $exit_code -eq 0 ]]; then
        log_info "Hook '$HOOK_NAME' completed successfully${message:+: }$message"
    else
        log_error "Hook '$HOOK_NAME' failed with exit code $exit_code${message:+: }$message"
    fi
}

# ==============================================================================
# EXPORT FUNCTIONS (for use in hooks)
# ==============================================================================

# Export all functions and variables for use in hooks
export -f init_common
export -f detect_platform is_windows is_macos is_linux
export -f get_timestamp get_stack_trace log_message
export -f log_emergency log_fatal log_critical log_error log_warning log_notice log_info log_debug log_trace
export -f rotate_logs_if_needed stat_file_size rotate_log_file clean_old_logs
export -f print_color print_error print_warning print_info print_success print_header print_progress
export -f get_current_branch get_default_branch branch_exists_local branch_exists_remote
export -f is_protected_branch get_staged_files get_staged_content count_commits_since_base
export -f is_rebased_on has_merge_commits fetch_remote_branch
export -f validate_branch_name extract_jira_id validate_commit_message get_base_branch
export -f get_required_source_branch validate_branch_source check_branch_creation_rules
export -f scan_for_secrets is_sensitive_file
export -f get_config get_max_commits is_auto_add_enabled is_parallel_execution_enabled
export -f die exit_success command_exists run_with_timeout trim in_array finalize_hook

# Log that common.sh has been loaded
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    echo "common.sh should be sourced, not executed directly" >&2
    exit 1
fi
