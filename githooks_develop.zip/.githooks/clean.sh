#!/usr/bin/env bash
# Git Hooks Log Cleaner
# Removes old logs and performs log rotation
# Version: 2.0.0

set -euo pipefail

# Colors
readonly COLOR_RESET='\033[0m'
readonly COLOR_GREEN='\033[0;32m'
readonly COLOR_CYAN='\033[0;36m'
readonly COLOR_BOLD='\033[1m'

# Emoji
readonly EMOJI_SUCCESS="✓"
readonly EMOJI_INFO="ℹ"

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GIT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Log directory
LOG_DIR="$GIT_ROOT/.git/hook-logs"

# Default: clean logs older than 21 days
DAYS="${1:-21}"

echo ""
echo -e "${COLOR_CYAN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo -e "${COLOR_CYAN}${COLOR_BOLD}  Git Hooks Log Cleaner${COLOR_RESET}"
echo -e "${COLOR_CYAN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo ""

# ==============================================================================
# CHECK LOG DIRECTORY
# ==============================================================================

if [[ ! -d "$LOG_DIR" ]]; then
    echo -e "${COLOR_CYAN}${EMOJI_INFO} No log directory found. Nothing to clean.${COLOR_RESET}"
    exit 0
fi

# ==============================================================================
# CLEAN OLD LOGS
# ==============================================================================

echo -e "${COLOR_CYAN}${EMOJI_INFO} Cleaning logs older than $DAYS days...${COLOR_RESET}"

# Count files before cleaning
BEFORE_COUNT=$(find "$LOG_DIR" -name "*.log*" 2>/dev/null | wc -l)

# Detect platform and use appropriate find command
if [[ "$(uname -s)" =~ ^(Darwin|Linux) ]]; then
    find "$LOG_DIR" -name "*.log*" -mtime +${DAYS} -delete 2>/dev/null || true
else
    # Windows/Git Bash
    find "$LOG_DIR" -name "*.log*" -mtime +${DAYS} -exec rm -f {} \; 2>/dev/null || true
fi

# Count files after cleaning
AFTER_COUNT=$(find "$LOG_DIR" -name "*.log*" 2>/dev/null | wc -l)

DELETED_COUNT=$((BEFORE_COUNT - AFTER_COUNT))

echo -e "${COLOR_GREEN}${EMOJI_SUCCESS} Deleted $DELETED_COUNT old log files${COLOR_RESET}"

# ==============================================================================
# CALCULATE DISK USAGE
# ==============================================================================

if command -v du >/dev/null 2>&1; then
    DISK_USAGE=$(du -sh "$LOG_DIR" 2>/dev/null | cut -f1)
    echo -e "${COLOR_CYAN}${EMOJI_INFO} Current log directory size: $DISK_USAGE${COLOR_RESET}"
fi

# ==============================================================================
# SUMMARY
# ==============================================================================

echo ""
echo -e "${COLOR_GREEN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo -e "${COLOR_GREEN}${COLOR_BOLD}  Cleanup Complete${COLOR_RESET}"
echo -e "${COLOR_GREEN}${COLOR_BOLD}=======================================${COLOR_RESET}"
echo ""
echo -e "${COLOR_CYAN}${EMOJI_INFO} Log directory: $LOG_DIR${COLOR_RESET}"
echo -e "${COLOR_CYAN}${EMOJI_INFO} Remaining log files: $AFTER_COUNT${COLOR_RESET}"
echo ""
echo -e "${COLOR_CYAN}${EMOJI_INFO} To change the cleanup period:${COLOR_RESET}"
echo -e "  .githooks/clean.sh <days>"
echo ""

exit 0
