#!/usr/bin/env bash
set -euo pipefail

err() { printf "ERROR: %s\n" "$*" >&2; }
info() { printf "→ %s\n" "$*" >&2; }
ok()   { printf "✓ %s\n" "$*" >&2; }

# 0) Preconditions
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  err "Not inside a Git repository."
  exit 1
fi
if [[ ! -d ".githooks" ]]; then
  err "Folder '.githooks' not found at repo root."
  exit 1
fi

ROOT="$(git rev-parse --show-toplevel)"
cd "${ROOT}"

# 1) Core settings (will fail if git config is unavailable)
info "Configuring repo settings…"
git config core.hooksPath .githooks
git config rebase.autosquash true
git config fetch.prune true
if ! git config --get hooks.maxCommits >/dev/null 2>&1; then
  git config hooks.maxCommits 5
fi
ok "Git config updated (hooksPath, autosquash, prune, hooks.maxCommits)"

# 2) Mark hooks executable (STRICT: fail if files missing or chmod fails)
#    Top-level: portable via globs; Library: recursive and portable via 'find' (no -maxdepth).
info "Marking hook scripts executable…"

# Top-level files under .githooks/ (non-recursive)
shopt -s nullglob
top_files=( .githooks/* )
shopt -u nullglob
if ((${#top_files[@]} == 0)); then
  err "No files found in .githooks/. Expected core hook files (e.g., pre-commit, pre-push…)."
  exit 1
fi
chmod +x "${top_files[@]}"
ok "Top-level hooks executable: ${#top_files[@]} file(s)"

# Library files under .githooks/lib (recursive via find; portable on Linux/macOS/Git Bash)
if [[ ! -d ".githooks/lib" ]]; then
  err "Missing '.githooks/lib' directory (expected for shared helpers like lib/common.sh)."
  exit 1
fi

# Collect count first to produce meaningful errors if empty.
lib_count="$(find ".githooks/lib" -type f | wc -l | awk '{print $1}')"
if [[ "${lib_count}" == "0" ]]; then
  err "No files found under .githooks/lib (expected lib/common.sh at minimum)."
  exit 1
fi

# Run chmod for each file; if any chmod fails, the script exits due to 'set -e'.
# (Use ';' instead of '+' for BSD/GNU portability.)
find ".githooks/lib" -type f -exec chmod +x {} \;
ok "Library hooks executable: ${lib_count} file(s)"

# 3) Logging directory (will fail if FS permissions are wrong — intentionally)
info "Preparing log directory…"
mkdir -p .git/hook-logs
EXCLUDE_FILE=".git/info/exclude"
mkdir -p "$(dirname "${EXCLUDE_FILE}")"
touch "${EXCLUDE_FILE}"
# Append only if not already present
if ! grep -qE '^\# hook logs$' "${EXCLUDE_FILE}" 2>/dev/null; then
  {
    echo "# hook logs"
    echo ".git/hook-logs/"
  } >> "${EXCLUDE_FILE}"
fi
ok "Log directory ready at .git/hook-logs"

# 4) Final summary + usage
cat >&2 <<'SUMMARY'
================================================================================
Git hooks installed ✅
================================================================================

WHAT JUST HAPPENED
------------------
• core.hooksPath set to ".githooks"
• rebase.autosquash=true, fetch.prune=true
• hooks.maxCommits set (default 5 if unset)
• All hook scripts under .githooks/ and .githooks/lib/ marked executable
• Log directory created: .git/hook-logs (ignored via .git/info/exclude)

STRICT MODE (this installer)
----------------------------
• Any missing folders/files, permission issues, or chmod failures will stop here
  with an explicit error. This is by design so problems are visible early.

USAGE — DAY-TO-DAY
------------------
1) Create a valid short-lived branch:
     git checkout -b "feature-ABC-123-awesome-update"
   Rejected examples:
     git checkout -b "feat-abc-1-bad"   # wrong format
     git checkout -b "random-branch"    # doesn’t match policy
   (Naming is enforced at push-time by pre-push; you can enable commit-time
    enforcement by adding the optional guard mentioned in docs.)

2) Write a compliant commit subject:
     git commit -m "feat: ABC-123 Add user list pagination"
   Non-compliant subjects are blocked by commit-msg
   (auto "Merge …"/"Revert …" allowed).

3) Push with linear history:
     git push
   If push fails:
     • "Not rebased on base" → git fetch && git rebase origin/develop (or origin/main)
     • "Too many unique commits" → git rebase -i <base> to curate
     • "Merge commits to protected" → rebase locally, then push

SECURITY GUARDS (pre-commit)
----------------------------
• Blocks staged: .env/.env.*, *.pem, *.p12, id_rsa*, *.key
• Secret scan on added lines (AWS, GitHub PAT, Slack, Google, Stripe, password=, Azure)
• Hints if lockfiles or Terraform files changed

LOGGING
-------
• Structured logs to: .git/hook-logs/<hook>.log (rotates ~256KB, keeps 2 archives)
• Clean/rotate/expire (21d):  bash .githooks/clean.sh

KNOBS & BYPASSES
----------------
• Commit limit:                  git config hooks.maxCommits 7
• Enable extras’ timeouts:       git config hooks.enableTimeout true
• Timeout seconds/cmd:           git config hooks.timeoutSeconds 180
                                 git config hooks.timeoutCmd timeout   # or gtimeout on macOS
• Bypass all hooks once (warns): BYPASS_HOOKS=1 git commit -m "…"
• Allow direct commit to protected once: ALLOW_DIRECT_PROTECTED=1 git commit -m "…"

TROUBLESHOOTING (why install can fail)
--------------------------------------
• ".githooks/" missing  → copy the hook suite to repo root.
• No files in ".githooks/" or ".githooks/lib/" → verify you didn’t miss any files.
• Permission denied on chmod/mkdir → fix FS permissions and rerun.
• Git config errors → ensure Git is installed and PATH is correct.

Happy shipping! 🚀
SUMMARY
