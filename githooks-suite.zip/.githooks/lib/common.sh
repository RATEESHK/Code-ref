#!/usr/bin/env bash
# Shared util library for hooks
set -uo pipefail

# ---- Configurable constants ----
LOG_DIR=".git/hook-logs"
MAX_LOG_BYTES=$((256 * 1024)) # rotation threshold ~256KB
DATE_FMT="+%Y-%m-%dT%H:%M:%S%z"

# Regexes
PROTECTED_RE='^(main|develop|release($|/.*))$'
SHORTLIVED_RE='^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$'
COMMIT_SUBJECT_RE='^(feat|fix|chore|break|tests): [A-Z]{2,10}-[0-9]+ .+'

# Allowed auto messages
is_auto_msg() {
  local s="$1"
  [[ "$s" =~ ^Merge[[:space:]] ]] || [[ "$s" =~ ^Revert[[:space:]] ]]
}

# ---- Logging ----
ensure_logdir() { mkdir -p "${LOG_DIR}"; }

bytes_of() { [[ -f "$1" ]] && wc -c <"$1" | awk '{print $1}' || echo 0; }

rotate_if_big() {
  local log="$1"
  local size
  size="$(bytes_of "${log}")"
  if (( size > MAX_LOG_BYTES )); then
    local base="${log%*.log}"
    [[ -f "${base}.log.2" ]] && rm -f "${base}.log.2"
    [[ -f "${base}.log.1" ]] && mv -f "${base}.log.1" "${base}.log.2"
    [[ -f "${base}.log"   ]] && mv -f "${base}.log"   "${base}.log.1"
    : > "${base}.log"
  fi
}

log_line() {
  # usage: log_line <hook> <level> <message...>
  local hook="$1"; shift
  local level="$1"; shift
  ensure_logdir
  local ts; ts="$(date "${DATE_FMT}")"
  local log="${LOG_DIR}/${hook}.log"
  rotate_if_big "${log}"
  printf "%s\t%s\t%s\t%s\n" "${ts}" "${hook}" "${level}" "$*" >> "${log}"
}

# ---- Git helpers ----
branch_name() {
  git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "HEAD"
}

is_protected_branch() {
  local b="${1:-$(branch_name)}"
  [[ "${b}" =~ ${PROTECTED_RE} ]]
}

is_shortlived_branch() {
  local b="${1:-$(branch_name)}"
  [[ "${b}" =~ ${SHORTLIVED_RE} ]]
}

config_get() {
  # usage: config_get key default
  local key="$1" def="${2:-}"
  local val
  if val="$(git config --get "${key}" 2>/dev/null)"; then
    printf "%s" "${val}"
  else
    printf "%s" "${def}"
  fi
}

config_bool() {
  # usage: config_bool key defaultBool
  local key="$1" def="${2:-false}"
  local val; val="$(git config --type=bool --get "${key}" 2>/dev/null || echo "${def}")"
  [[ "${val}" == "true" ]]
}

# ---- Staged inspection ----
staged_files() { # prints one per line
  git diff --cached --name-only --diff-filter=ACMR
}

staged_added_lines() { # added lines only, excluding diff headers
  git diff --cached --unified=0 --no-color | sed -n '/^+/p' | sed '/^+++ /d;s/^+//'
}

# ---- Guards & scans ----
guard_sensitive_files() {
  local hook="${1}"
  local bad=()
  while IFS= read -r f; do
    [[ -z "$f" ]] && continue
    case "$f" in
      .env|.env.*|*.pem|*.p12|id_rsa*|*.key)
        bad+=("$f")
        ;;
    esac
  done < <(staged_files)

  if (( ${#bad[@]} )); then
    log_line "${hook}" "ERROR" "Sensitive files staged: ${bad[*]}"
    {
      echo "❌ Sensitive files blocked:"
      for x in "${bad[@]}"; do echo "   - $x"; done
      echo "   Remove from index (git restore --staged <file>) and use safe secrets management."
    } >&2
    return 1
  fi
}

scan_secrets_fast() {
  local hook="${1}"
  local hits=0
  # Fast patterns (added lines only)
  local re_list=(
    'AKIA[0-9A-Z]{16}'                                      # AWS Access Key ID
    'aws(.{0,20})?(secret|access)[^A-Za-z0-9]?([0-9a-zA-Z/+]{40})' # AWS secret-ish
    'gh[pous]_[A-Za-z0-9]{36,}'                             # GitHub PATs
    'xox[baprs]-[A-Za-z0-9-]{10,48}'                        # Slack token
    'AIza[0-9A-Za-z_\\-]{35}'                                # Google API key
    'sk_(live|test)_[0-9A-Za-z]{24,}'                       # Stripe secret key
    '-----BEGIN[[:space:]]+(RSA|DSA|EC|OPENSSH)?[[:space:]]*PRIVATE KEY-----'
    '(?i)password[[:space:]]*='                             # simple password=
    'AccountKey=|SharedAccessKey='                          # Azure/Storage
  )

  local lines
  lines="$(staged_added_lines || true)"
  if [[ -z "${lines}" ]]; then
    return 0
  fi

  for re in "${re_list[@]}"; do
    if echo "${lines}" | grep -E -q -- "${re}"; then
      ((hits++))
      break
    fi
  done

  if (( hits > 0 )); then
    log_line "${hook}" "ERROR" "Secret patterns detected in added lines."
    cat >&2 <<'EOF'
❌ Potential secret detected in staged changes (added lines).
   If this is a false positive, rotate credentials and commit a remediation.
   Tip: Add allowlist comments only after security review; do not commit secrets.
EOF
    return 1
  fi
}

hint_lockfiles_and_terraform() {
  local changed
  changed="$(staged_files | tr '\n' ' ' )"
  local hint=()
  [[ "${changed}" =~ (^|[[:space:]])(package-lock\.json|yarn\.lock|pnpm-lock\.yaml)($|[[:space:]]) ]] && hint+=("dependency lockfile changed")
  echo "${changed}" | grep -Eq '(^|[[:space:]])(.+\.tf|.+\.tfvars)($|[[:space:]])' && hint+=("Terraform files changed")
  if (( ${#hint[@]} )); then
    echo "ℹ️  Hint: ${hint[*]}" >&2
  fi
}

# ---- Base rules ----
compute_base_for_branch() {
  local b="${1:-$(branch_name)}"
  local prefix="${b%%-*}"  # text before first '-'
  case "${prefix}" in
    feature|bugfix|techdebt) echo "origin/develop" ;;
    hotfix)                  echo "origin/main"    ;;
    *)                       echo ""               ;;
  esac
}

ensure_fetched_ref() {
  local ref="$1"
  local remote="${ref%%/*}"
  git rev-parse --verify -q "${ref}" >/dev/null 2>&1 || git fetch "${remote}" --no-tags --prune
}

# ---- Linear checks ----
is_ancestor_of_head() {
  local base="$1"
  git merge-base --is-ancestor "${base}" HEAD
}

count_unique_commits_no_merges() {
  local range="$1" # e.g., base..HEAD
  git rev-list --count --no-merges "${range}"
}

has_merge_commits_in_range() {
  local range="$1"
  git rev-list --merges --count "${range}" | grep -qv '^0$'
}

# ---- Extension runner ----
run_extension_if_exists() {
  # usage: run_extension_if_exists <hook> <funcname> [args...]
  local hook="$1" fn="$2"; shift 2
  if [[ -f ".githooks/run-commands.sh" ]]; then
    # shellcheck disable=SC1091
    source ".githooks/run-commands.sh"
    if declare -F "${fn}" >/dev/null 2>&1; then
      "${fn}" "$@"
      return $?
    fi
  fi
  return 0
}
