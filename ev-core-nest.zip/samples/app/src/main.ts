import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { Module, Controller, Get } from '@nestjs/common';
import { LoggingModule, LoggerService } from '../../../src/logging';
import { AllExceptionsFilter, LoggingInterceptor, CorrelationIdMiddleware } from '../../../src/http';
import { APP_FILTER, APP_INTERCEPTOR } from '@nestjs/core';
import { VersionService } from '../../../src/version';

@Controller('health')
class HealthController {
  @Get()
  ok() { return { ok: true }; }
}

@Controller('version')
class VersionController {
  constructor(private readonly version: VersionService) {}
  @Get()
  v() { return { name: this.version.name, version: this.version.version }; }
}

@Module({
  imports: [
    LoggingModule.forRoot({ service: process.env.SERVICE_NAME || 'sample', version: process.env.SERVICE_VERSION || '0.1.0' }),
  ],
  controllers: [HealthController, VersionController],
  providers: [
    VersionService,
    { provide: APP_FILTER, useClass: AllExceptionsFilter },
    { provide: APP_INTERCEPTOR, useClass: LoggingInterceptor },
  ]
})
class AppModule {}

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { logger: false });
  app.use(new CorrelationIdMiddleware().use);
  await app.listen(process.env.PORT || 3005);
  const logger = app.get(LoggerService);
  logger.info('sample_app_started', { ctx: { port: process.env.PORT || 3005 } });
}
bootstrap();
