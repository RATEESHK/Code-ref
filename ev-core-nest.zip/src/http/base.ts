export interface ErrorEnvelope { code: string; message: string; meta?: any }
export interface BaseResponse<T> { correlationId?: string; data?: T; error?: ErrorEnvelope }
