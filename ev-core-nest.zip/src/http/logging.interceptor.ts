import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable, tap } from 'rxjs';
import { requestContext } from './correlation.context';
import { LoggerService } from '../logging';

@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  constructor(private readonly logger: LoggerService) {}
  intercept(ctx: ExecutionContext, next: CallHandler): Observable<any> {
    const http = ctx.switchToHttp();
    const req = http.getRequest();
    const { method, url } = req;
    const rc = requestContext.getStore();
    const correlationId = rc?.correlationId || req.correlationId;
    const start = Date.now();
    return next.handle().pipe(
      tap({
        next: () => this.logger.info('request_ok', { correlationId, ctx: { method, url, ms: Date.now() - start } }),
        error: (e) => this.logger.error('request_error', { correlationId, ctx: { method, url, ms: Date.now() - start }, err: { name: e?.name, message: e?.message, stack: e?.stack } }),
      })
    );
  }
}
