export class ApiServiceException extends Error { constructor(message: string, public status?: number, public body?: any) { super(message); } }
export class ApiServiceBadRequestException extends ApiServiceException {}
export class ApiServiceUnauthorisedException extends ApiServiceException {}
export class ApiServiceForbiddenException extends ApiServiceException {}
export class ApiServiceNotFoundException extends ApiServiceException {}
export class ApiServiceConflictException extends ApiServiceException {}
export class ApiServiceInternalServerErrorException extends ApiServiceException {}
