import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import axiosRetry from 'axios-retry';
import { requestContext } from '../http/correlation.context';
import { buildRetryPolicy } from './retry-policy.builder';

export class ApiService {
  private readonly client: AxiosInstance;
  constructor(client?: AxiosInstance) {
    this.client = client ?? axios.create({ timeout: 30000 });
    axiosRetry(this.client, buildRetryPolicy());
  }

  private withCorrelation(cfg: AxiosRequestConfig) {
    const rc = requestContext.getStore();
    return { ...cfg, headers: { 'x-correlation-id': rc?.correlationId, ...(cfg.headers || {}) } };
    }

  async request<T>(cfg: AxiosRequestConfig): Promise<T> {
    const res = await this.client.request(this.withCorrelation(cfg));
    return res.data as T;
  }

  async get<T>(url: string, headers?: Record<string, string>): Promise<T> {
    return this.request<T>({ method: 'GET', url, headers });
  }

  async post<T>(url: string, data?: any, headers?: Record<string, string>): Promise<T> {
    return this.request<T>({ method: 'POST', url, data, headers });
  }
}
