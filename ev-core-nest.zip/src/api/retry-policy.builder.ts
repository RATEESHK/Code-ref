import { IAxiosRetryConfig } from 'axios-retry';
export function buildRetryPolicy(): IAxiosRetryConfig {
  return {
    retries: 3,
    retryDelay: (retryCount) => Math.min(1000 * Math.pow(2, retryCount), 4000),
    retryCondition: (error) => {
      const status = error.response?.status;
      return !status || (status >= 500 && status < 600);
    }
  }
}
