export interface IApiGwSettings { baseUrl: string; apiKey?: string; tenantId?: string; }

export interface IApiGatewayAuthSettings {
  assetManagement?: IApiGwSettings;
  billing?: IApiGwSettings;
  cpo?: IApiGwSettings;
  customerManagement?: IApiGwSettings;
  ocpi?: IApiGwSettings;
  shared?: IApiGwSettings;
}

export class ApiGatewayAuthProvider {
  constructor(private readonly settings: IApiGatewayAuthSettings) {}
  for(service: keyof IApiGatewayAuthSettings): { baseUrl?: string; headers: Record<string,string> } {
    const s = (this.settings[service] as IApiGwSettings) || this.settings.shared;
    if (!s) return { headers: {} };
    return { baseUrl: s.baseUrl, headers: { 'x-api-key': s.apiKey || '', 'x-tenant-id': s.tenantId || '' } };
  }
}
