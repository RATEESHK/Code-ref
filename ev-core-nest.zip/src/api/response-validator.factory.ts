export type ResponseValidator = (status: number, data: any) => boolean;

// example factory — extend as needed
export const ApiResponseValidatorFactory = {
  jsonOk: (): ResponseValidator => (status, data) => status >= 200 && status < 300 && data !== undefined,
};
