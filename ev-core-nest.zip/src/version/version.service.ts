import { Injectable } from '@nestjs/common';
@Injectable()
export class VersionService {
  get version() { return process.env.SERVICE_VERSION || '0.1.0'; }
  get name() { return process.env.SERVICE_NAME || 'ev-core-service'; }
}
