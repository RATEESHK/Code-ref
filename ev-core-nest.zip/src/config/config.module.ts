import { Module } from '@nestjs/common';
import { ConfigModule as NestConfigModule } from '@nestjs/config';
import * as Joi from 'joi';

@Module({
  imports: [NestConfigModule.forRoot({
    isGlobal: true,
    validationSchema: Joi.object({
      SERVICE_NAME: Joi.string().default('ev-core-service'),
      SERVICE_VERSION: Joi.string().default('0.1.0'),
      REDIS_URL: Joi.string().default('redis://localhost:6379')
    }),
  })]
})
export class ConfigModule {}
