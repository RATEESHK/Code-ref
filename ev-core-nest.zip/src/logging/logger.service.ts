import { Injectable } from '@nestjs/common';
import { LogEntry, LogLevel, LogEnricher, LogSink } from './log.types';

const levelOrder: LogLevel[] = ['trace','debug','info','warn','error','fatal'];
function allows(level: LogLevel, min: LogLevel) {
  return levelOrder.indexOf(level) >= levelOrder.indexOf(min);
}

export interface LoggerOptions {
  service: string;
  version: string;
  minLevel?: LogLevel;
  enrichers?: LogEnricher[];
  sinks?: LogSink[];
}

@Injectable()
export class LoggerService {
  private readonly service: string;
  private readonly version: string;
  private readonly minLevel: LogLevel;
  private readonly enrichers: LogEnricher[];
  private readonly sinks: LogSink[];

  constructor(opts: LoggerOptions) {
    this.service = opts.service;
    this.version = opts.version;
    this.minLevel = opts.minLevel ?? 'info';
    this.enrichers = opts.enrichers ?? [];
    this.sinks = (opts.sinks ?? []);
  }

  private base(level: LogLevel, msg: string, data?: Partial<LogEntry>): LogEntry {
    return { ts: new Date().toISOString(), level, msg, service: this.service, version: this.version, ...data };
  }

  private emit(entry: LogEntry) {
    if (!allows(entry.level, this.minLevel)) return;
    const enriched = this.enrichers.reduce((acc, e) => e.enrich(acc), entry);
    for (const sink of this.sinks) if (allows(enriched.level, sink.minLevel)) sink.write(enriched);
  }

  log(level: LogLevel, msg: string, data?: Partial<LogEntry>) { this.emit(this.base(level, msg, data)); }
  fatal(msg: string, data?: Partial<LogEntry>) { this.log('fatal', msg, data); }
  error(msg: string, data?: Partial<LogEntry>) { this.log('error', msg, data); }
  warn (msg: string, data?: Partial<LogEntry>) { this.log('warn' , msg, data); }
  info (msg: string, data?: Partial<LogEntry>) { this.log('info' , msg, data); }
  debug(msg: string, data?: Partial<LogEntry>) { this.log('debug', msg, data); }
  trace(msg: string, data?: Partial<LogEntry>) { this.log('trace', msg, data); }
}
