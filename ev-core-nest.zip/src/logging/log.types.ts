export type LogLevel = 'fatal' | 'error' | 'warn' | 'info' | 'debug' | 'trace';

export interface LogEntry {
  ts: string;
  level: LogLevel;
  msg: string;
  service: string;
  version: string;
  correlationId?: string;
  traceId?: string;
  spanId?: string;
  tenantId?: string;
  userId?: string;
  ctx?: Record<string, unknown>;
  err?: { name: string; message: string; stack?: string; code?: string };
  tags?: string[];
  event?: string;
}

export interface LogEnricher { enrich(entry: LogEntry): LogEntry; }
export interface LogSink { minLevel: LogLevel; write(entry: LogEntry): void; }
