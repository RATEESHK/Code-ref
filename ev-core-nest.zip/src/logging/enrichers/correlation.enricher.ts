import { LogEnricher, LogEntry } from '../log.types';
import { requestContext } from '../../http/correlation.context';

export class CorrelationEnricher implements LogEnricher {
  enrich(entry: LogEntry): LogEntry {
    const rc = requestContext.getStore();
    return { ...entry, correlationId: rc?.correlationId ?? entry.correlationId };
  }
}
