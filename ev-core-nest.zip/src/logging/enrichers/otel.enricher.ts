import { context, trace } from '@opentelemetry/api';
import { LogEnricher, LogEntry } from '../log.types';

export class OtelIdsEnricher implements LogEnricher {
  enrich(entry: LogEntry): LogEntry {
    const span = trace.getSpan(context.active());
    const spanCtx = span?.spanContext();
    if (!spanCtx) return entry;
    return { ...entry, traceId: spanCtx.traceId, spanId: spanCtx.spanId };
  }
}
