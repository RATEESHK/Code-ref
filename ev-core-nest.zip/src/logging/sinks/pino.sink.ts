import pino from 'pino';
import { LogSink, LogEntry, LogLevel } from '../log.types';

export class PinoSink implements LogSink {
  public readonly minLevel: LogLevel;
  private readonly logger: pino.Logger;
  constructor(minLevel: LogLevel = 'info', pretty = process.env.NODE_ENV === 'development') {
    this.minLevel = minLevel;
    this.logger = pino({ level: 'trace', transport: pretty ? { target: 'pino-pretty', options: { colorize: true } } : undefined });
  }
  write(entry: LogEntry): void {
    const { err, ...rest } = entry;
    const map = { trace: this.logger.trace.bind(this.logger), debug: this.logger.debug.bind(this.logger),
      info: this.logger.info.bind(this.logger), warn: this.logger.warn.bind(this.logger),
      error: this.logger.error.bind(this.logger), fatal: this.logger.fatal.bind(this.logger) };
    if (err) map['error']({ ...rest, err }, entry.msg); else map[entry.level](rest, entry.msg);
  }
}
