import { DynamicModule, Module } from '@nestjs/common';
import { LoggerService, LoggerOptions } from './logger.service';
import { PinoSink } from './sinks/pino.sink';
import { CorrelationEnricher } from './enrichers/correlation.enricher';
import { OtelIdsEnricher } from './enrichers/otel.enricher';

@Module({})
export class LoggingModule {
  static forRoot(opts: Partial<LoggerOptions> & { service: string; version: string }): DynamicModule {
    const providers = [{
      provide: LoggerService,
      useFactory: () => new LoggerService({
        service: opts.service,
        version: opts.version,
        minLevel: opts.minLevel ?? (process.env.LOG_LEVEL as any) ?? 'info',
        enrichers: opts.enrichers ?? [new CorrelationEnricher(), new OtelIdsEnricher()],
        sinks:     opts.sinks     ?? [new PinoSink('info')]
      })
    }];
    return { module: LoggingModule, providers, exports: providers };
  }
}
