export interface DynamoKey { pk: string; sk?: string; }
