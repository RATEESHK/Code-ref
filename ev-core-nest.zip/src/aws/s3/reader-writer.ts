import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
export class S3ReaderWriter {
  private readonly s3: S3Client;
  constructor(cfg?: { region?: string }) {
    this.s3 = new S3Client({ region: cfg?.region || process.env.AWS_REGION || 'us-east-1' });
  }
  async put(bucket: string, key: string, body: Buffer | string) {
    await this.s3.send(new PutObjectCommand({ Bucket: bucket, Key: key, Body: body }));
  }
  async get(bucket: string, key: string) {
    const res = await this.s3.send(new GetObjectCommand({ Bucket: bucket, Key: key }));
    return res.Body as any;
  }
}
