# ev-core-nest

A **NestJS/TypeScript** port of `EV.Core` with idiomatic modules and DI.
This library provides **logging**, **HTTP pipeline (correlation, exceptions)**, **API client with retry**, **validators**,
**base request/response envelope**, **AWS (DynamoDB/S3) adapters**, **version service**, and **setup modules**.

> Install it as a library or copy this repo as a starting point for your services.

## Quick start

```bash
npm install
npm run build
npm run sample   # runs the sample Nest app using ev-core-nest
```

## Modules

- `LoggingModule` — structured logging (Pino) + OTel ids enrichment
- `HttpModule` — correlation-id middleware, exception filter, logging interceptor, idempotency middleware (Redis)
- `ApiModule` — `ApiService` with retry policy and request builder, response validator factory
- `AwsModule` — DynamoDB/S3 thin adapters (AWS SDK v3)
- `Validation` — `IsGuid`, domain validator hooks
- `VersionModule` — version provider
- `Config` — environment schema validation via Joi

## Mapping from EV.Core (C#) to Nest/TS

- **ApiService\<T\>** → `ApiService` + `HttpRequestBuilder` + `RetryPolicyBuilder`
- **FluentValidation** → `class-validator` decorators (`IsGuid`, domain validators)
- **Serilog** → Pino sink via `LoggerService` with enrichers
- **DI Setup** (`SetupDi*`) → Nest dynamic modules (`forRoot()`)
- **BaseResponse / ErrorResponse** → `BaseResponse<T>` union with `ErrorEnvelope`
- **DynamoDbReaderWriter** → `DynamoDbReaderWriter` using v3 DocClient
- **VersionProvider** → `VersionService`

