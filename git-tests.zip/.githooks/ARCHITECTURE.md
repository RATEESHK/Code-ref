# Git Flow Hook Suite - Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       GIT FLOW HOOK SUITE ARCHITECTURE                      │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                              GIT OPERATIONS                                 │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐     │
│  │git commit│  │ git push │  │git checkout│ git merge │  │git rebase│     │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘     │
└───────┼─────────────┼─────────────┼─────────────┼─────────────┼────────────┘
        │             │             │             │             │
        ▼             ▼             ▼             ▼             ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            GIT HOOK TRIGGERS                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │ pre-commit   │  │  pre-push    │  │post-checkout │  │  pre-rebase  │   │
│  │              │  │              │  │              │  │              │   │
│  │ • Protected  │  │ • Branch     │  │ • Protected  │  │ • Protect    │   │
│  │   branch     │  │   naming     │  │   warnings   │  │   branches   │   │
│  │   check      │  │ • History    │  │ • Git Flow   │  │              │   │
│  │ • Custom     │  │   limits     │  │   guidance   │  │              │   │
│  │   commands   │  │ • Linear     │  │              │  │              │   │
│  │              │  │   history    │  │              │  │              │   │
│  └──────┬───────┘  └──────┬───────┘  └──────────────┘  └──────────────┘   │
│         │                 │                                                │
│  ┌──────▼────────┐  ┌─────▼──────┐  ┌──────────────┐  ┌──────────────┐   │
│  │prepare-commit-│  │ commit-msg │  │ post-merge   │  │post-rewrite  │   │
│  │     msg       │  │            │  │              │  │              │   │
│  │              │  │ • Format   │  │ • Smart      │  │ • Force push │   │
│  │ • Auto-      │  │   validate │  │   hints      │  │   reminder   │   │
│  │   populate   │  │ • JIRA ID  │  │              │  │              │   │
│  │   JIRA IDs   │  │   check    │  │              │  │              │   │
│  └──────────────┘  └────────────┘  └──────────────┘  └──────────────┘   │
│                                                                             │
└──────────────────────────────────┬──────────────────────────────────────────┘
                                   │
                                   │ All hooks source
                                   ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         SHARED LIBRARY (lib/common.sh)                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐            │
│  │    Logging      │  │  Validation     │  │   Git Flow      │            │
│  │                 │  │                 │  │                 │            │
│  │ • log_info()    │  │ • Branch names  │  │ • get_base()    │            │
│  │ • log_error()   │  │ • Commit msgs   │  │ • is_protected()│            │
│  │ • log_warn()    │  │ • JIRA IDs      │  │ • count_commits │            │
│  │ • Stack traces  │  │ • Patterns      │  │ • has_merges()  │            │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘            │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐            │
│  │ Error Messages  │  │  Configuration  │  │ Smart Detection │            │
│  │                 │  │                 │  │                 │            │
│  │ • Formatted     │  │ • get_config()  │  │ • Lockfiles     │            │
│  │ • Contextual    │  │ • Defaults      │  │ • IaC files     │            │
│  │ • Fix commands  │  │ • Per-repo      │  │ • CI/CD config  │            │
│  │ • Color coded   │  │ • Git Flow      │  │ • Auto hints    │            │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘            │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────┐           │
│  │              Command Execution Framework                    │           │
│  │                                                             │           │
│  │  • execute_commands() - Run custom linting/testing         │           │
│  │  • Priority-based execution                                │           │
│  │  • Timeout support                                         │           │
│  │  • Parallel execution option                               │           │
│  │  • Auto-staging after fixes                                │           │
│  └─────────────────────────────────────────────────────────────┘           │
│                                                                             │
└──────────────────────────────────┬──────────────────────────────────────────┘
                                   │
                                   │ Reads configuration
                                   ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                       CONFIGURATION & DATA FILES                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐            │
│  │  commands.conf  │  │  Git Config     │  │   Hook Logs     │            │
│  │                 │  │                 │  │                 │            │
│  │ • Custom cmds   │  │ • maxCommits    │  │ • pre-commit    │            │
│  │ • Priorities    │  │ • autoAddFix    │  │ • pre-push      │            │
│  │ • Timeouts      │  │ • parallelExec  │  │ • commit-msg    │            │
│  │ • Mandatory     │  │ • hooksPath     │  │ • Timestamps    │            │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│                          GIT FLOW BRANCHING MODEL                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│         main (production)                                                   │
│           │                                                                 │
│           ├─── tag: v1.0.0                                                  │
│           │                                                                 │
│           │◄────────── release/1.0.0 ◄───────┐                              │
│           │                 │                 │                              │
│           │                 │                 │                              │
│           │◄───── hotfix-PROJ-789 ◄───┐      │                              │
│           │           │               │      │                              │
│           │           │               │      │                              │
│         develop       │               │      │                              │
│           │◄──────────┴───────────────┘      │                              │
│           │                                  │                              │
│           ├──── feat-PROJ-123-feature ───────┘                              │
│           │                                                                 │
│           ├──── bugfix-PROJ-456-fix                                         │
│           │                                                                 │
│           ├──── docs-PROJ-789-docs                                          │
│           │                                                                 │
│                                                                             │
│  Enforced by hooks:                                                         │
│  • Features/bugfixes branch from develop                                    │
│  • Hotfixes branch from main                                                │
│  • Releases branch from develop, merge to main + develop                    │
│  • Linear history (no merge commits on feature branches)                    │
│  • Max commits per branch (default: 5)                                      │
│  • Protected branches (no direct commits)                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│                         VALIDATION FLOW DIAGRAM                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Developer runs: git commit                                                 │
│         │                                                                   │
│         ▼                                                                   │
│  ┌──────────────┐                                                           │
│  │ pre-commit   │                                                           │
│  └──────┬───────┘                                                           │
│         │                                                                   │
│         ├─► Is protected branch? ──Yes──► Block (unless bypass)             │
│         │         │                                                         │
│         │         No                                                        │
│         │         │                                                         │
│         ├─► Run custom commands ──Fail──► Block with details               │
│         │         │                                                         │
│         │         Pass                                                      │
│         │         │                                                         │
│         ▼         ▼                                                         │
│  ┌──────────────────────┐                                                   │
│  │ prepare-commit-msg   │                                                   │
│  └──────┬───────────────┘                                                   │
│         │                                                                   │
│         ├─► Extract JIRA ID from branch                                     │
│         │                                                                   │
│         ├─► Auto-populate commit message                                    │
│         │                                                                   │
│         ▼                                                                   │
│  [Commit message editor]                                                    │
│         │                                                                   │
│         ▼                                                                   │
│  ┌──────────────┐                                                           │
│  │ commit-msg   │                                                           │
│  └──────┬───────┘                                                           │
│         │                                                                   │
│         ├─► Validate format ──Invalid──► Block with examples               │
│         │         │                                                         │
│         │         Valid                                                     │
│         │         │                                                         │
│         ▼         ▼                                                         │
│  ✅ Commit created!                                                          │
│                                                                             │
│  Developer runs: git push                                                   │
│         │                                                                   │
│         ▼                                                                   │
│  ┌──────────────┐                                                           │
│  │  pre-push    │                                                           │
│  └──────┬───────┘                                                           │
│         │                                                                   │
│         ├─► Validate branch name ──Invalid──► Block with fix commands      │
│         │         │                                                         │
│         │         Valid                                                     │
│         │         │                                                         │
│         ├─► Check branch source ──Wrong──► Block with correct workflow     │
│         │         │                                                         │
│         │         Correct                                                   │
│         │         │                                                         │
│         ├─► Count commits ──Too many──► Block with squash guide            │
│         │         │                                                         │
│         │         OK                                                        │
│         │         │                                                         │
│         ├─► Check for merges ──Found──► Block with rebase guide            │
│         │         │                                                         │
│         │         None                                                      │
│         │         │                                                         │
│         ├─► Run custom commands ──Fail──► Block with errors                │
│         │         │                                                         │
│         │         Pass                                                      │
│         │         │                                                         │
│         ▼         ▼                                                         │
│  ✅ Push successful!                                                         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│                        ERROR MESSAGE STRUCTURE                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ═══════════════════════════════════════════                                │
│  Hook: pre-push FAILED                                                      │
│  ═══════════════════════════════════════════                                │
│                                                                             │
│  ❌ Invalid branch name: invalid-branch                                     │
│                                                                             │
│  Branch naming policy enforces Git Flow strategy:                           │
│                                                                             │
│  Long-lived branches (infinite lifetime)                                    │
│    Pattern: ^(main|develop|release($|/.*))$                                 │
│    Examples: main, develop, release/1.0.0                                   │
│                                                                             │
│  Short-lived branches (temporary)                                           │
│    Pattern: <type>-<JIRA-ID>-<description>                                  │
│    Examples:                                                                │
│      • feat-PROJ-123-add-user-authentication                                │
│      • bugfix-JIRA-456-fix-login-timeout                                    │
│                                                                             │
│  Git Flow Branching Rules                                                   │
│    1. Feature branches MUST branch from 'develop'                           │
│    2. Hotfix branches MUST branch from 'main'                               │
│                                                                             │
│  How to fix                                                                 │
│    1. Rename your branch:                                                   │
│       git branch -m invalid-branch feat-PROJ-123-description                │
│                                                                             │
│    2. Update remote:                                                        │
│       git push origin --delete invalid-branch                               │
│       git push origin -u feat-PROJ-123-description                          │
│                                                                             │
│  Current Git State                                                          │
│    Current branch: invalid-branch                                           │
│    Should branch from: develop                                              │
│                                                                             │
│  To bypass (emergency only): BYPASS_HOOKS=1 git push                        │
│  ═══════════════════════════════════════════                                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│                    BYPASS & EMERGENCY MECHANISMS                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Normal operation:                                                          │
│    git commit  ──► All hooks run ──► Validation ──► ✅ or ❌                │
│                                                                             │
│  Emergency bypass (skip ALL hooks):                                         │
│    BYPASS_HOOKS=1 git commit  ──► No hooks run ──► ✅ Always succeeds       │
│                                                                             │
│  Protected branch bypass:                                                   │
│    ALLOW_DIRECT_PROTECTED=1 git commit  ──► Allows protected commits        │
│                                                                             │
│  Note: All bypasses are logged for audit trail                             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│                    INSTALLATION & CONFIGURATION FLOW                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  1. Developer clones repository                                             │
│         │                                                                   │
│         ▼                                                                   │
│  2. Run installer: .githooks/install-hooks.sh                               │
│         │                                                                   │
│         ├─► Set core.hooksPath = .githooks                                  │
│         │                                                                   │
│         ├─► Configure Git Flow settings                                     │
│         │   • rebase.autosquash = true                                      │
│         │   • fetch.prune = true                                            │
│         │   • pull.rebase = true                                            │
│         │                                                                   │
│         ├─► Initialize hook settings                                        │
│         │   • hooks.maxCommits = 5                                          │
│         │   • hooks.autoAddAfterFix = false                                 │
│         │   • hooks.parallelExecution = false                               │
│         │                                                                   │
│         ├─► Make hooks executable (Unix)                                    │
│         │                                                                   │
│         ├─► Create log directory                                            │
│         │                                                                   │
│         ├─► Add logs to .git/info/exclude                                   │
│         │                                                                   │
│         ▼                                                                   │
│  3. Verify installation                                                     │
│         │                                                                   │
│         ▼                                                                   │
│  4. ✅ Hooks active and enforcing Git Flow                                   │
│                                                                             │
│  Customization (optional):                                                  │
│    • Edit commands.conf for custom linting/testing                          │
│    • Adjust git config hooks.* settings                                     │
│    • Add team-specific patterns                                             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

```

## Legend

| Symbol | Meaning |
|--------|---------|
| `│` | Flow continues |
| `▼` | Flows downward |
| `►` | Flows rightward |
| `◄` | Flows leftward |
| `├─►` | Decision point |
| `✅` | Success / Allowed |
| `❌` | Failure / Blocked |
| `⚠️` | Warning |

## Components Overview

1. **Git Hooks**: Entry points triggered by Git operations
2. **Shared Library**: Reusable functions and logic
3. **Configuration**: Settings and custom commands
4. **Git Flow Model**: Visual representation of branching strategy
5. **Validation Flow**: Step-by-step hook execution
6. **Error Messages**: Structured, helpful output format
7. **Bypass Mechanisms**: Emergency overrides
8. **Installation Flow**: Setup process
