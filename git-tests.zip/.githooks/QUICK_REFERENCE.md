# Git Flow Hook Suite - Quick Reference

## 🚀 Installation

```bash
# Unix-like systems (Linux, macOS, Git Bash on Windows)
.githooks/install-hooks.sh

# Windows (Command Prompt)
.githooks\install-hooks.bat
```

## 🌿 Branch Naming

### Format
```
<type>-<JIRA-ID>-<description>
```

### Examples
```bash
feat-PROJ-123-add-user-authentication
bugfix-JIRA-456-fix-login-timeout
hotfix-APP-789-patch-security-vulnerability
docs-WIKI-101-update-api-documentation
refactor-TECH-202-modernize-database-layer
```

### Types
- `feat/feature` → New features (from develop)
- `bugfix/fix` → Bug fixes (from develop)
- `hotfix` → Critical fixes (from main)
- `release` → Release prep (from develop)
- `docs` → Documentation
- `test` → Testing
- `refactor` → Code refactoring
- `perf` → Performance
- `chore` → Maintenance
- `build/ci/style/techdebt/revert`

## 💬 Commit Messages

### Format
```
<type>: <JIRA-ID> <description>
```

### Examples
```
feat: PROJ-123 Add user authentication module
fix: JIRA-456 Resolve login timeout issue
chore: TASK-789 Update dependencies
break: API-101 Remove deprecated endpoints
tests: TEST-202 Add payment processor tests
```

### Types
`feat`, `fix`, `chore`, `break`, `tests`, `build`, `ci`, `docs`, `perf`, `refactor`, `style`, `test`

## 🔄 Git Flow Workflows

### Feature Development
```bash
# 1. Start from develop
git checkout develop
git pull origin develop

# 2. Create feature branch
git checkout -b feat-PROJ-123-add-feature

# 3. Make changes
git add .
git commit -m "feat: PROJ-123 Add feature"

# 4. Keep updated (rebase, don't merge)
git fetch origin
git rebase origin/develop

# 5. Push
git push -u origin feat-PROJ-123-add-feature

# 6. After PR approval, merge with --no-ff
git checkout develop
git merge --no-ff feat-PROJ-123-add-feature
git push origin develop
```

### Hotfix (Critical Production Fix)
```bash
# 1. Start from main
git checkout main
git pull origin main

# 2. Create hotfix branch
git checkout -b hotfix-PROJ-456-fix-critical-bug

# 3. Fix and commit
git add .
git commit -m "fix: PROJ-456 Resolve critical issue"

# 4. Push
git push -u origin hotfix-PROJ-456-fix-critical-bug

# 5. After PR approval, merge to BOTH main and develop
git checkout main
git merge --no-ff hotfix-PROJ-456-fix-critical-bug
git tag -a v1.0.1 -m "Hotfix release 1.0.1"
git push origin main --tags

git checkout develop
git merge --no-ff hotfix-PROJ-456-fix-critical-bug
git push origin develop
```

### Release Preparation
```bash
# 1. Start from develop
git checkout develop
git pull origin develop

# 2. Create release branch
git checkout -b release/1.0.0

# 3. Bug fixes and version bumps only
git commit -m "fix: PROJ-789 Release preparation"

# 4. When ready, merge to main and develop
git checkout main
git merge --no-ff release/1.0.0
git tag -a v1.0.0 -m "Release 1.0.0"
git push origin main --tags

git checkout develop
git merge --no-ff release/1.0.0
git push origin develop

# 5. Delete release branch
git branch -d release/1.0.0
```

## 📦 Squashing Commits

### Interactive Rebase (Recommended)
```bash
# 1. Rebase onto base branch
git rebase -i develop

# 2. In editor, mark commits to squash
pick abc1234 First commit
squash def5678 Second commit  # Change 'pick' to 'squash'
squash ghi9012 Third commit   # Change 'pick' to 'squash'

# 3. Save, edit final message

# 4. Force push safely
git push --force-with-lease
```

### Soft Reset
```bash
# 1. Reset to base, keep changes staged
git reset --soft $(git merge-base develop HEAD)

# 2. Create single commit
git commit -m "feat: PROJ-123 Complete feature"

# 3. Force push
git push --force-with-lease
```

## ⚙️ Configuration

```bash
# Adjust commit limit (default: 5)
git config hooks.maxCommits 10

# Enable auto-staging after linting fixes
git config hooks.autoAddAfterFix true

# Enable parallel command execution
git config hooks.parallelExecution true

# View current settings
git config --list | grep hooks
```

## 🔥 Bypass (Emergency Only)

```bash
# Skip all hooks
BYPASS_HOOKS=1 git commit
BYPASS_HOOKS=1 git push

# Allow protected branch commits
ALLOW_DIRECT_PROTECTED=1 git commit

# Windows (Command Prompt)
set BYPASS_HOOKS=1 && git commit
set ALLOW_DIRECT_PROTECTED=1 && git commit
```

## 🛠️ Custom Commands

Edit `.githooks/commands.conf`:
```bash
# Format: HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION

# Pre-commit
pre-commit:1:true:60:npx lint-staged:Lint staged files
pre-commit:2:false:120:npx tsc --noEmit:TypeScript check
pre-commit:3:true:30:npm run lint:fix:Auto-fix linting

# Pre-push
pre-push:1:true:300:npm test:Run test suite
pre-push:2:false:600:npm run build:Build project
pre-push:3:false:60:npm audit --audit-level=high:Security audit
```

## 🐛 Common Issues

### "Branch not created from correct base"
```bash
# Recreate from correct base
git checkout develop
git branch -D feat-PROJ-123-feature
git checkout -b feat-PROJ-123-feature

# Or rebase onto correct base
git rebase --onto develop <old-base> feat-PROJ-123-feature
```

### "Too many commits"
```bash
# Squash commits
git rebase -i develop
# Or soft reset
git reset --soft $(git merge-base develop HEAD)
git commit -m "feat: PROJ-123 Description"
```

### "Merge commits detected"
```bash
# Rebase to remove merge commits
git rebase develop
# Force push
git push --force-with-lease
```

### "Invalid commit message"
```bash
# Amend last commit
git commit --amend
# Or reset and recommit
git reset --soft HEAD~1
git commit -m "feat: PROJ-123 Description"
```

## 📊 View Logs

```bash
# View hook execution logs
cat .githooks/logs/pre-commit.log
cat .githooks/logs/pre-push.log
cat .githooks/logs/commit-msg.log

# Tail logs in real-time
tail -f .githooks/logs/pre-commit.log
```

## 🧪 Testing

```bash
# Run test suite
.githooks/test-hooks.sh

# Manual tests
# Test valid branch
git checkout -b feat-TEST-123-test-feature

# Test invalid branch (should fail on push)
git checkout -b invalid-branch-name

# Test protected branch (should fail)
git checkout develop
echo "test" > test.txt && git add test.txt
git commit -m "test"
```

## 🗑️ Uninstallation

```bash
# Uninstall hooks (keeps scripts)
.githooks/uninstall-hooks.sh

# Completely remove
rm -rf .githooks
git add .githooks
git commit -m "chore: Remove Git Flow hooks"
```

## 📖 Full Documentation

See [.githooks/README.md](.githooks/README.md) for complete documentation.

---

**Quick Tip**: Print this page and keep it near your desk for easy reference! 🖨️
