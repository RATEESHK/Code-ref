# Git Flow Hook Suite

A **production-grade, cross-platform Git hook suite** that enforces [Git Flow branching strategy](https://nvie.com/posts/a-successful-git-branching-model/), branch naming conventions, curated commit history, and commit message standards. Works seamlessly on **Linux, macOS, and Windows (Git Bash)**.

---

## 🎯 Features

### ✅ Git Flow Enforcement
- **Branch Creation Validation**: Enforces correct base branches (features from `develop`, hotfixes from `main`)
- **Protected Branches**: Prevents direct commits to `main`, `develop`, and `release/*`
- **Linear History**: Blocks merge commits, enforces rebase workflow
- **Curated History**: Limits commits per branch (default: 5, configurable)

### ✅ Branch Naming Policy
**Long-lived branches** (infinite lifetime):
- `main`, `develop`, `release/*`

**Short-lived branches** (temporary, with JIRA ticket):
```
<type>-<JIRA-ID>-<description>

Examples:
  feat-PROJ-123-add-user-authentication
  bugfix-JIRA-456-fix-login-timeout
  hotfix-APP-789-patch-security-vulnerability
  docs-WIKI-101-update-api-documentation
```

**Supported types**:
- `feat`, `feature` - New features (from `develop`)
- `bugfix`, `fix` - Bug fixes (from `develop`)
- `hotfix` - Critical production fixes (from `main`)
- `release` - Release preparation (from `develop`)
- `docs`, `test`, `refactor`, `perf`, `chore`, `build`, `ci`, `style`, `techdebt`

### ✅ Commit Message Format
**Required format**:
```
<type>: <JIRA-ID> <description>

Examples:
  feat: PROJ-123 Add user authentication module
  fix: JIRA-456 Resolve login timeout issue
  chore: TASK-789 Update dependencies to latest versions
```

**Auto-population**: JIRA IDs are automatically extracted from branch names and inserted into commit messages.

### ✅ Custom Command Framework
Execute custom linting, testing, or build verification commands via `.githooks/commands.conf`:
```bash
# Format: HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
pre-commit:1:true:60:npx lint-staged:Lint staged files
pre-commit:2:false:120:npx tsc --noEmit:TypeScript check
pre-push:1:true:300:npm test:Run test suite
```

**Features**:
- Priority-based execution
- Mandatory vs optional checks
- Timeout support
- Parallel execution (configurable)
- Auto-staging after fixes
- Detailed error reporting with stack traces

### ✅ Developer Quality of Life
- **Smart Hints**: Detects lockfile, IaC, and CI/CD changes with actionable reminders
- **Protected Branch Warnings**: Clear guidance when checking out protected branches
- **Contextual Error Messages**: Shows current Git state, exact fix commands, and Git Flow guidance
- **Force Push Reminders**: Suggests `--force-with-lease` after rebasing
- **Comprehensive Logging**: All hook executions logged with timestamps and stack traces

### ✅ Bypass Mechanisms
```bash
# Skip all hooks (emergency only)
BYPASS_HOOKS=1 git commit
BYPASS_HOOKS=1 git push

# Allow direct commits to protected branches
ALLOW_DIRECT_PROTECTED=1 git commit
```

---

## 📦 Installation

### Quick Start

#### Linux / macOS / Git Bash (Windows)
```bash
cd /path/to/your/repo
.githooks/install-hooks.sh
```

#### Windows (Command Prompt)
```cmd
cd C:\path\to\your\repo
.githooks\install-hooks.bat
```

### What Gets Configured

**Git Settings**:
- `core.hooksPath = .githooks`
- `rebase.autosquash = true`
- `fetch.prune = true`
- `pull.rebase = true`

**Hook Settings**:
- `hooks.maxCommits = 5` (adjustable)
- `hooks.autoAddAfterFix = false` (enable to auto-stage after linting fixes)
- `hooks.parallelExecution = false` (enable for faster command execution)

**Installed Hooks**:
- ✅ `pre-commit` - Validates protected branches, runs custom commands
- ✅ `prepare-commit-msg` - Auto-populates JIRA IDs
- ✅ `commit-msg` - Validates commit message format
- ✅ `applypatch-msg` - Validates patch messages (git am)
- ✅ `pre-push` - Branch naming, curated history, linear history enforcement
- ✅ `post-checkout` - Protected branch warnings
- ✅ `post-merge` - Smart hints (lockfiles, IaC, CI/CD)
- ✅ `pre-rebase` - Prevents rebasing protected branches
- ✅ `post-rewrite` - Force push reminders

---

## 🚀 Usage

### Git Flow Workflow

#### 1. Start a New Feature
```bash
# Always branch from develop
git checkout develop
git pull origin develop
git checkout -b feat-PROJ-123-add-user-authentication

# Make changes
echo "code" > file.js
git add file.js

# JIRA ID auto-populated from branch name
git commit -m "feat: PROJ-123 Add user authentication"

# Push (hooks validate branch naming and commit count)
git push -u origin feat-PROJ-123-add-user-authentication
```

#### 2. Create a Hotfix
```bash
# Hotfixes branch from main
git checkout main
git pull origin main
git checkout -b hotfix-PROJ-456-fix-critical-bug

# Make fix
git add .
git commit -m "fix: PROJ-456 Resolve critical security issue"

# Push
git push -u origin hotfix-PROJ-456-fix-critical-bug

# After PR approval, merge to main AND develop
git checkout main
git merge --no-ff hotfix-PROJ-456-fix-critical-bug
git tag -a v1.0.1 -m "Hotfix release 1.0.1"
git push origin main --tags

git checkout develop
git merge --no-ff hotfix-PROJ-456-fix-critical-bug
git push origin develop
```

#### 3. Create a Release
```bash
# Release branches from develop
git checkout develop
git pull origin develop
git checkout -b release/1.0.0

# Update version numbers, docs, etc.
# Only bug fixes allowed on release branches

# When ready, merge to main and develop
git checkout main
git merge --no-ff release/1.0.0
git tag -a v1.0.0 -m "Release 1.0.0"
git push origin main --tags

git checkout develop
git merge --no-ff release/1.0.0
git push origin develop
```

### Curated History (Squashing Commits)

If you have too many commits on your branch:

**Option 1: Interactive Rebase**
```bash
# Squash commits into logical units
git rebase -i develop

# In editor, change 'pick' to 'squash' for commits to combine
# pick abc1234 First commit
# squash def5678 Second commit
# squash ghi9012 Third commit

# Force push (safe version)
git push --force-with-lease
```

**Option 2: Soft Reset**
```bash
# Reset to base branch, keeping all changes staged
git reset --soft $(git merge-base develop HEAD)

# Create single commit
git commit -m "feat: PROJ-123 Complete feature description"

# Force push
git push --force-with-lease
```

---

## ⚙️ Configuration

### Adjust Commit Limit
```bash
# Increase max commits per branch
git config hooks.maxCommits 10

# View current setting
git config hooks.maxCommits
```

### Enable Auto-Staging After Fixes
```bash
# Auto-stage files after linting fixes
git config hooks.autoAddAfterFix true
```

### Enable Parallel Command Execution
```bash
# Run commands with same priority in parallel
git config hooks.parallelExecution true
```

### Custom Commands

Edit `.githooks/commands.conf`:
```bash
# Format: HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION

# Pre-commit checks
pre-commit:1:true:60:npx lint-staged:Lint staged files
pre-commit:2:false:120:npx tsc --noEmit --skipLibCheck:TypeScript check
pre-commit:3:true:30:npm run lint:fix:Auto-fix linting

# Pre-push checks
pre-push:1:true:300:npm test:Run test suite
pre-push:2:false:600:npm run build:Build project
pre-push:3:false:60:npm audit --audit-level=high:Security audit
```

**Command Placeholders**:
- `{staged}` - Replaced with list of staged files (pre-commit only)

---

## 🧪 Testing

### Test Branch Naming (Should Fail)
```bash
# Invalid branch name
git checkout -b invalid-branch
echo "test" > test.txt
git add test.txt
git commit -m "test"
git push origin invalid-branch
# ❌ Error: Invalid branch name
```

### Test Valid Branch (Should Pass)
```bash
git checkout develop
git checkout -b feat-TEST-123-valid-branch
echo "test" > test.txt
git add test.txt
git commit -m "feat: TEST-123 Add test"
git push -u origin feat-TEST-123-valid-branch
# ✅ Success
```

### Test Protected Branch (Should Fail)
```bash
git checkout develop
echo "test" > test.txt
git add test.txt
git commit -m "test"
# ❌ Error: Direct commits to protected branch blocked
```

### Test Too Many Commits (Should Fail)
```bash
git checkout -b feat-TEST-456-too-many-commits

# Create 10 commits (exceeds default limit of 5)
for i in {1..10}; do
  echo "change $i" > file$i.txt
  git add file$i.txt
  git commit -m "feat: TEST-456 Change $i"
done

git push -u origin feat-TEST-456-too-many-commits
# ❌ Error: Too many commits (10 > 5)
```

### View Hook Logs
```bash
# View detailed execution logs
cat .githooks/logs/pre-commit.log
cat .githooks/logs/pre-push.log
cat .githooks/logs/commit-msg.log
```

---

## 🐛 Troubleshooting

### "Branch not created from correct base"

**Problem**: Your branch wasn't created from the correct base (`develop` for features, `main` for hotfixes).

**Fix**:
```bash
# Option 1: Recreate branch
git checkout develop
git pull origin develop
git branch -D feat-PROJ-123-feature
git checkout -b feat-PROJ-123-feature
# Reapply changes

# Option 2: Rebase onto correct base
git rebase --onto develop <old-base> feat-PROJ-123-feature
git push --force-with-lease
```

### "Too many commits"

**Problem**: Your branch has more commits than allowed (default: 5).

**Fix**: See [Curated History (Squashing Commits)](#curated-history-squashing-commits) section.

### "Merge commits detected"

**Problem**: Your branch has merge commits (Git Flow requires linear history).

**Fix**:
```bash
# Rebase to remove merge commits
git rebase develop

# If conflicts occur
git status  # See conflicted files
# Edit files to resolve conflicts
git add <resolved-files>
git rebase --continue

# Force push
git push --force-with-lease
```

### "Invalid commit message format"

**Problem**: Your commit message doesn't follow the required format.

**Fix**:
```bash
# Amend last commit
git commit --amend

# Or reset and commit again
git reset --soft HEAD~1
git commit -m "feat: PROJ-123 Proper description"
```

### Hooks Not Running

**Problem**: Hooks aren't executing.

**Fix**:
```bash
# Verify hooks path
git config --local core.hooksPath
# Should output: .githooks

# If not set, reinstall
.githooks/install-hooks.sh

# On Windows, ensure Git Bash is used
where bash
```

### Line Ending Issues (Windows)

**Problem**: Hooks fail with "bad interpreter" errors on Windows.

**Fix**:
```bash
# Convert line endings to LF
dos2unix .githooks/*

# Or use Git to normalize
git add --renormalize .githooks/
git commit -m "chore: Normalize line endings"
```

---

## 🗑️ Uninstallation

### Remove Hooks
```bash
# Linux / macOS / Git Bash
.githooks/uninstall-hooks.sh

# Completely remove hooks directory
rm -rf .githooks
git add .githooks
git commit -m "chore: Remove Git Flow hooks"
```

### What Gets Removed
- ✅ `core.hooksPath` configuration
- ✅ `hooks.*` configurations
- ✅ Logs (archived before removal)
- ⚠️ Hook scripts remain (manual deletion required)

---

## 📁 File Structure

```
.githooks/
├── lib/
│   └── common.sh              # Shared library functions
├── logs/                      # Hook execution logs (auto-created, git-ignored)
│   ├── pre-commit.log
│   ├── pre-push.log
│   └── ...
├── pre-commit                 # Validates protected branches, runs commands
├── prepare-commit-msg         # Auto-populates JIRA IDs
├── commit-msg                 # Validates commit message format
├── applypatch-msg             # Validates patch messages
├── pre-push                   # Branch naming, curated history enforcement
├── post-checkout              # Protected branch warnings
├── post-merge                 # Smart hints
├── pre-rebase                 # Prevents rebasing protected branches
├── post-rewrite               # Force push reminders
├── commands.conf              # Custom command configuration
├── install-hooks.sh           # Installation script (Linux/macOS/Git Bash)
├── install-hooks.bat          # Installation script (Windows)
├── uninstall-hooks.sh         # Uninstallation script
├── .gitattributes             # Line ending configuration
└── README.md                  # This file
```

---

## 🤝 Contributing

### Adding New Hooks
1. Create hook file in `.githooks/`
2. Add shebang: `#!/usr/bin/env bash`
3. Source common library: `source "${SCRIPT_DIR}/lib/common.sh"`
4. Implement hook logic with proper error handling
5. Make executable: `chmod +x .githooks/<hook-name>`
6. Update `install-hooks.sh` to include new hook

### Adding Custom Commands
Edit `.githooks/commands.conf` and add your commands following the format:
```
HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
```

---

## 📚 References

- [Git Flow Branching Model](https://nvie.com/posts/a-successful-git-branching-model/) (Vincent Driessen)
- [Git Hooks Documentation](https://git-scm.com/docs/githooks)
- [Conventional Commits](https://www.conventionalcommits.org/)

---

## 📄 License

This Git hook suite is provided as-is for use in your projects. Feel free to modify and adapt to your team's needs.

---

## 🎓 Best Practices

1. **Commit Often, Push Clean**: Commit frequently locally, squash before pushing
2. **Rebase, Don't Merge**: Keep feature branches up-to-date by rebasing on develop
3. **Use `--force-with-lease`**: Safer than `--force`, prevents overwriting others' work
4. **Descriptive Branch Names**: Make branch purpose clear in the name
5. **Atomic Commits**: Each commit should represent one logical change
6. **Test Before Pushing**: Run tests locally before pushing to avoid CI failures

---

## 💡 Tips

- **Bypass Hooks Sparingly**: Only use `BYPASS_HOOKS=1` in emergencies
- **Configure Limits Per Project**: Adjust `hooks.maxCommits` based on project size
- **Enable Auto-Add for Formatters**: Set `hooks.autoAddAfterFix=true` if using Prettier/ESLint fixes
- **Review Logs**: Check `.githooks/logs/` if hooks behave unexpectedly
- **Team Coordination**: Discuss hook configurations with your team before enforcing
- **Document Exceptions**: When bypassing hooks, document why in commit message

---

**Built with ❤️ for teams that value clean Git history and Git Flow discipline.**
