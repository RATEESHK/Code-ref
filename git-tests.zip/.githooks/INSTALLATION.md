# Installation Instructions

## Prerequisites

Before installing the Git Flow hook suite, ensure you have:

1. **Git** version 2.0 or higher
   ```bash
   git --version
   ```

2. **Bash** shell (included with Git for Windows)
   - Linux/macOS: Built-in
   - Windows: Git Bash (comes with Git for Windows)

3. **A Git repository** initialized
   ```bash
   git init  # if not already initialized
   ```

## Installation Steps

### Option 1: Linux / macOS / Git Bash (Windows)

1. **Open Git Bash** (on Windows) or Terminal (on Linux/macOS)

2. **Navigate to your repository**
   ```bash
   cd /path/to/your/repository
   ```

3. **Make installation script executable** (if needed)
   ```bash
   chmod +x .githooks/install-hooks.sh
   chmod +x .githooks/*.sh
   chmod +x .githooks/pre-commit
   chmod +x .githooks/prepare-commit-msg
   chmod +x .githooks/commit-msg
   chmod +x .githooks/applypatch-msg
   chmod +x .githooks/pre-push
   chmod +x .githooks/post-checkout
   chmod +x .githooks/post-merge
   chmod +x .githooks/pre-rebase
   chmod +x .githooks/post-rewrite
   ```

4. **Run installation script**
   ```bash
   .githooks/install-hooks.sh
   ```

5. **Verify installation**
   ```bash
   git config --local core.hooksPath
   # Should output: .githooks
   ```

### Option 2: Windows (Command Prompt)

1. **Open Command Prompt**

2. **Navigate to your repository**
   ```cmd
   cd C:\path\to\your\repository
   ```

3. **Run installation script**
   ```cmd
   .githooks\install-hooks.bat
   ```

4. **Verify installation**
   ```cmd
   git config --local core.hooksPath
   ```

### Option 3: Manual Installation

If the automated scripts don't work, you can install manually:

1. **Set hooks path**
   ```bash
   git config --local core.hooksPath .githooks
   ```

2. **Configure Git settings**
   ```bash
   git config --local rebase.autosquash true
   git config --local fetch.prune true
   git config --local pull.rebase true
   git config --local hooks.maxCommits 5
   git config --local hooks.autoAddAfterFix false
   git config --local hooks.parallelExecution false
   ```

3. **Make hooks executable** (Unix-like systems)
   ```bash
   chmod +x .githooks/pre-commit
   chmod +x .githooks/prepare-commit-msg
   chmod +x .githooks/commit-msg
   chmod +x .githooks/applypatch-msg
   chmod +x .githooks/pre-push
   chmod +x .githooks/post-checkout
   chmod +x .githooks/post-merge
   chmod +x .githooks/pre-rebase
   chmod +x .githooks/post-rewrite
   ```

4. **Create log directory**
   ```bash
   mkdir -p .githooks/logs
   ```

5. **Add logs to .git/info/exclude**
   ```bash
   echo ".githooks/logs/" >> .git/info/exclude
   ```

## Post-Installation

### 1. Verify Configuration

```bash
# Check hooks path
git config --local core.hooksPath

# Check all hook configurations
git config --list | grep hooks

# List all configured settings
git config --list | grep -E '(core.hooksPath|rebase.autosquash|fetch.prune|pull.rebase|hooks.)'
```

### 2. Test the Hooks

#### Test 1: Valid Branch
```bash
# Ensure develop branch exists
git checkout -b develop 2>/dev/null || git checkout develop

# Create a valid feature branch
git checkout -b feat-TEST-123-test-installation

# Create a test file
echo "test" > test.txt
git add test.txt

# Commit (JIRA ID should be auto-populated)
git commit -m "feat: TEST-123 Test hook installation"

# Clean up
git checkout develop
git branch -D feat-TEST-123-test-installation
rm -f test.txt
```

#### Test 2: Invalid Branch (Should Fail)
```bash
# Create invalid branch
git checkout -b invalid-branch-name

# Try to commit
echo "test" > test.txt
git add test.txt
git commit -m "test"

# Try to push (should fail with detailed error)
git push origin invalid-branch-name

# Clean up
git checkout develop
git branch -D invalid-branch-name
rm -f test.txt
```

#### Test 3: Protected Branch (Should Fail)
```bash
# Try to commit directly to develop
git checkout develop
echo "test" > test.txt
git add test.txt
git commit -m "test"
# Should fail with protected branch error

# Clean up
git reset HEAD~1 2>/dev/null || true
rm -f test.txt
```

### 3. View Logs

```bash
# View hook logs
cat .githooks/logs/pre-commit.log
cat .githooks/logs/pre-push.log
cat .githooks/logs/commit-msg.log

# Or tail logs in real-time
tail -f .githooks/logs/pre-commit.log
```

## Troubleshooting

### Issue: Hooks Not Running

**Symptom**: Git commands complete without running hooks

**Solutions**:

1. **Check hooks path configuration**
   ```bash
   git config --local core.hooksPath
   # Should be: .githooks
   ```

2. **Reinstall hooks**
   ```bash
   .githooks/install-hooks.sh  # or .bat on Windows
   ```

3. **Check file permissions** (Unix-like systems)
   ```bash
   ls -la .githooks/
   # Hook files should have 'x' (executable) permission
   ```

4. **Make hooks executable**
   ```bash
   chmod +x .githooks/*
   ```

### Issue: "Bad Interpreter" Error (Windows)

**Symptom**: `/usr/bin/env: 'bash': No such file or directory`

**Solutions**:

1. **Ensure Git Bash is installed**
   - Download from: https://git-scm.com/download/win
   - Install Git for Windows with default options

2. **Run commands from Git Bash**, not Command Prompt or PowerShell

3. **Check line endings**
   ```bash
   # Convert to Unix line endings
   dos2unix .githooks/*
   
   # Or use Git to normalize
   git add --renormalize .githooks/
   ```

### Issue: Line Ending Problems

**Symptom**: Hooks fail with unexpected character errors

**Solution**:

1. **Ensure .gitattributes is present**
   ```bash
   cat .githooks/.gitattributes
   # Should contain: *.sh text eol=lf
   ```

2. **Normalize line endings**
   ```bash
   git add --renormalize .githooks/
   git commit -m "chore: Normalize line endings"
   ```

### Issue: Permission Denied

**Symptom**: `Permission denied` when running hooks

**Solution** (Unix-like systems):
```bash
# Make all hooks executable
chmod +x .githooks/pre-commit
chmod +x .githooks/prepare-commit-msg
chmod +x .githooks/commit-msg
chmod +x .githooks/applypatch-msg
chmod +x .githooks/pre-push
chmod +x .githooks/post-checkout
chmod +x .githooks/post-merge
chmod +x .githooks/pre-rebase
chmod +x .githooks/post-rewrite
chmod +x .githooks/lib/common.sh
```

### Issue: Hooks Too Strict

**Symptom**: Can't commit because of hook validation

**Temporary Bypass** (emergency only):
```bash
# Skip all hooks
BYPASS_HOOKS=1 git commit -m "Emergency commit"
BYPASS_HOOKS=1 git push

# Allow protected branch commits
ALLOW_DIRECT_PROTECTED=1 git commit -m "Hotfix"
```

**Permanent Solution**: Adjust configuration
```bash
# Increase commit limit if needed
git config hooks.maxCommits 10

# Or fix the actual issue (preferred)
```

## Uninstallation

### Full Uninstallation

```bash
# Run uninstall script
.githooks/uninstall-hooks.sh

# Remove hooks directory
rm -rf .githooks

# Commit the removal
git add .githooks
git commit -m "chore: Remove Git Flow hooks"
```

### Temporary Disable (Keep Files)

```bash
# Unset hooks path
git config --local --unset core.hooksPath

# To re-enable later
git config --local core.hooksPath .githooks
```

## Advanced Configuration

### Custom Commit Limit

```bash
# Set per repository
git config --local hooks.maxCommits 10

# Set globally (all repos)
git config --global hooks.maxCommits 10
```

### Enable Auto-Staging After Fixes

```bash
# When linters auto-fix files, automatically stage them
git config --local hooks.autoAddAfterFix true
```

### Enable Parallel Command Execution

```bash
# Run commands with same priority in parallel (faster)
git config --local hooks.parallelExecution true
```

### Custom Commands

Edit `.githooks/commands.conf`:

```bash
# Add your custom linting, testing, or build commands
# Format: HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION

pre-commit:1:true:60:npx lint-staged:Lint staged files
pre-commit:2:false:120:npx tsc --noEmit:TypeScript check
pre-push:1:true:300:npm test:Run test suite
```

## Team Rollout

### Phase 1: Individual Testing
1. One developer installs hooks
2. Test for 1-2 weeks
3. Gather feedback and adjust configurations

### Phase 2: Team Pilot
1. Small team (3-5 people) installs hooks
2. Document common issues
3. Create team-specific documentation

### Phase 3: Full Rollout
1. Commit hooks to repository
2. Send installation instructions to team
3. Provide support during transition
4. Document bypass procedures for emergencies

### Communication Template

```
📢 New Git Flow Hooks

We're implementing Git Flow hooks to improve our branch and commit hygiene.

Installation:
1. Pull latest changes
2. Run: .githooks/install-hooks.sh (or .bat on Windows)
3. Test with: git checkout -b feat-TEST-123-test

Key Changes:
✅ Branch naming: feat-PROJ-123-description
✅ Commit format: feat: PROJ-123 Description
✅ Max 5 commits per branch (squash if needed)
✅ No direct commits to main/develop

Questions? Check .githooks/README.md or ask in #engineering

Emergency bypass: BYPASS_HOOKS=1 git commit
```

## Next Steps

1. ✅ **Installation complete** - Hooks are now active
2. 📖 **Read the documentation** - [.githooks/README.md](.githooks/README.md)
3. 🚀 **Start using Git Flow** - Follow branch naming conventions
4. 🔧 **Customize** - Edit `.githooks/commands.conf` for custom commands
5. 📚 **Share with team** - Help others install and use the hooks

## Support

- **Documentation**: [.githooks/README.md](.githooks/README.md)
- **Quick Reference**: [.githooks/QUICK_REFERENCE.md](.githooks/QUICK_REFERENCE.md)
- **Changelog**: [.githooks/CHANGELOG.md](.githooks/CHANGELOG.md)
- **Issues**: Check hook logs in `.githooks/logs/`

---

**Installation complete! Happy committing! 🎉**
