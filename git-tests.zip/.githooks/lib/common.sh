#!/usr/bin/env bash

# =============================================================================
# Git Hooks Common Library
# Production-grade shared functions for Git Flow enforcement
# =============================================================================

# Terminal colors
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly MAGENTA='\033[0;35m'
readonly CYAN='\033[0;36m'
readonly BOLD='\033[1m'
readonly NC='\033[0m' # No Color

# Hook configuration
readonly HOOKS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
readonly LOG_DIR="${HOOKS_DIR}/logs"
readonly COMMANDS_CONF="${HOOKS_DIR}/commands.conf"

# Ensure log directory exists
mkdir -p "$LOG_DIR" 2>/dev/null

# =============================================================================
# Logging Functions
# =============================================================================

log_file() {
    local hook_name="${1:-unknown}"
    echo "${LOG_DIR}/${hook_name}.log"
}

log_entry() {
    local level="$1"
    local hook_name="$2"
    local message="$3"
    local timestamp
    timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
    
    local log_file_path
    log_file_path="$(log_file "$hook_name")"
    
    echo "[$timestamp] [$level] $message" >> "$log_file_path"
}

log_info() {
    local hook_name="$1"
    local message="$2"
    log_entry "INFO" "$hook_name" "$message"
}

log_warn() {
    local hook_name="$1"
    local message="$2"
    log_entry "WARN" "$hook_name" "$message"
}

log_error() {
    local hook_name="$1"
    local message="$2"
    log_entry "ERROR" "$hook_name" "$message"
}

log_debug() {
    local hook_name="$1"
    local message="$2"
    if [[ "${DEBUG_HOOKS:-}" == "1" ]]; then
        log_entry "DEBUG" "$hook_name" "$message"
    fi
}

# Log stack trace for errors
log_stack_trace() {
    local hook_name="$1"
    local i=0
    local stack_trace=""
    
    while caller $i >/dev/null 2>&1; do
        local frame
        frame="$(caller $i)"
        stack_trace="${stack_trace}  at ${frame}\n"
        ((i++))
    done
    
    if [[ -n "$stack_trace" ]]; then
        log_error "$hook_name" "Stack trace:\n${stack_trace}"
    fi
}

# =============================================================================
# Configuration Management
# =============================================================================

get_config() {
    local key="$1"
    local default="${2:-}"
    local value
    
    value="$(git config --get "$key" 2>/dev/null || echo "")"
    
    if [[ -z "$value" ]]; then
        echo "$default"
    else
        echo "$value"
    fi
}

set_config() {
    local key="$1"
    local value="$2"
    git config "$key" "$value"
}

get_max_commits() {
    local max_commits
    max_commits="$(get_config "hooks.maxCommits" "5")"
    echo "$max_commits"
}

is_auto_add_after_fix_enabled() {
    local enabled
    enabled="$(get_config "hooks.autoAddAfterFix" "false")"
    [[ "$enabled" == "true" ]]
}

is_parallel_execution_enabled() {
    local enabled
    enabled="$(get_config "hooks.parallelExecution" "false")"
    [[ "$enabled" == "true" ]]
}

# =============================================================================
# Branch Management
# =============================================================================

get_current_branch() {
    git symbolic-ref --short HEAD 2>/dev/null || echo ""
}

get_remote_url() {
    git config --get remote.origin.url 2>/dev/null || echo ""
}

is_protected_branch() {
    local branch="$1"
    
    # Protected branches: main, develop, release/*
    if [[ "$branch" =~ ^(main|master|develop)$ ]]; then
        return 0
    fi
    
    if [[ "$branch" =~ ^release/ ]]; then
        return 0
    fi
    
    return 1
}

is_long_lived_branch() {
    local branch="$1"
    
    # Long-lived branches pattern: ^(main|develop|release($|/.*))$
    if [[ "$branch" =~ ^(main|master|develop)$ ]]; then
        return 0
    fi
    
    if [[ "$branch" =~ ^release($|/.*) ]]; then
        return 0
    fi
    
    return 1
}

is_valid_branch_name() {
    local branch="$1"
    
    # Check if it's a long-lived branch
    if is_long_lived_branch "$branch"; then
        return 0
    fi
    
    # Check short-lived branch pattern
    # ^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$
    if [[ "$branch" =~ ^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$ ]]; then
        return 0
    fi
    
    return 1
}

extract_jira_id() {
    local branch="$1"
    
    # Extract JIRA ID from branch name (e.g., PROJ-123 from feat-PROJ-123-description)
    if [[ "$branch" =~ -([A-Z]{2,10}-[0-9]+)- ]]; then
        echo "${BASH_REMATCH[1]}"
        return 0
    fi
    
    return 1
}

get_branch_base() {
    local branch="$1"
    
    # Determine the base branch according to Git Flow
    if [[ "$branch" =~ ^hotfix- ]]; then
        # Hotfixes branch from main
        if git rev-parse --verify main >/dev/null 2>&1; then
            echo "main"
        elif git rev-parse --verify master >/dev/null 2>&1; then
            echo "master"
        else
            echo "develop"
        fi
    elif [[ "$branch" =~ ^release- ]]; then
        # Releases branch from develop
        echo "develop"
    else
        # Features, bugfixes, etc. branch from develop
        echo "develop"
    fi
}

get_merge_base() {
    local branch="$1"
    local base
    base="$(get_branch_base "$branch")"
    
    # Get the merge base commit
    git merge-base "$base" "$branch" 2>/dev/null || echo ""
}

# =============================================================================
# Commit Management
# =============================================================================

count_commits_ahead() {
    local branch="$1"
    local base
    base="$(get_branch_base "$branch")"
    
    # Count commits unique to the branch
    local count
    count="$(git rev-list --count "${base}..${branch}" 2>/dev/null || echo "0")"
    
    echo "$count"
}

has_merge_commits() {
    local branch="$1"
    local base
    base="$(get_branch_base "$branch")"
    
    # Check for merge commits in the branch
    local merge_count
    merge_count="$(git rev-list --merges --count "${base}..${branch}" 2>/dev/null || echo "0")"
    
    [[ "$merge_count" -gt 0 ]]
}

is_valid_commit_message() {
    local message="$1"
    
    # Allow merge and revert commits
    if [[ "$message" =~ ^Merge ]]; then
        return 0
    fi
    
    if [[ "$message" =~ ^Revert ]]; then
        return 0
    fi
    
    # Check format: ^(feat|fix|chore|break|tests): [A-Z]{2,10}-[0-9]+ .+
    if [[ "$message" =~ ^(feat|fix|chore|break|tests|build|ci|docs|perf|refactor|style|test):\ [A-Z]{2,10}-[0-9]+\ .+ ]]; then
        return 0
    fi
    
    return 1
}

# =============================================================================
# File Detection Helpers
# =============================================================================

detect_lockfile_changes() {
    local files=("$@")
    local lockfiles=(
        "package-lock.json"
        "yarn.lock"
        "pnpm-lock.yaml"
        "Gemfile.lock"
        "Pipfile.lock"
        "poetry.lock"
        "composer.lock"
        "Cargo.lock"
        "go.sum"
    )
    
    for file in "${files[@]}"; do
        for lockfile in "${lockfiles[@]}"; do
            if [[ "$file" == *"$lockfile" ]]; then
                return 0
            fi
        done
    done
    
    return 1
}

detect_iac_changes() {
    local files=("$@")
    local patterns=(
        "*.tf"
        "*.tfvars"
        "*.hcl"
        "*.yaml"
        "*.yml"
        "Dockerfile"
        "docker-compose"
    )
    
    for file in "${files[@]}"; do
        for pattern in "${patterns[@]}"; do
            if [[ "$file" == $pattern ]] || [[ "$file" == *"/$pattern" ]]; then
                return 0
            fi
        done
    done
    
    return 1
}

detect_ci_changes() {
    local files=("$@")
    local patterns=(
        ".github/workflows/"
        ".gitlab-ci.yml"
        "azure-pipelines"
        "Jenkinsfile"
        ".circleci/"
        ".travis.yml"
    )
    
    for file in "${files[@]}"; do
        for pattern in "${patterns[@]}"; do
            if [[ "$file" == *"$pattern"* ]]; then
                return 0
            fi
        done
    done
    
    return 1
}

# =============================================================================
# Error Formatting
# =============================================================================

print_error_header() {
    local hook_name="$1"
    echo ""
    echo -e "${RED}${BOLD}========================================${NC}"
    echo -e "${RED}${BOLD}Hook: ${hook_name} FAILED${NC}"
    echo -e "${RED}${BOLD}========================================${NC}"
    echo ""
}

print_error_footer() {
    local bypass_hint="${1:-git commit}"
    echo ""
    echo -e "${YELLOW}To bypass (emergency only):${NC}"
    echo -e "${CYAN}  BYPASS_HOOKS=1 ${bypass_hint}${NC}"
    echo ""
    echo -e "${RED}${BOLD}========================================${NC}"
}

print_section() {
    local title="$1"
    echo ""
    echo -e "${BOLD}${title}:${NC}"
}

print_success() {
    local message="$1"
    echo -e "${GREEN}✓${NC} ${message}"
}

print_failure() {
    local message="$1"
    echo -e "${RED}✗${NC} ${message}"
}

print_warning() {
    local message="$1"
    echo -e "${YELLOW}⚠${NC} ${message}"
}

print_info() {
    local message="$1"
    echo -e "${CYAN}ℹ${NC} ${message}"
}

# =============================================================================
# Branch Naming Error Messages
# =============================================================================

print_branch_naming_error() {
    local branch="$1"
    local hook_name="${2:-pre-push}"
    
    print_error_header "$hook_name"
    
    echo -e "${RED}Invalid branch name:${NC} ${BOLD}${branch}${NC}"
    echo ""
    echo -e "${BOLD}Branch naming policy enforces Git Flow strategy:${NC}"
    echo ""
    
    print_section "Long-lived branches (infinite lifetime)"
    echo -e "  Pattern: ${CYAN}^(main|develop|release(\$|/.*))$${NC}"
    echo "  Examples:"
    echo "    • main"
    echo "    • develop"
    echo "    • release/1.0.0"
    echo "    • release/v2.3.0-beta"
    echo ""
    
    print_section "Short-lived branches (temporary)"
    echo -e "  Pattern: ${CYAN}^(TYPE)-[JIRA-ID]-[description]$${NC}"
    echo -e "  Format:  ${CYAN}(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+${NC}"
    echo ""
    echo "  Type       │ Branches from │ Merges to     │ Purpose"
    echo "  ───────────┼───────────────┼───────────────┼────────────────────────"
    echo "  feat       │ develop       │ develop       │ New features"
    echo "  feature    │ develop       │ develop       │ New features (alias)"
    echo "  bugfix/fix │ develop       │ develop       │ Non-critical bug fixes"
    echo "  hotfix     │ main          │ main+develop  │ Critical production fixes"
    echo "  release    │ develop       │ main+develop  │ Release preparation"
    echo "  docs       │ develop       │ develop       │ Documentation"
    echo "  test       │ develop       │ develop       │ Testing improvements"
    echo "  refactor   │ develop       │ develop       │ Code refactoring"
    echo "  perf       │ develop       │ develop       │ Performance improvements"
    echo "  chore      │ develop       │ develop       │ Maintenance tasks"
    echo "  build      │ develop       │ develop       │ Build system changes"
    echo "  ci         │ develop       │ develop       │ CI/CD changes"
    echo "  style      │ develop       │ develop       │ Code style changes"
    echo "  revert     │ any           │ source        │ Revert previous changes"
    echo "  techdebt   │ develop       │ develop       │ Technical debt reduction"
    echo ""
    echo "  Valid examples:"
    echo "    • feat-PROJ-123-add-user-authentication"
    echo "    • bugfix-JIRA-456-fix-login-timeout"
    echo "    • hotfix-APP-789-patch-security-vulnerability"
    echo "    • docs-WIKI-101-update-api-documentation"
    echo "    • refactor-TECH-202-modernize-database-layer"
    echo ""
    
    print_section "JIRA ID Requirements"
    echo "  • Project key: 2-10 uppercase letters (e.g., PROJ, JIRA, APP)"
    echo "  • Issue number: One or more digits (e.g., 123, 4567)"
    echo "  • Description: Lowercase letters, numbers, and hyphens"
    echo ""
    
    print_section "Git Flow Branching Rules"
    echo "  1. Feature branches MUST branch from 'develop'"
    echo "  2. Hotfix branches MUST branch from 'main'"
    echo "  3. Release branches MUST branch from 'develop'"
    echo "  4. Never commit directly to main or develop (use bypass if necessary)"
    echo ""
    
    print_section "How to fix"
    local base
    base="$(get_branch_base "$branch")"
    
    # Suggest a valid branch name based on current branch
    local suggested_name=""
    if [[ "$branch" =~ ^hotfix ]]; then
        suggested_name="hotfix-PROJ-123-fix-issue-description"
    elif [[ "$branch" =~ ^release ]]; then
        suggested_name="release/1.0.0"
    else
        suggested_name="feat-PROJ-123-your-feature-description"
    fi
    
    echo "  1. Rename your branch to follow the convention:"
    echo -e "     ${CYAN}git branch -m ${branch} ${suggested_name}${NC}"
    echo ""
    echo "  2. If you already pushed the old branch, update remote:"
    echo -e "     ${CYAN}git push origin --delete ${branch}${NC}"
    echo -e "     ${CYAN}git push origin -u ${suggested_name}${NC}"
    echo ""
    echo "  3. Or create a new branch from ${base} with correct naming:"
    echo -e "     ${CYAN}git checkout ${base}${NC}"
    echo -e "     ${CYAN}git checkout -b ${suggested_name}${NC}"
    echo -e "     ${CYAN}git cherry-pick <commit-range>${NC}  ${YELLOW}# if you want to preserve commits${NC}"
    echo ""
    
    print_section "Current Git State"
    echo -e "  Current branch: ${BOLD}${branch}${NC}"
    echo -e "  Should branch from: ${BOLD}${base}${NC}"
    local remote_url
    remote_url="$(get_remote_url)"
    if [[ -n "$remote_url" ]]; then
        echo -e "  Remote: ${remote_url}"
    fi
    
    print_error_footer "git push"
    
    return 1
}

# =============================================================================
# Curated History Error Messages
# =============================================================================

print_commit_limit_error() {
    local branch="$1"
    local commit_count="$2"
    local max_commits="$3"
    local hook_name="${4:-pre-push}"
    
    print_error_header "$hook_name"
    
    echo -e "${RED}Too many commits on branch:${NC} ${BOLD}${branch}${NC}"
    echo ""
    echo -e "  Current commits: ${RED}${BOLD}${commit_count}${NC}"
    echo -e "  Maximum allowed: ${GREEN}${BOLD}${max_commits}${NC}"
    echo ""
    
    local base
    base="$(get_branch_base "$branch")"
    
    print_section "Why this matters"
    echo "  Curated history keeps your commits clean, reviewable, and meaningful."
    echo "  Large numbers of commits usually indicate:"
    echo "    • Work-in-progress commits that should be squashed"
    echo "    • Experimental changes that need cleanup"
    echo "    • Multiple logical changes that should be separate PRs"
    echo ""
    
    print_section "Git Flow Best Practices"
    echo "  • Each feature/fix should be atomic and focused"
    echo "  • Squash related commits into logical units"
    echo "  • Keep commit history linear and easy to review"
    echo "  • Make it easy to revert entire features if needed"
    echo ""
    
    print_section "How to fix - Option 1: Interactive Rebase (Recommended)"
    echo "  1. Start interactive rebase from base branch:"
    echo -e "     ${CYAN}git rebase -i ${base}${NC}"
    echo ""
    echo "  2. In the editor, mark commits to squash:"
    echo "     pick abc1234 First commit"
    echo "     squash def5678 Second commit  <- Change 'pick' to 'squash'"
    echo "     squash ghi9012 Third commit   <- Change 'pick' to 'squash'"
    echo ""
    echo "  3. Save and close. Git will let you edit the final commit message."
    echo ""
    echo "  4. Force push (if already pushed):"
    echo -e "     ${CYAN}git push --force-with-lease${NC}"
    echo ""
    
    print_section "How to fix - Option 2: Soft Reset"
    echo "  1. Soft reset to base branch (keeps all changes staged):"
    echo -e "     ${CYAN}git reset --soft \$(git merge-base ${base} HEAD)${NC}"
    echo ""
    echo "  2. Create a single commit with all changes:"
    echo -e "     ${CYAN}git commit -m \"feat: PROJ-123 Your feature description\"${NC}"
    echo ""
    echo "  3. Force push (if already pushed):"
    echo -e "     ${CYAN}git push --force-with-lease${NC}"
    echo ""
    
    print_section "How to fix - Option 3: Adjust Limit"
    echo "  If you genuinely need more commits (rare), increase the limit:"
    echo -e "     ${CYAN}git config hooks.maxCommits 10${NC}"
    echo ""
    echo "  Note: Discuss with your team before changing limits."
    echo ""
    
    print_section "Current Git State"
    echo -e "  Current branch: ${BOLD}${branch}${NC}"
    echo -e "  Base branch: ${BOLD}${base}${NC}"
    echo -e "  Commits on this branch: ${BOLD}${commit_count}${NC}"
    echo ""
    echo "  Recent commits:"
    git log --oneline "${base}..HEAD" 2>/dev/null | head -n 10 | while IFS= read -r line; do
        echo "    ${line}"
    done
    
    if [[ "$commit_count" -gt 10 ]]; then
        echo "    ... and $((commit_count - 10)) more"
    fi
    
    print_error_footer "git push"
    
    return 1
}

print_merge_commit_error() {
    local branch="$1"
    local hook_name="${2:-pre-push}"
    
    print_error_header "$hook_name"
    
    echo -e "${RED}Merge commits detected on branch:${NC} ${BOLD}${branch}${NC}"
    echo ""
    
    local base
    base="$(get_branch_base "$branch")"
    
    print_section "Why this is blocked"
    echo "  Git Flow enforces linear history through rebasing, not merging."
    echo "  Merge commits:"
    echo "    • Create complex, non-linear history"
    echo "    • Make it harder to review changes"
    echo "    • Complicate bisecting and cherry-picking"
    echo "    • Can cause 'foxtrot merges' (incorrect parent order)"
    echo ""
    
    print_section "Git Flow Integration Strategy"
    echo "  • Feature branches: Rebase on develop, then merge with --no-ff"
    echo "  • Hotfix branches: Rebase on main, then merge with --no-ff"
    echo "  • Release branches: Merge to main with --no-ff, then to develop"
    echo "  • The --no-ff on final integration preserves branch context"
    echo ""
    
    print_section "How to fix - Remove merge commits"
    echo "  1. Backup your current branch:"
    echo -e "     ${CYAN}git branch backup-${branch}${NC}"
    echo ""
    echo "  2. Rebase onto base branch to remove merge commits:"
    echo -e "     ${CYAN}git rebase ${base}${NC}"
    echo ""
    echo "  3. If conflicts occur, resolve them:"
    echo -e "     ${CYAN}git status${NC}  ${YELLOW}# See conflicted files${NC}"
    echo -e "     ${YELLOW}# Edit files to resolve conflicts${NC}"
    echo -e "     ${CYAN}git add <resolved-files>${NC}"
    echo -e "     ${CYAN}git rebase --continue${NC}"
    echo ""
    echo "  4. Force push (if already pushed):"
    echo -e "     ${CYAN}git push --force-with-lease${NC}"
    echo ""
    
    print_section "Alternative - Recreate branch"
    echo "  If rebase is too complex, recreate the branch:"
    echo ""
    echo "  1. Get list of files changed:"
    echo -e "     ${CYAN}git diff ${base}...HEAD --name-only > changed_files.txt${NC}"
    echo ""
    echo "  2. Create new branch from base:"
    echo -e "     ${CYAN}git checkout ${base}${NC}"
    echo -e "     ${CYAN}git checkout -b ${branch}-clean${NC}"
    echo ""
    echo "  3. Apply your changes:"
    echo -e "     ${CYAN}git checkout ${branch} -- .${NC}"
    echo -e "     ${CYAN}git commit -m \"feat: PROJ-123 Your description\"${NC}"
    echo ""
    
    print_section "Current Git State"
    echo -e "  Current branch: ${BOLD}${branch}${NC}"
    echo -e "  Base branch: ${BOLD}${base}${NC}"
    echo ""
    echo "  Merge commits found:"
    git log --merges --oneline "${base}..HEAD" 2>/dev/null | while IFS= read -r line; do
        echo "    ${line}"
    done
    
    print_error_footer "git push"
    
    return 1
}

# =============================================================================
# Commit Message Error Messages
# =============================================================================

print_commit_message_error() {
    local message="$1"
    local hook_name="${2:-commit-msg}"
    
    print_error_header "$hook_name"
    
    echo -e "${RED}Invalid commit message format${NC}"
    echo ""
    echo -e "${BOLD}Your message:${NC}"
    echo "┌────────────────────────────────────────"
    echo "$message" | sed 's/^/│ /'
    echo "└────────────────────────────────────────"
    echo ""
    
    print_section "Required Format"
    echo -e "  ${CYAN}<type>: <JIRA-ID> <description>${NC}"
    echo ""
    echo "  Where:"
    echo "    • type: feat, fix, chore, break, tests, build, ci, docs, perf, refactor, style"
    echo "    • JIRA-ID: [A-Z]{2,10}-[0-9]+ (e.g., PROJ-123)"
    echo "    • description: Clear description of the change"
    echo ""
    
    print_section "Valid Examples"
    echo "  ✓ feat: PROJ-123 Add user authentication module"
    echo "  ✓ fix: JIRA-456 Resolve login timeout issue"
    echo "  ✓ chore: TASK-789 Update dependencies to latest versions"
    echo "  ✓ break: API-101 Remove deprecated v1 endpoints"
    echo "  ✓ tests: TEST-202 Add unit tests for payment processor"
    echo "  ✓ docs: DOC-303 Update API documentation for v2"
    echo ""
    
    print_section "Commit Types"
    echo "  feat     - New feature"
    echo "  fix      - Bug fix"
    echo "  chore    - Maintenance, dependencies, tooling"
    echo "  break    - Breaking changes"
    echo "  tests    - Adding or updating tests"
    echo "  build    - Build system or external dependencies"
    echo "  ci       - CI/CD configuration"
    echo "  docs     - Documentation only"
    echo "  perf     - Performance improvements"
    echo "  refactor - Code refactoring"
    echo "  style    - Code style (formatting, semicolons, etc.)"
    echo ""
    
    print_section "Auto-population"
    local current_branch
    current_branch="$(get_current_branch)"
    local jira_id
    if jira_id="$(extract_jira_id "$current_branch")"; then
        echo "  Your branch name contains JIRA ID: ${BOLD}${jira_id}${NC}"
        echo "  This should be auto-populated in commit messages."
        echo ""
        echo "  Suggested format for your commit:"
        echo -e "    ${CYAN}feat: ${jira_id} <your description here>${NC}"
        echo ""
    else
        echo "  Your branch name doesn't contain a JIRA ID."
        echo "  Make sure your branch follows the naming convention."
        echo ""
    fi
    
    print_section "How to fix"
    echo "  1. Amend your commit with correct format:"
    echo -e "     ${CYAN}git commit --amend${NC}"
    echo ""
    echo "  2. Or reset and commit again:"
    echo -e "     ${CYAN}git reset --soft HEAD~1${NC}"
    echo -e "     ${CYAN}git commit -m \"feat: PROJ-123 Your description\"${NC}"
    echo ""
    
    print_section "Special Cases"
    echo "  Merge commits (start with 'Merge') and revert commits"
    echo "  (start with 'Revert') are allowed without JIRA IDs."
    echo ""
    
    print_error_footer "git commit"
    
    return 1
}

# =============================================================================
# Protected Branch Error Messages
# =============================================================================

print_protected_branch_error() {
    local branch="$1"
    local action="${2:-commit}"
    local hook_name="${3:-pre-commit}"
    
    print_error_header "$hook_name"
    
    echo -e "${RED}Direct ${action}s to protected branch are not allowed:${NC} ${BOLD}${branch}${NC}"
    echo ""
    
    print_section "Git Flow Protection"
    echo "  Protected branches (main, develop, release/*) are integration points."
    echo "  They should only receive changes through proper Git Flow merges:"
    echo ""
    echo "  • main: Receives release branches and hotfixes (with --no-ff)"
    echo "  • develop: Receives feature branches and releases (with --no-ff)"
    echo "  • release/*: Receives bug fixes, merges to main and develop"
    echo ""
    
    print_section "Proper Git Flow Workflow"
    
    if [[ "$branch" == "develop" ]]; then
        echo "  For new features:"
        echo "  1. Create feature branch from develop:"
        echo -e "     ${CYAN}git checkout develop${NC}"
        echo -e "     ${CYAN}git pull origin develop${NC}"
        echo -e "     ${CYAN}git checkout -b feat-PROJ-123-your-feature${NC}"
        echo ""
        echo "  2. Make your changes and commit:"
        echo -e "     ${CYAN}git add .${NC}"
        echo -e "     ${CYAN}git commit -m \"feat: PROJ-123 Add your feature\"${NC}"
        echo ""
        echo "  3. Push and create pull request:"
        echo -e "     ${CYAN}git push -u origin feat-PROJ-123-your-feature${NC}"
        echo ""
        echo "  4. After PR approval, merge with --no-ff:"
        echo -e "     ${CYAN}git checkout develop${NC}"
        echo -e "     ${CYAN}git merge --no-ff feat-PROJ-123-your-feature${NC}"
        echo -e "     ${CYAN}git push origin develop${NC}"
        
    elif [[ "$branch" == "main" ]] || [[ "$branch" == "master" ]]; then
        echo "  For hotfixes:"
        echo "  1. Create hotfix branch from main:"
        echo -e "     ${CYAN}git checkout main${NC}"
        echo -e "     ${CYAN}git pull origin main${NC}"
        echo -e "     ${CYAN}git checkout -b hotfix-PROJ-456-critical-fix${NC}"
        echo ""
        echo "  2. Make your fix and commit:"
        echo -e "     ${CYAN}git add .${NC}"
        echo -e "     ${CYAN}git commit -m \"fix: PROJ-456 Fix critical issue\"${NC}"
        echo ""
        echo "  3. Merge to main and develop:"
        echo -e "     ${CYAN}git checkout main${NC}"
        echo -e "     ${CYAN}git merge --no-ff hotfix-PROJ-456-critical-fix${NC}"
        echo -e "     ${CYAN}git tag -a v1.0.1 -m \"Hotfix release 1.0.1\"${NC}"
        echo -e "     ${CYAN}git push origin main --tags${NC}"
        echo ""
        echo -e "     ${CYAN}git checkout develop${NC}"
        echo -e "     ${CYAN}git merge --no-ff hotfix-PROJ-456-critical-fix${NC}"
        echo -e "     ${CYAN}git push origin develop${NC}"
        
    elif [[ "$branch" =~ ^release/ ]]; then
        echo "  Release branches receive only bug fixes:"
        echo "  1. Create bugfix branch from release:"
        echo -e "     ${CYAN}git checkout ${branch}${NC}"
        echo -e "     ${CYAN}git checkout -b bugfix-PROJ-789-release-fix${NC}"
        echo ""
        echo "  2. Fix and merge back:"
        echo -e "     ${CYAN}git commit -m \"fix: PROJ-789 Fix release issue\"${NC}"
        echo -e "     ${CYAN}git checkout ${branch}${NC}"
        echo -e "     ${CYAN}git merge --no-ff bugfix-PROJ-789-release-fix${NC}"
    fi
    
    echo ""
    
    print_section "Emergency Override"
    echo "  If you absolutely must commit directly (e.g., CI configuration):"
    echo -e "  ${CYAN}ALLOW_DIRECT_PROTECTED=1 git commit -m \"Your message\"${NC}"
    echo ""
    echo -e "  ${YELLOW}⚠  Use this sparingly and document why in commit message${NC}"
    echo ""
    
    print_section "Current Git State"
    echo -e "  Current branch: ${BOLD}${branch}${NC}"
    echo -e "  Branch type: ${BOLD}Protected (Git Flow integration point)${NC}"
    local remote_url
    remote_url="$(get_remote_url)"
    if [[ -n "$remote_url" ]]; then
        echo -e "  Remote: ${remote_url}"
    fi
    
    print_error_footer "git commit"
    
    return 1
}

# =============================================================================
# Command Execution Framework
# =============================================================================

# Parse commands.conf and execute commands for a given hook
execute_commands() {
    local hook_name="$1"
    local staged_files_file="${2:-}"
    
    if [[ ! -f "$COMMANDS_CONF" ]]; then
        log_debug "$hook_name" "No commands.conf found, skipping custom commands"
        return 0
    fi
    
    # Read and parse commands for this hook
    local commands=()
    local priorities=()
    local mandatory_flags=()
    local timeouts=()
    local descriptions=()
    
    while IFS=':' read -r cmd_hook priority mandatory timeout command description; do
        # Skip comments and empty lines
        [[ "$cmd_hook" =~ ^#.*$ ]] && continue
        [[ -z "$cmd_hook" ]] && continue
        
        # Skip commands for other hooks
        [[ "$cmd_hook" != "$hook_name" ]] && continue
        
        commands+=("$command")
        priorities+=("$priority")
        mandatory_flags+=("$mandatory")
        timeouts+=("$timeout")
        descriptions+=("$description")
    done < "$COMMANDS_CONF"
    
    if [[ ${#commands[@]} -eq 0 ]]; then
        log_debug "$hook_name" "No commands configured for this hook"
        return 0
    fi
    
    log_info "$hook_name" "Executing ${#commands[@]} custom commands"
    
    # Execute commands
    local failed_commands=()
    local passed_commands=()
    local parallel_enabled
    parallel_enabled="$(is_parallel_execution_enabled && echo "true" || echo "false")"
    
    echo ""
    echo -e "${BOLD}Running custom checks...${NC}"
    echo ""
    
    for i in "${!commands[@]}"; do
        local cmd="${commands[$i]}"
        local desc="${descriptions[$i]}"
        local mandatory="${mandatory_flags[$i]}"
        local timeout="${timeouts[$i]}"
        
        # Replace {staged} placeholder with staged files
        if [[ -n "$staged_files_file" ]] && [[ "$cmd" == *"{staged}"* ]]; then
            local staged_files
            staged_files="$(cat "$staged_files_file" 2>/dev/null | tr '\n' ' ')"
            cmd="${cmd//\{staged\}/$staged_files}"
        fi
        
        echo -ne "  ${desc}... "
        log_info "$hook_name" "Executing: $cmd (timeout: ${timeout}s)"
        
        local start_time
        start_time="$(date +%s)"
        
        # Execute with timeout
        local exit_code=0
        local output
        output="$(timeout "${timeout}s" bash -c "$cmd" 2>&1)" || exit_code=$?
        
        local end_time
        end_time="$(date +%s)"
        local duration=$((end_time - start_time))
        
        if [[ $exit_code -eq 0 ]]; then
            echo -e "${GREEN}✓${NC} (${duration}s)"
            passed_commands+=("$desc")
            log_info "$hook_name" "Command passed: $desc (exit: $exit_code, duration: ${duration}s)"
            
            # Auto-add files if enabled and this is a fixing command
            if is_auto_add_after_fix_enabled && [[ "$cmd" == *"fix"* ]] || [[ "$cmd" == *"prettier"* ]]; then
                if [[ -n "$staged_files_file" ]]; then
                    log_info "$hook_name" "Auto-staging modified files after fix"
                    git add -u
                fi
            fi
        else
            echo -e "${RED}✗${NC} (exit: $exit_code)"
            log_error "$hook_name" "Command failed: $desc (exit: $exit_code, duration: ${duration}s)"
            log_error "$hook_name" "Output: $output"
            
            if [[ "$mandatory" == "true" ]]; then
                failed_commands+=("$desc (exit code: $exit_code)")
            else
                print_warning "Non-mandatory check failed: $desc"
            fi
            
            # Show command output if there were errors
            if [[ -n "$output" ]]; then
                echo ""
                echo -e "${YELLOW}Output:${NC}"
                echo "$output" | sed 's/^/  /'
                echo ""
            fi
        fi
    done
    
    # Report results
    if [[ ${#failed_commands[@]} -gt 0 ]]; then
        echo ""
        print_error_header "$hook_name"
        
        print_section "Failed Checks"
        for failed in "${failed_commands[@]}"; do
            print_failure "$failed"
        done
        
        if [[ ${#passed_commands[@]} -gt 0 ]]; then
            print_section "Passed Checks"
            for passed in "${passed_commands[@]}"; do
                print_success "$passed"
            done
        fi
        
        print_error_footer "git commit"
        return 1
    fi
    
    echo ""
    log_info "$hook_name" "All custom commands passed"
    return 0
}

# =============================================================================
# Bypass Check
# =============================================================================

should_bypass_hooks() {
    [[ "${BYPASS_HOOKS:-}" == "1" ]]
}

should_allow_direct_protected() {
    [[ "${ALLOW_DIRECT_PROTECTED:-}" == "1" ]]
}

# =============================================================================
# Smart Hints
# =============================================================================

print_lockfile_hint() {
    echo ""
    print_warning "Lockfile changes detected"
    echo "  Make sure to run your package manager's install command:"
    echo "    • npm: npm ci"
    echo "    • yarn: yarn install --frozen-lockfile"
    echo "    • pnpm: pnpm install --frozen-lockfile"
    echo "    • composer: composer install"
    echo "    • pip: pip install -r requirements.txt"
    echo ""
}

print_iac_hint() {
    echo ""
    print_warning "Infrastructure-as-Code changes detected"
    echo "  Remember to:"
    echo "    • Run terraform plan / validate"
    echo "    • Review changes in staging environment"
    echo "    • Update documentation if infrastructure changed"
    echo ""
}

print_ci_hint() {
    echo ""
    print_warning "CI/CD configuration changes detected"
    echo "  Remember to:"
    echo "    • Test pipeline locally if possible"
    echo "    • Review changes with DevOps team"
    echo "    • Update documentation if workflow changed"
    echo ""
}

print_force_push_hint() {
    echo ""
    print_info "After rebasing, remember to use --force-with-lease:"
    echo -e "  ${CYAN}git push --force-with-lease${NC}"
    echo ""
    echo "  This is safer than --force as it checks that your local"
    echo "  copy is up-to-date with the remote branch."
    echo ""
}

# =============================================================================
# Initialization
# =============================================================================

log_debug "common" "Common library loaded successfully"
