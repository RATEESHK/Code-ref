#!/usr/bin/env bash

# =============================================================================
# Git Hooks Uninstallation Script
# Removes Git Flow hook suite and restores default configuration
# =============================================================================

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOKS_DIR="${SCRIPT_DIR}"
GIT_DIR="$(git rev-parse --git-dir 2>/dev/null || echo "")"

# =============================================================================
# Helper Functions
# =============================================================================

print_header() {
    echo ""
    echo -e "${RED}${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${RED}${BOLD}  Git Flow Hook Suite - Uninstallation${NC}"
    echo -e "${RED}${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo ""
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_info() {
    echo -e "${CYAN}ℹ${NC} $1"
}

# =============================================================================
# Confirmation
# =============================================================================

confirm_uninstall() {
    echo -e "${YELLOW}${BOLD}WARNING: This will remove all Git Flow hooks and configurations.${NC}"
    echo ""
    echo "The following will be removed/reset:"
    echo "  • core.hooksPath configuration"
    echo "  • Git Flow specific configurations"
    echo "  • Hook configuration (hooks.maxCommits, etc.)"
    echo ""
    echo "The following will be archived:"
    echo "  • Hook logs (.githooks/logs/)"
    echo ""
    
    read -p "Do you want to continue? (yes/no): " -r
    echo ""
    
    if [[ ! $REPLY =~ ^[Yy][Ee][Ss]$ ]]; then
        echo "Uninstallation cancelled."
        echo ""
        exit 0
    fi
}

# =============================================================================
# Uninstallation Steps
# =============================================================================

step_1_archive_logs() {
    echo -e "${BOLD}Step 1: Archiving logs...${NC}"
    echo ""
    
    local log_dir="${HOOKS_DIR}/logs"
    
    if [[ -d "$log_dir" ]] && [[ -n "$(ls -A "$log_dir" 2>/dev/null)" ]]; then
        local timestamp
        timestamp="$(date +%Y%m%d_%H%M%S)"
        local archive_name="hooks-logs-${timestamp}.tar.gz"
        
        tar -czf "$archive_name" -C "${HOOKS_DIR}" logs 2>/dev/null || {
            print_warning "Could not create archive (tar not available)"
            
            # Fallback: move logs to backup directory
            local backup_dir="${HOOKS_DIR}/logs.backup.${timestamp}"
            mv "$log_dir" "$backup_dir"
            print_success "Moved logs to: $backup_dir"
            echo ""
            return
        }
        
        print_success "Archived logs to: $archive_name"
        
        # Remove logs directory
        rm -rf "$log_dir"
        print_success "Removed logs directory"
    else
        print_info "No logs to archive"
    fi
    
    echo ""
}

step_2_remove_git_config() {
    echo -e "${BOLD}Step 2: Removing Git configurations...${NC}"
    echo ""
    
    # Remove hooks path
    local hooks_path
    hooks_path="$(git config --local core.hooksPath 2>/dev/null || echo "")"
    
    if [[ -n "$hooks_path" ]]; then
        git config --local --unset core.hooksPath
        print_success "Removed core.hooksPath (was: $hooks_path)"
    else
        print_info "core.hooksPath not set"
    fi
    
    # Remove hook-specific configurations
    local hook_configs=(
        "hooks.maxCommits"
        "hooks.autoAddAfterFix"
        "hooks.parallelExecution"
    )
    
    for config in "${hook_configs[@]}"; do
        if git config --local "$config" >/dev/null 2>&1; then
            local value
            value="$(git config --local "$config")"
            git config --local --unset "$config"
            print_success "Removed $config (was: $value)"
        fi
    done
    
    echo ""
}

step_3_restore_git_config() {
    echo -e "${BOLD}Step 3: Restoring Git configurations (optional)...${NC}"
    echo ""
    
    # Ask if user wants to restore default Git configs
    read -p "Restore default Git configurations? (yes/no): " -r
    echo ""
    
    if [[ $REPLY =~ ^[Yy][Ee][Ss]$ ]]; then
        # Unset rebase.autosquash (restore to default)
        if git config --local rebase.autosquash >/dev/null 2>&1; then
            git config --local --unset rebase.autosquash
            print_success "Reset rebase.autosquash to default"
        fi
        
        # Unset fetch.prune (restore to default)
        if git config --local fetch.prune >/dev/null 2>&1; then
            git config --local --unset fetch.prune
            print_success "Reset fetch.prune to default"
        fi
        
        # Unset pull.rebase (restore to default)
        if git config --local pull.rebase >/dev/null 2>&1; then
            git config --local --unset pull.rebase
            print_success "Reset pull.rebase to default"
        fi
    else
        print_info "Keeping existing Git configurations"
    fi
    
    echo ""
}

step_4_remove_from_exclude() {
    echo -e "${BOLD}Step 4: Cleaning up .git/info/exclude...${NC}"
    echo ""
    
    local exclude_file="${GIT_DIR}/info/exclude"
    
    if [[ -f "$exclude_file" ]]; then
        if grep -q "^\.githooks/logs/" "$exclude_file" 2>/dev/null; then
            # Remove the line
            sed -i.bak '/^\.githooks\/logs\//d' "$exclude_file"
            rm -f "${exclude_file}.bak"
            print_success "Removed logs from .git/info/exclude"
        else
            print_info "Logs not found in .git/info/exclude"
        fi
    else
        print_info ".git/info/exclude does not exist"
    fi
    
    echo ""
}

step_5_verify_uninstallation() {
    echo -e "${BOLD}Step 5: Verifying uninstallation...${NC}"
    echo ""
    
    # Check hooks path
    local hooks_path
    hooks_path="$(git config --local core.hooksPath 2>/dev/null || echo "")"
    
    if [[ -z "$hooks_path" ]]; then
        print_success "Hooks path removed"
    else
        print_warning "Hooks path still set: $hooks_path"
    fi
    
    # Check hook configs
    if ! git config --local hooks.maxCommits >/dev/null 2>&1; then
        print_success "Hook configurations removed"
    else
        print_warning "Some hook configurations still present"
    fi
    
    # Check logs
    if [[ ! -d "${HOOKS_DIR}/logs" ]]; then
        print_success "Logs directory removed"
    else
        print_warning "Logs directory still exists"
    fi
    
    echo ""
}

# =============================================================================
# Summary
# =============================================================================

print_summary() {
    echo -e "${GREEN}${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}${BOLD}  Uninstallation Complete!${NC}"
    echo -e "${GREEN}${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo ""
    
    echo -e "${BOLD}What was removed:${NC}"
    echo ""
    echo "  ✓ core.hooksPath configuration"
    echo "  ✓ hooks.maxCommits configuration"
    echo "  ✓ hooks.autoAddAfterFix configuration"
    echo "  ✓ hooks.parallelExecution configuration"
    echo "  ✓ Logs directory (archived)"
    echo ""
    
    echo -e "${BOLD}What remains:${NC}"
    echo ""
    echo "  • Hook scripts (.githooks/)"
    echo "  • Configuration file (.githooks/commands.conf)"
    echo "  • Archived logs (if created)"
    echo ""
    
    echo -e "${BOLD}To completely remove hooks from repository:${NC}"
    echo ""
    echo "  1. Delete the .githooks directory:"
    echo "     rm -rf .githooks"
    echo ""
    echo "  2. Commit the change:"
    echo "     git add .githooks"
    echo "     git commit -m \"chore: Remove Git Flow hooks\""
    echo ""
    
    echo -e "${BOLD}To reinstall hooks:${NC}"
    echo ""
    echo "  Run the installation script again:"
    echo "    .githooks/install-hooks.sh"
    echo ""
    
    echo -e "${GREEN}${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo ""
}

# =============================================================================
# Main Uninstallation
# =============================================================================

main() {
    print_header
    
    # Validate environment
    if [[ -z "$GIT_DIR" ]]; then
        print_error "Not in a git repository"
        echo ""
        exit 1
    fi
    
    confirm_uninstall
    
    step_1_archive_logs
    step_2_remove_git_config
    step_3_restore_git_config
    step_4_remove_from_exclude
    step_5_verify_uninstallation
    
    print_summary
}

main "$@"
