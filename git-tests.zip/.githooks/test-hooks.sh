#!/usr/bin/env bash

# =============================================================================
# Git Hooks Test Suite
# Comprehensive tests for all hook functionality
# =============================================================================

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# Test counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# =============================================================================
# Helper Functions
# =============================================================================

print_header() {
    echo ""
    echo -e "${BLUE}${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}${BOLD}  Git Flow Hook Suite - Test Suite${NC}"
    echo -e "${BLUE}${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo ""
}

print_test() {
    echo ""
    echo -e "${BOLD}Test $1: $2${NC}"
    echo "-----------------------------------------------------------"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_failure() {
    echo -e "${RED}✗${NC} $1"
}

test_passed() {
    ((TESTS_PASSED++))
    print_success "PASSED"
}

test_failed() {
    ((TESTS_FAILED++))
    print_failure "FAILED: $1"
}

run_test() {
    ((TESTS_RUN++))
}

# =============================================================================
# Setup
# =============================================================================

setup_test_env() {
    echo "Setting up test environment..."
    
    # Ensure we're in the repo root
    cd "$(git rev-parse --show-toplevel)"
    
    # Install hooks if not already installed
    if [[ "$(git config --local core.hooksPath)" != ".githooks" ]]; then
        echo "Installing hooks..."
        .githooks/install-hooks.sh > /dev/null 2>&1
    fi
    
    # Ensure develop branch exists
    if ! git rev-parse --verify develop >/dev/null 2>&1; then
        git checkout -b develop 2>/dev/null || git checkout develop
    fi
    
    print_success "Test environment ready"
}

cleanup_test_branches() {
    echo ""
    echo "Cleaning up test branches..."
    
    local test_branches
    test_branches="$(git branch | grep -E 'test-|feat-TEST-|bugfix-TEST-|hotfix-TEST-' || true)"
    
    if [[ -n "$test_branches" ]]; then
        echo "$test_branches" | xargs -I {} git branch -D {} 2>/dev/null || true
        print_success "Test branches cleaned up"
    else
        print_success "No test branches to clean up"
    fi
}

# =============================================================================
# Test Cases
# =============================================================================

test_branch_naming_valid() {
    run_test
    print_test "$TESTS_RUN" "Valid branch naming"
    
    local branch="feat-TEST-123-valid-branch-name"
    
    # Create branch
    git checkout develop >/dev/null 2>&1
    if git checkout -b "$branch" >/dev/null 2>&1; then
        # Create a dummy commit
        echo "test $RANDOM" > test-file.txt
        git add test-file.txt
        
        if git commit -m "feat: TEST-123 Valid commit" >/dev/null 2>&1; then
            test_passed
            git checkout develop >/dev/null 2>&1
            git branch -D "$branch" >/dev/null 2>&1
            rm -f test-file.txt
            return 0
        fi
    fi
    
    test_failed "Could not create valid branch"
    return 1
}

test_branch_naming_invalid() {
    run_test
    print_test "$TESTS_RUN" "Invalid branch naming (should fail on push)"
    
    local branch="invalid-branch-name"
    
    # Create branch
    git checkout develop >/dev/null 2>&1
    if git checkout -b "$branch" >/dev/null 2>&1; then
        echo "test $RANDOM" > test-file.txt
        git add test-file.txt
        git commit -m "test" >/dev/null 2>&1
        
        # Try to push (should fail)
        # Note: This requires a remote, so we test the validation logic instead
        if .githooks/pre-push origin "$(git config --get remote.origin.url 2>/dev/null || echo 'test')" <<< "$branch $(git rev-parse HEAD) refs/heads/$branch 0000000000000000000000000000000000000000" 2>&1 | grep -q "Invalid branch name"; then
            test_passed
        else
            test_failed "Invalid branch was not rejected"
        fi
        
        git checkout develop >/dev/null 2>&1
        git branch -D "$branch" >/dev/null 2>&1
        rm -f test-file.txt
        return 0
    fi
    
    test_failed "Test setup failed"
    return 1
}

test_commit_message_valid() {
    run_test
    print_test "$TESTS_RUN" "Valid commit message format"
    
    local branch="feat-TEST-456-test-commit-message"
    
    git checkout develop >/dev/null 2>&1
    git checkout -b "$branch" >/dev/null 2>&1
    
    echo "test $RANDOM" > test-file.txt
    git add test-file.txt
    
    if git commit -m "feat: TEST-456 Valid commit message" >/dev/null 2>&1; then
        test_passed
    else
        test_failed "Valid commit message was rejected"
    fi
    
    git checkout develop >/dev/null 2>&1
    git branch -D "$branch" >/dev/null 2>&1
    rm -f test-file.txt
}

test_commit_message_invalid() {
    run_test
    print_test "$TESTS_RUN" "Invalid commit message format (should fail)"
    
    local branch="feat-TEST-789-test-invalid-message"
    
    git checkout develop >/dev/null 2>&1
    git checkout -b "$branch" >/dev/null 2>&1
    
    echo "test $RANDOM" > test-file.txt
    git add test-file.txt
    
    # Should fail
    if git commit -m "invalid message format" 2>&1 | grep -q "Invalid commit message"; then
        test_passed
    else
        test_failed "Invalid commit message was not rejected"
    fi
    
    git checkout develop >/dev/null 2>&1
    git branch -D "$branch" >/dev/null 2>&1
    rm -f test-file.txt
}

test_protected_branch_commit() {
    run_test
    print_test "$TESTS_RUN" "Protected branch direct commit (should fail)"
    
    git checkout develop >/dev/null 2>&1
    
    echo "test $RANDOM" > test-file.txt
    git add test-file.txt
    
    # Should fail
    if git commit -m "feat: TEST-999 Direct commit" 2>&1 | grep -q "protected branch"; then
        test_passed
        git reset HEAD~1 >/dev/null 2>&1
    else
        test_failed "Protected branch commit was not blocked"
        git reset HEAD~1 >/dev/null 2>&1
    fi
    
    rm -f test-file.txt
}

test_bypass_hooks() {
    run_test
    print_test "$TESTS_RUN" "Bypass hooks mechanism"
    
    git checkout develop >/dev/null 2>&1
    
    echo "test $RANDOM" > test-file.txt
    git add test-file.txt
    
    # Should succeed with bypass
    if BYPASS_HOOKS=1 git commit -m "test bypass" >/dev/null 2>&1; then
        test_passed
        git reset HEAD~1 >/dev/null 2>&1
    else
        test_failed "Bypass mechanism did not work"
        git reset HEAD~1 >/dev/null 2>&1
    fi
    
    rm -f test-file.txt
}

test_jira_auto_population() {
    run_test
    print_test "$TESTS_RUN" "JIRA ID auto-population"
    
    local branch="feat-TEST-111-auto-jira"
    
    git checkout develop >/dev/null 2>&1
    git checkout -b "$branch" >/dev/null 2>&1
    
    echo "test $RANDOM" > test-file.txt
    git add test-file.txt
    
    # Commit without JIRA ID (should be auto-populated)
    if git commit -m "Add feature" >/dev/null 2>&1; then
        # Check if JIRA ID was added
        local last_commit
        last_commit="$(git log -1 --pretty=%B)"
        
        if echo "$last_commit" | grep -q "TEST-111"; then
            test_passed
        else
            test_failed "JIRA ID was not auto-populated"
        fi
    else
        test_failed "Commit failed"
    fi
    
    git checkout develop >/dev/null 2>&1
    git branch -D "$branch" >/dev/null 2>&1
    rm -f test-file.txt
}

test_configuration() {
    run_test
    print_test "$TESTS_RUN" "Hook configuration"
    
    # Check if configurations are set
    local hooks_path
    hooks_path="$(git config --local core.hooksPath)"
    
    if [[ "$hooks_path" == ".githooks" ]]; then
        test_passed
    else
        test_failed "Hooks path not configured correctly: $hooks_path"
    fi
}

test_log_creation() {
    run_test
    print_test "$TESTS_RUN" "Log file creation"
    
    if [[ -d ".githooks/logs" ]]; then
        test_passed
    else
        test_failed "Log directory does not exist"
    fi
}

# =============================================================================
# Main Test Execution
# =============================================================================

main() {
    print_header
    
    setup_test_env
    
    echo ""
    echo -e "${BOLD}Running tests...${NC}"
    
    # Run all tests
    test_configuration
    test_log_creation
    test_branch_naming_valid
    test_branch_naming_invalid
    test_commit_message_valid
    test_commit_message_invalid
    test_protected_branch_commit
    test_bypass_hooks
    test_jira_auto_population
    
    cleanup_test_branches
    
    # Print summary
    echo ""
    echo -e "${BLUE}${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BOLD}Test Summary${NC}"
    echo -e "${BLUE}${BOLD}═══════════════════════════════════════════════════════════${NC}"
    echo ""
    echo "  Tests run:    $TESTS_RUN"
    echo -e "  Tests passed: ${GREEN}$TESTS_PASSED${NC}"
    echo -e "  Tests failed: ${RED}$TESTS_FAILED${NC}"
    echo ""
    
    if [[ $TESTS_FAILED -eq 0 ]]; then
        echo -e "${GREEN}${BOLD}✓ All tests passed!${NC}"
        echo ""
        exit 0
    else
        echo -e "${RED}${BOLD}✗ Some tests failed${NC}"
        echo ""
        exit 1
    fi
}

main "$@"
