# Changelog

All notable changes to the Git Flow Hook Suite will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-11-07

### Added
- **Complete Git Flow enforcement** following Vincent Driessen's branching model
- **Cross-platform support** for Linux, macOS, and Windows (Git Bash)
- **Branch naming validation** with comprehensive error messages and fix instructions
- **Git Flow branch source validation** (features from develop, hotfixes from main)
- **Curated history enforcement** with configurable commit limits (default: 5)
- **Linear history enforcement** blocking merge commits
- **Commit message format validation** with auto-population of JIRA IDs
- **Protected branch detection** preventing direct commits to main/develop/release/*
- **Custom command execution framework** via commands.conf
  - Priority-based execution
  - Mandatory vs optional checks
  - Timeout support
  - Parallel execution support (configurable)
  - Auto-staging after fixes (configurable)
- **Smart hints system** detecting:
  - Lockfile changes (npm, yarn, pnpm, pip, composer, etc.)
  - Infrastructure-as-Code changes (Terraform, Docker, K8s)
  - CI/CD configuration changes
- **Comprehensive logging** with timestamps and stack traces
- **Contextual error messages** showing:
  - Current Git state
  - Exact fix commands
  - Git Flow workflow guidance
  - Valid examples
- **Bypass mechanisms**:
  - `BYPASS_HOOKS=1` - Skip all hooks
  - `ALLOW_DIRECT_PROTECTED=1` - Allow protected branch operations
- **Installation scripts**:
  - `install-hooks.sh` (Unix-like systems)
  - `install-hooks.bat` (Windows)
- **Uninstallation script** with log archival
- **Comprehensive documentation** with examples and troubleshooting
- **Test suite** for hook validation
- **Hook logs** automatically created and git-ignored

### Hooks Implemented
- `pre-commit` - Protected branch validation, custom commands
- `prepare-commit-msg` - JIRA ID auto-population
- `commit-msg` - Commit message format validation
- `applypatch-msg` - Patch message validation (git am)
- `pre-push` - Branch naming, curated history, linear history enforcement
- `post-checkout` - Protected branch warnings, Git Flow guidance
- `post-merge` - Smart hints for lockfiles, IaC, CI/CD
- `pre-rebase` - Protected branch rebase prevention
- `post-rewrite` - Force push reminders

### Configuration
- `hooks.maxCommits` - Maximum commits per branch (default: 5)
- `hooks.autoAddAfterFix` - Auto-stage after linting fixes (default: false)
- `hooks.parallelExecution` - Parallel command execution (default: false)
- `core.hooksPath` - Set to .githooks
- `rebase.autosquash` - Enabled for Git Flow
- `fetch.prune` - Enabled for cleanup
- `pull.rebase` - Enabled for linear history

### Branch Naming Patterns
- **Long-lived**: `main`, `develop`, `release/*`
- **Short-lived**: `<type>-<JIRA-ID>-<description>`
  - Supported types: feat, feature, bugfix, fix, hotfix, release, docs, test, refactor, perf, chore, build, ci, style, techdebt, revert

### Commit Message Format
- **Format**: `<type>: <JIRA-ID> <description>`
- **Types**: feat, fix, chore, break, tests, build, ci, docs, perf, refactor, style, test
- **Auto-population**: JIRA IDs extracted from branch names

### Git Flow Enforcement
- Features branch from `develop`, merge to `develop`
- Hotfixes branch from `main`, merge to `main` and `develop`
- Releases branch from `develop`, merge to `main` and `develop`
- Protected branches block direct commits
- Rebase workflow enforced (no merge commits)
- Squashed commits enforced (configurable limit)

### Developer Experience
- Colored, formatted error messages
- Contextual help based on current Git state
- Exact fix commands (not generic examples)
- Git Flow workflow guidance
- Force push safety reminders
- Comprehensive hook logs for debugging

### Files Structure
```
.githooks/
├── lib/
│   └── common.sh              # 1500+ lines of shared functions
├── logs/                      # Auto-created, git-ignored
├── pre-commit                 # 150 lines
├── prepare-commit-msg         # 130 lines
├── commit-msg                 # 50 lines
├── applypatch-msg             # 50 lines
├── pre-push                   # 350 lines
├── post-checkout              # 180 lines
├── post-merge                 # 90 lines
├── pre-rebase                 # 180 lines
├── post-rewrite               # 50 lines
├── commands.conf              # Custom command configuration
├── install-hooks.sh           # 400 lines
├── install-hooks.bat          # 300 lines (Windows)
├── uninstall-hooks.sh         # 250 lines
├── test-hooks.sh              # 350 lines
├── .gitattributes             # Line ending configuration
├── .gitignore                 # Log exclusion
├── README.md                  # 600+ lines of documentation
└── CHANGELOG.md               # This file
```

### Total Lines of Code
- Shell scripts: ~4,500 lines
- Documentation: ~800 lines
- Configuration: ~50 lines
- **Total: ~5,350 lines of production-grade code**

### Platform Support
- ✅ Linux (Ubuntu, Debian, RHEL, etc.)
- ✅ macOS (Intel and Apple Silicon)
- ✅ Windows (Git Bash, WSL)
- ✅ Git version 2.0+
- ✅ Bash 4.0+

### Quality Assurance
- Comprehensive error handling with stack traces
- Input validation on all user data
- Safe file operations (temp files, atomic writes)
- Cross-platform path handling
- Color support detection
- Graceful degradation for missing tools

### Security
- No execution of untrusted code
- Proper quoting of all variables
- Input sanitization for branch names and messages
- Secure temp file creation with cleanup
- No hardcoded credentials or secrets

---

## Future Enhancements (Planned)

### Version 1.1.0 (Planned)
- [ ] Integration with popular JIRA/issue tracking APIs
- [ ] Automatic PR template population
- [ ] Code quality metrics collection
- [ ] Integration with SonarQube/CodeClimate
- [ ] Team-wide hook configuration distribution
- [ ] Webhook notifications (Slack, Teams, Discord)
- [ ] Advanced commit statistics and reports

### Version 1.2.0 (Planned)
- [ ] Support for GitHub Flow and GitLab Flow
- [ ] Custom branching model configuration
- [ ] Hook performance profiling
- [ ] Interactive mode for conflict resolution
- [ ] Integration with pre-commit framework
- [ ] Docker container for testing
- [ ] CI/CD integration examples

---

## Known Limitations

1. **Remote Branch Handling**: Cannot block checkout of non-compliant remote branches (Git limitation)
2. **Parallel Execution**: Commands with same priority run sequentially by default (enable with config)
3. **Windows Line Endings**: Requires `.gitattributes` configuration for proper CRLF handling
4. **Git Version**: Some features require Git 2.0+ (particularly `--force-with-lease`)

---

## Migration Guide

### From No Hooks
1. Run `install-hooks.sh`
2. Rename existing branches to follow naming convention
3. Test on a feature branch before enforcing team-wide

### From Other Hook Systems
1. Back up existing hooks: `cp -r .git/hooks .git/hooks.backup`
2. Run `install-hooks.sh`
3. Migrate custom logic to `commands.conf`
4. Test thoroughly before team rollout

---

## Credits

- **Git Flow Model**: [Vincent Driessen](https://nvie.com/posts/a-successful-git-branching-model/)
- **Conventional Commits**: [conventionalcommits.org](https://www.conventionalcommits.org/)
- **Inspiration**: Teams that value clean Git history and disciplined workflows

---

**Maintained with ❤️ for engineering teams that take Git Flow seriously.**
