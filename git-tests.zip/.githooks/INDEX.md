# Git Flow Hook Suite - File Index

## 📋 Complete File Listing

This document provides an overview of all files in the Git Flow Hook Suite.

---

## 🎯 Core Hook Files (Executable Scripts)

### Client-Side Hooks

| File | Lines | Purpose | When It Runs |
|------|-------|---------|--------------|
| `pre-commit` | 147 | Validates protected branches, runs custom commands | Before commit is created |
| `prepare-commit-msg` | 132 | Auto-populates JIRA IDs from branch names | Before commit message editor opens |
| `commit-msg` | 51 | Validates commit message format | After commit message is saved |
| `applypatch-msg` | 51 | Validates patch message format | When applying patches via `git am` |
| `pre-push` | 345 | Enforces branch naming, curated history, linear history | Before pushing to remote |
| `post-checkout` | 181 | Warns about protected branches, provides Git Flow guidance | After checking out a branch |
| `post-merge` | 91 | Provides smart hints after merging | After merge is completed |
| `pre-rebase` | 180 | Prevents rebasing protected branches | Before rebase starts |
| `post-rewrite` | 62 | Reminds about force push after rebase | After rebase/amend is completed |

**Total Hook Lines:** 1,240 lines

---

## 📚 Shared Library

| File | Lines | Purpose |
|------|-------|---------|
| `lib/common.sh` | 1,574 | Shared functions, logging, error formatting, Git Flow logic |

**Key Functions:**
- Logging (with timestamps and stack traces)
- Branch validation and naming
- Commit message validation
- Protected branch detection
- Git Flow base branch determination
- Error message formatting
- Smart file detection (lockfiles, IaC, CI/CD)
- Command execution framework
- Configuration management

---

## 🛠️ Installation & Management Scripts

| File | Lines | Platform | Purpose |
|------|-------|----------|---------|
| `install-hooks.sh` | 407 | Unix-like (Linux, macOS, Git Bash) | Automated installation with verification |
| `install-hooks.bat` | 293 | Windows (Command Prompt) | Windows-specific installer |
| `uninstall-hooks.sh` | 350 | Unix-like | Uninstaller with log archival and cleanup |
| `getting-started.sh` | 410 | Unix-like | Interactive guide for new users |
| `test-hooks.sh` | 350 | Unix-like | Automated test suite with 9 test cases |

**Total Management Lines:** 1,810 lines

---

## ⚙️ Configuration Files

| File | Lines | Purpose |
|------|-------|---------|
| `commands.conf` | 45 | Custom command configuration for linting, testing, etc. |
| `.gitattributes` | 25 | Cross-platform line ending configuration (LF for scripts) |
| `.gitignore` | 12 | Excludes log files and temporary files from git |

**Configuration Format (commands.conf):**
```
HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
```

---

## 📖 Documentation Files

| File | Lines | Content | Audience |
|------|-------|---------|----------|
| `README.md` | 620 | Complete feature documentation, workflows, troubleshooting | All users |
| `QUICK_REFERENCE.md` | 240 | Cheat sheet with common commands and patterns | Daily use |
| `INSTALLATION.md` | 380 | Step-by-step installation guide with troubleshooting | New installers |
| `CHANGELOG.md` | 250 | Version history, features, future enhancements | Maintainers |
| `PACKAGE_SUMMARY.md` | 450 | Complete package overview, metrics, compliance | Management |
| `INDEX.md` | (This file) | File listing and organization | Reference |

**Total Documentation Lines:** ~2,180 lines

---

## 📁 Directories

### `lib/`
Shared library code used by all hooks.

**Contents:**
- `common.sh` - All shared functions

### `logs/` (Auto-Created)
Hook execution logs for debugging.

**Auto-Generated Files:**
- `pre-commit.log`
- `prepare-commit-msg.log`
- `commit-msg.log`
- `applypatch-msg.log`
- `pre-push.log`
- `post-checkout.log`
- `post-merge.log`
- `pre-rebase.log`
- `post-rewrite.log`

**Note:** Logs are automatically excluded from Git via `.git/info/exclude`

---

## 📊 Statistics Summary

### By Category

| Category | Files | Lines | Percentage |
|----------|-------|-------|------------|
| Hook Scripts | 9 | 1,240 | 23.2% |
| Shared Library | 1 | 1,574 | 29.4% |
| Management Scripts | 5 | 1,810 | 33.8% |
| Configuration | 3 | 82 | 1.5% |
| Documentation | 6 | 2,180 | 12.1% |
| **Total** | **24** | **~5,350** | **100%** |

### By File Type

| Type | Count | Purpose |
|------|-------|---------|
| Bash Scripts (`.sh`) | 14 | Executable hooks and utilities |
| Hook Files (no extension) | 9 | Git hook entry points |
| Markdown (`.md`) | 6 | Documentation |
| Configuration (`.conf`, `.gitattributes`, `.gitignore`) | 3 | Settings |
| Batch Files (`.bat`) | 1 | Windows installer |

---

## 🎯 File Relationships

### Dependency Graph

```
All Hooks
    ├── lib/common.sh (sourced by all hooks)
    │   ├── Logging functions
    │   ├── Branch validation
    │   ├── Commit validation
    │   ├── Error formatting
    │   └── Command execution
    │
    └── commands.conf (read by hooks)
        └── Custom command definitions

Installation Scripts
    ├── install-hooks.sh (Unix)
    ├── install-hooks.bat (Windows)
    └── Sets: core.hooksPath, Git configs, permissions

Management Scripts
    ├── uninstall-hooks.sh
    ├── test-hooks.sh
    └── getting-started.sh

Documentation
    ├── README.md (main reference)
    ├── QUICK_REFERENCE.md (cheat sheet)
    ├── INSTALLATION.md (setup guide)
    ├── CHANGELOG.md (version history)
    ├── PACKAGE_SUMMARY.md (overview)
    └── INDEX.md (this file)
```

---

## 🔍 Quick Find Guide

### I want to...

**Install the hooks**
- Unix: `install-hooks.sh`
- Windows: `install-hooks.bat`
- Help: `INSTALLATION.md`

**Learn how to use Git Flow**
- Start: `getting-started.sh` (interactive)
- Reference: `QUICK_REFERENCE.md` (commands)
- Complete: `README.md` (workflows)

**Customize the hooks**
- Commands: `commands.conf`
- Settings: Git config (see `INSTALLATION.md`)
- Code: `lib/common.sh`

**Troubleshoot issues**
- Errors: Check `logs/` directory
- Guide: `INSTALLATION.md` (troubleshooting section)
- Docs: `README.md` (troubleshooting section)

**Test the hooks**
- Automated: `test-hooks.sh`
- Manual: `INSTALLATION.md` (testing section)
- Interactive: `getting-started.sh`

**Uninstall**
- Script: `uninstall-hooks.sh`
- Guide: `INSTALLATION.md` (uninstallation section)

**Understand what's included**
- Summary: `PACKAGE_SUMMARY.md`
- Changes: `CHANGELOG.md`
- Files: `INDEX.md` (this file)

---

## 🚀 Getting Started Checklist

- [ ] Run `install-hooks.sh` (or `.bat` on Windows)
- [ ] Read `QUICK_REFERENCE.md`
- [ ] Run `getting-started.sh` (interactive guide)
- [ ] Test with a feature branch
- [ ] Customize `commands.conf` for your tools
- [ ] Share `INSTALLATION.md` with team
- [ ] Keep `QUICK_REFERENCE.md` handy

---

## 📝 Maintenance Notes

### When Adding New Hooks

1. Create hook file in `.githooks/`
2. Add shebang: `#!/usr/bin/env bash`
3. Source common library: `source "${SCRIPT_DIR}/lib/common.sh"`
4. Update `install-hooks.sh` to make it executable
5. Update `install-hooks.bat` with chmod command
6. Add to this INDEX.md
7. Update `README.md` with hook description
8. Add test case to `test-hooks.sh`

### When Adding New Features

1. Implement in `lib/common.sh` if shared
2. Update relevant hooks to use new feature
3. Add configuration option if needed
4. Update `CHANGELOG.md`
5. Update `README.md` and `QUICK_REFERENCE.md`
6. Add test case to `test-hooks.sh`

---

## 🎓 Learning Path

**Beginner (Getting Started):**
1. `getting-started.sh` - Interactive guide
2. `QUICK_REFERENCE.md` - Essential commands
3. `INSTALLATION.md` - Setup and troubleshooting

**Intermediate (Daily Usage):**
1. `QUICK_REFERENCE.md` - Always keep open
2. `README.md` (workflows section) - Git Flow patterns
3. `commands.conf` - Customize for your project

**Advanced (Customization):**
1. `lib/common.sh` - Understand the functions
2. Individual hook files - See implementation
3. `test-hooks.sh` - Testing framework
4. `PACKAGE_SUMMARY.md` - Complete overview

---

## 🔐 File Permissions

### Unix-like Systems (Linux, macOS, Git Bash)

**Should be executable (755):**
- All hook files (no extension)
- All `.sh` files
- `lib/common.sh`

**Should be readable (644):**
- All `.md` files
- Configuration files (`.conf`, `.gitattributes`, `.gitignore`)
- `.bat` files (Windows handles differently)

**Set by installer:**
```bash
chmod +x .githooks/*.sh
chmod +x .githooks/pre-*
chmod +x .githooks/post-*
chmod +x .githooks/prepare-*
chmod +x .githooks/commit-msg
chmod +x .githooks/applypatch-msg
chmod +x .githooks/lib/common.sh
```

---

## 🎨 Color Coding Guide

All scripts use ANSI color codes for better readability:

- 🔴 **Red** - Errors, failures, critical issues
- 🟢 **Green** - Success, passed checks
- 🟡 **Yellow** - Warnings, non-critical issues
- 🔵 **Blue** - Headers, sections
- 🔵 **Cyan** - Commands, file paths
- 🟣 **Magenta** - Special messages
- **Bold** - Important information

---

## 🌐 Platform-Specific Files

### Unix-like (Linux, macOS, Git Bash)
- Primary: All `.sh` scripts
- Line endings: LF (enforced by `.gitattributes`)

### Windows
- Primary: `install-hooks.bat`
- Line endings: CRLF (enforced by `.gitattributes`)
- Note: Hooks run in Git Bash even on Windows

---

## 📞 Support & Resources

### Internal Documentation
- `README.md` - Complete guide
- `INSTALLATION.md` - Setup help
- `QUICK_REFERENCE.md` - Quick lookup

### External References
- [Git Flow Model](https://nvie.com/posts/a-successful-git-branching-model/)
- [Git Hooks Documentation](https://git-scm.com/docs/githooks)
- [Conventional Commits](https://www.conventionalcommits.org/)

### Debugging
- Check logs: `.githooks/logs/*.log`
- Run tests: `.githooks/test-hooks.sh`
- Enable debug: `DEBUG_HOOKS=1 git commit`

---

**Last Updated:** 2025-11-07  
**Version:** 1.0.0  
**Total Files:** 24  
**Total Lines:** ~5,350
