#!/usr/bin/env bash

# =============================================================================
# Git Flow Hook Suite - Getting Started Script
# Interactive guide to help you get started with the hooks
# =============================================================================

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
NC='\033[0m'

clear

cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║        🚀 Git Flow Hook Suite - Getting Started 🚀            ║
║                                                               ║
║     Production-Grade Git Flow Enforcement for Your Team      ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
EOF

echo ""
echo -e "${CYAN}Welcome to the Git Flow Hook Suite!${NC}"
echo ""
echo "This interactive guide will help you:"
echo "  ✅ Understand what the hooks do"
echo "  ✅ Install the hooks in your repository"
echo "  ✅ Test the installation"
echo "  ✅ Learn the basic workflows"
echo ""

read -p "Press Enter to continue..." -r
clear

# =============================================================================
# Section 1: What Are These Hooks?
# =============================================================================

cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║                   📚 What Are These Hooks?                    ║
╚═══════════════════════════════════════════════════════════════╝
EOF

echo ""
echo -e "${BOLD}Git Flow Hook Suite enforces:${NC}"
echo ""
echo "  1️⃣  ${GREEN}Git Flow Branching Strategy${NC}"
echo "      • Features from 'develop', hotfixes from 'main'"
echo "      • Protected branches (main, develop, release/*)"
echo "      • Linear history (no merge commits)"
echo ""
echo "  2️⃣  ${GREEN}Branch Naming Convention${NC}"
echo "      • Format: feat-PROJ-123-description"
echo "      • Includes JIRA ticket ID"
echo "      • Type-based prefixes (feat, bugfix, hotfix, etc.)"
echo ""
echo "  3️⃣  ${GREEN}Commit Message Standards${NC}"
echo "      • Format: feat: PROJ-123 Description"
echo "      • Auto-populates JIRA IDs from branch names"
echo "      • Conventional commit types"
echo ""
echo "  4️⃣  ${GREEN}Curated History${NC}"
echo "      • Maximum 5 commits per branch (configurable)"
echo "      • Encourages squashing related commits"
echo "      • Keeps history clean and reviewable"
echo ""
echo "  5️⃣  ${GREEN}Developer Quality of Life${NC}"
echo "      • Smart hints for lockfile changes"
echo "      • Protected branch warnings"
echo "      • Detailed, contextual error messages"
echo ""

read -p "Press Enter to continue..." -r
clear

# =============================================================================
# Section 2: Installation Check
# =============================================================================

cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║                    🔧 Installation Check                      ║
╚═══════════════════════════════════════════════════════════════╝
EOF

echo ""
echo "Checking if hooks are already installed..."
echo ""

HOOKS_INSTALLED=false
HOOKS_PATH="$(git config --local core.hooksPath 2>/dev/null || echo '')"

if [[ "$HOOKS_PATH" == ".githooks" ]]; then
    echo -e "${GREEN}✓${NC} Hooks are already installed!"
    echo "  Hooks path: $HOOKS_PATH"
    HOOKS_INSTALLED=true
else
    echo -e "${YELLOW}⚠${NC} Hooks are not installed yet"
    if [[ -n "$HOOKS_PATH" ]]; then
        echo "  Current hooks path: $HOOKS_PATH"
    fi
fi

echo ""

if ! $HOOKS_INSTALLED; then
    echo -e "${BOLD}Would you like to install the hooks now?${NC}"
    echo ""
    read -p "Install hooks? (yes/no): " -r
    echo ""
    
    if [[ $REPLY =~ ^[Yy][Ee][Ss]$ ]] || [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "Installing hooks..."
        echo ""
        
        SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
        if [[ -x "${SCRIPT_DIR}/install-hooks.sh" ]]; then
            "${SCRIPT_DIR}/install-hooks.sh"
        else
            echo -e "${RED}✗${NC} Installation script not found or not executable"
            echo "  Please run: .githooks/install-hooks.sh"
            exit 1
        fi
        
        echo ""
        echo -e "${GREEN}✓${NC} Installation complete!"
        HOOKS_INSTALLED=true
    else
        echo "Skipping installation. You can install later by running:"
        echo "  .githooks/install-hooks.sh"
        echo ""
        exit 0
    fi
fi

read -p "Press Enter to continue..." -r
clear

# =============================================================================
# Section 3: Understanding Branch Naming
# =============================================================================

cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║                  🌿 Branch Naming Guide                       ║
╚═══════════════════════════════════════════════════════════════╝
EOF

echo ""
echo -e "${BOLD}Branch Naming Format:${NC}"
echo ""
echo "  <type>-<JIRA-ID>-<description>"
echo ""
echo -e "${BOLD}Common Types:${NC}"
echo ""
echo "  ${GREEN}feat${NC}     → New feature (from develop)"
echo "  ${GREEN}bugfix${NC}   → Bug fix (from develop)"
echo "  ${GREEN}hotfix${NC}   → Critical fix (from main)"
echo "  ${GREEN}docs${NC}     → Documentation"
echo "  ${GREEN}test${NC}     → Testing"
echo "  ${GREEN}refactor${NC} → Code refactoring"
echo ""
echo -e "${BOLD}Valid Examples:${NC}"
echo ""
echo "  ✅ feat-PROJ-123-add-user-authentication"
echo "  ✅ bugfix-JIRA-456-fix-login-timeout"
echo "  ✅ hotfix-APP-789-patch-security-vulnerability"
echo "  ✅ docs-WIKI-101-update-api-documentation"
echo ""
echo -e "${BOLD}Invalid Examples:${NC}"
echo ""
echo "  ❌ feature/add-authentication   (no JIRA ID)"
echo "  ❌ fix-bug                       (no JIRA ID)"
echo "  ❌ PROJ-123                      (no type or description)"
echo "  ❌ my-awesome-feature            (no JIRA ID)"
echo ""

read -p "Press Enter to continue..." -r
clear

# =============================================================================
# Section 4: Understanding Commit Messages
# =============================================================================

cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║                 💬 Commit Message Guide                       ║
╚═══════════════════════════════════════════════════════════════╝
EOF

echo ""
echo -e "${BOLD}Commit Message Format:${NC}"
echo ""
echo "  <type>: <JIRA-ID> <description>"
echo ""
echo -e "${BOLD}Common Types:${NC}"
echo ""
echo "  ${GREEN}feat${NC}     → New feature"
echo "  ${GREEN}fix${NC}      → Bug fix"
echo "  ${GREEN}chore${NC}    → Maintenance"
echo "  ${GREEN}docs${NC}     → Documentation"
echo "  ${GREEN}test${NC}     → Testing"
echo "  ${GREEN}refactor${NC} → Refactoring"
echo ""
echo -e "${BOLD}Valid Examples:${NC}"
echo ""
echo "  ✅ feat: PROJ-123 Add user authentication module"
echo "  ✅ fix: JIRA-456 Resolve login timeout issue"
echo "  ✅ chore: TASK-789 Update dependencies to latest"
echo "  ✅ docs: WIKI-101 Update API documentation"
echo ""
echo -e "${BOLD}Auto-Population:${NC}"
echo ""
echo "  If your branch is: ${CYAN}feat-PROJ-123-add-auth${NC}"
echo "  And you commit:    ${CYAN}Add authentication${NC}"
echo "  Result message:    ${GREEN}feat: PROJ-123 Add authentication${NC}"
echo ""
echo "  The JIRA ID is automatically extracted and inserted! ✨"
echo ""

read -p "Press Enter to continue..." -r
clear

# =============================================================================
# Section 5: Git Flow Workflows
# =============================================================================

cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║                   🔄 Git Flow Workflows                       ║
╚═══════════════════════════════════════════════════════════════╝
EOF

echo ""
echo -e "${BOLD}1️⃣  Feature Development${NC}"
echo ""
echo "  # Start from develop"
echo "  ${CYAN}git checkout develop${NC}"
echo "  ${CYAN}git pull origin develop${NC}"
echo ""
echo "  # Create feature branch"
echo "  ${CYAN}git checkout -b feat-PROJ-123-add-feature${NC}"
echo ""
echo "  # Make changes and commit"
echo "  ${CYAN}git add .${NC}"
echo "  ${CYAN}git commit -m \"feat: PROJ-123 Add feature\"${NC}"
echo ""
echo "  # Push and create PR"
echo "  ${CYAN}git push -u origin feat-PROJ-123-add-feature${NC}"
echo ""
echo ""
echo -e "${BOLD}2️⃣  Hotfix (Critical Production Fix)${NC}"
echo ""
echo "  # Start from main"
echo "  ${CYAN}git checkout main${NC}"
echo "  ${CYAN}git pull origin main${NC}"
echo ""
echo "  # Create hotfix branch"
echo "  ${CYAN}git checkout -b hotfix-PROJ-456-fix-critical-bug${NC}"
echo ""
echo "  # Fix and commit"
echo "  ${CYAN}git add .${NC}"
echo "  ${CYAN}git commit -m \"fix: PROJ-456 Fix critical bug\"${NC}"
echo ""
echo "  # Push"
echo "  ${CYAN}git push -u origin hotfix-PROJ-456-fix-critical-bug${NC}"
echo ""

read -p "Press Enter to continue..." -r
clear

# =============================================================================
# Section 6: Interactive Test
# =============================================================================

cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║                     🧪 Interactive Test                       ║
╚═══════════════════════════════════════════════════════════════╝
EOF

echo ""
echo "Let's test the hooks with a real example!"
echo ""
echo -e "${BOLD}We'll create a test branch and commit.${NC}"
echo ""

read -p "Run interactive test? (yes/no): " -r
echo ""

if [[ $REPLY =~ ^[Yy][Ee][Ss]$ ]] || [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Creating test branch..."
    echo ""
    
    # Ensure we're on develop or main
    git checkout develop 2>/dev/null || git checkout main 2>/dev/null || git checkout -b develop
    
    # Create test branch
    TEST_BRANCH="feat-TEST-999-getting-started-test"
    
    if git checkout -b "$TEST_BRANCH" 2>/dev/null; then
        echo -e "${GREEN}✓${NC} Created branch: $TEST_BRANCH"
        echo ""
        
        # Create test file
        echo "Getting Started Test - $(date)" > getting-started-test.txt
        git add getting-started-test.txt
        
        echo "Committing test file..."
        echo ""
        
        if git commit -m "feat: TEST-999 Test getting started guide"; then
            echo ""
            echo -e "${GREEN}✓${NC} Commit successful!"
            echo ""
            echo "The hooks validated:"
            echo "  ✅ Branch naming"
            echo "  ✅ Commit message format"
            echo "  ✅ JIRA ID presence"
            echo ""
        else
            echo ""
            echo -e "${RED}✗${NC} Commit failed (this shouldn't happen)"
            echo ""
        fi
        
        # Cleanup
        echo "Cleaning up test..."
        git checkout develop 2>/dev/null || git checkout main 2>/dev/null
        git branch -D "$TEST_BRANCH" 2>/dev/null
        rm -f getting-started-test.txt
        
        echo -e "${GREEN}✓${NC} Test complete and cleaned up"
        echo ""
    else
        echo -e "${RED}✗${NC} Could not create test branch"
        echo ""
    fi
else
    echo "Skipping interactive test."
    echo ""
fi

read -p "Press Enter to continue..." -r
clear

# =============================================================================
# Section 7: Configuration Options
# =============================================================================

cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║                  ⚙️  Configuration Options                    ║
╚═══════════════════════════════════════════════════════════════╝
EOF

echo ""
echo -e "${BOLD}Current Configuration:${NC}"
echo ""

MAX_COMMITS="$(git config --local hooks.maxCommits 2>/dev/null || echo '5')"
AUTO_ADD="$(git config --local hooks.autoAddAfterFix 2>/dev/null || echo 'false')"
PARALLEL="$(git config --local hooks.parallelExecution 2>/dev/null || echo 'false')"

echo "  Max commits per branch:       ${CYAN}${MAX_COMMITS}${NC}"
echo "  Auto-add after fixes:         ${CYAN}${AUTO_ADD}${NC}"
echo "  Parallel command execution:   ${CYAN}${PARALLEL}${NC}"
echo ""
echo -e "${BOLD}Common Configuration Commands:${NC}"
echo ""
echo "  # Change commit limit"
echo "  ${CYAN}git config hooks.maxCommits 10${NC}"
echo ""
echo "  # Enable auto-staging after linting fixes"
echo "  ${CYAN}git config hooks.autoAddAfterFix true${NC}"
echo ""
echo "  # Enable parallel command execution (faster)"
echo "  ${CYAN}git config hooks.parallelExecution true${NC}"
echo ""

read -p "Would you like to adjust any settings? (yes/no): " -r
echo ""

if [[ $REPLY =~ ^[Yy][Ee][Ss]$ ]] || [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Current max commits: $MAX_COMMITS"
    read -p "Enter new max commits (or press Enter to keep current): " -r NEW_MAX
    if [[ -n "$NEW_MAX" ]]; then
        git config --local hooks.maxCommits "$NEW_MAX"
        echo -e "${GREEN}✓${NC} Updated max commits to: $NEW_MAX"
        echo ""
    fi
fi

read -p "Press Enter to continue..." -r
clear

# =============================================================================
# Section 8: Resources and Next Steps
# =============================================================================

cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║               📚 Resources and Next Steps                     ║
╚═══════════════════════════════════════════════════════════════╝
EOF

echo ""
echo -e "${BOLD}Documentation:${NC}"
echo ""
echo "  📖 Complete Guide:      ${CYAN}.githooks/README.md${NC}"
echo "  📄 Quick Reference:     ${CYAN}.githooks/QUICK_REFERENCE.md${NC}"
echo "  🔧 Installation Guide:  ${CYAN}.githooks/INSTALLATION.md${NC}"
echo "  📝 Change Log:          ${CYAN}.githooks/CHANGELOG.md${NC}"
echo "  📦 Package Summary:     ${CYAN}.githooks/PACKAGE_SUMMARY.md${NC}"
echo ""
echo -e "${BOLD}Useful Commands:${NC}"
echo ""
echo "  # View hook logs"
echo "  ${CYAN}cat .githooks/logs/pre-commit.log${NC}"
echo "  ${CYAN}cat .githooks/logs/pre-push.log${NC}"
echo ""
echo "  # Test hooks"
echo "  ${CYAN}.githooks/test-hooks.sh${NC}"
echo ""
echo "  # Uninstall hooks"
echo "  ${CYAN}.githooks/uninstall-hooks.sh${NC}"
echo ""
echo -e "${BOLD}Emergency Bypass:${NC}"
echo ""
echo "  # Skip all hooks (use sparingly!)"
echo "  ${CYAN}BYPASS_HOOKS=1 git commit${NC}"
echo "  ${CYAN}BYPASS_HOOKS=1 git push${NC}"
echo ""
echo "  # Allow protected branch commits"
echo "  ${CYAN}ALLOW_DIRECT_PROTECTED=1 git commit${NC}"
echo ""
echo -e "${BOLD}Next Steps:${NC}"
echo ""
echo "  1. Read the Quick Reference guide"
echo "  2. Try creating a real feature branch"
echo "  3. Share the installation guide with your team"
echo "  4. Customize .githooks/commands.conf for your tools"
echo ""

read -p "Press Enter to finish..." -r
clear

# =============================================================================
# Final Message
# =============================================================================

cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║                  🎉 You're All Set! 🎉                        ║
║                                                               ║
║        Git Flow hooks are configured and ready to use!       ║
║                                                               ║
║              Happy committing with clean history! 🚀          ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
EOF

echo ""
echo -e "${GREEN}${BOLD}Summary:${NC}"
echo ""
echo "  ✅ Hooks installed and configured"
echo "  ✅ Git Flow enforcement active"
echo "  ✅ Branch naming validation enabled"
echo "  ✅ Commit message validation enabled"
echo "  ✅ Protected branches secured"
echo ""
echo -e "${BOLD}Quick Reference:${NC}"
echo ""
echo "  ${CYAN}Branch:${NC}  feat-PROJ-123-description"
echo "  ${CYAN}Commit:${NC}  feat: PROJ-123 Description"
echo "  ${CYAN}Bypass:${NC}  BYPASS_HOOKS=1 git commit"
echo ""
echo -e "For help, see: ${CYAN}.githooks/README.md${NC}"
echo ""
echo -e "${MAGENTA}Thank you for using Git Flow Hook Suite! 💜${NC}"
echo ""
