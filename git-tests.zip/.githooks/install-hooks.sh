#!/usr/bin/env bash
#
# Git Flow Hooks Installer (Unix/Linux/macOS/Git Bash)
#
# This script installs Git hooks for enforcing Git Flow branching strategy.
# It configures Git to use the hooks in this directory and sets up the
# necessary permissions and configurations.
#
# Usage:
#   ./install-hooks.sh
#
# Requirements:
#   - Git 2.9+ (for core.hooksPath)
#   - Bash 4.0+
#

set -euo pipefail

# Color codes for output
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly CYAN='\033[0;36m'
readonly NC='\033[0m' # No Color
readonly BOLD='\033[1m'

# Script directory (absolute path)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Counters for summary
SUCCESS_COUNT=0
WARNING_COUNT=0
ERROR_COUNT=0

#######################################
# Print colored output
# Arguments:
#   $1 - Color code
#   $2 - Message
#######################################
print_color() {
    local color="$1"
    shift
    echo -e "${color}$*${NC}"
}

#######################################
# Print section header
# Arguments:
#   $1 - Section title
#######################################
print_header() {
    echo ""
    print_color "$CYAN" "═══════════════════════════════════════════════════════════════"
    print_color "$CYAN$BOLD" "  $1"
    print_color "$CYAN" "═══════════════════════════════════════════════════════════════"
    echo ""
}

#######################################
# Print step message
# Arguments:
#   $1 - Step number
#   $2 - Step description
#######################################
print_step() {
    echo ""
    print_color "$BLUE$BOLD" "[$1/5] $2"
    echo ""
}

#######################################
# Print success message
# Arguments:
#   $* - Message
#######################################
print_success() {
    print_color "$GREEN" "✓ $*"
    ((SUCCESS_COUNT++))
}

#######################################
# Print warning message
# Arguments:
#   $* - Message
#######################################
print_warning() {
    print_color "$YELLOW" "⚠ $*"
    ((WARNING_COUNT++))
}

#######################################
# Print error message
# Arguments:
#   $* - Message
#######################################
print_error() {
    print_color "$RED" "✗ $*"
    ((ERROR_COUNT++))
}

#######################################
# Print info message
# Arguments:
#   $* - Message
#######################################
print_info() {
    print_color "$BLUE" "ℹ $*"
}

#######################################
# Check Git version
# Returns:
#   0 if Git 2.9+, 1 otherwise
#######################################
check_git_version() {
    if ! command -v git &> /dev/null; then
        print_error "Git is not installed"
        return 1
    fi

    local git_version
    git_version=$(git --version | awk '{print $3}')
    local major minor
    major=$(echo "$git_version" | cut -d. -f1)
    minor=$(echo "$git_version" | cut -d. -f2)

    if [[ $major -lt 2 ]] || [[ $major -eq 2 && $minor -lt 9 ]]; then
        print_error "Git 2.9+ required (found: $git_version)"
        return 1
    fi

    print_success "Git version: $git_version"
    return 0
}

#######################################
# Check if inside a Git repository
# Returns:
#   0 if in repo, 1 otherwise
#######################################
check_git_repo() {
    if ! git -C "$REPO_ROOT" rev-parse --git-dir &> /dev/null; then
        print_error "Not inside a Git repository"
        return 1
    fi

    print_success "Git repository detected"
    return 0
}

#######################################
# Make hook files executable
# Returns:
#   0 on success
#######################################
set_hook_permissions() {
    local hooks=(
        "pre-commit"
        "prepare-commit-msg"
        "commit-msg"
        "applypatch-msg"
        "pre-push"
        "post-checkout"
        "post-merge"
        "pre-rebase"
        "post-rewrite"
    )

    local scripts=(
        "getting-started.sh"
        "test-hooks.sh"
        "uninstall-hooks.sh"
        "lib/common.sh"
    )

    local count=0

    # Make hooks executable
    for hook in "${hooks[@]}"; do
        local hook_path="$SCRIPT_DIR/$hook"
        if [[ -f "$hook_path" ]]; then
            chmod +x "$hook_path"
            ((count++))
        else
            print_warning "Hook not found: $hook"
        fi
    done

    # Make scripts executable
    for script in "${scripts[@]}"; do
        local script_path="$SCRIPT_DIR/$script"
        if [[ -f "$script_path" ]]; then
            chmod +x "$script_path"
            ((count++))
        fi
    done

    if [[ $count -gt 0 ]]; then
        print_success "Set executable permissions on $count files"
    else
        print_warning "No hook files found to set permissions"
    fi

    return 0
}

#######################################
# Configure Git to use hooks directory
# Returns:
#   0 on success, 1 on failure
#######################################
configure_git_hooks_path() {
    local relative_path=".githooks"
    
    # Set core.hooksPath to relative path
    if git -C "$REPO_ROOT" config --local core.hooksPath "$relative_path"; then
        print_success "Configured Git to use hooks from: $relative_path"
        return 0
    else
        print_error "Failed to configure Git hooks path"
        return 1
    fi
}

#######################################
# Set default Git configurations
# Returns:
#   0 on success
#######################################
set_default_configs() {
    local configs=(
        "hooks.maxCommits:5:Maximum commits ahead of remote"
        "hooks.autoAddAfterFix:false:Auto-stage files after linting fixes"
        "hooks.parallelExecution:false:Run custom commands in parallel"
        "hooks.commandTimeout:300:Timeout for custom commands (seconds)"
    )

    local set_count=0
    local skip_count=0

    for config_entry in "${configs[@]}"; do
        IFS=':' read -r key default_value description <<< "$config_entry"
        
        # Check if already configured
        if git -C "$REPO_ROOT" config --local --get "$key" &> /dev/null; then
            local current_value
            current_value=$(git -C "$REPO_ROOT" config --local --get "$key")
            print_info "$key = $current_value (already set)"
            ((skip_count++))
        else
            git -C "$REPO_ROOT" config --local "$key" "$default_value"
            print_success "$key = $default_value"
            ((set_count++))
        fi
    done

    if [[ $set_count -gt 0 ]]; then
        echo ""
        print_info "Set $set_count new configuration(s)"
    fi
    if [[ $skip_count -gt 0 ]]; then
        print_info "Kept $skip_count existing configuration(s)"
    fi

    return 0
}

#######################################
# Create logs directory
# Returns:
#   0 on success
#######################################
create_logs_directory() {
    local logs_dir="$SCRIPT_DIR/logs"
    
    if [[ ! -d "$logs_dir" ]]; then
        if mkdir -p "$logs_dir"; then
            print_success "Created logs directory: $logs_dir"
        else
            print_warning "Failed to create logs directory"
            return 1
        fi
    else
        print_info "Logs directory already exists"
    fi

    return 0
}

#######################################
# Verify hook installation
# Returns:
#   0 if all checks pass, 1 otherwise
#######################################
verify_installation() {
    local all_good=true

    # Check core.hooksPath
    local hooks_path
    hooks_path=$(git -C "$REPO_ROOT" config --local --get core.hooksPath || echo "")
    if [[ "$hooks_path" == ".githooks" ]]; then
        print_success "core.hooksPath is correctly set"
    else
        print_error "core.hooksPath is not set correctly (expected: .githooks, got: $hooks_path)"
        all_good=false
    fi

    # Check hook files exist and are executable
    local hooks=(
        "pre-commit"
        "pre-push"
        "commit-msg"
        "prepare-commit-msg"
    )

    local executable_count=0
    for hook in "${hooks[@]}"; do
        local hook_path="$SCRIPT_DIR/$hook"
        if [[ -f "$hook_path" && -x "$hook_path" ]]; then
            ((executable_count++))
        fi
    done

    if [[ $executable_count -eq ${#hooks[@]} ]]; then
        print_success "All core hooks are executable"
    else
        print_warning "Some hooks may not be executable ($executable_count/${#hooks[@]})"
        all_good=false
    fi

    # Check shared library
    if [[ -f "$SCRIPT_DIR/lib/common.sh" ]]; then
        print_success "Shared library found"
    else
        print_error "Shared library (lib/common.sh) not found"
        all_good=false
    fi

    # Check logs directory
    if [[ -d "$SCRIPT_DIR/logs" ]]; then
        print_success "Logs directory exists"
    else
        print_warning "Logs directory not found"
    fi

    # Check configurations
    local required_configs=("hooks.maxCommits")
    for config in "${required_configs[@]}"; do
        if git -C "$REPO_ROOT" config --local --get "$config" &> /dev/null; then
            ((executable_count++)) # Reuse counter
        else
            print_warning "Configuration not set: $config"
            all_good=false
        fi
    done

    if $all_good; then
        return 0
    else
        return 1
    fi
}

#######################################
# Print installation summary
#######################################
print_summary() {
    echo ""
    print_header "Installation Summary"

    echo ""
    print_color "$BOLD" "Statistics:"
    print_success "Successful operations: $SUCCESS_COUNT"
    
    if [[ $WARNING_COUNT -gt 0 ]]; then
        print_warning "Warnings: $WARNING_COUNT"
    fi
    
    if [[ $ERROR_COUNT -gt 0 ]]; then
        print_error "Errors: $ERROR_COUNT"
    fi

    echo ""
    print_color "$BOLD" "Next Steps:"
    echo ""
    echo "  1. Test the installation:"
    print_color "$GREEN" "     ./githooks/test-hooks.sh"
    echo ""
    echo "  2. Read the quick reference:"
    print_color "$GREEN" "     cat .githooks/QUICK_REFERENCE.md"
    echo ""
    echo "  3. Try the interactive guide:"
    print_color "$GREEN" "     ./.githooks/getting-started.sh"
    echo ""
    echo "  4. Create your first Git Flow branch:"
    print_color "$GREEN" "     git checkout -b feat-PROJ-123-add-new-feature"
    echo ""

    echo ""
    print_color "$BOLD" "Documentation:"
    echo ""
    echo "  • Complete Guide:     .githooks/README.md"
    echo "  • Quick Reference:    .githooks/QUICK_REFERENCE.md"
    echo "  • Installation Guide: .githooks/INSTALLATION.md"
    echo "  • Architecture:       .githooks/ARCHITECTURE.md"
    echo ""

    echo ""
    print_color "$BOLD" "Configuration:"
    echo ""
    echo "  View all settings:"
    print_color "$CYAN" "    git config --list | grep hooks"
    echo ""
    echo "  Adjust commit limit:"
    print_color "$CYAN" "    git config hooks.maxCommits 10"
    echo ""

    echo ""
    print_color "$BOLD" "Emergency Bypass:"
    echo ""
    echo "  Skip hooks (emergency only!):"
    print_color "$YELLOW" "    BYPASS_HOOKS=1 git commit"
    print_color "$YELLOW" "    BYPASS_HOOKS=1 git push"
    echo ""
}

#######################################
# Main installation function
#######################################
main() {
    print_header "Git Flow Hooks Installation"
    
    print_info "Repository: $REPO_ROOT"
    print_info "Hooks directory: $SCRIPT_DIR"
    echo ""

    # Step 1: Pre-flight checks
    print_step 1 "Pre-flight Checks"
    check_git_version || exit 1
    check_git_repo || exit 1

    # Step 2: Set permissions
    print_step 2 "Setting Permissions"
    set_hook_permissions

    # Step 3: Configure Git
    print_step 3 "Configuring Git"
    configure_git_hooks_path || exit 1
    set_default_configs

    # Step 4: Create directories
    print_step 4 "Creating Directories"
    create_logs_directory

    # Step 5: Verify installation
    print_step 5 "Verifying Installation"
    if verify_installation; then
        echo ""
        print_color "$GREEN$BOLD" "✓ Installation verified successfully!"
    else
        echo ""
        print_color "$YELLOW$BOLD" "⚠ Installation completed with warnings"
        print_info "The hooks should still work, but some features may be limited"
    fi

    # Print summary
    print_summary

    # Final status
    echo ""
    if [[ $ERROR_COUNT -eq 0 ]]; then
        print_color "$GREEN$BOLD" "🎉 Git Flow hooks installed successfully!"
        echo ""
        return 0
    else
        print_color "$RED$BOLD" "❌ Installation completed with errors"
        echo ""
        print_info "Please review the errors above and try again"
        return 1
    fi
}

# Run main function
main "$@"
