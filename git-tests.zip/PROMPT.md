Generate a **complete, reusable native Git hook suite** and a **Windows setup script** for this repository. The hooks must run on **Linux, macOS, and Windows (Git Bash)** and enforce our branching/commitpush/PR/merge rules, curated history.

Make sure to mee tall the funcational requirments to follow the #fetch https://nvie.com/posts/a-successful-git-branching-model/

Also, make sure the hooks have proper success and failuer messages along with the proper strucured log with proper stack traces. So, that developers can fix the issues while doing their commits or pull, or push or raising PR or anything that has to do with git version control.

Allow Branch creation from develop only if the branches are following the given branch naming pattern. Now if the branch user trys to create a branch don't allow if they are not mentioning from which point they want the branch to be created. Give them the clear instructions and tell them what is allowed and what is not allowed.

Make sure to have the context of the actions based on that suggest the name of the branches. So, when you are suggesting the troubleshooting steps is should give the commands with the curent state and not the hints with some pre defined examples.

It should implement all the enforcement to make sure the users are following the git flow branching strategy.

### 1. BRANCH NAMING POLICY (MANDATORY)
**Implementation Requirements:**
- [ ] **Enforcement Point**: Pre-push hook must validate ALL branch names
- [ ] **Allowed Patterns**:
  - Long-lived: `^(main|develop|release($|/.*))$`
  - Short-lived: `^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$`
- [ ] **Error Handling**: Show exact regex pattern, current branch name, and 3 valid examples
- [ ] **Remote Branch Handling**: 
  - Allow checkout of non-compliant remote branches
  - Block commits to non-compliant branches with clear explanation
  - Provide migration path for legacy branches
- [ ] **Error Recovery**: Provide exact commands to fix base issues

### 2. CURATED HISTORY ENFORCEMENT (MANDATORY)
**Implementation Requirements:**
- [ ] **Commit Limit**: 
  - Default: 5 commits (configurable via `git config hooks.maxCommits`)
  - Count only commits unique to branch vs base
  - Formula: `git rev-list --count "$base..HEAD"`
- [ ] **Linear History**:
  - Block merge commits to protected branches
  - Enforce rebase workflow
  - Detect and prevent "foxtrot merges"
- [ ] **Squash Enforcement**: Pre-push must verify commits are squashed
- [ ] **Error Messages**: Show current count, limit, and squash instructions
- [ ] **Error Recovery**: Provide exact commands to fix base issues

### 3. COMMIT MESSAGE POLICY (MANDATORY)
**Implementation Requirements:**
- [ ] **Format Regex**: `^(feat|fix|chore|break|tests): [A-Z]{2,10}-[0-9]+ .+`
- [ ] **Auto-Population**:
  - Extract JIRA ID from branch name
  - Pre-fill in prepare-commit-msg hook
  - Skip if already compliant or merge/revert
- [ ] **Validation Points**:
  - commit-msg hook
  - applypatch-msg hook (for git am)
- [ ] **Special Cases**: Allow "Merge" and "Revert" prefixes
- [ ] **Error Recovery**: Provide exact commands to fix base issues

### 4. DEVELOPER QUALITY OF LIFE (MANDATORY)
**Implementation Requirements:**
- [ ] **Protected Branch Features**:
  - Block direct commits (unless `ALLOW_DIRECT_PROTECTED=1`)
  - Show friendly warning when checking out
  - Reminder about protection on each action
- [ ] **Smart Hints**:
  - Detect lockfile changes (ALL package managers)
  - Detect Terraform/IaC changes
  - Detect CI/CD configuration changes
  - Post-rebase reminder for `--force-with-lease`
- [ ] **Extension Framework**:
  - Configurable pre/post command execution
  - Support for linting, prettier, type-checking, build verification
  - Timeout configuration per command
  - Sequential/parallel execution options
- [ ] **Error Recovery**: Provide exact commands to fix base issues

### 5. INSTALLATION & CONFIGURATION (MANDATORY)
**Implementation Requirements:**
- [ ] **Installer Script** (`install-hooks.sh`):
  - Set `core.hooksPath=.githooks`
  - Set `rebase.autosquash=true`
  - Set `fetch.prune=true`
  - Initialize `hooks.maxCommits=5` if unset
  - Make all hooks executable
  - Create log directory with proper permissions
  - Add logs to `.git/info/exclude`
  - Display complete configuration summary
  - Show ALL test commands
- [ ] **Uninstaller Script** (`uninstall-hooks.sh`):
  - Restore original hooks path
  - Archive logs before removal
  - Remove configurations
  - Confirmation prompt
  - [ ] **Error Recovery**: Provide exact commands to fix base issues

### 6. BYPASS MECHANISMS (MANDATORY)
**Implementation Requirements:**
- [ ] **Global Bypass**: `BYPASS_HOOKS=1` - skip all hooks
- [ ] **Protected Bypass**: `ALLOW_DIRECT_PROTECTED=1` - allow protected branch commits
- [ ] **Error Recovery**: Provide exact commands to fix base issues

### 7. CUSTOM COMMAND EXTENSION FRAMEWORK (MANDATORY)
**Implementation Requirements:**
- [ ] **Command Configuration File** (`.githooks/commands.conf`):
  ```bash
  # Format: HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
  pre-commit:1:true:30:node scripts/check-casing.js:Check casing
  pre-commit:2:true:60:npx lint-staged:Lint-Staged
  pre-commit:3:false:120:npx tsc --noEmit --skipLibCheck:TypeScript Check
  pre-commit:4:true:30:npm run lint:fix:Auto-fix linting
  pre-push:1:true:300:npm test:Run test suite
  pre-push:2:false:600:npm run build:Build project
  commit-msg:1:false:10:node scripts/validate-message.js:Custom message validation
  ```
- [ ] **Command Runner Implementation**:
  ```bash
  # Required functionality:
  - Parse commands.conf file
  - Execute commands in priority order
  - Track individual command status
  - Aggregate all failures
  - Show real-time progress
  - Handle timeouts gracefully
  - Support both mandatory and optional commands
  - Capture and log command output
  ```
- [ ] **Auto-fix and Re-staging Support**:
  - After successful lint/prettier fixes, auto-stage modified files
  - Configurable via `git config hooks.autoAddAfterFix true`
  - Show which files were re-staged
- [ ] **Lint-staged Integration**:
  - Read `.lintstagedrc.json` or `package.json` lint-staged config
  - Pass staged files to commands with `{staged}` placeholder
  - Support glob patterns for file filtering
- [ ] **Error Reporting Format**:
  ```
  ========================================
  Hook: pre-commit FAILED
  
  Failed Checks:
  ✗ Check casing (exit code: 1)
  ✗ TypeScript Check (exit code: 2)
  
  Passed Checks:
  ✓ Lint-Staged
  
  To bypass (emergency only): BYPASS_HOOKS=1 git commit
  ========================================
  ```
- [ ] **Parallel Execution Support**:
  - Commands with same priority run in parallel
  - Configurable via `git config hooks.parallelExecution true`
  - Proper output buffering for parallel commands