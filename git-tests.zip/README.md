# git-tests

This repository includes a **production-grade Git Flow hook suite** that enforces branching strategy, commit standards, and curated history.

## 🚀 Quick Start

### Install Hooks

#### Linux / macOS / Git Bash (Windows)
```bash
.githooks/install-hooks.sh
```

#### Windows (Command Prompt)
```cmd
.githooks\install-hooks.bat
```

### Verify Installation
```bash
# Test branch naming
git checkout -b feat-TEST-123-test-feature

# Test commit format
echo "test" > test.txt
git add test.txt
git commit -m "feat: TEST-123 Test the hooks"
```

## 📖 Documentation

For complete documentation, see [.githooks/README.md](.githooks/README.md)

## 🎯 Key Features

✅ **Git Flow Enforcement** - Features from `develop`, hotfixes from `main`  
✅ **Branch Naming** - `feat-PROJ-123-description` format with JIRA IDs  
✅ **Commit Messages** - `feat: PROJ-123 Description` auto-populated  
✅ **Curated History** - Max 5 commits per branch (configurable)  
✅ **Linear History** - No merge commits, rebase workflow  
✅ **Custom Commands** - Linting, testing, build verification  
✅ **Cross-Platform** - Works on Linux, macOS, Windows

## 🔧 Configuration

```bash
# Adjust commit limit
git config hooks.maxCommits 10

# Enable auto-staging after fixes
git config hooks.autoAddAfterFix true

# Enable parallel command execution
git config hooks.parallelExecution true
```

## 🔥 Bypass (Emergency Only)

```bash
# Skip all hooks
BYPASS_HOOKS=1 git commit
BYPASS_HOOKS=1 git push

# Allow protected branch commits
ALLOW_DIRECT_PROTECTED=1 git commit
```

## 📚 Git Flow Quick Reference

### Feature Branch
```bash
git checkout develop
git checkout -b feat-PROJ-123-add-feature
# Work on feature
git commit -m "feat: PROJ-123 Add feature"
git push -u origin feat-PROJ-123-add-feature
```

### Hotfix Branch
```bash
git checkout main
git checkout -b hotfix-PROJ-456-fix-bug
# Fix critical bug
git commit -m "fix: PROJ-456 Fix critical bug"
git push -u origin hotfix-PROJ-456-fix-bug
```

### Release Branch
```bash
git checkout develop
git checkout -b release/1.0.0
# Bug fixes only
git commit -m "fix: PROJ-789 Release preparation"
```

## 🧹 Uninstall

```bash
.githooks/uninstall-hooks.sh
```