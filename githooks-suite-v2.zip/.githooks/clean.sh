#!/usr/bin/env bash
set -euo pipefail

LOG_DIR=".git/hook-logs"
MAX_BYTES=$((256 * 1024))
RETENTION_DAYS=21

bytes_of(){ if [[ -f "$1" ]]; then wc -c <"$1" | awk '{print $1}'; else echo 0; fi; }

rotate_one(){
  local f="$1"
  local base="${f%.log}"
  [[ -f "${base}.log.2" ]] && rm -f "${base}.log.2"
  [[ -f "${base}.log.1" ]] && mv -f "${base}.log.1" "${base}.log.2"
  [[ -f "${base}.log"   ]] && mv -f "${base}.log"   "${base}.log.1"
  : > "${base}.log"
}

main(){
  mkdir -p "${LOG_DIR}"
  shopt -s nullglob
  for f in "${LOG_DIR}"/*.log; do
    size="$(bytes_of "${f}")"
    if (( size > MAX_BYTES )); then
      rotate_one "${f}"
      echo "Rotated ${f} (size=${size} bytes)" >&2
    fi
  done
  find "${LOG_DIR}" -type f -mtime +"${RETENTION_DAYS}" -print -delete 2>/dev/null || true
}
main "$@"
