#!/usr/bin/env bash
set -euo pipefail
have(){ command -v "$1" >/dev/null 2>&1; }
run_maybe_timeout(){ local secs="$1"; shift; local enable_env="${HOOKS_ENABLE_TIMEOUT:-}"; local enable_cfg=false
  if command -v git >/dev/null 2>&1; then if git config --type=bool --get hooks.enableTimeout >/dev/null 2>&1; then
    [[ "$(git config --type=bool --get hooks.enableTimeout)" == "true" ]] && enable_cfg=true; fi; fi
  if [[ "${enable_env}" == "1" || "${enable_cfg}" == "true" ]]; then local tcmd; tcmd="$(git config --get hooks.timeoutCmd 2>/dev/null || true)"
    if [[ -z "${tcmd}" ]]; then if have timeout; then tcmd="timeout"; elif have gtimeout; then tcmd="gtimeout"; else tcmd=""; fi; fi
    if [[ -n "${tcmd}" ]]; then "${tcmd}" "${secs}" "$@"; else echo "⚠️  Timeout requested but no timeout command found; running without." >&2; "$@"; fi
  else "$@"; fi; }
precommit_extra(){ local files=("$@"); [[ ${#files[@]} -eq 0 ]] && return 0
  local use_lint_staged=0; if [[ -f package.json ]]; then if grep -q '"lint-staged"' package.json 2>/dev/null && have npx; then use_lint_staged=1; fi; fi
  if (( use_lint_staged == 1 )); then echo "→ Running lint-staged…"; run_maybe_timeout "$(git config --get hooks.timeoutSeconds 2>/dev/null || echo 180)" npx --yes lint-staged; return $?; fi
  mapfile -t js_changed < <(printf "%s\n" "${files[@]}" | grep -E '\.(js|jsx|ts|tsx)$' || true)
  if [[ ${#js_changed[@]} -eq 0 ]]; then return 0; fi
  if have npx && npx --yes prettier -v >/dev/null 2>&1; then echo "→ Prettier (staged)"
    run_maybe_timeout "$(git config --get hooks.timeoutSeconds 2>/dev/null || echo 180)" npx --yes prettier --write "${js_changed[@]}"; git add -- "${js_changed[@]}"; fi
  if have npx && npx --yes eslint -v >/dev/null 2>&1; then echo "→ ESLint (staged)"
    run_maybe_timeout "$(git config --get hooks.timeoutSeconds 2>/dev/null || echo 180)" npx --yes eslint --fix --max-warnings=0 "${js_changed[@]}"; git add -- "${js_changed[@]}"; fi; }
commitmsg_extra(){ local msg_file="$1"; local subject; subject="$(head -n1 "${msg_file}" | tr -d '\r')"
  [[ "${subject}" =~ ^WIP ]] && echo "ℹ️  Hint: Subject starts with WIP" >&2
  [[ "${#subject}" -gt 72 ]] && echo "ℹ️  Hint: Subject >72 chars" >&2; }
has_pkg_script(){ local n="$1"; [[ -f package.json ]] && grep -q ""${n}"" package.json 2>/dev/null; }
prepush_extra(){ local branch="$1" base="$2" ahead="$3" limit="$4"
  mapfile -t changed < <(git diff --name-only "${base}..HEAD" | grep -E '\.(js|jsx|ts|tsx)$' || true)
  if [[ ${#changed[@]} -eq 0 ]]; then echo "→ No JS/TS changes vs ${base}; skipping Node checks."; return 0; fi
  if has_pkg_script "typecheck"; then echo "→ Typecheck (npm run -s typecheck)"; run_maybe_timeout "$(git config --get hooks.timeoutSeconds 2>/dev/null || echo 180)" npm run -s typecheck
  elif have npx && npx --yes tsc -v >/dev/null 2>&1; then echo "→ Typecheck (npx tsc --noEmit --skipLibCheck)"; run_maybe_timeout "$(git config --get hooks.timeoutSeconds 2>/dev/null || echo 180)" npx --yes tsc --noEmit --skipLibCheck; fi
  if has_pkg_script "lint"; then echo "→ Lint (npm run -s lint)"; run_maybe_timeout "$(git config --get hooks.timeoutSeconds 2>/dev/null || echo 180)" npm run -s lint
  elif have npx && npx --yes eslint -v >/dev/null 2>&1; then echo "→ Lint (eslint on changed files)"; run_maybe_timeout "$(git config --get hooks.timeoutSeconds 2>/dev/null || echo 180)" npx --yes eslint --max-warnings=0 "${changed[@]}"; fi
  if has_pkg_script "test:quick"; then echo "→ Tests (npm run -s test:quick)"; run_maybe_timeout "$(git config --get hooks.timeoutSeconds 2>/dev/null || echo 180)" npm run -s test:quick
  elif have npx && npx --yes jest -v >/dev/null 2>&1; then echo "→ Tests (Jest --findRelatedTests)"; run_maybe_timeout "$(git config --get hooks.timeoutSeconds 2>/dev/null || echo 180)" npx --yes jest --findRelatedTests "${changed[@]}" --passWithNoTests
  elif has_pkg_script "test"; then echo "→ Tests (npm test)"; run_maybe_timeout "$(git config --get hooks.timeoutSeconds 2>/dev/null || echo 180)" npm test -- --passWithNoTests || npm test --passWithNoTests
  else echo "ℹ️  No test runner detected; skipping tests." >&2; fi; }
