#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
GH_DIR="${ROOT}/.githooks"
LOG_DIR="${ROOT}/.git/hook-logs"

usage(){ cat <<EOF
hooksctl.sh — control & diagnostics for native Git hooks
Usage:
  $0 install                 # run installer
  $0 doctor                  # verify config, perms, logs
  $0 level <LEVEL>           # set hooks.logLevel (TRACE|DEBUG|INFO|NOTICE|WARN|ERROR|CRITICAL|FATAL)
  $0 tail [hook|all]         # tail -f a log (default: all)
  $0 simulate all            # run integration simulations in a temp repo
  $0 clean-logs              # rotate & prune logs
EOF
}

ensure_repo(){ git rev-parse --is-inside-work-tree >/dev/null 2>&1 || { echo "Not a git repo" >&2; exit 1; }; }

install_cmd(){ bash "${GH_DIR}/install-hooks.sh"; }
doctor_cmd(){
  ensure_repo
  echo "== Doctor =="
  echo "hooksPath: $(git config --get core.hooksPath)"
  echo "maxCommits: $(git config --get hooks.maxCommits || echo unset)"
  echo "logLevel: $(git config --get hooks.logLevel || echo unset)"
  echo "enableTimeout: $(git config --type=bool --get hooks.enableTimeout || echo false)"
  echo "-- Files --"; ls -la "${GH_DIR}" || true; ls -la "${GH_DIR}/lib" || true
  echo "-- Executable bits --"
  find "${GH_DIR}" -maxdepth 1 -type f -print0 | xargs -0 ls -l
  find "${GH_DIR}/lib" -type f -print0 | xargs -0 ls -l
  echo "-- Logging smoke test --"
  mkdir -p "${LOG_DIR}"; ts="$(date +%s)"; echo "${ts} doctor" >> "${LOG_DIR}/all.log"; echo "Wrote to ${LOG_DIR}/all.log"
}
level_cmd(){ local lv="${1:-INFO}"; git config hooks.logLevel "${lv}"; echo "Set hooks.logLevel=${lv}"; }
tail_cmd(){ mkdir -p "${LOG_DIR}"; local t="${1:-all}"; if [[ "${t}" == "all" ]]; then tail -f "${LOG_DIR}/all.log"; else tail -f "${LOG_DIR}/${t}.log"; fi; }

simulate_all(){
  tmp="$(mktemp -d)"; echo "→ Creating temp repo at ${tmp}"; git init -q "${tmp}"; cp -R "${GH_DIR}" "${tmp}/"
  (
    cd "${tmp}"
    bash .githooks/install-hooks.sh
    git config user.name "Hooks Tester"; git config user.email "tester@example.com"
    git checkout -q -b main; echo "x" > a.txt; git add a.txt
    if git commit -m "feat: ABC-1 ok on main" 2>/dev/null; then echo "ERROR: direct commit to protected branch was allowed (expected block)"; exit 1
    else echo "✓ pre-commit blocked direct commit to protected"; fi
    ALLOW_DIRECT_PROTECTED=1 git commit -m "feat: ABC-1 allow once" || { echo "ERROR: allow direct failed"; exit 1; }
    git checkout -q -b feat-abc-1-bad; echo "y" > b.txt; git add b.txt; git commit -m "feat: ABC-2 bad branch" || true
    git checkout -q -b feature-ABC-3-good; echo "z" > c.txt; git add c.txt; git commit -m "feat: ABC-3 good"; git branch -M feature-ABC-3-good
    mkdir remote.git && (cd remote.git && git init -q --bare); git remote add origin "${tmp}/remote.git"; git push -u origin feature-ABC-3-good >/dev/null
    git checkout -q -b feat-abc-1-bad; echo "bad" > d.txt; git add d.txt; git commit -m "feat: ABC-4 bad branch" || true
    if git push -u origin feat-abc-1-bad >/dev/null 2>&1; then echo "ERROR: bad-named branch push succeeded (expected block)"; exit 1
    else echo "✓ pre-push blocked bad-named branch"; fi
    git checkout -q feature-ABC-3-good; echo "ok2" > e.txt; git add e.txt
    if git commit -m "Update stuff" 2>/dev/null; then echo "ERROR: non-compliant subject passed (expected fail)"; exit 1
    else echo "✓ commit-msg blocked non-compliant subject"; fi
    echo 'AWS_SECRET=AKIAABCDEFGHIJKLMNOP' > .env; git add .env
    if git commit -m "chore: ABC-5 secret" 2>/dev/null; then echo "ERROR: secret scan missed (expected fail)"; exit 1
    else echo "✓ pre-commit secret scan blocked commit"; fi
    echo "All simulations passed."
  )
}
clean_logs_cmd(){ bash "${GH_DIR}/clean.sh"; }

cmd="${1:-}"
case "${cmd}" in
  install) install_cmd ;;
  doctor) doctor_cmd ;;
  level) shift || true; level_cmd "${1:-INFO}" ;;
  tail) shift || true; tail_cmd "${1:-all}" ;;
  simulate) shift || true; sub="${1:-}"; [[ "${sub}" == "all" ]] || { usage; exit 1; }; simulate_all ;;
  clean-logs) clean_logs_cmd ;;
  *) usage; exit 1 ;;
esac
