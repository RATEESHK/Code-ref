param([Parameter(ValueFromRemainingArguments=$true)] $Args)
# PowerShell wrapper: forward to Git Bash
$bash = "${env:ProgramFiles}\Git\bin\bash.exe"
if (-Not (Test-Path $bash)) { Write-Error "Git Bash not found at $bash"; exit 1 }
& $bash -lc ".githooks/hooksctl.sh $Args"
