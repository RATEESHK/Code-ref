#!/usr/bin/env bash
set -euo pipefail

err() { printf "ERROR: %s\n" "$*" >&2; }
info() { printf "→ %s\n" "$*" >&2; }
ok()   { printf "✓ %s\n" "$*" >&2; }

if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  err "Not inside a Git repository."
  exit 1
fi
if [[ ! -d ".githooks" ]]; then
  err "Folder '.githooks' not found at repo root."
  exit 1
fi

ROOT="$(git rev-parse --show-toplevel)"
cd "${ROOT}"

info "Configuring repo settings…"
git config core.hooksPath .githooks
git config rebase.autosquash true
git config fetch.prune true
if ! git config --get hooks.maxCommits >/dev/null 2>&1; then
  git config hooks.maxCommits 5
fi
if ! git config --get hooks.logLevel >/dev/null 2>&1; then
  git config hooks.logLevel INFO
fi
ok "Git config updated (hooksPath, autosquash, prune, hooks.maxCommits, hooks.logLevel)"

info "Marking hook scripts executable…"
shopt -s nullglob
top_files=( .githooks/* )
shopt -u nullglob
if ((${#top_files[@]} == 0)); then
  err "No files found in .githooks/. Expected core hook files (e.g., pre-commit, pre-push…)."
  exit 1
fi
chmod +x "${top_files[@]}"
if [[ ! -d ".githooks/lib" ]]; then
  err "Missing '.githooks/lib' directory (expected for shared helpers like lib/common.sh)."
  exit 1
fi
lib_count="$(find ".githooks/lib" -type f | wc -l | awk '{print $1}')"
if [[ "${lib_count}" == "0" ]]; then
  err "No files found under .githooks/lib (expected lib/common.sh at minimum)."
  exit 1
fi
find ".githooks/lib" -type f -exec chmod +x {} \;
ok "Hooks executable: ${#top_files[@]} top-level, ${lib_count} in lib/"

info "Preparing log directory…"
mkdir -p .git/hook-logs
EXCLUDE_FILE=".git/info/exclude"
mkdir -p "$(dirname "${EXCLUDE_FILE}")"
touch "${EXCLUDE_FILE}"
if ! grep -qE '^\# hook logs$' "${EXCLUDE_FILE}" 2>/dev/null; then
  {
    echo "# hook logs"
    echo ".git/hook-logs/"
  } >> "${EXCLUDE_FILE}"
fi
ok "Log directory ready at .git/hook-logs"

cat >&2 <<'SUMMARY'
================================================================================
Git hooks installed ✅
================================================================================

WHAT & DEFAULTS
• core.hooksPath=".githooks", rebase.autosquash=true, fetch.prune=true
• hooks.maxCommits=5 (limit unique commits ahead of base on pre-push)
• hooks.logLevel=INFO (levels: TRACE, DEBUG, INFO, NOTICE, WARN, ERROR, CRITICAL, FATAL/EMERGENCY)
• Logs: .git/hook-logs/<hook>.log and .git/hook-logs/all.log (rotates ~256KB, keeps 2 archives)
• Clean logs: bash .githooks/clean.sh

VERBOSE/TRACE
• To see every step: git config hooks.logLevel TRACE   # or HOOKS_LOG_LEVEL=TRACE per command
• Shell xtrace:      HOOKS_TRACE=1 git commit -m "..."

USAGE NOTES
• Branch naming enforced at push. Protected: ^(main|develop|release($|/.*))$
  Short-lived:      ^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$
• Commit subject enforced on commit: ^(feat|fix|chore|break|tests): [A-Z]{2,10}-[0-9]+ .+
  (Merge/Revert subjects are allowed.)

CONTROL TOOL
• Run:  .githooks/hooksctl.sh doctor          # checks env, perms, config, logging
         .githooks/hooksctl.sh simulate all    # spins up a temp repo & runs positive/negative flows
         .githooks/hooksctl.sh tail pre-commit # live tail a specific hook log
         .githooks/hooksctl.sh level DEBUG     # change log level for this repo

Inspired by the idea of a terminal "git buddy" assistant CLI for visibility & ergonomics.
SUMMARY
