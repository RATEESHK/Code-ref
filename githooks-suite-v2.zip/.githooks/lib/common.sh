#!/usr/bin/env bash
set -uo pipefail

LOG_DIR=".git/hook-logs"
MAX_LOG_BYTES=$((256 * 1024))
DATE_FMT="+%Y-%m-%dT%H:%M:%S%z"

level_num(){ case "$(echo "${1:-INFO}" | tr '[:lower:]' '[:upper:]')" in
  TRACE) echo 0;; DEBUG) echo 1;; INFO) echo 2;; NOTICE) echo 3;; WARN|WARNING) echo 4;;
  ERROR) echo 5;; CRITICAL) echo 6;; FATAL|EMERGENCY) echo 7;; *) echo 2;; esac; }
level_name(){ case "${1:-2}" in
  0) echo TRACE;; 1) echo DEBUG;; 2) echo INFO;; 3) echo NOTICE;; 4) echo WARN;;
  5) echo ERROR;; 6) echo CRITICAL;; 7) echo FATAL;; *) echo INFO;; esac; }
LOG_THRESHOLD_NUM(){ local e="${HOOKS_LOG_LEVEL:-}"; [[ -n "$e" ]] && { level_num "$e"; return; }
  level_num "$(git config --get hooks.logLevel 2>/dev/null || echo INFO)"; }

ensure_logdir(){ mkdir -p "${LOG_DIR}"; }
bytes_of(){ [[ -f "$1" ]] && wc -c <"$1" | awk '{print $1}' || echo 0; }
rotate_if_big(){ local log="$1"; local size; size="$(bytes_of "${log}")"
  if (( size > MAX_LOG_BYTES )); then local base="${log%*.log}"
    [[ -f "${base}.log.2" ]] && rm -f "${base}.log.2"
    [[ -f "${base}.log.1" ]] && mv -f "${base}.log.1" "${base}.log.2"
    [[ -f "${base}.log"   ]] && mv -f "${base}.log"   "${base}.log.1"
    : > "${base}.log"; fi; }

log_emit(){ local hook="$1"; shift; local lvl="${1:-2}"; shift; local status="${1:-"-"}"; shift; local msg="$*"
  local threshold; threshold="$(LOG_THRESHOLD_NUM)"; (( lvl < threshold )) && return 0
  ensure_logdir; local ts; ts="$(date "${DATE_FMT}")"; local lvl_name; lvl_name="$(level_name "${lvl}")"
  local user_name="$(git config --get user.name 2>/dev/null || echo '-')"
  local branch="$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo 'HEAD')"
  local log="${LOG_DIR}/${hook}.log"; rotate_if_big "${log}"; rotate_if_big "${LOG_DIR}/all.log"
  local line; line="$(printf "%s\t%s\t%s\t%s\t%s\t%s\n" "${ts}" "${hook}" "${lvl_name}" "${status}" "${branch}" "${msg}")"
  printf "%s\n" "${line}" >> "${log}"; printf "%s\n" "${line}" >> "${LOG_DIR}/all.log"
  if (( lvl >= 4 )); then printf "%s\n" "${line}" >&2; fi; }

log_trace(){ log_emit "${1}" 0 "-" "${*:2}"; } ; log_debug(){ log_emit "${1}" 1 "-" "${*:2}"; }
log_info(){ log_emit "${1}" 2 "-" "${*:2}"; }  ; log_notice(){ log_emit "${1}" 3 "-" "${*:2}"; }
log_warn(){ log_emit "${1}" 4 "-" "${*:2}"; }  ; log_error(){ log_emit "${1}" 5 "ERR" "${*:2}"; }
log_crit(){ log_emit "${1}" 6 "CRIT" "${*:2}"; } ; log_fatal(){ log_emit "${1}" 7 "FATAL" "${*:2}"; }

begin_hook(){ HOOK_NAME="$1"; HOOK_START_NS="$(date +%s%N 2>/dev/null || date +%s)"; [[ "${HOOKS_TRACE:-}" == "1" ]] && set -x;
  log_info "${HOOK_NAME}" "BEGIN hook=${HOOK_NAME} repo=$(git rev-parse --show-toplevel 2>/dev/null || echo .)"; }
end_hook_success(){ local now; now="$(date +%s%N 2>/dev/null || date +%s)"; local dur_ms
  if [[ "${HOOK_START_NS:-}" =~ ^[0-9]+$ && "${now}" =~ ^[0-9]+$ ]]; then dur_ms="$(( (now - HOOK_START_NS) / 1000000 ))" 2>/dev/null || dur_ms="0"; else dur_ms="0"; fi
  log_info "${HOOK_NAME}" "END success duration_ms=${dur_ms}"; }
end_hook_fail(){ local code="${1:-1}"; local now; now="$(date +%s%N 2>/dev/null || date +%s)"; local dur_ms
  if [[ "${HOOK_START_NS:-}" =~ ^[0-9]+$ && "${now}" =~ ^[0-9]+$ ]]; then dur_ms="$(( (now - HOOK_START_NS) / 1000000 ))" 2>/dev/null || dur_ms="0"; else dur_ms="0"; fi
  log_error "${HOOK_NAME}" "END failure exit_code=${code} duration_ms=${dur_ms}"; }
die(){ local hook="${HOOK_NAME:-hook}"; local msg="$*"; log_error "${hook}" "${msg}"; echo "❌ ${msg}" >&2; end_hook_fail 1; exit 1; }

PROTECTED_RE='^(main|develop|release($|/.*))$'
SHORTLIVED_RE='^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$'
COMMIT_SUBJECT_RE='^(feat|fix|chore|break|tests): [A-Z]{2,10}-[0-9]+ .+'
is_auto_msg(){ local s="$1"; [[ "$s" =~ ^Merge[[:space:]] || "$s" =~ ^Revert[[:space:]] ]]; }
branch_name(){ git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "HEAD"; }
is_protected_branch(){ local b="${1:-$(branch_name)}"; [[ "${b}" =~ ${PROTECTED_RE} ]]; }
is_shortlived_branch(){ local b="${1:-$(branch_name)}"; [[ "${b}" =~ ${SHORTLIVED_RE} ]]; }
config_get(){ local k="$1" d="${2:-}"; local v; v="$(git config --get "${k}" 2>/dev/null || true)"; [[ -n "$v" ]] && printf "%s" "$v" || printf "%s" "$d"; }
config_bool(){ local k="$1" d="${2:-false}"; local v; v="$(git config --type=bool --get "${k}" 2>/dev/null || echo "${d}")"; [[ "$v" == "true" ]]; }
staged_files(){ git diff --cached --name-only --diff-filter=ACMR; }
staged_added_lines(){ git diff --cached --unified=0 --no-color | sed -n '/^+/p' | sed '/^+++ /d;s/^+//'; }
guard_sensitive_files(){ local bad=() f; while IFS= read -r f; do [[ -z "$f" ]] && continue; case "$f" in
  .env|.env.*|*.pem|*.p12|id_rsa*|*.key) bad+=("$f");; esac; done < <(staged_files); (( ${#bad[@]} )) && die "Sensitive files staged: ${bad[*]}"; }
scan_secrets_fast(){ local lines; lines="$(staged_added_lines || true)"; [[ -z "${lines}" ]] && return 0
  local re_list=( 'AKIA[0-9A-Z]{16}' 'aws(.{0,20})?(secret|access)[^A-Za-z0-9]?([0-9a-zA-Z/+]{40})' 'gh[pous]_[A-Za-z0-9]{36,}'
    'xox[baprs]-[A-Za-z0-9-]{10,48}' 'AIza[0-9A-Za-z_\-]{35}' 'sk_(live|test)_[0-9A-Za-z]{24,}'
    '-----BEGIN[[:space:]]+(RSA|DSA|EC|OPENSSH)?[[:space:]]*PRIVATE KEY-----' '(?i)password[[:space:]]*=' 'AccountKey=|SharedAccessKey=' )
  for re in "${re_list[@]}"; do if echo "${lines}" | grep -E -q -- "${re}"; then die "Potential secret detected in staged added lines (pattern: ${re})"; fi; done; }
hint_lockfiles_and_terraform(){ local changed; changed="$(staged_files | tr '\n' ' ' )"; local hint=()
  [[ "${changed}" =~ (^|[[:space:]])(package-lock\.json|yarn\.lock|pnpm-lock\.yaml)($|[[:space:]]) ]] && hint+=("dependency lockfile changed")
  echo "${changed}" | grep -Eq '(^|[[:space:]])(.+\.tf|.+\.tfvars)($|[[:space:]])' && hint+=("Terraform files changed")
  (( ${#hint[@]} )) && { log_notice "${HOOK_NAME}" "HINT: ${hint[*]}"; echo "ℹ️  ${hint[*]}" >&2; }; }
compute_base_for_branch(){ local b="${1:-$(branch_name)}"; local prefix="${b%%-*}"
  case "${prefix}" in feature|bugfix|techdebt) echo "origin/develop";; hotfix) echo "origin/main";; *) echo "";; esac; }
ensure_fetched_ref(){ local ref="$1"; local remote="${ref%%/*}"; git rev-parse --verify -q "${ref}" >/dev/null 2>&1 || git fetch "${remote}" --no-tags --prune; }
is_ancestor_of_head(){ local base="$1"; git merge-base --is-ancestor "${base}" HEAD; }
count_unique_commits_no_merges(){ local range="$1"; git rev-list --count --no-merges "${range}"; }
has_merge_commits_in_range(){ local range="$1"; git rev-list --merges --count "${range}" | grep -qv '^0$'; }
run_extension_if_exists(){ local hook="$1" fn="$2"; shift 2
  if [[ -f ".githooks/run-commands.sh" ]]; then source ".githooks/run-commands.sh"; if declare -F "${fn}" >/dev/null 2>&1; then "${fn}" "$@"; return $?; fi; fi; return 0; }
