# Contributing to Git Hooks Suite

Thank you for contributing! This guide will help you understand the architecture and development workflow.

## Table of Contents
- [Architecture Overview](#architecture-overview)
- [Development Setup](#development-setup)
- [Creating New Hooks](#creating-new-hooks)
- [Modifying Existing Hooks](#modifying-existing-hooks)
- [Testing](#testing)
- [Code Style](#code-style)
- [Pull Request Process](#pull-request-process)

---

## Architecture Overview

### Directory Structure

```
.githooks/
├── lib/
│   ├── common.sh          # Shared library
│   └── runner.sh          # Command execution framework
├── test/
│   ├── test-suite.sh      # Main test runner
│   ├── test-scenarios/    # Individual test cases
│   └── test-fixtures/     # Test data
├── pre-commit             # Pre-commit hook
├── commit-msg             # Commit message validation
├── prepare-commit-msg     # Message preparation
├── pre-push               # Pre-push validation
├── pre-rebase             # Rebase warnings
├── post-rewrite           # Post-rewrite actions
├── post-checkout          # Checkout notifications
├── applypatch-msg         # Patch validation
├── install-hooks.sh       # Installation script
├── uninstall-hooks.sh     # Uninstallation script
├── clean.sh               # Log cleanup
├── commands.conf          # Custom commands configuration
└── run-commands.sh        # Legacy extensions
```

### Component Responsibilities

#### lib/common.sh
- Logging infrastructure
- Branch validation functions
- Secret scanning patterns
- Platform detection
- Utility functions

#### lib/runner.sh
- Parse commands.conf
- Execute custom commands
- Handle timeouts
- Manage parallel execution
- Auto-restage files

#### Hook Files
- Source common.sh
- Initialize logging
- Check for bypass
- Perform validation
- Call runner for custom commands
- Exit with proper status

---

## Development Setup

### Prerequisites

```bash
# Git 2.9+
git --version

# Bash 4.0+
bash --version

# Standard Unix tools
which grep sed awk
```

### Initial Setup

```bash
# Clone repository
git clone <repository-url>
cd <repository>

# Install hooks
./.githooks/install-hooks.sh

# Run tests
bash .githooks/test/test-suite.sh --all --verbose
```

### Development Workflow

```bash
# Create feature branch
git checkout -b feat-ABC-123-your-feature

# Make changes to hooks
nano .githooks/pre-commit

# Test changes
bash .githooks/test/test-suite.sh --verbose

# Test specific hook manually
bash .githooks/pre-commit

# Commit changes (will trigger hooks!)
git commit -m "feat: ABC-123 Add new validation"

# Push changes
git push origin feat-ABC-123-your-feature
```

---

## Creating New Hooks

### Step 1: Create Hook File

```bash
#!/usr/bin/env bash

# ============================================================================
# Your-Hook-Name Hook
# Purpose: Brief description of what this hook does
# Checks: List what it validates/enforces
# ============================================================================

set -euo pipefail

HOOK_NAME="your-hook-name"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
source "$SCRIPT_DIR/lib/runner.sh"

init_hook "$HOOK_NAME"

# Check for bypass
if is_bypassed "$HOOK_NAME"; then
    exit_hook "$HOOK_NAME" 0 "Bypassed"
fi

# Your validation logic here
show_progress "$HOOK_NAME" 1 3 "Checking something..."

# Example validation
if ! some_validation_function; then
    log_message $LOG_ERROR "$HOOK_NAME" "Validation failed"
    echo -e "${RED}[Error]${NC} Validation failed!"
    echo -e "${YELLOW}Hint:${NC} How to fix this"
    exit_hook "$HOOK_NAME" 1 "Validation failed"
fi

show_progress "$HOOK_NAME" 2 3 "Running custom commands..."

# Run custom commands
if ! run_hook_commands "$HOOK_NAME"; then
    exit_hook "$HOOK_NAME" 1 "Custom commands failed"
fi

show_progress "$HOOK_NAME" 3 3 "Finalizing..."

log_message $LOG_INFO "$HOOK_NAME" "All checks passed"
exit_hook "$HOOK_NAME" 0 "Success"
```

### Step 2: Make Executable

```bash
chmod +x .githooks/your-hook-name
```

### Step 3: Add Tests

Create test function in `test/test-suite.sh`:

```bash
test_your_hook_feature() {
    log_test "INFO" "Testing your hook feature..."
    
    # Setup test scenario
    echo "test" > test-file.txt
    git add test-file.txt
    
    # Run validation
    if git commit -m "feat: TEST-123 Test" 2>&1 | grep -q "expected output"; then
        return 0
    fi
    
    return 1
}
```

### Step 4: Add to Test Runner

In `test/test-suite.sh`, add to `run_all_tests()`:

```bash
# Your feature tests
if [ "$category" = "all" ] || [ "$category" = "your-feature" ]; then
    echo -e "\n${BOLD}${CYAN}═══ Your Feature Tests ═══${NC}"
    run_test "Your feature should work" test_your_hook_feature
fi
```

### Step 5: Document

Update README.md with:
- Hook description
- What it validates
- Example usage
- Configuration options

---

## Modifying Existing Hooks

### Best Practices

1. **Always test before committing:**
   ```bash
   bash .githooks/test/test-suite.sh
   ```

2. **Maintain backward compatibility:**
   ```bash
   # Check if new config exists
   new_config=$(git config hooks.newFeature || echo "default")
   ```

3. **Add clear error messages:**
   ```bash
   echo -e "${RED}[Error]${NC} What went wrong"
   echo -e "${YELLOW}Hint:${NC} How to fix it"
   echo -e "${GREEN}Example:${NC} git checkout -b feat-ABC-123-description"
   ```

4. **Log everything:**
   ```bash
   log_message $LOG_INFO "$HOOK_NAME" "Starting validation"
   log_message $LOG_ERROR "$HOOK_NAME" "Validation failed: $reason"
   ```

### Common Patterns

#### Adding Validation

```bash
# Check condition
if ! validate_something; then
    log_message $LOG_ERROR "$HOOK_NAME" "Validation failed"
    echo -e "${RED}[Error]${NC} Validation failed"
    exit_hook "$HOOK_NAME" 1 "Validation failed"
fi
```

#### Adding Configuration

```bash
# In common.sh, add to function
get_config_value() {
    local key="$1"
    local default="$2"
    git config "$key" 2>/dev/null || echo "$default"
}

# In hook, use it
my_value=$(get_config_value "hooks.myConfig" "default-value")
```

#### Adding Secret Pattern

```bash
# In common.sh, add to SECRET_PATTERNS array
SECRET_PATTERNS=(
    # ... existing patterns ...
    'your-new-pattern-regex'
)
```

---

## Testing

### Running Tests

```bash
# All tests
bash .githooks/test/test-suite.sh --all

# Specific category
bash .githooks/test/test-suite.sh --category security

# Verbose output
bash .githooks/test/test-suite.sh --verbose

# Strict mode (fail on first error)
bash .githooks/test/test-suite.sh --strict
```

### Writing Tests

#### Test Structure

```bash
test_feature_name() {
    log_test "INFO" "Testing feature..."
    
    # Setup
    setup_test_environment
    
    # Execute
    result=$(run_command)
    
    # Assert
    if [ "$result" = "expected" ]; then
        return 0  # Pass
    fi
    
    return 1  # Fail
}
```

#### Test Checklist

- [ ] Test success case
- [ ] Test failure case
- [ ] Test edge cases
- [ ] Test with bypass enabled
- [ ] Test cross-platform (if applicable)
- [ ] Test with invalid input
- [ ] Test logging output

### Manual Testing

```bash
# Test hook directly
bash .githooks/pre-commit

# Test with specific file
echo "test" > test.txt
git add test.txt
bash .githooks/pre-commit

# Test with environment variables
BYPASS_HOOKS=1 bash .githooks/pre-commit

# Test logging
tail -f .git/hook-logs/complete.log &
git commit -m "test"
```

---

## Code Style

### Shell Script Style

```bash
#!/usr/bin/env bash

# Use strict mode
set -euo pipefail

# Constants in UPPERCASE
HOOK_NAME="pre-commit"
MAX_RETRIES=3

# Variables in lowercase
local_variable="value"
function_result=$(some_function)

# Functions use snake_case
function_name() {
    local param1="$1"
    local param2="$2"
    
    # Do something
    return 0
}

# Always quote variables
echo "$variable"
echo "${variable}"

# Use [[ ]] for conditionals
if [[ "$variable" = "value" ]]; then
    # Do something
fi

# Use $() for command substitution (not backticks)
result=$(command)

# Array usage
declare -a my_array=("item1" "item2")
for item in "${my_array[@]}"; do
    echo "$item"
done
```

### Error Handling

```bash
# Always check exit codes
if some_command; then
    # Success
else
    # Failure
    log_message $LOG_ERROR "$HOOK_NAME" "Command failed"
    exit_hook "$HOOK_NAME" 1 "Command failed"
fi

# Use || for fallbacks
value=$(git config key 2>/dev/null || echo "default")

# Fail fast with set -e
set -euo pipefail
```

### Logging Standards

```bash
# Use appropriate log levels
log_message $LOG_EMERGENCY "$HOOK_NAME" "System is unusable"
log_message $LOG_FATAL "$HOOK_NAME" "Fatal error occurred"
log_message $LOG_CRITICAL "$HOOK_NAME" "Critical condition"
log_message $LOG_ERROR "$HOOK_NAME" "Error condition"
log_message $LOG_WARNING "$HOOK_NAME" "Warning condition"
log_message $LOG_NOTICE "$HOOK_NAME" "Normal but significant"
log_message $LOG_INFO "$HOOK_NAME" "Informational message"
log_message $LOG_DEBUG "$HOOK_NAME" "Debug-level message"
log_message $LOG_TRACE "$HOOK_NAME" "Trace-level message"

# Include context in messages
log_message $LOG_ERROR "$HOOK_NAME" "Failed to validate branch: $branch_name"

# Log both success and failure
log_message $LOG_INFO "$HOOK_NAME" "Validation started"
log_message $LOG_INFO "$HOOK_NAME" "Validation completed successfully"
```

### User Messages

```bash
# Use colors for clarity
echo -e "${RED}[Error]${NC} Something went wrong"
echo -e "${YELLOW}[Warning]${NC} Be careful"
echo -e "${GREEN}[Success]${NC} All good"
echo -e "${CYAN}[Info]${NC} FYI"

# Provide actionable guidance
echo -e "${RED}[Error]${NC} Invalid branch name"
echo -e "${YELLOW}Current:${NC} $branch_name"
echo -e "${GREEN}Valid format:${NC} feat-ABC-123-description"
echo -e "${CYAN}Example:${NC} git checkout -b feat-ABC-123-my-feature"

# Use consistent formatting
echo -e "\n${BOLD}Summary:${NC}"
echo -e "  ✓ Checks passed: $passed"
echo -e "  ✗ Checks failed: $failed"
```

---

## Pull Request Process

### Before Submitting

1. **Run all tests:**
   ```bash
   bash .githooks/test/test-suite.sh --all --verbose
   ```

2. **Test manually:**
   ```bash
   # Install your changes
   ./.githooks/install-hooks.sh
   
   # Test typical workflows
   git checkout -b test-branch
   git commit -m "test"
   git push
   ```

3. **Check logs for errors:**
   ```bash
   grep ERROR .git/hook-logs/complete.log
   ```

4. **Update documentation:**
   - README.md for user-facing changes
   - TROUBLESHOOTING.md for known issues
   - Code comments for complex logic

5. **Follow commit message format:**
   ```
   feat: ABC-123 Add branch validation
   fix: DEF-456 Fix secret scanning bug
   docs: GHI-789 Update troubleshooting guide
   test: JKL-012 Add test for custom commands
   ```

### PR Checklist

- [ ] All tests pass
- [ ] New tests added for new features
- [ ] Documentation updated
- [ ] Backward compatibility maintained
- [ ] Error messages are clear and actionable
- [ ] Logging added for new functionality
- [ ] Code follows style guide
- [ ] Manual testing completed
- [ ] No performance regression

### PR Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] All tests pass
- [ ] New tests added
- [ ] Manual testing completed

## Checklist
- [ ] Code follows style guide
- [ ] Documentation updated
- [ ] Backward compatible
- [ ] Error messages clear
```

---

## Common Development Tasks

### Adding a New Secret Pattern

1. Edit `lib/common.sh`:
```bash
SECRET_PATTERNS=(
    # ... existing patterns ...
    'your-new-pattern'
)
```

2. Add test in `test/test-suite.sh`:
```bash
test_new_secret_detection() {
    # Test implementation
}
```

3. Run tests:
```bash
bash .githooks/test/test-suite.sh --category security
```

### Adding a New Configuration Option

1. Document in `install-hooks.sh`:
```bash
echo -e "  ${CYAN}git config hooks.newOption value${NC}  Description"
```

2. Use in hook:
```bash
new_value=$(git config hooks.newOption || echo "default")
```

3. Add to README.md configuration section

### Improving Performance

1. Profile execution:
```bash
time bash .githooks/pre-commit
```

2. Identify slow operations:
```bash
grep "duration" .git/hook-logs/complete.log
```

3. Optimize:
   - Cache results
   - Use parallel execution
   - Skip unnecessary checks
   - Optimize regex patterns

---

## Questions?

- Check existing hooks for examples
- Review test suite for patterns
- Read TROUBLESHOOTING.md for common issues
- Check logs for debugging: `.git/hook-logs/complete.log`

---

**Happy Contributing!** 🎉
