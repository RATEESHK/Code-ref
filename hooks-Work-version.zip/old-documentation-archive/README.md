# Git Hooks Test Suite

## TL;DR - Quick Start

```bash
# 1. Enable tests
bash test-config.sh setup-dev

# 2. Run all tests
bash run-comprehensive-tests.sh

# 3. Check results
# Tests will display summary and save detailed logs
```

---

## What Is This?

A comprehensive test infrastructure for Git hooks that provides:

- ✅ **Automatic state management** - Save and restore repository state
- ✅ **Branch independence** - Tests run from a configured base branch
- ✅ **Test enablement control** - Explicit opt-in required
- ✅ **Comprehensive logging** - Detailed execution logs with timestamps
- ✅ **Automatic cleanup** - Removes test artifacts after execution

---

## Key Files

| File | Purpose | When to Use |
|------|---------|-------------|
| **test-config.sh** | Configuration management | Setup, view, or modify test settings |
| **run-comprehensive-tests.sh** | Main test runner | Run all tests with full workflow |
| **setup-test-environment.sh** | Environment setup | Manual setup before tests |
| **cleanup-test-environment.sh** | Environment cleanup | Manual cleanup after tests |
| **IMPLEMENTATION_SUMMARY.md** | What was built | Understand the implementation |
| **TESTING_GUIDE.md** | Complete documentation | Detailed usage instructions |
| **QUICK_REFERENCE.md** | Command reference | Quick command lookup |
| **TEST_INFRASTRUCTURE.md** | Architecture docs | Understand the design |

---

## First Time Setup

### Option 1: Quick Setup (Recommended)

```bash
# Setup for development
bash test-config.sh setup-dev
```

This configures:
- Tests: enabled
- Base branch: develop
- Log verbosity: verbose
- Auto-cleanup: enabled

### Option 2: Manual Setup

```bash
# Enable tests
git config hooks.tests.enabled true

# Set base branch (where tests run from)
git config hooks.tests.baseBranch develop

# Set log verbosity (quiet, normal, verbose, debug)
git config hooks.tests.logVerbosity verbose
```

### Option 3: Environment Variables

```bash
# Enable tests via environment
export GITHOOKS_TESTS_ENABLED=true
export GITHOOKS_TEST_BASE_BRANCH=develop
export GITHOOKS_TEST_LOG_LEVEL=verbose
```

---

## Running Tests

### Run All Tests

```bash
bash run-comprehensive-tests.sh
```

This will:
1. Check if tests are enabled
2. Setup test environment (save state, clean artifacts)
3. Run all 9 test categories
4. Generate comprehensive summary
5. Cleanup test environment (restore state)

### Run Specific Tests

```bash
# Branch naming tests
bash test-scenarios/branch-tests.sh

# Commit message tests
bash test-scenarios/commit-tests.sh

# Security tests
bash test-scenarios/security-tests.sh

# Hook execution tests
bash test-scenarios/hook-execution-tests.sh
```

---

## Test Categories

The comprehensive test suite includes:

1. **Branch Naming & Validation** - Branch name format, Jira tickets
2. **Commit Message Validation** - Conventional commits, format checking
3. **Security & Secrets Detection** - Credential scanning, secret detection
4. **Protected Branch Enforcement** - Push prevention, force push blocking
5. **Hook Command Integration** - Git command integration
6. **Logging & Audit Trail** - Execution logging, audit history
7. **Base Branch Validation** - Branch creation validation
8. **Hook Bypass & Override** - Emergency bypass mechanisms
9. **Direct Hook Execution** - All 8 Git hooks tested

---

## Configuration

### View Current Configuration

```bash
bash test-config.sh show
```

Output:
```
Git Hooks Test Configuration
════════════════════════════════════════

Execution Control:
  Tests Enabled:        YES

Test Environment:
  Base Branch:          develop
  Preserve State:       YES

Logging:
  Verbosity:            verbose
  Log Directory:        .githooks/test/logs

Cleanup:
  Auto-cleanup:         ENABLED

Test Categories:
  Categories:           all
```

### Common Configuration Commands

```bash
# Enable/disable tests
bash test-config.sh enable
bash test-config.sh disable

# Set base branch
git config hooks.tests.baseBranch main

# Set log verbosity
git config hooks.tests.logVerbosity debug

# Disable cleanup (for debugging)
git config hooks.tests.autoCleanup false

# Reset to defaults
bash test-config.sh reset
```

---

## Viewing Logs

Test logs are automatically created in `logs/` directory:

```bash
# View latest log
ls -t logs/*.log | head -1 | xargs cat

# View last 100 lines of latest log
ls -t logs/*.log | head -1 | xargs tail -100

# Search for failures
grep -r "FAILED" logs/

# Count test runs
ls -1 logs/*.log | wc -l
```

Log files are:
- Timestamped: `test-run-YYYYMMDD_HHMMSS.log`
- Detailed: All output with timestamps
- Retained: Last 10 test runs kept
- Gitignored: Never committed to repository

---

## Troubleshooting

### Tests Won't Run

**Error:** "Tests are not enabled"

```bash
# Solution: Enable tests
bash test-config.sh enable
```

### Wrong Branch

**Problem:** Tests running from wrong branch

```bash
# Solution: Set correct base branch
git config hooks.tests.baseBranch develop

# Verify
bash test-config.sh show
```

### Test Artifacts Remain

**Problem:** Test branches remain after tests

```bash
# Solution: Enable auto-cleanup
git config hooks.tests.autoCleanup true

# Or manually cleanup
bash cleanup-test-environment.sh
```

### Need Debug Information

```bash
# Enable debug logging
export GITHOOKS_TEST_LOG_LEVEL=debug

# Disable cleanup to inspect artifacts
export GITHOOKS_TEST_CLEANUP=false

# Run tests
bash run-comprehensive-tests.sh

# Inspect artifacts
git branch | grep test-
ls -la logs/
```

---

## Understanding Test Execution

### What Happens During a Test Run

```
1. Configuration Check
   ✓ Verify tests are enabled
   ✓ Load configuration settings

2. Environment Setup
   ✓ Save current branch
   ✓ Stash uncommitted changes
   ✓ Clean previous test artifacts
   ✓ Switch to base branch
   ✓ Create log infrastructure

3. Test Execution
   ✓ Run all test categories
   ✓ Log results and timings
   ✓ Track pass/fail status

4. Summary Generation
   ✓ Calculate statistics
   ✓ Generate detailed report
   ✓ Identify failures

5. Environment Cleanup
   ✓ Remove test artifacts
   ✓ Restore original branch
   ✓ Restore stashed changes
   ✓ Finalize logs
```

### State Preservation

**Before Tests:**
```bash
# Your state
Current Branch: feature/ABC-123
Uncommitted Changes: Yes
Test Branches: None
```

**During Tests:**
```bash
# Saved state
Current Branch: develop (base branch)
Original State: Stashed
Test Branches: test-*, *-test (created)
```

**After Tests:**
```bash
# Restored state
Current Branch: feature/ABC-123 (restored)
Uncommitted Changes: Yes (restored)
Test Branches: None (cleaned)
```

---

## Documentation

### For Quick Reference
- **QUICK_REFERENCE.md** - Common commands and options

### For Learning
- **IMPLEMENTATION_SUMMARY.md** - What was built and why
- **TESTING_GUIDE.md** - Complete usage guide

### For Understanding
- **TEST_INFRASTRUCTURE.md** - Architecture and design

---

## Examples

### Development Workflow

```bash
# Day 1: First setup
cd .githooks/test
bash test-config.sh setup-dev
bash run-comprehensive-tests.sh

# Day 2: After making changes
bash run-comprehensive-tests.sh

# Day 3: Debugging a failure
export GITHOOKS_TEST_LOG_LEVEL=debug
export GITHOOKS_TEST_CLEANUP=false
bash run-comprehensive-tests.sh
# Inspect: git branch | grep test-
# Cleanup: bash cleanup-test-environment.sh
```

### CI/CD Pipeline

```bash
#!/bin/bash
set -e

# Setup for CI
bash .githooks/test/test-config.sh setup-ci

# Run tests
bash .githooks/test/run-comprehensive-tests.sh

# Archive logs (example)
cp -r .githooks/test/logs /tmp/test-artifacts/
```

---

## Support

### Getting Help

1. **Configuration Issues:** Check `test-config.sh show`
2. **Test Failures:** Review logs in `logs/` directory
3. **Understanding Behavior:** Read `TESTING_GUIDE.md`
4. **Architecture Questions:** Read `TEST_INFRASTRUCTURE.md`
5. **Quick Commands:** Check `QUICK_REFERENCE.md`

### Common Questions

**Q: Do I need to run setup every time?**  
A: No, configuration persists. Setup only needed once or when changing settings.

**Q: Will tests modify my current branch?**  
A: No, tests run on the configured base branch and restore your original branch.

**Q: What if I have uncommitted changes?**  
A: They are automatically stashed and restored after tests (if state preservation enabled).

**Q: Can I run tests on a specific branch?**  
A: Yes, configure the base branch: `git config hooks.tests.baseBranch <branch>`

**Q: Where are test logs stored?**  
A: In `.githooks/test/logs/` with timestamped filenames.

**Q: Are logs committed to git?**  
A: No, logs are gitignored and never committed.

---

## Summary

This test infrastructure provides **reliable, repeatable, and transparent** testing for Git hooks with:

✅ Automatic state management  
✅ Branch independence  
✅ Explicit test enablement  
✅ Comprehensive logging  
✅ Automatic cleanup  
✅ Flexible configuration  
✅ Complete documentation  

**Get started in 2 commands:**

```bash
bash test-config.sh setup-dev
bash run-comprehensive-tests.sh
```

**For complete documentation, see:**
- `IMPLEMENTATION_SUMMARY.md` - What was built
- `TESTING_GUIDE.md` - How to use it
- `QUICK_REFERENCE.md` - Command reference
- `TEST_INFRASTRUCTURE.md` - Architecture details
