# Custom Commands Guide

Complete guide to configuring custom commands for Git hooks.

## Table of Contents
- [Overview](#overview)
- [Configuration Format](#configuration-format)
- [Language-Specific Examples](#language-specific-examples)
- [Advanced Usage](#advanced-usage)
- [Troubleshooting](#troubleshooting)

---

## Overview

Custom commands allow you to extend Git hooks with project-specific checks like linting, testing, building, and more.

### Features

- **Priority-based execution** - Control order of execution
- **Mandatory vs Optional** - Block commits or just warn
- **Timeout control** - Prevent hanging commands
- **Parallel execution** - Run independent checks simultaneously
- **File placeholders** - Pass staged files to commands
- **Auto-restaging** - Re-add fixed files automatically

### Configuration File

Location: `.githooks/commands.conf`

Format:
```
HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
```

---

## Configuration Format

### Fields

| Field | Description | Example |
|-------|-------------|---------|
| HOOK | Hook name | `pre-commit`, `commit-msg`, `pre-push` |
| PRIORITY | Execution order (lower = first) | `1`, `2`, `3` |
| MANDATORY | Block on failure? | `true`, `false` |
| TIMEOUT | Max seconds (0 = no limit) | `30`, `60`, `300` |
| COMMAND | Shell command to run | `npm run lint` |
| DESCRIPTION | Human-readable name | `Lint staged files` |

### Available Hooks

- `pre-commit` - Before commit is created
- `commit-msg` - After commit message is written
- `pre-push` - Before changes are pushed

### Placeholders

- `{staged}` - Replaced with list of staged file paths
- Environment variables available in commands:
  - `$STAGED_FILES` - Space-separated staged files
  - `$GIT_HOOK_NAME` - Current hook name
  - `$GIT_USER_NAME` - Git user name
  - `$GIT_USER_EMAIL` - Git user email

---

## Language-Specific Examples

### JavaScript / TypeScript / Node.js

```bash
# .githooks/commands.conf

# Pre-commit checks
pre-commit:1:true:30:npx lint-staged:Lint and format staged files
pre-commit:2:false:60:npx tsc --noEmit --skipLibCheck:TypeScript type checking
pre-commit:3:true:30:node scripts/check-imports.js:Validate imports
pre-commit:4:false:30:npx prettier --check {staged}:Check formatting
pre-commit:5:false:30:npm run lint:css:Lint CSS files

# Pre-push checks
pre-push:1:true:300:npm test:Run test suite
pre-push:2:false:600:npm run build:Verify build
pre-push:3:false:120:npm audit --audit-level=moderate:Security audit
pre-push:4:false:180:npm run test:coverage:Coverage check

# Commit message checks
commit-msg:1:false:10:node scripts/validate-ticket.js:Validate ticket format
```

#### With lint-staged integration

```json
// package.json
{
  "lint-staged": {
    "*.{js,jsx,ts,tsx}": [
      "eslint --fix",
      "prettier --write"
    ],
    "*.{css,scss}": [
      "stylelint --fix"
    ]
  }
}
```

```bash
# commands.conf
pre-commit:1:true:30:npx lint-staged:Lint and format
```

### Python

```bash
# .githooks/commands.conf

# Pre-commit checks
pre-commit:1:true:30:black --check {staged}:Format Python files
pre-commit:2:true:30:flake8 {staged}:Lint Python files
pre-commit:3:false:60:mypy {staged}:Type checking
pre-commit:4:false:30:isort --check {staged}:Check import sorting
pre-commit:5:false:30:pylint {staged}:Code quality check

# Pre-push checks
pre-push:1:true:300:pytest:Run tests
pre-push:2:false:120:pytest --cov:Coverage check
pre-push:3:false:120:bandit -r .:Security scan
pre-push:4:false:60:safety check:Dependency security check
```

#### With Poetry

```bash
pre-commit:1:true:30:poetry run black --check {staged}:Format check
pre-commit:2:true:30:poetry run flake8 {staged}:Lint
pre-push:1:true:300:poetry run pytest:Tests
```

### Java / Maven

```bash
# .githooks/commands.conf

# Pre-commit checks
pre-commit:1:true:60:mvn checkstyle:check:Checkstyle validation
pre-commit:2:false:60:mvn spotbugs:check:SpotBugs analysis
pre-commit:3:false:60:mvn pmd:check:PMD check

# Pre-push checks
pre-push:1:true:600:mvn clean test:Run tests
pre-push:2:false:900:mvn clean package:Build package
pre-push:3:false:300:mvn dependency:analyze:Dependency analysis
```

### Java / Gradle

```bash
pre-commit:1:true:60:./gradlew checkstyleMain:Checkstyle
pre-commit:2:false:60:./gradlew spotbugsMain:SpotBugs
pre-push:1:true:600:./gradlew test:Tests
pre-push:2:false:900:./gradlew build:Build
```

### .NET / C#

```bash
# .githooks/commands.conf

# Pre-commit checks
pre-commit:1:true:60:dotnet format --verify-no-changes:Format verification
pre-commit:2:false:60:dotnet build --no-restore:Build check
pre-commit:3:false:30:dotnet format analyzers:Analyzer check

# Pre-push checks
pre-push:1:true:300:dotnet test:Run tests
pre-push:2:false:600:dotnet build --configuration Release:Release build
pre-push:3:false:120:dotnet list package --vulnerable:Security check
```

### Go

```bash
# .githooks/commands.conf

# Pre-commit checks
pre-commit:1:true:30:gofmt -l {staged}:Format check
pre-commit:2:true:30:go vet ./...:Go vet
pre-commit:3:false:60:golangci-lint run:Linting
pre-commit:4:false:30:go mod tidy:Tidy modules

# Pre-push checks
pre-push:1:true:300:go test ./...:Run tests
pre-push:2:false:180:go test -race ./...:Race detection
pre-push:3:false:120:go test -cover ./...:Coverage check
```

### Ruby / Rails

```bash
# .githooks/commands.conf

# Pre-commit checks
pre-commit:1:true:30:rubocop --format simple {staged}:Ruby linting
pre-commit:2:false:30:bundle exec reek {staged}:Code smell detection
pre-commit:3:false:60:bundle exec brakeman -q:Security scan

# Pre-push checks
pre-push:1:true:300:bundle exec rspec:Run tests
pre-push:2:false:120:bundle exec rubocop:Full lint check
```

### Rust

```bash
# .githooks/commands.conf

# Pre-commit checks
pre-commit:1:true:30:cargo fmt -- --check:Format check
pre-commit:2:true:60:cargo clippy -- -D warnings:Clippy linting
pre-commit:3:false:60:cargo check:Quick check

# Pre-push checks
pre-push:1:true:300:cargo test:Run tests
pre-push:2:false:600:cargo build --release:Release build
```

### PHP

```bash
# .githooks/commands.conf

# Pre-commit checks
pre-commit:1:true:30:./vendor/bin/php-cs-fixer fix --dry-run {staged}:Format check
pre-commit:2:true:30:./vendor/bin/phpcs {staged}:Code sniffer
pre-commit:3:false:60:./vendor/bin/phpstan analyze:Static analysis
pre-commit:4:false:30:./vendor/bin/psalm:Psalm check

# Pre-push checks
pre-push:1:true:300:./vendor/bin/phpunit:Run tests
pre-push:2:false:120:composer validate:Validate composer.json
```

---

## Advanced Usage

### Parallel Execution

Commands with the same priority run in parallel:

```bash
# These run in parallel (same priority)
pre-commit:1:false:30:npm run lint:js:Lint JavaScript
pre-commit:1:false:30:npm run lint:css:Lint CSS
pre-commit:1:false:30:npm run lint:html:Lint HTML

# Then this runs (higher priority number)
pre-commit:2:true:60:npm run type-check:Type checking
```

Enable parallel execution:
```bash
git config hooks.parallelExecution true
```

### Auto-restaging Fixed Files

Enable auto-restage after lint fixes:
```bash
git config hooks.autoAddAfterFix true
```

Example workflow:
```bash
# commands.conf
pre-commit:1:true:30:npx eslint --fix {staged}:Fix linting issues
pre-commit:2:true:30:npx prettier --write {staged}:Format files

# With autoAddAfterFix=true:
# 1. Files are linted and fixed
# 2. Files are formatted
# 3. Fixed files are automatically re-staged
# 4. Commit proceeds with clean code
```

### Conditional Execution

Run commands only if certain files changed:

```bash
# Check TypeScript only if .ts files staged
pre-commit:1:false:60:bash -c '[[ $(git diff --cached --name-only | grep -c "\.ts$") -gt 0 ]] && npx tsc --noEmit || true':TypeScript check

# Run database migrations if schema changed
pre-push:1:false:120:bash -c '[[ $(git diff origin/main --name-only | grep -q "schema") ]] && npm run migrate || true':Database migrations
```

### Timeout Strategies

```bash
# Quick checks (< 30s)
pre-commit:1:true:10:quick-lint:Fast linting

# Medium checks (30s - 2min)
pre-commit:2:false:60:medium-check:Moderate check

# Long checks (> 2min)
pre-push:1:false:300:npm test:Full test suite

# No timeout (use with caution)
pre-push:2:false:0:long-running-task:Slow task
```

### Project-Specific Scripts

Create custom scripts in `scripts/` directory:

```bash
# scripts/check-todos.sh
#!/bin/bash
if git diff --cached | grep -i "TODO\|FIXME"; then
    echo "Warning: TODOs found in commit"
    exit 1
fi
```

```bash
# commands.conf
pre-commit:5:false:5:bash scripts/check-todos.sh:Check for TODOs
```

### Multi-stage Checks

```bash
# Stage 1: Fast checks (mandatory)
pre-commit:1:true:10:eslint --max-warnings 0 {staged}:Lint
pre-commit:2:true:10:prettier --check {staged}:Format

# Stage 2: Slower checks (optional)
pre-commit:10:false:60:tsc --noEmit:Type check
pre-commit:11:false:60:npm run test:related:Related tests

# Stage 3: Pre-push only
pre-push:1:true:300:npm test:Full tests
pre-push:2:false:600:npm run build:Build
```

---

## Real-World Examples

### React / Next.js Project

```bash
# .githooks/commands.conf

# Fast pre-commit checks
pre-commit:1:true:30:npx lint-staged:Lint and format
pre-commit:2:false:60:npx tsc --noEmit:Type check
pre-commit:3:false:30:node scripts/check-translations.js:Check i18n

# Pre-push checks
pre-push:1:true:300:npm test -- --passWithNoTests:Tests
pre-push:2:false:600:npm run build:Build check
pre-push:3:false:120:npm run test:e2e:smoke:Smoke tests
```

### Full-stack (Node + Python)

```bash
# Frontend checks
pre-commit:1:true:30:cd frontend && npx lint-staged:Frontend lint
pre-commit:2:false:60:cd frontend && npx tsc --noEmit:Frontend types

# Backend checks
pre-commit:10:true:30:cd backend && black --check {staged}:Backend format
pre-commit:11:true:30:cd backend && flake8 {staged}:Backend lint

# Integration
pre-push:1:true:300:npm run test:integration:Integration tests
pre-push:2:false:600:docker-compose build:Docker build
```

### Monorepo

```bash
# Shared checks
pre-commit:1:true:30:npx lint-staged:Lint all

# Package-specific (conditional)
pre-commit:10:false:60:bash -c '[[ $(git diff --cached --name-only | grep "^packages/ui/") ]] && cd packages/ui && npm run type-check || true':UI types
pre-commit:11:false:60:bash -c '[[ $(git diff --cached --name-only | grep "^packages/api/") ]] && cd packages/api && npm run validate || true':API validation

# Monorepo-wide
pre-push:1:true:600:npm run test:all:All tests
pre-push:2:false:900:npm run build:all:Build all packages
```

### Microservices

```bash
# Detect changed services
pre-commit:1:true:30:bash scripts/lint-changed-services.sh:Lint changed services
pre-push:1:true:300:bash scripts/test-changed-services.sh:Test changed services
pre-push:2:false:600:bash scripts/build-changed-services.sh:Build changed services
```

---

## Troubleshooting

### Command Not Running

1. **Check syntax:**
   ```bash
   # Verify format
   cat .githooks/commands.conf | grep -v "^#" | grep -v "^$"
   
   # Each line should have 6 fields separated by colons
   ```

2. **Check logs:**
   ```bash
   tail -50 .git/hook-logs/complete.log | grep "custom command"
   ```

3. **Test command manually:**
   ```bash
   # Run the exact command
   npm run lint
   
   # Check exit code
   echo $?
   ```

### Timeout Issues

```bash
# Increase timeout
pre-commit:1:true:120:slow-command:Slow check
#                 ^^^ Increase this

# Or make optional
pre-commit:1:false:60:slow-command:Slow check
#            ^^^^^ Change to false
```

### Files Not Staged After Fixes

```bash
# Enable auto-restage
git config hooks.autoAddAfterFix true

# Verify setting
git config hooks.autoAddAfterFix
# Should output: true
```

### Parallel Execution Issues

```bash
# Disable parallel execution
git config hooks.parallelExecution false

# Or use different priorities
pre-commit:1:true:30:command1:First
pre-commit:2:true:30:command2:Second (runs after first)
```

---

## Best Practices

### Performance

1. **Use staged files:**
   ```bash
   # Good: Only check staged files
   pre-commit:1:true:30:eslint {staged}:Lint
   
   # Bad: Check all files
   pre-commit:1:true:60:eslint src/:Lint
   ```

2. **Appropriate timeouts:**
   ```bash
   # Fast checks: 10-30s
   pre-commit:1:true:10:quick-lint:Fast lint
   
   # Slow checks: pre-push only
   pre-push:1:true:300:npm test:Full tests
   ```

3. **Make slow checks optional:**
   ```bash
   pre-commit:1:true:30:fast-mandatory:Quick check
   pre-commit:2:false:60:slow-optional:Slow check
   ```

### Organization

1. **Group by stage:**
   ```bash
   # Format (priority 1-9)
   pre-commit:1:true:30:prettier {staged}:Format
   
   # Lint (priority 10-19)
   pre-commit:10:true:30:eslint {staged}:Lint
   
   # Type check (priority 20-29)
   pre-commit:20:false:60:tsc --noEmit:Types
   ```

2. **Clear descriptions:**
   ```bash
   # Good
   pre-commit:1:true:30:npm run lint:Lint JavaScript files
   
   # Bad
   pre-commit:1:true:30:npm run lint:Lint
   ```

3. **Comments:**
   ```bash
   # Format checks
   pre-commit:1:true:30:prettier {staged}:Format
   
   # Linting checks
   pre-commit:10:true:30:eslint {staged}:Lint
   ```

---

## Quick Reference

### Common Commands

```bash
# Edit configuration
nano .githooks/commands.conf

# Disable auto-restage
git config hooks.autoAddAfterFix false

# Enable parallel execution
git config hooks.parallelExecution true

# View command output
tail -f .git/hook-logs/complete.log

# Test commands
git commit -m "test"
```

### Syntax Cheat Sheet

```
HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
│    │        │         │       │       └─ Display name
│    │        │         │       └────────── Shell command
│    │        │         └────────────────── Seconds (0=unlimited)
│    │        └──────────────────────────── true=block, false=warn
│    └───────────────────────────────────── Lower=first
└────────────────────────────────────────── pre-commit/commit-msg/pre-push
```

---

**Need Help?** Check [TROUBLESHOOTING.md](TROUBLESHOOTING.md) or view logs at `.git/hook-logs/complete.log`
