# Git Hooks Test Suite - Quick Reference

## Enable Tests (First Time)

```bash
# Option 1: Quick development setup
bash .githooks/test/test-config.sh setup-dev

# Option 2: Manual enable
git config hooks.tests.enabled true

# Option 3: Environment variable
export GITHOOKS_TESTS_ENABLED=true
```

## Run All Tests

```bash
bash .githooks/test/run-comprehensive-tests.sh
```

## Run Specific Tests

```bash
# Branch naming
bash .githooks/test/test-scenarios/branch-tests.sh

# Commit messages
bash .githooks/test/test-scenarios/commit-tests.sh

# Security/secrets
bash .githooks/test/test-scenarios/security-tests.sh

# Hook execution
bash .githooks/test/test-scenarios/hook-execution-tests.sh
```

## View Configuration

```bash
bash .githooks/test/test-config.sh show
```

## Common Configurations

```bash
# Set base branch (tests run from here)
git config hooks.tests.baseBranch develop

# Set log verbosity (quiet, normal, verbose, debug)
git config hooks.tests.logVerbosity verbose

# Disable auto-cleanup (keep test artifacts)
git config hooks.tests.autoCleanup false

# Disable state preservation (don't save/restore)
git config hooks.tests.preserveState false
```

## Environment Variables (Override Git Config)

```bash
export GITHOOKS_TESTS_ENABLED=true
export GITHOOKS_TEST_BASE_BRANCH=develop
export GITHOOKS_TEST_LOG_LEVEL=verbose
export GITHOOKS_TEST_CLEANUP=true
export GITHOOKS_TEST_CATEGORIES=all
```

## View Test Logs

```bash
# View latest log
ls -t .githooks/test/logs/*.log | head -1 | xargs cat

# View all logs
ls .githooks/test/logs/

# Search for failures
grep -r "FAILED" .githooks/test/logs/
```

## Manual Environment Management

```bash
# Setup only
bash .githooks/test/setup-test-environment.sh

# ... do manual testing ...

# Cleanup only
bash .githooks/test/cleanup-test-environment.sh
```

## Troubleshooting

```bash
# Tests won't run
bash .githooks/test/test-config.sh enable

# Clean test artifacts manually
git branch -D $(git branch | grep 'test-')

# Reset configuration
bash .githooks/test/test-config.sh reset
```

## Test Categories

1. **branch-naming** - Branch name validation
2. **commit-validation** - Commit message format
3. **security-checks** - Secrets detection
4. **protected-branches** - Protected branch enforcement
5. **hook-commands** - Hook command integration
6. **logging-system** - Logging & audit trail
7. **base-branch-enforcement** - Base branch validation
8. **bypass-mechanism** - Hook bypass controls
9. **hook-execution** - Direct hook execution

## Exit Codes

- **0** - All tests passed
- **1** - Some tests failed or error occurred

## Files

- **test-config.sh** - Configuration management
- **setup-test-environment.sh** - Environment setup
- **cleanup-test-environment.sh** - Environment cleanup
- **run-comprehensive-tests.sh** - Main test runner
- **test-suite.sh** - Legacy test suite
- **logs/** - Test execution logs
- **test-scenarios/** - Individual test files

## Full Documentation

See `TESTING_GUIDE.md` for complete documentation.
