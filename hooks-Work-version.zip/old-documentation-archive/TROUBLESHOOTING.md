# Troubleshooting Guide

Common issues and solutions for Git Hooks Suite.

## Table of Contents
- [Installation Issues](#installation-issues)
- [Hook Execution Issues](#hook-execution-issues)
- [Performance Issues](#performance-issues)
- [Custom Command Issues](#custom-command-issues)
- [Logging Issues](#logging-issues)
- [Platform-Specific Issues](#platform-specific-issues)

---

## Installation Issues

### Hooks not running after installation

**Symptoms:**
- Commits/pushes succeed without any validation
- No hook messages appear

**Solutions:**

1. **Verify hooks path:**
   ```bash
   git config core.hooksPath
   # Should output: .githooks
   ```

2. **Reinstall hooks:**
   ```bash
   ./.githooks/install-hooks.sh
   ```

3. **Check file permissions (Linux/macOS):**
   ```bash
   chmod +x .githooks/*
   chmod +x .githooks/lib/*
   ```

4. **Check if bypassed:**
   ```bash
   # Make sure these aren't set in your environment
   unset BYPASS_HOOKS
   unset ALLOW_DIRECT_PROTECTED
   ```

### Permission denied errors (Linux/macOS)

**Error:**
```
bash: .githooks/pre-commit: Permission denied
```

**Solution:**
```bash
chmod +x .githooks/*
chmod +x .githooks/lib/*
```

### Script not found (Windows)

**Error:**
```
bash: ./githooks/install-hooks.sh: No such file or directory
```

**Solution:**
```bash
# Use Unix-style paths in Git Bash
bash .githooks/install-hooks.sh

# Or use forward slashes
bash ./.githooks/install-hooks.sh
```

---

## Hook Execution Issues

### "source: not found" error

**Error:**
```
source: not found
.githooks/pre-commit: line 12: source: not found
```

**Cause:** Running with sh instead of bash

**Solution:**
```bash
# Hooks should have: #!/usr/bin/env bash
# Check shebang:
head -1 .githooks/pre-commit

# If using sh, switch to bash
bash .githooks/pre-commit
```

### Hooks running but validation not working

**Symptoms:**
- Invalid branch names pass
- Invalid commit messages accepted

**Diagnosis:**
```bash
# Check logs for errors
tail -50 .git/hook-logs/complete.log

# Test hook directly
bash .githooks/pre-commit

# Verify regex patterns
git config --get-regexp hooks.
```

**Solutions:**

1. **Check for bypass environment variables:**
   ```bash
   env | grep BYPASS
   env | grep ALLOW_DIRECT
   ```

2. **Verify common.sh is sourced:**
   ```bash
   grep "source.*common.sh" .githooks/pre-commit
   ```

3. **Check Git version:**
   ```bash
   git --version
   # Requires Git 2.9+ for core.hooksPath
   ```

### "Bad substitution" error

**Error:**
```
.githooks/lib/common.sh: line 45: ${parameter//pattern/string}: bad substitution
```

**Cause:** Using sh instead of bash

**Solution:**
Ensure scripts use bash:
```bash
#!/usr/bin/env bash
```

---

## Performance Issues

### Hooks are very slow

**Symptoms:**
- Commits take >5 seconds
- Push takes >10 seconds

**Diagnosis:**
```bash
# Check which commands are slow
tail -100 .git/hook-logs/complete.log | grep duration

# Time a commit
time git commit -m "feat: TEST-123 Test"
```

**Solutions:**

1. **Reduce log level:**
   ```bash
   export GIT_HOOK_LOG_LEVEL=3  # Errors only
   ```

2. **Enable parallel execution:**
   ```bash
   git config hooks.parallelExecution true
   ```

3. **Optimize custom commands:**
   ```bash
   # Reduce timeouts in commands.conf
   # Remove non-essential checks
   nano .githooks/commands.conf
   ```

4. **Check secret scanning performance:**
   ```bash
   # For large repos, consider staged-only scanning
   # Already implemented by default
   ```

5. **Disable verbose logging:**
   ```bash
   unset GIT_HOOK_LOG_LEVEL
   ```

### Secret scanning timeout

**Error:**
```
[ERROR] [pre-commit] Secret scanning timeout
```

**Solutions:**

1. **Increase timeout in commands.conf:**
   ```bash
   # Change from 30 to 60 seconds
   pre-commit:1:true:60:scan-secrets:Secret scanning
   ```

2. **Exclude large files:**
   ```bash
   # Add to .gitignore
   *.min.js
   *.bundle.js
   dist/*
   build/*
   ```

---

## Custom Command Issues

### Commands not running

**Symptoms:**
- Custom commands in commands.conf don't execute
- No output from custom commands

**Diagnosis:**
```bash
# Check commands.conf syntax
cat .githooks/commands.conf

# Check for errors in logs
grep "custom command" .git/hook-logs/complete.log

# Test runner directly
bash .githooks/lib/runner.sh
```

**Solutions:**

1. **Verify commands.conf format:**
   ```bash
   # Correct format:
   # HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
   pre-commit:1:true:30:npm run lint:Linting
   
   # Wrong formats:
   pre-commit,1,true,30,npm run lint,Linting  # Wrong separator
   pre-commit:1:yes:30:npm run lint:Linting   # Wrong boolean
   ```

2. **Check command exists:**
   ```bash
   # Verify command is available
   which npm
   which node
   which npx
   ```

3. **Test command manually:**
   ```bash
   # Run the command yourself
   npm run lint
   npx tsc --noEmit
   ```

### Command timeout issues

**Error:**
```
[ERROR] Command timeout: Build verification (timeout after 60s)
```

**Solutions:**

1. **Increase timeout:**
   ```bash
   # In commands.conf
   pre-push:2:false:300:npm run build:Build verification
   #                 ^^^ Increase this value
   ```

2. **Make command optional:**
   ```bash
   # Change mandatory from true to false
   pre-push:2:false:300:npm run build:Build verification
   #          ^^^^^
   ```

3. **Optimize the command:**
   ```bash
   # Use faster alternatives
   # Instead of: npm run build
   # Use: npm run build:quick
   ```

### {staged} placeholder not working

**Symptoms:**
- Commands don't receive staged files
- Linters run on all files instead of staged

**Solution:**
```bash
# Ensure correct placeholder usage
pre-commit:1:true:30:npx eslint {staged}:Linting

# For commands that need file list as args
pre-commit:1:true:30:npx prettier --write {staged}:Format

# Note: {staged} is replaced with actual file paths
```

---

## Logging Issues

### Logs not being created

**Symptoms:**
- .git/hook-logs/ directory empty
- No complete.log file

**Solutions:**

1. **Check directory permissions:**
   ```bash
   ls -la .git/hook-logs/
   # Should be writable
   
   # Fix permissions
   chmod 755 .git/hook-logs/
   ```

2. **Manually create directory:**
   ```bash
   mkdir -p .git/hook-logs
   touch .git/hook-logs/complete.log
   ```

3. **Check disk space:**
   ```bash
   df -h .
   # Ensure sufficient space
   ```

### Logs too large

**Symptoms:**
- Log files several MB in size
- Slow hook execution

**Solutions:**

1. **Run log cleanup:**
   ```bash
   bash .githooks/clean.sh
   ```

2. **Configure log rotation:**
   ```bash
   # Edit clean.sh to rotate more aggressively
   # Change MAX_SIZE from 262144 to 131072 (128KB)
   ```

3. **Reduce log level:**
   ```bash
   export GIT_HOOK_LOG_LEVEL=4  # Warnings and above
   ```

### Can't read logs

**Error:**
```
Permission denied: .git/hook-logs/complete.log
```

**Solution:**
```bash
# Fix permissions
chmod 644 .git/hook-logs/*.log

# Or view with sudo (Linux/macOS)
sudo tail .git/hook-logs/complete.log
```

---

## Platform-Specific Issues

### Windows (Git Bash)

#### Line ending issues

**Error:**
```
$'\r': command not found
```

**Solution:**
```bash
# Convert line endings
dos2unix .githooks/*
dos2unix .githooks/lib/*

# Or use Git
git config core.autocrlf false
```

#### Path issues

**Error:**
```
/c/Users/...: No such file or directory
```

**Solution:**
```bash
# Use Unix-style paths
cd /c/Users/yourname/project
./githooks/install-hooks.sh

# Or use relative paths
cd e:/BasicAngularApp
./.githooks/install-hooks.sh
```

#### timeout command not found

**Error:**
```
timeout: command not found
```

**Solution:**
```bash
# timeout is optional in runner.sh
# Commands will run without timeout limit
# To add timeout support, install coreutils:
# choco install coreutils
```

### macOS

#### BSD vs GNU utils

**Error:**
```
stat: illegal option -- c
```

**Solution:**
```bash
# Install GNU coreutils
brew install coreutils

# Commands automatically use gstat/gfind when available
```

#### Permission issues with SIP

**Error:**
```
Operation not permitted
```

**Solution:**
```bash
# Don't install hooks in system directories
# Use project-specific .githooks only
```

### Linux

#### SELinux blocking execution

**Error:**
```
Permission denied (SELinux)
```

**Solution:**
```bash
# Check SELinux status
getenforce

# Temporarily disable
sudo setenforce 0

# Or update context
chcon -R -t user_home_t .githooks/
```

---

## Debugging Tips

### Enable verbose logging

```bash
# For all hooks
export GIT_HOOK_LOG_LEVEL=8  # Maximum verbosity

# Run command and check logs
git commit -m "test"
tail -50 .git/hook-logs/complete.log
```

### Test hooks manually

```bash
# Test pre-commit
echo "test" > file.txt
git add file.txt
bash .githooks/pre-commit

# Test commit-msg
echo "feat: TEST-123 Test" > /tmp/msg.txt
bash .githooks/commit-msg /tmp/msg.txt

# Test pre-push (more complex)
echo "refs/heads/main $(git rev-parse HEAD) refs/heads/main 0000000000000000000000000000000000000000" | bash .githooks/pre-push origin url
```

### Check hook execution

```bash
# Trace hook execution
bash -x .githooks/pre-commit

# Check if hook is called
echo "echo 'PRE-COMMIT CALLED' >> /tmp/hook-debug.log" >> .githooks/pre-commit
git commit -m "test"
cat /tmp/hook-debug.log
```

### Verify regex patterns

```bash
# Test branch name
branch="feat-ABC-123-test"
if [[ "$branch" =~ ^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$ ]]; then
    echo "Valid"
else
    echo "Invalid"
fi
```

---

## Getting Help

1. **Check logs first:**
   ```bash
   tail -100 .git/hook-logs/complete.log
   ```

2. **Run tests:**
   ```bash
   bash .githooks/test/test-suite.sh --verbose
   ```

3. **Search for error message:**
   ```bash
   grep -r "error message" .githooks/
   ```

4. **Check configuration:**
   ```bash
   git config --get-regexp hooks.
   git config core.hooksPath
   ```

5. **Verify installation:**
   ```bash
   ./.githooks/install-hooks.sh
   ```

---

## Common Solutions Checklist

Before reporting an issue, try:

- [ ] Reinstall hooks: `./.githooks/install-hooks.sh`
- [ ] Check permissions: `chmod +x .githooks/*`
- [ ] Verify Git config: `git config core.hooksPath`
- [ ] Review logs: `tail -50 .git/hook-logs/complete.log`
- [ ] Test manually: `bash .githooks/pre-commit`
- [ ] Check bypasses: `env | grep BYPASS`
- [ ] Run tests: `bash .githooks/test/test-suite.sh`
- [ ] Update Git: `git --version` (requires 2.9+)
- [ ] Clear environment: Restart terminal

---

**Last Updated:** November 4, 2025  
**Version:** 2.0
