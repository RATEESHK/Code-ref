# Installation Script v3.0 - Quick Reference

## 🚀 Quick Start

```bash
# Install with all features
bash .githooks/install-hooks.sh

# Test rollback functionality
bash .githooks/test-rollback.sh

# Uninstall (if needed)
bash .githooks/uninstall-hooks.sh
```

## ✨ Key Features

| Feature | Description |
|---------|-------------|
| **Auto .gitignore** | Automatically detects and updates `.gitignore` |
| **Complete Rollback** | Restores all changes if installation fails |
| **Error Recovery** | Handles interruptions (Ctrl+C) gracefully |
| **Audit Logging** | Comprehensive logs of all operations |
| **State Tracking** | Tracks every operation for rollback |
| **Zero Manual Steps** | Fully automated configuration |

## 📋 Installation Steps

The installation script performs **12 steps**:

| Step | Operation | Rollback |
|------|-----------|----------|
| **0** | Check/update `.gitignore` | Restore backup |
| **1** | Set hooks path (`core.hooksPath`) | Restore old value |
| **2** | Enable autosquash (`rebase.autosquash`) | Restore old value |
| **3** | Enable auto-prune (`fetch.prune`) | Restore old value |
| **4** | Set max commits (`hooks.maxCommits`) | Unset or restore |
| **5** | Configure auto-restage (`hooks.autoAddAfterFix`) | Unset or restore |
| **6** | Set branch mappings (15 types) | Unset all |
| **7** | Make hooks executable | N/A |
| **8** | Create log directory | Remove directory |
| **9** | Add logs to exclude | N/A |
| **10** | Setup test infrastructure | Remove directory |
| **11** | Create example configs | Remove files |

## 🔄 Rollback Mechanism

### When Rollback Triggers

- **Error during installation** (any step fails)
- **User interruption** (Ctrl+C pressed)
- **System signal** (TERM signal received)

### What Gets Rolled Back

```
Operation              → Rollback Action
─────────────────────────────────────────────────────
Git config changed     → Restore original value
Git config added       → Unset (remove)
Directory created      → Remove directory
File created           → Remove file
File modified          → Restore from backup
```

### Rollback Process

```
1. Detect failure/interruption
2. Display rollback message
3. Execute operations in reverse order
4. Log each rollback step
5. Clean up rollback script
6. Report completion
```

## 📁 File Management

### Created Files

```
.githooks/logs/
├── install-YYYYMMDD_HHMMSS.log      # Installation log
└── .rollback-YYYYMMDD_HHMMSS.sh     # Rollback script (temp)

.git/hook-logs/
├── complete.log                      # All hooks log
└── <hook-name>.log                   # Individual hook logs

.gitignore                            # Updated with hook patterns
```

### Temporary Files

- `.rollback-*.sh` - Deleted after successful installation
- `.gitignore.backup.*` - Deleted after successful installation
- `*.test-backup` - Only during testing

## 🎯 Common Scenarios

### Scenario 1: Fresh Installation

```bash
# No hooks configured, .gitignore exists
bash .githooks/install-hooks.sh

Output:
  [0/11] Checking .gitignore configuration...
    ✓ .gitignore file found
    ⚠ Some hook patterns are missing
    Add patterns? (Y/n): y
    ✓ Hook patterns added
  
  [1/11] Setting Git hooks path...
    ✓ Hooks path configured
  
  ... (continues through step 11)
  
  ✓ Installation Complete!
```

### Scenario 2: Missing .gitignore

```bash
# No .gitignore file exists
bash .githooks/install-hooks.sh

Output:
  [0/11] Checking .gitignore configuration...
    ⚠ .gitignore file not found!
    
    CRITICAL: .gitignore file is missing
    Would you like to create .gitignore now? (y/N): y
    ✓ .gitignore created with hook patterns
  
  ... (continues)
```

### Scenario 3: Installation Failure

```bash
# Something fails during installation
bash .githooks/install-hooks.sh

Output:
  [5/11] Configuring auto-restage...
    ✗ ERROR: Permission denied
  
  ═══════════════════════════════════════════════════
       INSTALLATION FAILED - EXECUTING ROLLBACK
  ═══════════════════════════════════════════════════
  
  ℹ Rolling back 5 operations...
  ℹ [ROLLBACK 1/5] Executing: git config --unset 'hooks.maxCommits'
  ✓ Rollback step completed
  ... (continues)
  
  ✓ Rollback completed - repository restored
```

### Scenario 4: User Interruption

```bash
# User presses Ctrl+C during installation
bash .githooks/install-hooks.sh
# Press Ctrl+C

Output:
  [3/11] Enabling automatic remote pruning...
  ^C
  
  ═══════════════════════════════════════════════════
       INSTALLATION FAILED - EXECUTING ROLLBACK
  ═══════════════════════════════════════════════════
  
  ℹ Rolling back 3 operations...
  ... (rolls back completed steps)
  
  ✓ Rollback completed - repository restored
```

### Scenario 5: Re-installation

```bash
# Hooks already installed
bash .githooks/install-hooks.sh

Output:
  [0/11] Checking .gitignore configuration...
    ✓ .gitignore file found
    ✓ All hook patterns present
  
  [1/11] Setting Git hooks path...
    ℹ [ROLLBACK] Registered: git config 'core.hooksPath' '.githooks'
    ✓ Hooks path configured
  
  ... (updates all configurations)
  
  ✓ Installation Complete!
```

## 🧪 Testing

### Test Suite

```bash
# Run all rollback tests
bash .githooks/test-rollback.sh

Output:
  ╔═══════════════════════════════════════════╗
  ║    Installation Rollback Test Suite      ║
  ╚═══════════════════════════════════════════╝

  Test 1: Normal Installation
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ✓ PASSED

  Test 2: .gitignore Creation
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ✓ PASSED

  ... (continues for all tests)

  ═══════════════════════════════════════════
                Test Summary
  ═══════════════════════════════════════════
  Total Tests:   7
  Passed:        7
  Failed:        0

  ✓ All tests passed!
```

### Manual Tests

```bash
# Test 1: Verify hooks are active
git checkout -b test-hooks
git commit --allow-empty -m "test"
git checkout -
git branch -D test-hooks

# Test 2: Check .gitignore
cat .gitignore | grep -A 6 "Git Hooks"

# Test 3: View logs
cat .githooks/logs/install-*.log | tail -50

# Test 4: Verify configurations
git config --list | grep hooks.

# Test 5: Test rollback (modify script to fail)
# Edit install-hooks.sh, add `exit 1` after step 5
bash .githooks/install-hooks.sh
# Should see rollback
git config --list | grep hooks.
# Should show no configs or old values
```

## 🔧 Configuration

### Git Config Keys

```bash
# Core configuration
git config core.hooksPath                      # .githooks

# Hook behavior
git config hooks.maxCommits                    # 5
git config hooks.autoAddAfterFix               # false
git config hooks.parallelExecution             # false (optional)

# Branch mappings (15 types)
git config hooks.branchMapping.hotfix          # origin/main
git config hooks.branchMapping.feat            # origin/develop
git config hooks.branchMapping.bugfix          # origin/develop
# ... (12 more)

# Test configuration (if enabled)
git config hooks.tests.enabled                 # true/false
git config hooks.tests.baseBranch              # origin/develop
git config hooks.tests.logVerbosity            # detailed
git config hooks.tests.autoCleanup             # true
```

### Bypass Options

```bash
# Skip all hooks (emergency)
BYPASS_HOOKS=1 git commit -m "emergency"

# Allow commit to protected branch
ALLOW_DIRECT_PROTECTED=1 git commit -m "hotfix"

# Disable specific hook
git config core.hooksPath /dev/null    # Temporary disable
git config core.hooksPath .githooks    # Re-enable
```

## 📊 Verification Checklist

After installation, verify:

- [ ] `.gitignore` contains hook patterns
  ```bash
  grep "Git Hooks - Custom Ignores" .gitignore
  ```

- [ ] Hooks path is configured
  ```bash
  git config core.hooksPath  # Should output: .githooks
  ```

- [ ] Branch mappings are set
  ```bash
  git config --list | grep hooks.branchMapping.
  ```

- [ ] Log directories exist
  ```bash
  ls -la .git/hook-logs/
  ls -la .githooks/logs/
  ```

- [ ] No rollback files remain
  ```bash
  ls .githooks/logs/.rollback-*.sh  # Should be empty
  ```

- [ ] Installation log exists
  ```bash
  ls -la .githooks/logs/install-*.log
  ```

- [ ] Hooks are executable
  ```bash
  ls -l .githooks/pre-commit  # Should have 'x' permission
  ```

## 🆘 Troubleshooting

### Issue: Installation fails immediately

**Check:** Are you in a git repository?
```bash
git status
```

**Fix:** Run from repository root
```bash
cd /path/to/repo
bash .githooks/install-hooks.sh
```

---

### Issue: .gitignore creation fails

**Check:** Permissions
```bash
ls -la .gitignore
```

**Fix:** Create manually
```bash
touch .gitignore
chmod 644 .gitignore
bash .githooks/install-hooks.sh
```

---

### Issue: Rollback doesn't complete

**Check:** Rollback log
```bash
cat .githooks/logs/install-*.log | grep ROLLBACK
```

**Fix:** Manual cleanup
```bash
# Remove partial configurations
git config --unset core.hooksPath
git config --remove-section hooks 2>/dev/null || true

# Restore .gitignore
cp .gitignore.backup .gitignore

# Try again
bash .githooks/install-hooks.sh
```

---

### Issue: Hooks not triggering

**Check:** Hooks path
```bash
git config core.hooksPath  # Should be: .githooks
```

**Fix:** Re-run installation
```bash
bash .githooks/install-hooks.sh
```

---

### Issue: Test infrastructure errors

**Check:** Test configuration
```bash
bash .githooks/test/test-config.sh show
```

**Fix:** Re-enable tests
```bash
bash .githooks/test/test-config.sh setup-dev
```

## 📚 Related Documentation

- **Complete Guide**: `.githooks/INSTALLATION_V3_GUIDE.md` (17,000 words)
- **Test Infrastructure**: `.githooks/test/TESTING_GUIDE.md`
- **Hook Documentation**: `.githooks/GITHOOKS_PROMPT.md`
- **Implementation Notes**: `.githooks/IMPLEMENTATION_COMPLETE.md`

## 🔗 Quick Links

```bash
# View installation log
cat .githooks/logs/install-*.log | less

# View hook logs
tail -f .git/hook-logs/complete.log

# Test hooks
bash .githooks/test/run-comprehensive-tests.sh

# Test rollback
bash .githooks/test-rollback.sh

# Uninstall
bash .githooks/uninstall-hooks.sh

# Re-install
bash .githooks/install-hooks.sh
```

## 🎓 Pro Tips

1. **Always review logs after installation**
   ```bash
   cat .githooks/logs/install-*.log | tail -100
   ```

2. **Keep a configuration backup**
   ```bash
   git config --list | grep hooks. > ~/git-hooks-backup.txt
   ```

3. **Test in a branch first**
   ```bash
   git checkout -b test-hooks-install
   bash .githooks/install-hooks.sh
   # Test functionality
   git checkout main
   git branch -D test-hooks-install
   ```

4. **Use dry-run for custom commands**
   ```bash
   # Edit commands.conf, test with:
   bash .githooks/pre-commit --dry-run
   ```

5. **Monitor logs during development**
   ```bash
   tail -f .git/hook-logs/complete.log &
   # Work normally, logs appear in real-time
   ```

---

**Version**: 3.0  
**Status**: Production-Ready ✅  
**Last Updated**: April 11, 2025
