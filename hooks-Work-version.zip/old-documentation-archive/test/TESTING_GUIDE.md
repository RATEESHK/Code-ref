# Git Hooks Testing Guide

## Overview

This guide explains how to run the comprehensive Git hooks test suite with proper state management, logging, and cleanup.

## Table of Contents

1. [Quick Start](#quick-start)
2. [Test Configuration](#test-configuration)
3. [Running Tests](#running-tests)
4. [Test Environment Management](#test-environment-management)
5. [Logging](#logging)
6. [Troubleshooting](#troubleshooting)

---

## Quick Start

### First Time Setup

```bash
# Navigate to test directory
cd .githooks/test

# Enable tests and configure for development
bash test-config.sh setup-dev

# Run comprehensive test suite
bash run-comprehensive-tests.sh
```

### Subsequent Runs

```bash
# Just run the tests (configuration persists)
bash .githooks/test/run-comprehensive-tests.sh
```

---

## Test Configuration

### Configuration Options

The test suite is controlled via `test-config.sh` which provides the following options:

#### 1. Enable/Disable Tests

```bash
# Enable tests
git config hooks.tests.enabled true
# OR
export GITHOOKS_TESTS_ENABLED=true
# OR
bash test-config.sh enable

# Disable tests
bash test-config.sh disable
```

#### 2. Set Test Base Branch

The base branch determines which branch tests will run from:

```bash
# Set base branch to 'develop'
git config hooks.tests.baseBranch develop
# OR
export GITHOOKS_TEST_BASE_BRANCH=develop

# Default: develop
```

#### 3. Configure Logging Verbosity

```bash
# Set log level (quiet, normal, verbose, debug)
git config hooks.tests.logVerbosity verbose
# OR
export GITHOOKS_TEST_LOG_LEVEL=verbose

# Default: normal
```

#### 4. Enable/Disable Auto-Cleanup

```bash
# Enable cleanup (removes test artifacts after tests)
git config hooks.tests.autoCleanup true

# Disable cleanup (keeps test artifacts for inspection)
git config hooks.tests.autoCleanup false

# Default: true
```

#### 5. State Preservation

```bash
# Enable state preservation (saves/restores branch and stash)
git config hooks.tests.preserveState true

# Disable state preservation
git config hooks.tests.preserveState false

# Default: true
```

### Quick Setup Commands

#### Development Testing

```bash
bash test-config.sh setup-dev
```

This configures:
- Tests: enabled
- Base branch: develop
- Log verbosity: verbose
- Auto-cleanup: enabled
- Categories: all

#### CI/CD Testing

```bash
bash test-config.sh setup-ci
```

This configures:
- Tests: enabled
- Base branch: main
- Log verbosity: normal
- Auto-cleanup: enabled
- Categories: all

### View Current Configuration

```bash
bash test-config.sh show
```

Example output:
```
Git Hooks Test Configuration
════════════════════════════════════════

Execution Control:
  Tests Enabled:        YES

Test Environment:
  Base Branch:          develop
  Preserve State:       YES

Logging:
  Verbosity:            verbose
  Log Directory:        .githooks/test/logs

Cleanup:
  Auto-cleanup:         ENABLED

Test Categories:
  Categories:           all
```

---

## Running Tests

### Comprehensive Test Suite

Runs all test categories with full setup/cleanup:

```bash
bash .githooks/test/run-comprehensive-tests.sh
```

This will:
1. Check if tests are enabled
2. Display test configuration
3. Setup test environment (save state, clean artifacts, switch to base branch)
4. Run all test categories
5. Generate comprehensive summary
6. Cleanup test environment (restore state, remove artifacts)

### Individual Test Categories

Run specific test categories:

```bash
# Branch naming tests
bash .githooks/test/test-scenarios/branch-tests.sh

# Commit message tests
bash .githooks/test/test-scenarios/commit-tests.sh

# Security tests
bash .githooks/test/test-scenarios/security-tests.sh

# Hook execution tests
bash .githooks/test/test-scenarios/hook-execution-tests.sh
```

### Custom Test Runs

```bash
# Run with specific categories
export GITHOOKS_TEST_CATEGORIES="branch,commit"
bash run-comprehensive-tests.sh

# Run from specific branch
export GITHOOKS_TEST_BASE_BRANCH="main"
bash run-comprehensive-tests.sh

# Run with debug logging
export GITHOOKS_TEST_LOG_LEVEL="debug"
bash run-comprehensive-tests.sh

# Run without cleanup (for inspection)
export GITHOOKS_TEST_CLEANUP="false"
bash run-comprehensive-tests.sh
```

---

## Test Environment Management

### What Happens During Setup

The `setup-test-environment.sh` script:

1. **Checks Prerequisites**
   - Verifies we're in a git repository
   - Checks if tests are enabled
   - Verifies hooks are installed

2. **Saves Current State**
   - Saves current branch name
   - Stashes uncommitted changes
   - Saves important git configurations

3. **Cleans Test Artifacts**
   - Removes test branches (test-*, *-test patterns)
   - Removes test tags
   - Removes temporary test files

4. **Switches to Base Branch**
   - Checkouts the configured base branch
   - Pulls latest changes if remote-tracking
   - Ensures clean working state

5. **Verifies Hooks**
   - Checks all 8 hooks are installed
   - Reports any missing hooks

6. **Sets Up Logging**
   - Creates log directory structure
   - Generates timestamped log file
   - Archives old logs (keeps last 10)

### What Happens During Cleanup

The `cleanup-test-environment.sh` script:

1. **Loads Saved State**
   - Reads state file from setup

2. **Cleans Test Artifacts**
   - Removes test branches created during tests
   - Removes test tags
   - Removes temporary files

3. **Restores Original Branch**
   - Switches back to original branch

4. **Restores Stashed Changes**
   - Pops stashed changes if any were stashed

5. **Restores Configurations**
   - Restores modified git configurations

6. **Finalizes Logs**
   - Writes log footer with summary
   - Archives log file

### Manual Environment Management

If you need to manually manage the environment:

```bash
# Setup only (without running tests)
bash .githooks/test/setup-test-environment.sh

# Your manual testing here...

# Cleanup only
bash .githooks/test/cleanup-test-environment.sh
```

---

## Logging

### Log Files

All test runs generate detailed log files:

```
.githooks/test/logs/
├── test-run-20241104_143022.log
├── test-run-20241104_150145.log
└── test-run-20241104_152301.log
```

### Log File Format

Each log file contains:

```
================================================================================
Git Hooks Test Execution Log
Started: 2024-11-04 14:30:22
================================================================================

Configuration:
  Base Branch:       develop
  Log Verbosity:     verbose
  Auto Cleanup:      enabled
  Test Categories:   all
  Preserve State:    enabled

Repository State:
  Current Branch:    hotfix-CRIT-222-should-pass-from-main
  Latest Commit:     abc1234 Fix critical bug
  Hooks Path:        .githooks

================================================================================

[2024-11-04 14:30:23] [INFO] Checking prerequisites...
[2024-11-04 14:30:23] [SUCCESS] Prerequisites check passed
[2024-11-04 14:30:24] [INFO] Saving current repository state...
...
```

### Log Verbosity Levels

#### Quiet (0)
- Only errors displayed
- Minimal output

#### Normal (1) - Default
- Errors and important status messages
- Test results summary

#### Verbose (2)
- All normal output
- Progress information
- Warnings

#### Debug (3)
- All verbose output
- Debug information
- Detailed execution traces

### Viewing Logs

```bash
# View latest log
tail -f .githooks/test/logs/test-run-*.log | tail -n 100

# View specific log
cat .githooks/test/logs/test-run-20241104_143022.log

# Search logs for failures
grep -r "FAILED" .githooks/test/logs/

# Count test runs
ls -1 .githooks/test/logs/*.log | wc -l
```

### Log Retention

- Logs are automatically archived
- Last 10 test runs are kept
- Older logs are automatically deleted
- Logs are gitignored (not committed)

---

## Troubleshooting

### Tests Won't Run

**Problem:** "Tests are not enabled"

**Solution:**
```bash
bash .githooks/test/test-config.sh enable
# OR
bash .githooks/test/test-config.sh setup-dev
```

---

### Repository State Issues

**Problem:** Tests fail due to dirty working directory

**Solution:**
```bash
# Enable state preservation (default)
git config hooks.tests.preserveState true

# Or manually clean before tests
git stash push -u
bash run-comprehensive-tests.sh
git stash pop
```

---

### Base Branch Not Found

**Problem:** "Base branch 'develop' does not exist"

**Solution:**
```bash
# Set base branch to one that exists
git config hooks.tests.baseBranch main

# Or create the develop branch
git checkout -b develop
git push -u origin develop
```

---

### Tests Leave Artifacts

**Problem:** Test branches remain after test completion

**Solution:**
```bash
# Ensure cleanup is enabled
git config hooks.tests.autoCleanup true

# Or manually run cleanup
bash .githooks/test/cleanup-test-environment.sh

# Or manually delete test branches
git branch -D $(git branch | grep 'test-')
```

---

### Can't Restore Original Branch

**Problem:** After tests, still on test base branch

**Solution:**
```bash
# Run cleanup manually
bash .githooks/test/cleanup-test-environment.sh

# Or manually checkout original branch
git checkout <your-branch>
```

---

### Logs Not Being Created

**Problem:** No log files in `.githooks/test/logs/`

**Solution:**
```bash
# Check log verbosity
git config hooks.tests.logVerbosity
# Should not be "quiet"

# Set to normal or verbose
git config hooks.tests.logVerbosity verbose

# Ensure log directory exists
mkdir -p .githooks/test/logs
```

---

### Permission Issues

**Problem:** "Permission denied" when running scripts

**Solution:**
```bash
# Make scripts executable
chmod +x .githooks/test/*.sh
chmod +x .githooks/test/test-scenarios/*.sh
```

---

## Test Categories

The comprehensive test suite includes:

1. **Branch Naming & Validation**
   - Branch name format validation
   - Jira ticket format checking
   - Protected branch detection

2. **Commit Message Validation**
   - Conventional commit format
   - Message length limits
   - Required patterns

3. **Security & Secrets Detection**
   - Credential scanning
   - API key detection
   - Private key detection

4. **Protected Branch Enforcement**
   - Direct push prevention
   - Force push blocking
   - Deletion prevention

5. **Hook Command Integration**
   - Commit --amend with Jira
   - Push with commit count
   - Rebase with warnings

6. **Logging & Audit Trail**
   - Hook execution logging
   - Violation tracking
   - Audit history

7. **Base Branch Validation**
   - Branch creation validation
   - Base branch enforcement
   - Hotfix special handling

8. **Hook Bypass & Override**
   - Emergency bypass mechanism
   - Hook disablement
   - Override controls

9. **Direct Hook Execution**
   - Pre-commit execution
   - Pre-push validation
   - Post-rewrite handling
   - All hook lifecycle tests

---

## Best Practices

### Before Making Changes

```bash
# Enable tests
bash .githooks/test/test-config.sh setup-dev

# Run full suite to establish baseline
bash .githooks/test/run-comprehensive-tests.sh
```

### After Making Changes

```bash
# Run relevant test category
bash .githooks/test/test-scenarios/<category>-tests.sh

# If all pass, run full suite
bash .githooks/test/run-comprehensive-tests.sh
```

### For CI/CD

```bash
# Configure for CI
bash .githooks/test/test-config.sh setup-ci

# Run comprehensive tests
bash .githooks/test/run-comprehensive-tests.sh

# Check exit code
echo $?  # 0 = success, non-zero = failure
```

### Debugging Failing Tests

```bash
# Enable debug logging
export GITHOOKS_TEST_LOG_LEVEL=debug

# Disable cleanup to inspect artifacts
export GITHOOKS_TEST_CLEANUP=false

# Run tests
bash .githooks/test/run-comprehensive-tests.sh

# Inspect test branches
git branch | grep test-

# Inspect logs
cat .githooks/test/logs/test-run-*.log | tail -n 100
```

---

## Summary

The Git hooks testing infrastructure provides:

✅ **State Management** - Saves and restores repository state  
✅ **Branch Independence** - Tests run from configured base branch  
✅ **Test Enablement** - Explicit opt-in via configuration  
✅ **Comprehensive Logging** - Detailed execution logs with timestamps  
✅ **Auto Cleanup** - Removes test artifacts automatically  
✅ **Configurable** - Flexible configuration via git config or env vars  
✅ **Reliable** - Consistent test environment across runs

For more information, see:
- `test-config.sh` - Configuration management
- `setup-test-environment.sh` - Environment setup
- `cleanup-test-environment.sh` - Environment cleanup
- `run-comprehensive-tests.sh` - Main test runner
