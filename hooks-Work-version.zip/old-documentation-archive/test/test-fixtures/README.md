# Test Fixtures

This directory contains test data and mock files used by the test suite.

## Available Fixtures

### 1. Sample Secret Patterns
Test files containing various secret patterns for security testing.

### 2. Sample Branch Names
Valid and invalid branch names for testing branch validation.

### 3. Sample Commit Messages
Various commit message formats for testing validation.

### 4. Mock Git Repositories
Pre-configured Git repositories for complex test scenarios.

## Usage

Test fixtures are automatically loaded by the test suite when needed.
