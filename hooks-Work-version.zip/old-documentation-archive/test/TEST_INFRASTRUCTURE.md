# Git Hooks Test Infrastructure

## Overview

The Git hooks test infrastructure provides a robust, reliable, and comprehensive testing framework with:

- **State Management** - Automatic save/restore of repository state
- **Branch Independence** - Tests run from a configured base branch regardless of your current branch
- **Test Enablement** - Explicit opt-in mechanism via configuration flags
- **Comprehensive Logging** - Detailed execution logs with timestamps and categorization
- **Auto Cleanup** - Automatic removal of test artifacts after execution
- **Configurable** - Flexible configuration via git config or environment variables

## Architecture

### Core Components

```
.githooks/test/
├── test-config.sh                    # Configuration management
├── setup-test-environment.sh         # Pre-test setup
├── cleanup-test-environment.sh       # Post-test cleanup
├── run-comprehensive-tests.sh        # Main test runner
├── test-suite.sh                     # Legacy test suite
├── TESTING_GUIDE.md                  # Complete documentation
├── QUICK_REFERENCE.md                # Quick command reference
├── logs/                             # Test execution logs
│   ├── .gitignore
│   └── test-run-*.log               # Timestamped log files
└── test-scenarios/                   # Individual test files
    ├── branch-tests.sh
    ├── commit-tests.sh
    ├── security-tests.sh
    ├── protected-tests.sh
    ├── command-tests.sh
    ├── logging-tests.sh
    ├── base-branch-tests.sh
    ├── bypass-tests.sh
    └── hook-execution-tests.sh
```

### Test Execution Flow

```
┌─────────────────────────────────────────────────────────────┐
│ 1. Configuration Check                                      │
│    - Verify tests are enabled                              │
│    - Load configuration settings                           │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. Environment Setup                                        │
│    - Save current state (branch, stash, configs)           │
│    - Clean previous test artifacts                         │
│    - Switch to test base branch                            │
│    - Verify hooks installation                             │
│    - Create log infrastructure                             │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. Test Execution                                           │
│    - Run all test categories sequentially                  │
│    - Log results and timings                               │
│    - Track pass/fail/skip status                           │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 4. Summary Generation                                       │
│    - Calculate statistics                                  │
│    - Generate detailed report                              │
│    - Identify failures                                     │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 5. Environment Cleanup                                      │
│    - Remove test branches/artifacts                        │
│    - Restore original branch                               │
│    - Restore stashed changes                               │
│    - Restore git configurations                            │
│    - Finalize logs                                         │
└─────────────────────────────────────────────────────────────┘
```

## Configuration System

### Configuration Priority

1. **Environment Variables** (highest priority)
2. **Git Config** (repository-specific)
3. **Defaults** (lowest priority)

### Configuration Options

| Option | Git Config Key | Environment Variable | Default | Description |
|--------|---------------|---------------------|---------|-------------|
| Tests Enabled | `hooks.tests.enabled` | `GITHOOKS_TESTS_ENABLED` | `false` | Enable/disable tests |
| Base Branch | `hooks.tests.baseBranch` | `GITHOOKS_TEST_BASE_BRANCH` | `develop` | Branch to run tests from |
| Log Verbosity | `hooks.tests.logVerbosity` | `GITHOOKS_TEST_LOG_LEVEL` | `normal` | Log detail level |
| Auto Cleanup | `hooks.tests.autoCleanup` | `GITHOOKS_TEST_CLEANUP` | `true` | Remove test artifacts |
| Test Categories | `hooks.tests.categories` | `GITHOOKS_TEST_CATEGORIES` | `all` | Which tests to run |
| Preserve State | `hooks.tests.preserveState` | `GITHOOKS_TEST_PRESERVE_STATE` | `true` | Save/restore state |

### Configuration Commands

```bash
# View current configuration
bash test-config.sh show

# Enable tests
bash test-config.sh enable

# Disable tests
bash test-config.sh disable

# Quick setup for development
bash test-config.sh setup-dev

# Quick setup for CI/CD
bash test-config.sh setup-ci

# Reset to defaults
bash test-config.sh reset
```

## State Management

### State File (`.test-state`)

During test execution, the system creates a state file that tracks:

```bash
CURRENT_BRANCH=hotfix-CRIT-222          # Original branch
STASH_CREATED=true                       # Whether changes were stashed
CONFIG_MAX_COMMITS=10                    # Saved git configs
CONFIG_AUTO_ADD=true
CONFIG_PARALLEL=false
LOG_FILE=/path/to/log-file.log          # Current log file
```

### State Preservation Process

1. **Save State** (setup-test-environment.sh)
   - Captures current branch name
   - Stashes uncommitted changes
   - Saves important git configurations

2. **Restore State** (cleanup-test-environment.sh)
   - Switches back to original branch
   - Pops stashed changes
   - Restores git configurations

### Cleanup Process

1. **Test Artifacts Removed**
   - Test branches matching patterns: `test-*`, `*-test`, `temp-test-*`
   - Test tags matching pattern: `test-*`
   - Temporary test files

2. **Repository State Restored**
   - Original branch checked out
   - Stashed changes applied
   - Git configurations restored

## Logging System

### Log File Format

```
================================================================================
Git Hooks Test Execution Log
Started: 2024-11-04 14:30:22
================================================================================

Configuration:
  Base Branch:       develop
  Log Verbosity:     verbose
  Auto Cleanup:      enabled
  Test Categories:   all
  Preserve State:    enabled

Repository State:
  Current Branch:    hotfix-CRIT-222-should-pass-from-main
  Latest Commit:     abc1234 Fix critical bug
  Hooks Path:        .githooks

================================================================================

[2024-11-04 14:30:23] [INFO] Checking prerequisites...
[2024-11-04 14:30:23] [SUCCESS] Prerequisites check passed
[2024-11-04 14:30:24] [INFO] Saving current repository state...
[2024-11-04 14:30:24] [DEBUG] Current branch: hotfix-CRIT-222-should-pass-from-main
[2024-11-04 14:30:25] [SUCCESS] State saved
...

================================================================================
Test Execution Completed
Finished: 2024-11-04 14:45:30
================================================================================
```

### Log Verbosity Levels

- **quiet** - Errors only, minimal output
- **normal** - Errors + important status + test results (default)
- **verbose** - Normal + progress + warnings
- **debug** - All output + debug traces

### Log Retention

- Automatically archives old logs
- Keeps last 10 test runs
- Older logs are automatically deleted
- All logs are gitignored

## Test Categories

### 1. Branch Naming & Validation
**File:** `branch-tests.sh`
**Tests:** Branch name format, Jira ticket validation, protected branch detection

### 2. Commit Message Validation
**File:** `commit-tests.sh`
**Tests:** Conventional commit format, message length, required patterns

### 3. Security & Secrets Detection
**File:** `security-tests.sh`
**Tests:** Credential scanning, API key detection, private key detection

### 4. Protected Branch Enforcement
**File:** `protected-tests.sh`
**Tests:** Direct push prevention, force push blocking, deletion prevention

### 5. Hook Command Integration
**File:** `command-tests.sh`
**Tests:** Commit --amend, push with count, rebase warnings

### 6. Logging & Audit Trail
**File:** `logging-tests.sh`
**Tests:** Hook execution logging, violation tracking, audit history

### 7. Base Branch Validation
**File:** `base-branch-tests.sh`
**Tests:** Branch creation validation, base branch enforcement, hotfix handling

### 8. Hook Bypass & Override
**File:** `bypass-tests.sh`
**Tests:** Emergency bypass, hook disablement, override controls

### 9. Direct Hook Execution
**File:** `hook-execution-tests.sh`
**Tests:** All 8 hooks (pre-commit, commit-msg, prepare-commit-msg, post-checkout, pre-push, post-rewrite, pre-rebase, applypatch-msg)

## Usage Scenarios

### Development Workflow

```bash
# First time setup
cd .githooks/test
bash test-config.sh setup-dev

# Before making changes
bash run-comprehensive-tests.sh  # Establish baseline

# After making changes
bash test-scenarios/relevant-tests.sh  # Quick verification

# Before committing
bash run-comprehensive-tests.sh  # Full verification
```

### CI/CD Pipeline

```bash
# Setup
bash .githooks/test/test-config.sh setup-ci

# Run tests
bash .githooks/test/run-comprehensive-tests.sh

# Check result
if [ $? -eq 0 ]; then
    echo "Tests passed"
else
    echo "Tests failed"
    exit 1
fi
```

### Debugging Failed Tests

```bash
# Enable debug logging and disable cleanup
export GITHOOKS_TEST_LOG_LEVEL=debug
export GITHOOKS_TEST_CLEANUP=false

# Run tests
bash run-comprehensive-tests.sh

# Inspect artifacts
git branch | grep test-
ls -la .githooks/test/logs/

# View detailed log
cat .githooks/test/logs/test-run-*.log | less
```

## Integration with Existing Hooks

The test infrastructure is designed to work seamlessly with the existing Git hooks:

1. **Non-Intrusive** - Tests don't interfere with normal Git operations
2. **Opt-In** - Must be explicitly enabled
3. **Isolated** - Tests run in isolated environment
4. **Comprehensive** - Tests all hook functionality

## Best Practices

### For Developers

1. ✅ Enable tests before making hook changes
2. ✅ Run tests after each significant change
3. ✅ Review test logs when tests fail
4. ✅ Use debug mode for troubleshooting
5. ✅ Keep test artifacts when debugging (disable cleanup)

### For CI/CD

1. ✅ Use `setup-ci` configuration
2. ✅ Run comprehensive test suite
3. ✅ Archive test logs as artifacts
4. ✅ Fail build on test failures
5. ✅ Enable cleanup to avoid state pollution

### For Troubleshooting

1. ✅ Use debug log verbosity
2. ✅ Disable cleanup to inspect artifacts
3. ✅ Check state file for saved state
4. ✅ Review detailed log files
5. ✅ Run individual test categories

## Performance Considerations

- **Setup Time**: ~2-5 seconds
- **Cleanup Time**: ~2-5 seconds
- **Test Execution**: Varies by category (5-30 seconds per category)
- **Total Time**: ~2-5 minutes for full suite

### Optimization Tips

1. Run specific test categories instead of full suite
2. Use normal verbosity instead of debug for faster execution
3. Disable state preservation if not needed
4. Run tests in parallel (future enhancement)

## Extensibility

### Adding New Test Categories

1. Create new test file in `test-scenarios/`
2. Follow existing test file structure
3. Add category to `run-comprehensive-tests.sh`
4. Update documentation

### Adding New Configuration Options

1. Add option to `test-config.sh`
2. Add getter/setter functions
3. Update `show_config` function
4. Document in `TESTING_GUIDE.md`

## Security Considerations

- Test logs may contain sensitive information
- Logs are gitignored by default
- State file is temporary and gitignored
- Test artifacts are cleaned automatically
- No credentials are stored in configuration

## Troubleshooting

### Common Issues

1. **Tests not running** - Check if tests are enabled
2. **State not restored** - Check if state preservation is enabled
3. **Logs not created** - Check log verbosity setting
4. **Artifacts remain** - Check if cleanup is enabled
5. **Base branch error** - Verify base branch exists

### Debug Commands

```bash
# Check configuration
bash test-config.sh show

# Verify tests are enabled
git config hooks.tests.enabled

# Check log directory
ls -la .githooks/test/logs/

# View state file
cat .githooks/test/.test-state

# Manual cleanup
bash cleanup-test-environment.sh
```

## Summary

The Git hooks test infrastructure provides:

✅ **Reliability** - Consistent test environment across runs  
✅ **Flexibility** - Configurable via multiple methods  
✅ **Transparency** - Detailed logging of all operations  
✅ **Safety** - State preservation and restoration  
✅ **Completeness** - All hooks and scenarios covered  
✅ **Maintainability** - Clear structure and documentation  

For detailed usage instructions, see `TESTING_GUIDE.md`.  
For quick command reference, see `QUICK_REFERENCE.md`.
