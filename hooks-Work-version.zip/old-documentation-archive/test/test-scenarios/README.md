# Test Scenarios

Individual test case implementations for specific hook functionality.

## Test Categories

### Branch Naming Tests
- `test_branch_invalid()` - Invalid branch name rejection
- `test_branch_valid()` - Valid branch name acceptance
- `test_branch_protected()` - Protected branch handling

### Commit Message Tests
- `test_commit_invalid()` - Invalid message rejection
- `test_commit_valid()` - Valid message acceptance
- `test_commit_autofill()` - JIRA ID auto-fill
- `test_commit_merge()` - Merge commit handling
- `test_commit_revert()` - Revert commit handling

### Security Tests
- `test_aws_key_detection()` - AWS key pattern detection
- `test_env_file_block()` - Environment file blocking
- `test_private_key_block()` - Private key file blocking
- `test_password_detection()` - Password pattern detection

### Protected Branch Tests
- `test_direct_commit_block()` - Direct commit blocking
- `test_direct_commit_bypass()` - Bypass mechanism

### Custom Command Tests
- `test_command_priority()` - Priority ordering
- `test_command_mandatory()` - Mandatory command handling
- `test_command_optional()` - Optional command handling

### Logging Tests
- `test_complete_log()` - Complete log verification
- `test_individual_logs()` - Per-hook log verification
- `test_log_rotation()` - Log rotation mechanism

### Bypass Tests
- `test_bypass_all()` - Global bypass mechanism
- `test_bypass_logging()` - Bypass action logging

## Running Individual Scenarios

```bash
# Run specific category
bash test-suite.sh --category branch
bash test-suite.sh --category security
bash test-suite.sh --category logging

# Run with verbose output
bash test-suite.sh --verbose

# Run in strict mode (fail on first error)
bash test-suite.sh --strict
```
