# Comprehensive Git Hooks Implementation Prompt - Version 2.0

## OBJECTIVE
Create a **production-ready, cross-platform Git hooks suite** with **complete implementation, testing framework, and verification tools**. This system must enforce branching policies, commit standards, and maintain curated history while providing exceptional developer experience with detailed logging and troubleshooting capabilities.

## CRITICAL REQUIREMENTS - IMPLEMENTATION CHECKLIST

### 1. BRANCH NAMING POLICY (MANDATORY)
**Implementation Requirements:**
- [ ] **Enforcement Point**: Pre-push hook must validate ALL branch names
- [ ] **Allowed Patterns**:
  - Long-lived: `^(main|develop|release($|/.*))$`
  - Short-lived: `^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$`
- [ ] **Error Handling**: Show exact regex pattern, current branch name, and 3 valid examples
- [ ] **Remote Branch Handling**: 
  - Allow checkout of non-compliant remote branches
  - Block commits to non-compliant branches with clear explanation
  - Provide migration path for legacy branches

### 2. BASE BRANCH ENFORCEMENT (MANDATORY)
**Implementation Requirements:**
- [ ] **Mapping Rules** (must be configurable via git config):
  ```
  feature|bugfix|techdebt|feat|fix → origin/develop
  hotfix → origin/main
  ```
- [ ] **Validation**: Pre-push must verify:
  - Branch is rebased on correct base: `git merge-base --is-ancestor "$base" HEAD`
  - No merge commits in branch history
  - Fetch base branch if not present locally
- [ ] **Error Recovery**: Provide exact commands to fix base issues

### 3. CURATED HISTORY ENFORCEMENT (MANDATORY)
**Implementation Requirements:**
- [ ] **Commit Limit**: 
  - Default: 5 commits (configurable via `git config hooks.maxCommits`)
  - Count only commits unique to branch vs base
  - Formula: `git rev-list --count "$base..HEAD"`
- [ ] **Linear History**:
  - Block merge commits to protected branches
  - Enforce rebase workflow
  - Detect and prevent "foxtrot merges"
- [ ] **Squash Enforcement**: Pre-push must verify commits are squashed
- [ ] **Error Messages**: Show current count, limit, and squash instructions

### 4. COMMIT MESSAGE POLICY (MANDATORY)
**Implementation Requirements:**
- [ ] **Format Regex**: `^(feat|fix|chore|break|tests): [A-Z]{2,10}-[0-9]+ .+`
- [ ] **Auto-Population**:
  - Extract JIRA ID from branch name
  - Pre-fill in prepare-commit-msg hook
  - Skip if already compliant or merge/revert
- [ ] **Validation Points**:
  - commit-msg hook
  - applypatch-msg hook (for git am)
- [ ] **Special Cases**: Allow "Merge" and "Revert" prefixes

### 5. DEVELOPER QUALITY OF LIFE (MANDATORY)
**Implementation Requirements:**
- [ ] **Protected Branch Features**:
  - Block direct commits (unless `ALLOW_DIRECT_PROTECTED=1`)
  - Show friendly warning when checking out
  - Reminder about protection on each action
- [ ] **Smart Hints**:
  - Detect lockfile changes (ALL package managers)
  - Detect Terraform/IaC changes
  - Detect CI/CD configuration changes
  - Post-rebase reminder for `--force-with-lease`
- [ ] **Extension Framework**:
  - Configurable pre/post command execution
  - Support for linting, prettier, type-checking, build verification
  - Timeout configuration per command
  - Sequential/parallel execution options

### 6. SECURITY SCANNING (MANDATORY)
**Implementation Requirements:**
- [ ] **Secret Patterns** (minimum set):
  ```
  AWS Keys: AKIA[0-9A-Z]{16}
  GitHub PAT: gh[ps]_[a-zA-Z0-9]{36}
  Slack: xox[baprs]-[0-9]{10,12}-[a-zA-Z0-9]{24}
  Google API: AIza[0-9A-Za-z_-]{35}
  Stripe: sk_(test_|live_)[0-9a-zA-Z]{24}
  Private Keys: -----BEGIN .* PRIVATE KEY
  Passwords: password\s*=\s*["'][^"']+
  API Keys: api[_-]?key\s*[:=]\s*["']?[a-zA-Z0-9_-]{20,}
  ```
- [ ] **Sensitive Files**:
  ```
  .env, .env.*, *.pem, *.p12, *.pfx, *_rsa, *_dsa, *_ecdsa, *_ed25519,
  *.key, *.cert, *.crt, credentials, secrets.json, secrets.yml, secrets.yaml
  ```
- [ ] **Performance**: Scan only staged content, only added lines

### 7. COMPREHENSIVE LOGGING SYSTEM (MANDATORY)
**Implementation Requirements:**
- [ ] **Log Levels** (all must be implemented):
  ```
  EMERGENCY(0), FATAL(1), CRITICAL(2), ERROR(3), 
  WARNING(4), NOTICE(5), INFO(6), DEBUG(7), TRACE(8)
  ```
- [ ] **Log Structure** (every entry must contain):
  ```
  [timestamp] [level] [hook] [PID] [user] [email] [branch] [commit] [stack_trace] message
  ```
- [ ] **Log Files**:
  - Complete log: `.git/hook-logs/complete.log` (ALL events)
  - Per-hook logs: `.git/hook-logs/<hook-name>.log`
  - Both must be written for every event
- [ ] **Log Rotation**:
  - Rotate at 256KB
  - Keep 2 archives
  - Delete logs older than 21 days
- [ ] **No Silent Failures**: Every exit must log reason
- [ ] **Progress Indicators**: Show [current/total] for multi-step operations
- [ ] **Stack Traces**: Include for all ERROR level and above

### 8. CROSS-PLATFORM COMPATIBILITY (MANDATORY)
**Implementation Requirements:**
- [ ] **Shell**: Pure Bash (`#!/usr/bin/env bash`)
- [ ] **Platform Detection**: Handle differences between:
  - Linux (GNU coreutils)
  - macOS (BSD utils)
  - Windows (Git Bash/MSYS2)
- [ ] **File Paths**: Handle spaces and special characters
- [ ] **Line Endings**: Work with both LF and CRLF
- [ ] **Command Availability**: Check before using non-POSIX commands

### 9. INSTALLATION & CONFIGURATION (MANDATORY)
**Implementation Requirements:**
- [ ] **Installer Script** (`install-hooks.sh`):
  - Set `core.hooksPath=.githooks`
  - Set `rebase.autosquash=true`
  - Set `fetch.prune=true`
  - Initialize `hooks.maxCommits=5` if unset
  - Make all hooks executable
  - Create log directory with proper permissions
  - Add logs to `.git/info/exclude`
  - Display complete configuration summary
  - Show ALL test commands
- [ ] **Uninstaller Script** (`uninstall-hooks.sh`):
  - Restore original hooks path
  - Archive logs before removal
  - Remove configurations
  - Confirmation prompt

### 10. BYPASS MECHANISMS (MANDATORY)
**Implementation Requirements:**
- [ ] **Global Bypass**: `BYPASS_HOOKS=1` - skip all hooks
- [ ] **Protected Bypass**: `ALLOW_DIRECT_PROTECTED=1` - allow protected branch commits
- [ ] **Logging**: All bypasses must be logged with reason and user

### 11. CUSTOM COMMAND EXTENSION FRAMEWORK (MANDATORY)
**Implementation Requirements:**
- [ ] **Command Configuration File** (`.githooks/commands.conf`):
  ```bash
  # Format: HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
  pre-commit:1:true:30:node scripts/check-casing.js:Check casing
  pre-commit:2:true:60:npx lint-staged:Lint-Staged
  pre-commit:3:false:120:npx tsc --noEmit --skipLibCheck:TypeScript Check
  pre-commit:4:true:30:npm run lint:fix:Auto-fix linting
  pre-push:1:true:300:npm test:Run test suite
  pre-push:2:false:600:npm run build:Build project
  commit-msg:1:false:10:node scripts/validate-message.js:Custom message validation
  ```
- [ ] **Command Runner Implementation**:
  ```bash
  # Required functionality:
  - Parse commands.conf file
  - Execute commands in priority order
  - Track individual command status
  - Aggregate all failures
  - Show real-time progress
  - Handle timeouts gracefully
  - Support both mandatory and optional commands
  - Capture and log command output
  ```
- [ ] **Auto-fix and Re-staging Support**:
  - After successful lint/prettier fixes, auto-stage modified files
  - Configurable via `git config hooks.autoAddAfterFix true`
  - Show which files were re-staged
- [ ] **Lint-staged Integration**:
  - Read `.lintstagedrc.json` or `package.json` lint-staged config
  - Pass staged files to commands with `{staged}` placeholder
  - Support glob patterns for file filtering
- [ ] **Error Reporting Format**:
  ```
  ========================================
  Hook: pre-commit FAILED
  
  Failed Checks:
  ✗ Check casing (exit code: 1)
  ✗ TypeScript Check (exit code: 2)
  
  Passed Checks:
  ✓ Lint-Staged
  
  To bypass (emergency only): BYPASS_HOOKS=1 git commit
  ========================================
  ```
- [ ] **Parallel Execution Support**:
  - Commands with same priority run in parallel
  - Configurable via `git config hooks.parallelExecution true`
  - Proper output buffering for parallel commands
- [ ] **Custom Environment Variables**:
  - Pass staged files as `STAGED_FILES` env variable
  - Pass hook name as `GIT_HOOK_NAME`
  - Pass git user info as `GIT_USER_NAME` and `GIT_USER_EMAIL`

## TESTING REQUIREMENTS - VERIFICATION CHECKLIST

### Test Scenarios (ALL MUST PASS)
```bash
# 1. Branch Naming Tests
test_branch_invalid()    # Should fail with clear error
test_branch_valid()       # Should succeed
test_branch_protected()   # Should allow creation
test_remote_noncompliant() # Should allow checkout, block commit

# 2. Commit Message Tests
test_commit_invalid()     # Should fail with format guide
test_commit_valid()       # Should succeed
test_commit_autofill()    # Should prefill JIRA ID
test_commit_merge()       # Should allow "Merge" prefix
test_commit_revert()      # Should allow "Revert" prefix

# 3. Base Branch Tests
test_base_not_ancestor()  # Should fail with rebase command
test_base_correct()       # Should succeed
test_base_fetch()         # Should auto-fetch if needed

# 4. History Curation Tests
test_too_many_commits()   # Should fail at configured limit
test_squashed_commits()   # Should succeed
test_merge_commit_block() # Should block to protected
test_linear_history()     # Should enforce rebase

# 5. Security Tests
test_aws_key_detection()  # Should block
test_env_file_block()     # Should block
test_private_key_block()  # Should block
test_password_detection() # Should block

# 6. Protected Branch Tests
test_direct_commit_block()   # Should fail
test_direct_commit_bypass()  # Should succeed with flag
test_protected_warning()     # Should show on checkout

# 7. Extension Tests
test_precommit_extra()    # Should run custom commands
test_commitmsg_extra()    # Should run validations
test_prepush_extra()      # Should run builds/tests
test_command_timeout()    # Should handle timeouts
test_parallel_execution() # Should run in parallel
test_auto_restage()      # Should re-add fixed files

# 8. Logging Tests
test_complete_log()       # Should contain all events
test_individual_logs()    # Should have per-hook logs
test_log_rotation()       # Should rotate at 256KB
test_log_cleanup()        # Should delete old logs
test_stack_traces()       # Should include on errors

# 9. Cross-Platform Tests
test_windows_gitbash()    # Should work in Git Bash
test_macos_terminal()     # Should work in Terminal
test_linux_shell()        # Should work in bash/zsh
test_special_characters() # Should handle spaces in paths

# 10. Bypass Tests
test_bypass_all()         # BYPASS_HOOKS=1 should work
test_bypass_protected()   # ALLOW_DIRECT_PROTECTED=1 should work
test_bypass_logging()     # Should log all bypasses

# 11. Custom Command Tests
test_command_priority()   # Should execute in order
test_command_mandatory()  # Should fail on mandatory failure
test_command_optional()   # Should continue on optional failure
test_command_output()     # Should capture and log output
test_lint_staged()        # Should integrate with lint-staged
```

### Test Verification Commands
```bash
# Run all tests
./githooks-test.sh --all --verbose

# Run specific category
./githooks-test.sh --category security

# Verify logs
./githooks-test.sh --verify-logs

# Stress test (performance)
./githooks-test.sh --stress --files 1000

# Coverage report
./githooks-test.sh --coverage

# Test custom commands
./githooks-test.sh --test-commands
```

## DELIVERABLE STRUCTURE

### Required Files (exact names)
```
.githooks/
├── install-hooks.sh      # Installer with full configuration
├── uninstall-hooks.sh    # Clean uninstaller
├── clean.sh              # Log rotation and cleanup
├── commands.conf         # User-defined custom commands
├── lib/
│   ├── common.sh         # Shared functions and constants
│   └── runner.sh         # Command runner framework
├── pre-commit            # Sensitive files, secrets, protected branches
├── commit-msg            # Message format validation
├── applypatch-msg        # git am validation
├── prepare-commit-msg    # Auto-fill JIRA ID
├── pre-push              # Branch name, base, history, squash
├── pre-rebase            # Protected branch warning
├── post-rewrite          # Push reminder after rebase
├── post-checkout         # Lockfile/terraform hints, warnings
├── run-commands.sh       # Extension framework (deprecated, for backward compatibility)
└── test/
    ├── test-suite.sh     # Complete test framework
    ├── test-scenarios/   # Individual test cases
    └── test-fixtures/    # Test data and mocks
```

### Configuration Files (project root)
```
.lintstagedrc.json        # Lint-staged configuration (optional)
.githooks.json            # Hook configuration overrides (optional)
```

## VALIDATION CRITERIA

### Performance Requirements
- [ ] Pre-commit: < 500ms for 100 staged files (excluding custom commands)
- [ ] Pre-push: < 2s including base fetch
- [ ] Secret scanning: < 1s for 1000 lines
- [ ] Log write: < 10ms per entry
- [ ] Custom command overhead: < 50ms per command

### Error Message Requirements
- [ ] Include: Current state, expected state, exact fix command
- [ ] Format: Colored output with emoji indicators
- [ ] Language: Clear, actionable, no technical jargon
- [ ] Examples: Always provide at least one valid example

### Documentation Requirements
- [ ] README.md with architecture diagram
- [ ] CONTRIBUTING.md with hook development guide
- [ ] TROUBLESHOOTING.md with common issues
- [ ] COMMANDS.md with custom command examples
- [ ] Each hook must have header comment with purpose

## IMPLEMENTATION NOTES

1. **Start with lib/common.sh** - This is the foundation
2. **Build command runner next** - Critical for extensibility
3. **Test incrementally** - Add tests for each feature as you build
4. **Log everything** - Better too much than too little
5. **Fail fast and loud** - Clear errors save debugging time
6. **Performance matters** - Developers will disable slow hooks
7. **Cross-platform from start** - Testing later is harder
8. **Make it configurable** - Different projects have different needs

## SUCCESS CRITERIA

The implementation is complete when:
1. ✅ All 11 requirement sections are fully implemented
2. ✅ All test scenarios pass on Linux, macOS, and Windows
3. ✅ Performance benchmarks are met
4. ✅ Zero silent failures (all exits logged)
5. ✅ Developer can understand any error in < 5 seconds
6. ✅ Installation takes < 30 seconds
7. ✅ Logs provide complete audit trail
8. ✅ Extensions can be added without modifying core hooks
9. ✅ Custom commands work without any manual setup
10. ✅ Lint-staged integration works out of the box

## FINAL VERIFICATION

Run this checklist after implementation:
```bash
# 1. Fresh installation test
git clone <repo> test-repo
cd test-repo
./.githooks/install-hooks.sh
[ $? -eq 0 ] && echo "✅ Installation successful"

# 2. Configure custom commands
cat > .githooks/commands.conf << 'EOF'
pre-commit:1:true:30:npx lint-staged:Lint and Format
pre-commit:2:false:60:npx tsc --noEmit:TypeScript Check
pre-push:1:true:300:npm test:Test Suite
EOF
[ $? -eq 0 ] && echo "✅ Commands configured"

# 3. Run complete test suite
./githooks/test/test-suite.sh --all --strict
[ $? -eq 0 ] && echo "✅ All tests passed"

# 4. Verify logging
tail -n 100 .git/hook-logs/complete.log | grep -E "ERROR|WARNING|FATAL"
[ $? -ne 0 ] && echo "✅ No unexpected errors"

# 5. Performance benchmark
time ./githooks/test/test-suite.sh --performance
echo "✅ Check times are within limits"

# 6. Cross-platform verification
for platform in linux macos windows; do
    docker run --rm -v $(pwd):/repo hooks-test:$platform
done

# 7. Test custom command execution
echo "test" > test.txt
git add test.txt
git commit -m "feat: TEST-123 Test custom commands"
[ $? -eq 0 ] && echo "✅ Custom commands executed"

# 8. Verify auto-restaging
echo "const  x=1" > test.js
git add test.js
git commit -m "feat: TEST-124 Test auto-fix"
git diff --cached test.js | grep "const x = 1"
[ $? -eq 0 ] && echo "✅ Auto-fix and restage works"

echo "🎉 Git hooks suite ready for production!"
```

## EXAMPLE USAGE SCENARIOS

### Scenario 1: Node.js/TypeScript Project
```bash
# .githooks/commands.conf
pre-commit:1:true:30:npx lint-staged:Lint staged files
pre-commit:2:false:60:npx tsc --noEmit:Type checking
pre-commit:3:true:30:node scripts/check-imports.js:Import validation
pre-push:1:true:300:npm test:Unit tests
pre-push:2:false:600:npm run build:Build validation
```

### Scenario 2: Python Project
```bash
# .githooks/commands.conf
pre-commit:1:true:30:black {staged}:Format Python files
pre-commit:2:true:30:flake8 {staged}:Lint Python files
pre-commit:3:false:60:mypy {staged}:Type checking
pre-push:1:true:300:pytest:Run tests
pre-push:2:false:120:bandit -r .:Security scan
```

### Scenario 3: Multi-language Project
```bash
# .githooks/commands.conf
pre-commit:1:true:30:./scripts/format-all.sh {staged}:Format all languages
pre-commit:2:true:60:./scripts/lint-all.sh {staged}:Lint all languages
pre-commit:3:false:120:./scripts/security-scan.sh:Security scanning
pre-push:1:true:600:./scripts/test-all.sh:Run all tests
pre-push:2:false:900:docker-compose build:Verify Docker build
```

---

This prompt ensures **nothing is missed** and provides **complete verification** of all functionality including the custom command extension framework. Every requirement has specific implementation details and corresponding tests.
