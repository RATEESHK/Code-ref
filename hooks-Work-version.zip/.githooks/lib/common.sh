#!/usr/bin/env bash

# ============================================================================
# Common Library for Git Hooks
# Purpose: Shared functions, constants, and utilities
# Source: source "$(dirname "$0")/lib/common.sh"
# ============================================================================

# Detect platform
detect_platform() {
    case "$(uname -s)" in
        Linux*)     PLATFORM="Linux";;
        Darwin*)    PLATFORM="macOS";;
        MINGW*|MSYS*|CYGWIN*) PLATFORM="Windows";;
        *)          PLATFORM="Unknown";;
    esac
}
detect_platform

# Logging setup
LOG_DIR=".git/hook-logs"
COMPLETE_LOG="$LOG_DIR/complete.log"
mkdir -p "$LOG_DIR" 2>/dev/null || true

# Log levels
LOG_EMERGENCY=0
LOG_FATAL=1
LOG_CRITICAL=2
LOG_ERROR=3
LOG_WARNING=4
LOG_NOTICE=5
LOG_INFO=6
LOG_DEBUG=7
LOG_TRACE=8

# Current log level (configurable)
CURRENT_LOG_LEVEL=${GIT_HOOK_LOG_LEVEL:-$LOG_INFO}

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'
BOLD='\033[1m'

# Regex patterns
PROTECTED_BRANCHES_REGEX='^(main|develop|release($|/.*))$'
SHORT_LIVED_BRANCHES_REGEX='^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$'
COMMIT_SUBJECT_REGEX='^(feat|fix|chore|break|tests): [A-Z]{2,10}-[0-9]+ .+'
JIRA_ID_REGEX='[A-Z]{2,10}-[0-9]+'

# Secret patterns
declare -a SECRET_PATTERNS=(
    'AKIA[0-9A-Z]{16}'
    'aws_secret_access_key'
    'ghp_[a-zA-Z0-9]{36}'
    'ghs_[a-zA-Z0-9]{36}'
    'gho_[a-zA-Z0-9]{36}'
    'xox[baprs]-[0-9]{10,12}-[a-zA-Z0-9]{24}'
    'AIza[0-9A-Za-z_-]{35}'
    'sk_(test_|live_)[0-9a-zA-Z]{24}'
    '-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY'
    'password\s*=\s*["\x27][^"\x27]+'
    'DefaultEndpointsProtocol=https;AccountName='
    'api[_-]?key\s*[:=]\s*["\x27]?[a-zA-Z0-9_-]{20,}'
    'token\s*[:=]\s*["\x27]?[a-zA-Z0-9_-]{20,}'
)

# Sensitive files
declare -a SENSITIVE_FILES=(
    '.env'
    '.env.*'
    '*.pem'
    '*.p12'
    '*.pfx'
    'id_rsa*'
    'id_dsa*'
    'id_ecdsa*'
    'id_ed25519*'
    '*.key'
    '*.cert'
    '*.crt'
    'credentials'
    'secrets.json'
    'secrets.yml'
    'secrets.yaml'
)

# Lock files and IaC files
declare -a LOCK_FILES=(
    'package-lock.json'
    'yarn.lock'
    'pnpm-lock.yaml'
    'Gemfile.lock'
    'Pipfile.lock'
    'poetry.lock'
    'composer.lock'
    'Cargo.lock'
    'go.sum'
    'pubspec.lock'
)

declare -a IAC_FILES=(
    '*.tf'
    '*.tfvars'
    '*.tfstate'
    '*.tfstate.backup'
    'Dockerfile'
    'docker-compose*.yml'
    'docker-compose*.yaml'
)

# Get stack trace
get_stack_trace() {
    local frame=0
    local trace=""
    while caller $frame >/dev/null 2>&1; do
        local line_info=$(caller $frame)
        trace="$trace -> $line_info"
        ((frame++))
    done
    echo "$trace"
}

# Logging function with complete trace
log_message() {
    local level="$1"
    local hook_name="${2:-unknown}"
    local message="$3"
    local level_name=""
    local color=""
    
    case $level in
        $LOG_EMERGENCY) level_name="EMERGENCY"; color="$RED" ;;
        $LOG_FATAL) level_name="FATAL"; color="$RED" ;;
        $LOG_CRITICAL) level_name="CRITICAL"; color="$RED" ;;
        $LOG_ERROR) level_name="ERROR"; color="$RED" ;;
        $LOG_WARNING) level_name="WARNING"; color="$YELLOW" ;;
        $LOG_NOTICE) level_name="NOTICE"; color="$CYAN" ;;
        $LOG_INFO) level_name="INFO"; color="$GREEN" ;;
        $LOG_DEBUG) level_name="DEBUG"; color="$BLUE" ;;
        $LOG_TRACE) level_name="TRACE"; color="$MAGENTA" ;;
    esac
    
    if [ "$level" -le "$CURRENT_LOG_LEVEL" ]; then
        local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
        local user=$(git config user.name 2>/dev/null || echo "unknown")
        local email=$(git config user.email 2>/dev/null || echo "unknown")
        local branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "unknown")
        local commit=$(git rev-parse --short HEAD 2>/dev/null || echo "unknown")
        local pid=$$
        
        # Stack trace for errors
        local stack_trace=""
        if [ "$level" -le "$LOG_ERROR" ]; then
            stack_trace=$(get_stack_trace)
            if [ -n "$stack_trace" ]; then
                stack_trace=" [Stack:$stack_trace]"
            fi
        fi
        
        # Format log entry
        local log_entry="[$timestamp] [$level_name] [$hook_name] [PID:$pid] [User:$user <$email>] [Branch:$branch] [Commit:$commit]$stack_trace $message"
        
        # Write to complete log
        echo "$log_entry" >> "$COMPLETE_LOG"
        
        # Write to hook-specific log
        local hook_log="$LOG_DIR/${hook_name}.log"
        echo "$log_entry" >> "$hook_log"
        
        # Output to console with color (only for INFO and above by default)
        if [ "$level" -le "$LOG_INFO" ]; then
            echo -e "${color}[$level_name] [$hook_name]${NC} $message" >&2
        fi
    fi
}

# Progress indicator
show_progress() {
    local hook_name="$1"
    local step="$2"
    local total="$3"
    local message="$4"
    
    echo -e "${CYAN}[$hook_name]${NC} [${step}/${total}] $message"
    log_message $LOG_INFO "$hook_name" "Progress: [${step}/${total}] $message"
}

# Check if bypassed
is_bypassed() {
    if [ "${BYPASS_HOOKS:-0}" = "1" ]; then
        local hook_name="${1:-hook}"
        log_message $LOG_WARNING "$hook_name" "Hook bypassed via BYPASS_HOOKS=1"
        echo -e "${YELLOW}[Warning]${NC} Hook bypassed via BYPASS_HOOKS=1"
        return 0
    fi
    return 1
}

# Check if direct protected commit allowed
is_protected_allowed() {
    [ "${ALLOW_DIRECT_PROTECTED:-0}" = "1" ]
}

# Get current branch
get_current_branch() {
    git rev-parse --abbrev-ref HEAD 2>/dev/null
}

# Check if branch is protected
is_protected_branch() {
    local branch="${1:-$(get_current_branch)}"
    [[ "$branch" =~ $PROTECTED_BRANCHES_REGEX ]]
}

# Check if branch is short-lived
is_short_lived_branch() {
    local branch="${1:-$(get_current_branch)}"
    [[ "$branch" =~ $SHORT_LIVED_BRANCHES_REGEX ]]
}

# Get branch type
get_branch_type() {
    local branch="${1:-$(get_current_branch)}"
    echo "$branch" | sed -E 's/^([^-]+)-.*/\1/'
}

# Get JIRA ID from branch
get_jira_id() {
    local branch="${1:-$(get_current_branch)}"
    echo "$branch" | grep -oE "$JIRA_ID_REGEX" | head -1
}

# Get base branch for branch type (configurable via git config)
get_base_branch() {
    local branch="${1:-$(get_current_branch)}"
    local branch_type=$(get_branch_type "$branch")
    
    # Return empty for long-lived branches
    if [[ -z "$branch_type" ]] || [[ "$branch" =~ ^(main|develop|release) ]]; then
        echo ""
        return 0
    fi
    
    # Try to get configured mapping first (hooks.branchMapping.TYPE)
    local configured_base
    configured_base=$(git config "hooks.branchMapping.${branch_type}" 2>/dev/null || true)
    
    if [[ -n "$configured_base" ]]; then
        echo "$configured_base"
        return 0
    fi
    
    # Fall back to default mappings
    case "$branch_type" in
        hotfix)
            echo "origin/main"
            ;;
        feat|feature|bugfix|fix|techdebt|perf|refactor|revert|style|test|build|chore|ci|docs)
            echo "origin/develop"
            ;;
        *)
            echo ""
            ;;
    esac
}

# Validate that a branch was created from the correct base
# Returns 0 if valid, 1 if invalid
validate_branch_base() {
    local target_branch="$1"
    local source_branch="$2"
    
    # Get expected base for target branch
    local expected_base
    expected_base=$(get_base_branch "$target_branch")
    
    # If no base requirement (long-lived branch), allow any
    if [[ -z "$expected_base" ]]; then
        return 0
    fi
    
    # Normalize branch names (remove origin/ prefix for comparison)
    local normalized_source="${source_branch#origin/}"
    local normalized_expected="${expected_base#origin/}"
    
    # Check if source matches expected
    if [[ "$normalized_source" == "$normalized_expected" ]]; then
        return 0
    fi
    
    # Also check with origin/ prefix
    if [[ "$source_branch" == "$expected_base" ]]; then
        return 0
    fi
    
    # Allow local develop/main to match origin/develop and origin/main
    if [[ "$source_branch" == "develop" && "$expected_base" == "origin/develop" ]]; then
        return 0
    fi
    
    if [[ "$source_branch" == "main" && "$expected_base" == "origin/main" ]]; then
        return 0
    fi
    
    # Invalid base
    return 1
}

# Check if commit message is valid
is_valid_commit_message() {
    local message="$1"
    
    # Allow merge and revert commits
    if [[ "$message" =~ ^(Merge |Revert ) ]]; then
        return 0
    fi
    
    # Check against regex
    if [[ "$message" =~ $COMMIT_SUBJECT_REGEX ]]; then
        return 0
    fi
    
    return 1
}

# Get list of staged files
get_staged_files() {
    git diff --cached --name-only --diff-filter=ACM
}

# Get added/modified lines for a file
get_added_lines() {
    local file="$1"
    git diff --cached "$file" 2>/dev/null | grep '^+' | grep -v '^+++'
}

# Scan for secrets in staged content
scan_for_secrets() {
    local hook_name="$1"
    local found_secrets=0
    local files=$(get_staged_files)
    
    if [ -z "$files" ]; then
        return 0
    fi
    
    log_message $LOG_INFO "$hook_name" "Scanning for secrets in staged files..."
    
    while IFS= read -r file; do
        # Skip binary files
        if file "$file" 2>/dev/null | grep -qi "binary"; then
            continue
        fi
        
        local added_lines=$(get_added_lines "$file")
        if [ -z "$added_lines" ]; then
            continue
        fi
        
        for pattern in "${SECRET_PATTERNS[@]}"; do
            if echo "$added_lines" | grep -qE "$pattern" 2>/dev/null; then
                log_message $LOG_ERROR "$hook_name" "Potential secret found in $file matching pattern: $pattern"
                echo -e "${RED}[Error]${NC} Potential secret detected in ${BOLD}$file${NC}"
                echo -e "${YELLOW}Pattern:${NC} $pattern"
                found_secrets=1
            fi
        done
    done <<< "$files"
    
    return $found_secrets
}

# Check for sensitive files
check_sensitive_files() {
    local hook_name="$1"
    local found_sensitive=0
    local files=$(get_staged_files)
    
    if [ -z "$files" ]; then
        return 0
    fi
    
    log_message $LOG_INFO "$hook_name" "Checking for sensitive files..."
    
    while IFS= read -r file; do
        local basename_file=$(basename "$file")
        for pattern in "${SENSITIVE_FILES[@]}"; do
            # Use bash pattern matching
            if [[ "$basename_file" == $pattern ]]; then
                log_message $LOG_ERROR "$hook_name" "Sensitive file detected: $file"
                echo -e "${RED}[Error]${NC} Sensitive file blocked: ${BOLD}$file${NC}"
                echo -e "${YELLOW}Hint:${NC} Add to .gitignore or encrypt before committing"
                found_sensitive=1
            fi
        done
    done <<< "$files"
    
    return $found_sensitive
}

# Check for lock file changes
check_lock_files() {
    local hook_name="$1"
    local old_ref="$2"
    local new_ref="$3"
    
    for pattern in "${LOCK_FILES[@]}"; do
        if git diff --name-only "$old_ref" "$new_ref" 2>/dev/null | grep -F "$(echo "$pattern" | sed 's/\*//')"; then
            log_message $LOG_NOTICE "$hook_name" "Lock file changed: $pattern"
            echo -e "${YELLOW}[Notice]${NC} Lock file changed: $pattern"
            echo -e "${CYAN}Hint:${NC} Remember to run package manager install/update commands"
        fi
    done
}

# Initialize logging for hook
init_hook() {
    local hook_name="$1"
    log_message $LOG_INFO "$hook_name" "=== Hook started ==="
    log_message $LOG_DEBUG "$hook_name" "Environment: PWD=$(pwd), USER=$(whoami), SHELL=${SHELL:-unknown}, PLATFORM=$PLATFORM"
}

# Exit hook with status
exit_hook() {
    local hook_name="$1"
    local status="$2"
    local message="${3:-}"
    
    if [ "$status" -eq 0 ]; then
        log_message $LOG_INFO "$hook_name" "=== Hook completed successfully ==="
        echo -e "${GREEN}✓${NC} $hook_name completed successfully"
    else
        log_message $LOG_ERROR "$hook_name" "=== Hook failed: $message ==="
        echo -e "${RED}✗${NC} $hook_name failed: $message"
    fi
    
    # Trigger log cleanup asynchronously
    if [ -f ".githooks/clean.sh" ]; then
        bash .githooks/clean.sh >/dev/null 2>&1 &
    fi
    
    exit "$status"
}
