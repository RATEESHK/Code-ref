# Git Hooks - Contributing Guide

**Version**: 3.0  
**Status**: Production-Ready ✅  
**Last Updated**: November 4, 2025

---

## 📋 Table of Contents

1. [Getting Started](#getting-started)
2. [Development Setup](#development-setup)
3. [Architecture](#architecture)
4. [Adding New Hooks](#adding-new-hooks)
5. [Extending Existing Hooks](#extending-existing-hooks)
6. [Custom Commands](#custom-commands)
7. [Validation Rules](#validation-rules)
8. [Writing Tests](#writing-tests)
9. [Code Style Guidelines](#code-style-guidelines)
10. [Pull Request Process](#pull-request-process)

---

## Getting Started

### Prerequisites

**Required**:
- Git 2.9+
- Bash 4.0+
- Basic shell scripting knowledge

**Recommended**:
- `jq` for JSON processing
- Code editor with shell script support (VS Code, Vim, etc.)
- Familiarity with Git hooks

### Quick Start

```bash
# 1. Clone repository
git clone <repository-url>
cd <repository-name>

# 2. Install hooks in development mode
bash .githooks/install-hooks.sh

# 3. Enable test infrastructure
bash .githooks/test/test-config.sh setup-dev

# 4. Run tests to verify setup
bash .githooks/test/run-comprehensive-tests.sh

# 5. Create feature branch
git checkout -b feat-PROJ-123-your-feature develop
```

### Repository Structure

```
.githooks/
├── install-hooks.sh              # Installation script with rollback
├── uninstall-hooks.sh            # Uninstallation script
├── pre-commit                    # Pre-commit hook
├── commit-msg                    # Commit message hook
├── pre-push                      # Pre-push hook
├── commands.conf                 # Custom commands configuration
├── security-patterns             # Security scan patterns
├── security-whitelist            # Whitelisted secrets/patterns
├── security-excludes             # Excluded files from scanning
├── backup/                       # Backups during installation
├── logs/                         # Hook execution logs
├── lib/                          # Shared library functions
│   ├── colors.sh                # Terminal colors
│   ├── validation.sh            # Validation functions
│   ├── security.sh              # Security scanning
│   └── utils.sh                 # Utility functions
└── test/                        # Test infrastructure
    ├── test-config.sh           # Test configuration
    ├── setup-test-environment.sh
    ├── cleanup-test-environment.sh
    ├── run-comprehensive-tests.sh
    ├── lib/                     # Test utilities
    │   └── test-utils.sh
    └── test-scenarios/          # Individual test scripts
        ├── test-branch-naming.sh
        ├── test-commit-messages.sh
        ├── test-security-scanning.sh
        ├── test-base-branch.sh
        ├── test-history-curation.sh
        ├── test-protected-branches.sh
        ├── test-custom-commands.sh
        ├── test-hook-integration.sh
        └── test-rollback.sh
```

### Development Workflow

```bash
# 1. Create feature branch
git checkout -b feat-PROJ-123-feature-name develop

# 2. Make changes
# Edit files...

# 3. Test changes
bash .githooks/test/run-comprehensive-tests.sh

# 4. Commit changes (hooks will run)
git add .
git commit -m "feat: PROJ-123 Add new feature"

# 5. Push changes
git push origin feat-PROJ-123-feature-name

# 6. Create pull request
# Through GitHub/GitLab UI
```

---

## Development Setup

### Initial Setup

```bash
# 1. Install development dependencies
# Ubuntu/Debian
sudo apt-get install bash git jq shellcheck shfmt

# macOS
brew install bash git jq shellcheck shfmt

# Windows (Git Bash + Chocolatey)
choco install git jq

# 2. Install hooks
bash .githooks/install-hooks.sh

# 3. Configure for development
git config hooks.verbose true
git config hooks.tests.enabled true
git config hooks.tests.logVerbosity detailed

# 4. Setup test environment
bash .githooks/test/test-config.sh setup-dev
```

### Development Tools

#### ShellCheck (Linter)

```bash
# Install
# Ubuntu: sudo apt-get install shellcheck
# macOS: brew install shellcheck

# Check a hook
shellcheck .githooks/pre-commit

# Check all hooks
find .githooks -name "*.sh" -exec shellcheck {} \;
```

#### shfmt (Formatter)

```bash
# Install
go install mvdan.cc/sh/v3/cmd/shfmt@latest

# Format a file
shfmt -w .githooks/pre-commit

# Format all hooks
find .githooks -name "*.sh" -exec shfmt -w {} \;
```

#### VS Code Extensions

Recommended extensions:
- shellcheck.shellcheck (Shell script linting)
- foxundermoon.shell-format (Shell script formatting)
- timonwong.shellcheck (Additional shell checking)

### Testing Your Changes

```bash
# Run all tests
bash .githooks/test/run-comprehensive-tests.sh

# Run specific category
bash .githooks/test/run-comprehensive-tests.sh branch

# Run with verbose output
bash .githooks/test/run-comprehensive-tests.sh --verbose

# Test manually
bash .githooks/pre-commit
bash .githooks/commit-msg .git/COMMIT_EDITMSG
bash .githooks/pre-push origin main
```

---

## Architecture

### Hook Execution Flow

```
Git Command (e.g., git commit)
        ↓
Git triggers hook (e.g., pre-commit)
        ↓
Load configuration
        ↓
Load shared libraries
        ↓
Execute validations in sequence:
    1. Branch naming (pre-commit)
    2. Base branch enforcement (pre-commit)
    3. Protected branch check (pre-commit)
    4. Security scanning (pre-commit)
    5. Custom commands (pre-commit)
    6. Commit message validation (commit-msg)
    7. History curation (pre-push)
        ↓
Success: Allow operation
Failure: Block operation with error
```

### Shared Libraries

#### colors.sh

```bash
# Purpose: Terminal color codes
# Usage:
source .githooks/lib/colors.sh
echo -e "${GREEN}Success${NC}"
echo -e "${RED}Error${NC}"

# Colors available:
# GREEN, RED, YELLOW, BLUE, CYAN, MAGENTA, NC (no color)
```

#### validation.sh

```bash
# Purpose: Validation functions
# Usage:
source .githooks/lib/validation.sh

# Functions:
validate_branch_name "feat-ABC-123-test"
validate_commit_message "feat: ABC-123 Description"
validate_base_branch "feat-ABC-123-test" "develop"
is_protected_branch "main"
```

#### security.sh

```bash
# Purpose: Security scanning
# Usage:
source .githooks/lib/security.sh

# Functions:
scan_for_secrets <file>
check_file_size <file>
is_binary_file <file>
load_security_patterns
load_security_whitelist
```

#### utils.sh

```bash
# Purpose: Utility functions
# Usage:
source .githooks/lib/utils.sh

# Functions:
log_message "INFO" "Message"
get_git_config "hooks.enabled" "true"
is_merge_commit
get_staged_files
get_commit_count <branch> <base>
```

### Configuration System

#### Git Config Keys

**Branch Naming**:
```bash
hooks.branchNaming.enabled=true
hooks.branchNaming.pattern=^(feat|fix|hotfix|chore|refactor|test)-[A-Z]+-[0-9]+-[a-zA-Z0-9-]+$
hooks.branchNaming.longLivedBranches=main,develop,release/*
```

**Commit Message**:
```bash
hooks.commitMessage.enabled=true
hooks.commitMessage.pattern=^(feat|fix|chore|refactor|test|docs|style|perf):\\s*[A-Z]+-[0-9]+
hooks.commitMessage.requireJiraId=true
hooks.commitMessage.autoPrefill=true
```

**Security**:
```bash
hooks.security.enabled=true
hooks.security.scanDepth=comprehensive
hooks.security.maxFileSizeMB=10
hooks.security.skipBinaryFiles=true
hooks.security.patternsFile=.githooks/security-patterns
hooks.security.whitelistFile=.githooks/security-whitelist
hooks.security.excludesFile=.githooks/security-excludes
```

**Base Branch Enforcement**:
```bash
hooks.baseBranch.enabled=true
hooks.baseBranch.mapping=feat:develop,fix:develop,hotfix:main
hooks.baseBranch.warnOnly=true
```

**History Curation**:
```bash
hooks.historyCuration.enabled=true
hooks.historyCuration.maxCommits=5
hooks.historyCuration.baseBranch=develop
```

**Protected Branches**:
```bash
hooks.protectedBranches.enabled=true
hooks.protectedBranches.branches=main,develop,release/*
hooks.protectedBranches.allowBypass=false
```

**Custom Commands**:
```bash
hooks.commands.enabled=true
hooks.commands.configFile=.githooks/commands.conf
hooks.commands.timeout=10
hooks.commands.parallel=false
```

#### Configuration Precedence

1. **Local** (repository): `.git/config`
2. **Global** (user): `~/.gitconfig`
3. **System** (machine): `/etc/gitconfig`

Lower number = higher priority. Local overrides global overrides system.

### Logging System

#### Log Files

```bash
# Installation logs
.githooks/logs/install-YYYYMMDD_HHMMSS.log

# Hook execution logs
.githooks/logs/pre-commit-YYYYMMDD_HHMMSS.log
.githooks/logs/commit-msg-YYYYMMDD_HHMMSS.log
.githooks/logs/pre-push-YYYYMMDD_HHMMSS.log

# Test logs
.githooks/test/logs/test-run-YYYYMMDD_HHMMSS.log
.githooks/test/logs/cleanup-YYYYMMDD_HHMMSS.log
```

#### Log Function

```bash
# Definition (in install-hooks.sh and hooks)
log() {
    local msg="$1"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    # Strip ANSI color codes before writing to log
    echo -e "[$timestamp] $msg" | sed 's/\x1b\[[0-9;]*m//g' >> "$LOG_FILE"
}

# Usage
log "Starting operation"
log "${GREEN}Success${NC}"  # Colors stripped in log file
```

---

## Adding New Hooks

### Available Git Hooks

Git supports these hooks:
- `pre-commit` - Before commit is created
- `prepare-commit-msg` - Before commit message editor
- `commit-msg` - Validate commit message
- `post-commit` - After commit is created
- `pre-push` - Before push to remote
- `pre-rebase` - Before rebase
- `post-checkout` - After checkout
- `post-merge` - After merge
- `pre-receive` - Server-side, before update
- `update` - Server-side, per branch
- `post-receive` - Server-side, after update

### Currently Implemented

- ✅ `pre-commit` - Branch naming, security, base branch
- ✅ `commit-msg` - Commit message format
- ✅ `pre-push` - History curation, protected branches

### Adding a New Hook

#### Example: post-commit Hook

**Purpose**: Send notification after successful commit

**Step 1: Create Hook File**

```bash
# Create file: .githooks/post-commit
cat > .githooks/post-commit << 'EOF'
#!/usr/bin/env bash

# ============================================================================
# Git Hook: post-commit
# Purpose: Notify after successful commit
# ============================================================================

set -euo pipefail

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Load shared libraries
source "$SCRIPT_DIR/lib/colors.sh"
source "$SCRIPT_DIR/lib/utils.sh"

# Configuration
ENABLED=$(get_git_config "hooks.postCommit.enabled" "true")
NOTIFY_URL=$(get_git_config "hooks.postCommit.notifyUrl" "")

# Check if enabled
if [ "$ENABLED" != "true" ]; then
    exit 0
fi

# Get commit info
COMMIT_HASH=$(git rev-parse HEAD)
COMMIT_MSG=$(git log -1 --pretty=%B)
AUTHOR=$(git log -1 --pretty=%an)

# Send notification
if [ -n "$NOTIFY_URL" ]; then
    curl -X POST "$NOTIFY_URL" \
        -H "Content-Type: application/json" \
        -d "{
            \"commit\": \"$COMMIT_HASH\",
            \"message\": \"$COMMIT_MSG\",
            \"author\": \"$AUTHOR\"
        }" 2>/dev/null || true
fi

# Log
echo -e "${GREEN}✓ Commit notification sent${NC}"

exit 0
EOF

chmod +x .githooks/post-commit
```

**Step 2: Add Configuration Support**

```bash
# In install-hooks.sh, add to configuration step:

# Post-commit hook configuration
git config hooks.postCommit.enabled true
git config hooks.postCommit.notifyUrl "https://your-webhook-url"
```

**Step 3: Add to Installation**

```bash
# In install-hooks.sh, add to installation steps:

# Step X: Install post-commit hook
log "${BLUE}Step X/12: Installing post-commit hook${NC}"
if cp "$HOOKS_SOURCE_DIR/post-commit" "$HOOKS_DEST_DIR/post-commit"; then
    chmod +x "$HOOKS_DEST_DIR/post-commit"
    save_rollback_action "rm -f \"$HOOKS_DEST_DIR/post-commit\""
    log "${GREEN}✓ post-commit hook installed${NC}"
else
    log "${RED}✗ Failed to install post-commit hook${NC}"
    perform_rollback "Failed at step X"
    exit 1
fi
```

**Step 4: Add Tests**

```bash
# Create: .githooks/test/test-scenarios/test-post-commit.sh
cat > .githooks/test/test-scenarios/test-post-commit.sh << 'EOF'
#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/test-utils.sh"

TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

test_post_commit_notification() {
    local branch="hook-test-post-commit-$$"
    
    # Setup
    git checkout -b "$branch" develop
    git config hooks.postCommit.enabled true
    
    # Make commit
    git commit --allow-empty -m "test: TEST-123 Post commit test"
    
    # Check if hook ran (check logs or output)
    # Verification logic here...
    
    # Cleanup
    git checkout develop
    git branch -D "$branch"
    
    return 0
}

main() {
    log_header "Post-Commit Hook Tests"
    
    run_test "Post-commit notification" test_post_commit_notification
    
    log_summary "$TESTS_RUN" "$TESTS_PASSED" "$TESTS_FAILED"
    
    [ $TESTS_FAILED -eq 0 ] && exit 0 || exit 1
}

main
EOF

chmod +x .githooks/test/test-scenarios/test-post-commit.sh
```

**Step 5: Update Documentation**

```bash
# Add to README.md:
# 
# ### Post-Commit Hook
# 
# **Purpose**: Send notification after successful commit
# 
# **Configuration**:
# ```bash
# git config hooks.postCommit.enabled true
# git config hooks.postCommit.notifyUrl "https://webhook-url"
# ```
# 
# **Behavior**:
# - Sends commit info to configured webhook
# - Includes commit hash, message, and author
# - Non-blocking (failures don't stop workflow)
```

---

## Extending Existing Hooks

### Adding Validation to Pre-Commit

**Example: Add file size limit**

```bash
# In .githooks/pre-commit, add new validation:

# File size validation
validate_file_sizes() {
    local max_size_mb=5
    local max_size_bytes=$((max_size_mb * 1024 * 1024))
    
    log "${BLUE}Checking file sizes...${NC}"
    
    local large_files=()
    while IFS= read -r file; do
        if [ -f "$file" ]; then
            local size=$(stat -f%z "$file" 2>/dev/null || stat -c%s "$file" 2>/dev/null)
            if [ "$size" -gt "$max_size_bytes" ]; then
                large_files+=("$file ($(echo "scale=2; $size/1024/1024" | bc)MB)")
            fi
        fi
    done < <(git diff --cached --name-only)
    
    if [ ${#large_files[@]} -gt 0 ]; then
        log "${RED}ERROR: Files exceed ${max_size_mb}MB limit:${NC}"
        printf '%s\n' "${large_files[@]}"
        return 1
    fi
    
    log "${GREEN}✓ All files within size limit${NC}"
    return 0
}

# Add to main execution:
if ! validate_file_sizes; then
    exit 1
fi
```

### Adding Pattern to Security Scanning

**Example: Detect API keys in new format**

```bash
# Add to .githooks/security-patterns:
# Format: PATTERN_NAME:REGEX_PATTERN

# Existing patterns...
AWS_ACCESS_KEY:AKIA[0-9A-Z]{16}
GITHUB_TOKEN:ghp_[0-9a-zA-Z]{36}

# New pattern:
CUSTOM_API_KEY:MYAPP_API_KEY_[0-9a-zA-Z]{32}
STRIPE_KEY:sk_(test|live)_[0-9a-zA-Z]{24}
```

### Adding Validation Rule

**Example: Require ticket ID in branch name**

```bash
# Create validation function in .githooks/lib/validation.sh:

validate_ticket_id() {
    local branch="$1"
    local pattern="$2"
    
    # Extract ticket ID from branch name
    if [[ $branch =~ ([A-Z]+-[0-9]+) ]]; then
        local ticket_id="${BASH_REMATCH[1]}"
        
        # Verify ticket exists (API call example)
        local ticket_exists=$(curl -s "https://api.jira.com/issue/$ticket_id" | jq -r '.key')
        
        if [ "$ticket_exists" = "$ticket_id" ]; then
            return 0
        else
            echo "ERROR: Ticket $ticket_id does not exist in JIRA"
            return 1
        fi
    fi
    
    echo "ERROR: No ticket ID found in branch name"
    return 1
}

# Use in pre-commit hook:
if git config hooks.branchNaming.verifyTicket | grep -q "true"; then
    if ! validate_ticket_id "$BRANCH_NAME" "$PATTERN"; then
        exit 1
    fi
fi
```

---

## Custom Commands

### Commands Configuration Format

**File**: `.githooks/commands.conf`

**Format**:
```
hook:priority:mandatory:timeout:command:description
```

**Fields**:
- `hook`: Hook name (pre-commit, commit-msg, pre-push)
- `priority`: Execution order (1 = first, higher = later)
- `mandatory`: true = must succeed, false = can fail
- `timeout`: Max execution time in seconds
- `command`: Shell command to execute
- `description`: Human-readable description

### Examples

```bash
# .githooks/commands.conf

# Run linter before commit (mandatory)
pre-commit:1:true:30:npm run lint:Lint code

# Run tests before commit (optional)
pre-commit:2:false:60:npm test:Run unit tests

# Build before push (mandatory)
pre-push:1:true:120:npm run build:Build application

# Generate docs before push (optional)
pre-push:2:false:30:npm run docs:Generate documentation

# Check dependencies (mandatory)
pre-commit:3:true:10:npm audit --audit-level=high:Security audit
```

### Adding Custom Command

```bash
# Method 1: Edit commands.conf directly
echo "pre-commit:4:true:15:./scripts/custom-check.sh:Custom validation" >> .githooks/commands.conf

# Method 2: Through script
cat >> .githooks/commands.conf << 'EOF'
pre-commit:5:false:20:python scripts/validate.py:Python validation
EOF

# Method 3: Programmatically
add_custom_command() {
    local hook=$1
    local priority=$2
    local mandatory=$3
    local timeout=$4
    local command=$5
    local description=$6
    
    echo "$hook:$priority:$mandatory:$timeout:$command:$description" >> .githooks/commands.conf
}

add_custom_command "pre-commit" "6" "true" "10" "shellcheck scripts/*.sh" "Check shell scripts"
```

### Command Execution Logic

Commands are executed in the hooks according to this logic:

```bash
# Load commands from config
while IFS=: read -r hook priority mandatory timeout command description; do
    # Skip comments and empty lines
    [[ "$hook" =~ ^# || -z "$hook" ]] && continue
    
    # Check if command is for this hook
    if [ "$hook" = "pre-commit" ]; then
        echo "Running: $description"
        
        # Execute with timeout
        if timeout "$timeout" bash -c "$command"; then
            echo "✓ $description passed"
        else
            local exit_code=$?
            
            if [ "$mandatory" = "true" ]; then
                echo "✗ $description failed (mandatory)"
                exit 1
            else
                echo "⚠ $description failed (optional)"
            fi
        fi
    fi
done < .githooks/commands.conf
```

### Advanced: Conditional Commands

```bash
# Run command only on specific branches
pre-commit:7:true:10:[[ $(git branch --show-current) =~ ^release/ ]] && npm run build-prod:Production build on release branches

# Run command only if files changed
pre-commit:8:false:15:git diff --cached --name-only | grep -q '\.ts$' && npm run typecheck:Type check TypeScript files

# Run command with environment check
pre-commit:9:true:20:[ "$CI" != "true" ] && npm run pre-commit-local:Local pre-commit checks
```

---

## Validation Rules

### Branch Naming Rules

**Default Pattern**:
```regex
^(feat|fix|hotfix|chore|refactor|test)-[A-Z]+-[0-9]+-[a-zA-Z0-9-]+$
```

**Customizing**:

```bash
# Allow different types
git config hooks.branchNaming.pattern '^(feature|bugfix|hotfix|chore|docs|style|refactor|test|perf)-[A-Z]+-[0-9]+-[a-zA-Z0-9-]+$'

# Allow lowercase JIRA IDs
git config hooks.branchNaming.pattern '^(feat|fix)-[A-Za-z]+-[0-9]+-[a-zA-Z0-9-]+$'

# No JIRA ID required
git config hooks.branchNaming.pattern '^(feat|fix)/[a-z-]+$'

# Custom project prefix
git config hooks.branchNaming.pattern '^(feat|fix)-MYPROJ-[0-9]+-[a-zA-Z0-9-]+$'
```

**Examples**:

```bash
# Valid:
feat-ABC-123-user-authentication
fix-BUG-456-login-issue
hotfix-CRIT-789-security-patch

# Invalid:
feature-branch          # Missing JIRA ID
feat-abc-123-test      # Lowercase JIRA project
feat_ABC_123_test      # Wrong separator
FEAT-ABC-123-test      # Uppercase type
```

### Commit Message Rules

**Default Pattern**:
```regex
^(feat|fix|chore|refactor|test|docs|style|perf):\s*[A-Z]+-[0-9]+
```

**Customizing**:

```bash
# Different format
git config hooks.commitMessage.pattern '^\[(FEAT|FIX|CHORE)\]\\s*[A-Z]+-[0-9]+'

# No type required
git config hooks.commitMessage.pattern '^[A-Z]+-[0-9]+:\\s*.+'

# Custom project
git config hooks.commitMessage.pattern '^(feat|fix):\\s*MYPROJ-[0-9]+'

# Optional JIRA ID
git config hooks.commitMessage.requireJiraId false
```

**Examples**:

```bash
# Valid:
feat: ABC-123 Add user authentication
fix: BUG-456 Fix login redirect
chore: TASK-789 Update dependencies

# Invalid:
Add authentication          # No type, no JIRA ID
feat: Add auth             # Missing JIRA ID
FEAT: ABC-123 Description  # Uppercase type
feat:ABC-123 Description   # Missing space after colon
```

### Security Patterns

**Default Patterns**:

```bash
# AWS
AWS_ACCESS_KEY:AKIA[0-9A-Z]{16}
AWS_SECRET_KEY:(aws_secret|secret_key)\\s*=\\s*['\"][0-9a-zA-Z/+]{40}['\"]

# GitHub
GITHUB_TOKEN:ghp_[0-9a-zA-Z]{36}
GITHUB_OAUTH:gho_[0-9a-zA-Z]{36}

# Generic
API_KEY:(api_key|apikey|api-key)\\s*[:=]\\s*['\"][0-9a-zA-Z]{20,}['\"]
PASSWORD:(password|passwd|pwd)\\s*[:=]\\s*['\"][^'\"]{8,}['\"]

# Tokens
JWT_TOKEN:eyJ[0-9a-zA-Z_-]*\\.[0-9a-zA-Z_-]*\\.[0-9a-zA-Z_-]*
BEARER_TOKEN:Bearer\\s+[0-9a-zA-Z\\._\\-]{20,}

# Slack
SLACK_TOKEN:xox[baprs]-[0-9a-zA-Z]{10,48}

# Private Keys
PRIVATE_KEY:-----BEGIN\\s+(RSA|DSA|EC|OPENSSH)\\s+PRIVATE\\s+KEY-----
```

**Adding Custom Patterns**:

```bash
# Add to .githooks/security-patterns
echo "STRIPE_KEY:sk_(test|live)_[0-9a-zA-Z]{24}" >> .githooks/security-patterns
echo "SENDGRID_KEY:SG\\.[0-9a-zA-Z_-]{22}\\.[0-9a-zA-Z_-]{43}" >> .githooks/security-patterns
echo "FIREBASE_KEY:AIza[0-9A-Za-z_-]{35}" >> .githooks/security-patterns
```

### Base Branch Mapping

**Default Mapping**:
```bash
feat → develop
fix → develop
hotfix → main
```

**Customizing**:

```bash
# Custom mapping
git config hooks.baseBranch.mapping "feat:develop,fix:develop,hotfix:main,release:develop,docs:develop"

# All from main
git config hooks.baseBranch.mapping "feat:main,fix:main,hotfix:main"

# Different for different projects
git config hooks.baseBranch.mapping "feature:dev,bugfix:dev,hotfix:production"
```

**Enforcement Level**:

```bash
# Warn only (default)
git config hooks.baseBranch.warnOnly true

# Strict enforcement (block)
git config hooks.baseBranch.warnOnly false
```

---

## Writing Tests

### Test Structure

```bash
#!/usr/bin/env bash

set -euo pipefail

# Setup
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/test-utils.sh"

# Counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test function
run_test() {
    local test_name="$1"
    local test_func="$2"
    
    TESTS_RUN=$((TESTS_RUN + 1))
    log_test "Running: $test_name"
    
    if $test_func; then
        TESTS_PASSED=$((TESTS_PASSED + 1))
        log_success "PASSED: $test_name"
    else
        TESTS_FAILED=$((TESTS_FAILED + 1))
        log_error "FAILED: $test_name"
    fi
}

# Individual tests
test_example() {
    # Setup
    local test_branch="hook-test-example-$$"
    
    # Execute
    git checkout -b "$test_branch" develop 2>&1
    local result=$?
    
    # Assert
    if [ $result -eq 0 ]; then
        # Cleanup
        git checkout develop
        git branch -D "$test_branch"
        return 0
    else
        return 1
    fi
}

# Main
main() {
    log_header "Example Test Suite"
    
    run_test "Example test" test_example
    
    log_summary "$TESTS_RUN" "$TESTS_PASSED" "$TESTS_FAILED"
    
    [ $TESTS_FAILED -eq 0 ] && exit 0 || exit 1
}

main
```

### Test Utilities

```bash
# Available in .githooks/test/lib/test-utils.sh

# Logging
log_header "Test Suite Name"
log_test "Running test..."
log_success "Test passed"
log_error "Test failed"
log_warning "Warning"
log_info "Information"
log_summary <total> <passed> <failed>

# Assertions
assert_equals <expected> <actual> <message>
assert_not_equals <unexpected> <actual> <message>
assert_contains <string> <substring> <message>
assert_file_exists <path> <message>
assert_command_success <command> <message>
assert_command_fails <command> <message>

# State management
save_test_state
restore_test_state
cleanup_test_artifacts

# Branch operations
create_test_branch <name> [base]
cleanup_test_branches

# Commit operations
create_test_commit <message> [file]
cleanup_test_commits
```

### Test Examples

#### Test 1: Branch Validation

```bash
test_valid_branch_name() {
    local branch="feat-TEST-999-example"
    
    git checkout -b "$branch" develop 2>&1
    local result=$?
    
    # Cleanup
    git checkout develop 2>&1
    git branch -D "$branch" 2>&1
    
    # Assert
    assert_equals 0 $result "Branch creation should succeed"
}

test_invalid_branch_name() {
    local branch="invalid-branch"
    
    git checkout -b "$branch" develop 2>&1
    local result=$?
    
    # Cleanup
    git checkout develop 2>&1
    git branch -D "$branch" 2>&1
    
    # Assert (should fail)
    assert_not_equals 0 $result "Invalid branch should be rejected"
}
```

#### Test 2: Commit Message Validation

```bash
test_valid_commit_message() {
    local branch="feat-TEST-888-commit-test"
    
    git checkout -b "$branch" develop
    git commit --allow-empty -m "feat: TEST-888 Valid message"
    local result=$?
    
    # Cleanup
    git checkout develop
    git branch -D "$branch"
    
    assert_equals 0 $result "Valid commit should succeed"
}

test_invalid_commit_message() {
    local branch="feat-TEST-777-commit-test"
    
    git checkout -b "$branch" develop
    git commit --allow-empty -m "invalid message" 2>&1
    local result=$?
    
    # Cleanup
    git checkout develop
    git branch -D "$branch"
    
    assert_not_equals 0 $result "Invalid commit should fail"
}
```

#### Test 3: Security Scanning

```bash
test_secret_detection() {
    local branch="feat-TEST-666-security-test"
    local test_file="test-secret.js"
    
    git checkout -b "$branch" develop
    
    # Create file with secret
    echo 'const KEY = "AKIAIOSFODNN7EXAMPLE";' > "$test_file"
    git add "$test_file"
    git commit -m "feat: TEST-666 Add config" 2>&1
    local result=$?
    
    # Cleanup
    rm -f "$test_file"
    git checkout develop
    git branch -D "$branch"
    
    # Should fail (secret detected)
    assert_not_equals 0 $result "Secret should be detected and blocked"
}
```

### Integration Tests

```bash
test_full_workflow() {
    local branch="feat-TEST-555-integration"
    
    # 1. Create branch
    git checkout -b "$branch" develop
    assert_equals 0 $? "Branch creation"
    
    # 2. Make changes
    echo "test" > test.js
    git add test.js
    
    # 3. Commit
    git commit -m "feat: TEST-555 Add test file"
    assert_equals 0 $? "Commit"
    
    # 4. Push (simulated)
    # Would test pre-push hook
    
    # Cleanup
    rm -f test.js
    git checkout develop
    git branch -D "$branch"
    
    return 0
}
```

---

## Code Style Guidelines

### Shell Script Best Practices

#### 1. Shebang

```bash
#!/usr/bin/env bash
# Use bash explicitly, portable across systems
```

#### 2. Error Handling

```bash
# Enable strict mode
set -euo pipefail
# -e: Exit on error
# -u: Error on undefined variable
# -o pipefail: Pipeline fails if any command fails
```

#### 3. Variables

```bash
# Use uppercase for constants
readonly MAX_FILE_SIZE=10485760

# Use lowercase for local variables
local file_name="example.txt"

# Quote variables
echo "$file_name"  # ✓ Good
echo $file_name    # ✗ Bad

# Use curly braces for clarity
echo "${file_name}.bak"  # ✓ Good
echo "$file_name.bak"    # ✗ Ambiguous
```

#### 4. Functions

```bash
# Document functions
# Purpose: Validate branch name
# Args: $1 - branch name
# Returns: 0 on success, 1 on failure
validate_branch_name() {
    local branch_name="$1"
    
    # Function body...
    
    return 0
}
```

#### 5. Conditionals

```bash
# Use [[ ]] for conditions
if [[ "$var" = "value" ]]; then  # ✓ Good
    # ...
fi

if [ "$var" = "value" ]; then    # ✓ Also good (POSIX)
    # ...
fi

if [ $var = value ]; then        # ✗ Bad (no quotes)
    # ...
fi
```

#### 6. Loops

```bash
# Iterate over files safely
while IFS= read -r file; do
    echo "$file"
done < <(find . -name "*.sh")

# Array iteration
for item in "${array[@]}"; do
    echo "$item"
done
```

#### 7. Exit Codes

```bash
# 0 = success
# 1 = general error
# 2 = misuse
# 126 = command cannot execute
# 127 = command not found
# 128+n = fatal signal n

# Explicit exit codes
exit 0  # Success
exit 1  # Error
```

### Code Organization

```bash
#!/usr/bin/env bash

# ============================================================================
# Script Name
# Purpose: Brief description
# ============================================================================

set -euo pipefail

# ====================
# Constants
# ====================
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly MAX_SIZE=10

# ====================
# Global Variables
# ====================
VERBOSE=false

# ====================
# Helper Functions
# ====================

log_message() {
    local msg="$1"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $msg"
}

# ====================
# Main Functions
# ====================

main_function() {
    # Main logic
    return 0
}

# ====================
# Main Execution
# ====================

main() {
    main_function
    exit $?
}

# Run main if executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
```

### Documentation

```bash
# Function documentation
# ====================
# validate_branch_name
# ====================
# Validates branch name against configured pattern
#
# Arguments:
#   $1 - branch_name: The branch name to validate
#   $2 - pattern: (optional) Regex pattern to match
#
# Returns:
#   0 - Branch name is valid
#   1 - Branch name is invalid
#
# Example:
#   validate_branch_name "feat-ABC-123-test"
#   validate_branch_name "feat-ABC-123-test" "^feat-.*"
# ====================
validate_branch_name() {
    local branch_name="$1"
    local pattern="${2:-}"
    
    # Implementation...
    
    return 0
}
```

### Linting and Formatting

```bash
# Run shellcheck
shellcheck .githooks/pre-commit

# Run shfmt (format)
shfmt -i 4 -w .githooks/pre-commit

# Check all scripts
find .githooks -name "*.sh" -exec shellcheck {} \;
find .githooks -name "*.sh" -exec shfmt -i 4 -w {} \;
```

---

## Pull Request Process

### Before Creating PR

1. **Run tests**:
   ```bash
   bash .githooks/test/run-comprehensive-tests.sh
   ```

2. **Lint code**:
   ```bash
   find .githooks -name "*.sh" -exec shellcheck {} \;
   ```

3. **Format code**:
   ```bash
   find .githooks -name "*.sh" -exec shfmt -i 4 -w {} \;
   ```

4. **Update documentation**:
   - Update relevant .md files
   - Add examples if needed
   - Document new configuration options

5. **Test manually**:
   ```bash
   # Test installation
   bash .githooks/uninstall-hooks.sh
   bash .githooks/install-hooks.sh
   
   # Test hooks
   git checkout -b feat-TEST-123-test
   git commit --allow-empty -m "test: TEST-123 Test"
   ```

### PR Checklist

- [ ] All tests pass
- [ ] Code follows style guidelines
- [ ] Functions are documented
- [ ] New features have tests
- [ ] Documentation is updated
- [ ] Commit messages follow format
- [ ] Branch name follows convention
- [ ] No secrets in code
- [ ] Backward compatible (or breaking changes documented)

### PR Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Changes Made
- Change 1
- Change 2

## Testing
- [ ] All tests pass
- [ ] Added new tests
- [ ] Tested manually

## Checklist
- [ ] Code follows style guidelines
- [ ] Documentation updated
- [ ] No breaking changes (or documented)
- [ ] All tests pass

## Related Issues
Closes #123
```

### Review Process

1. **Automated checks**:
   - Tests run automatically
   - Linting checks run
   - Coverage checked

2. **Code review**:
   - At least one approval required
   - Address review comments
   - Keep PR focused

3. **Merge**:
   - Squash commits if needed
   - Merge to develop
   - Delete feature branch

---

## Additional Resources

### Useful Links

- [Git Hooks Documentation](https://git-scm.com/docs/githooks)
- [Bash Guide](https://mywiki.wooledge.org/BashGuide)
- [ShellCheck](https://www.shellcheck.net/)
- [Google Shell Style Guide](https://google.github.io/styleguide/shellguide.html)

### Tools

- **ShellCheck**: Shell script linter
- **shfmt**: Shell script formatter
- **bats**: Bash Automated Testing System
- **shellspec**: BDD-style testing framework

### Examples

See test scripts for examples:
- `.githooks/test/test-scenarios/*.sh`
- Comprehensive examples of all features
- Testing patterns and best practices

---

**Version**: 3.0  
**Status**: Production-Ready ✅  
**Last Updated**: November 4, 2025

**See Also**:
- [GITHOOKS_README.md](GITHOOKS_README.md) - Complete documentation
- [GITHOOKS_TESTING.md](GITHOOKS_TESTING.md) - Testing guide
- [GITHOOKS_TROUBLESHOOTING.md](GITHOOKS_TROUBLESHOOTING.md) - Troubleshooting guide

---

## License

This project is licensed under the MIT License. See LICENSE file for details.

---

**Happy Contributing!** 🎉
