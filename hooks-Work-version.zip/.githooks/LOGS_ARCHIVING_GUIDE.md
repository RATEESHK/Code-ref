# Hook Logs Archive System Guide

## Overview

The Git hooks system includes an intelligent log archiving mechanism that preserves historical log data when uninstalling hooks or cleaning up old logs. This guide explains how the archiving system works.

---

## How It Works

### 1. **Automatic Archiving During Uninstall**

When you run the uninstall script, it automatically archives logs before deletion:

```bash
bash .githooks/uninstall-hooks.sh
```

**What Happens:**

1. **Step 1: Hook Execution Logs Archive**
   - The uninstall script detects if `.git/hook-logs/` directory exists
   - Creates a timestamped archive: `.git/hook-logs-archive-YYYYMMDD-HHMMSS.tar.gz`
   - Archives all hook execution logs (complete.log, pre-commit.log, commit-msg.log, pre-push.log)
   - Asks if you want to delete the original logs
   - If you say **YES**: Deletes `.git/hook-logs/` directory after archiving
   - If you say **NO**: Keeps original logs and the archive

2. **Step 2: Test Logs Archive**
   - If tests are enabled, asks if you want to remove test logs
   - Creates a timestamped archive: `.githooks/test/test-logs-archive-YYYYMMDD-HHMMSS.tar.gz`
   - Archives all test execution logs
   - Removes test log files but keeps the archive

### 2. **Archive Naming Convention**

Archives use a consistent naming pattern:

```
.git/hook-logs-archive-20251104-143025.tar.gz
                        └─YYYY MM DD HH MM SS
                          Date        Time

.githooks/test/test-logs-archive-20251104-143025.tar.gz
                                 └─YYYY MM DD HH MM SS
```

**Format**: `YYYYMMDD-HHMMSS` (Year, Month, Day, Hour, Minute, Second)

**Example**: 
- `hook-logs-archive-20251104-143025.tar.gz` = November 4, 2025 at 2:30:25 PM

### 3. **Archive Locations**

| Archive Type | Location | Contains |
|-------------|----------|----------|
| **Hook Execution Logs** | `.git/hook-logs-archive-*.tar.gz` | All hook execution logs (complete.log, pre-commit.log, etc.) |
| **Test Logs** | `.githooks/test/test-logs-archive-*.tar.gz` | Test execution logs (test-run-*.log) |
| **Installation Logs** | `.githooks/logs/install-*.log` | Installation logs (not archived, kept indefinitely) |
| **Uninstallation Logs** | `.githooks/logs/uninstall-*.log` | Uninstallation logs (not archived, kept indefinitely) |

### 4. **What Gets Archived**

#### Hook Execution Logs Archive Contains:
```
.git/hook-logs-archive-20251104-143025.tar.gz
├── .git/hook-logs/
│   ├── complete.log          # All hook executions
│   ├── pre-commit.log         # Pre-commit hook logs
│   ├── commit-msg.log         # Commit message validation logs
│   ├── pre-push.log           # Pre-push hook logs
│   ├── pre-commit.1.log       # Rotated logs (if any)
│   └── complete.1.log         # Rotated logs (if any)
```

#### Test Logs Archive Contains:
```
.githooks/test/test-logs-archive-20251104-143025.tar.gz
├── .githooks/test/logs/
│   ├── test-run-20251103_120000.log
│   ├── test-run-20251104_090000.log
│   └── test-*.log
```

---

## Log Rotation System

The system includes automatic log rotation to prevent logs from growing too large.

### How Log Rotation Works

**Script**: `.githooks/clean.sh`

**Configuration**:
- **MAX_SIZE**: 256 KB (262,144 bytes) - When a log exceeds this, it's rotated
- **MAX_ARCHIVES**: 2 - Number of rotated copies to keep
- **MAX_AGE_DAYS**: 21 - Logs older than 21 days are deleted

**Rotation Process**:

1. **Check Size**: When `complete.log` exceeds 256 KB
2. **Rotate**:
   ```
   complete.log → complete.1.log  (previous current)
   complete.1.log → complete.2.log  (older)
   complete.2.log → complete.3.log  (oldest, will be deleted)
   ```
3. **Create New**: New empty `complete.log` is created
4. **Delete Old**: `complete.3.log` is deleted (exceeds MAX_ARCHIVES)

**Example Rotation Timeline**:
```
Day 1:  complete.log (50 KB)
Day 10: complete.log (200 KB)
Day 15: complete.log (300 KB) → Triggers rotation
        complete.log (new, 0 KB)
        complete.1.log (300 KB from Day 15)
Day 20: complete.log (250 KB)
Day 25: complete.log (350 KB) → Triggers rotation
        complete.log (new, 0 KB)
        complete.1.log (350 KB from Day 25)
        complete.2.log (300 KB from Day 15)
Day 30: Logs older than 21 days deleted
```

### Running Log Cleanup Manually

```bash
# Run the cleanup script
bash .githooks/clean.sh
```

This will:
- Rotate logs exceeding 256 KB
- Keep 2 rotated copies
- Delete logs older than 21 days
- Run silently (no output unless errors)

---

## Working with Archives

### 1. **Extract an Archive**

```bash
# Extract hook execution logs
tar -xzf .git/hook-logs-archive-20251104-143025.tar.gz

# Extract test logs
tar -xzf .githooks/test/test-logs-archive-20251104-143025.tar.gz
```

### 2. **View Archive Contents (Without Extracting)**

```bash
# List files in archive
tar -tzf .git/hook-logs-archive-20251104-143025.tar.gz

# View specific log from archive
tar -xzOf .git/hook-logs-archive-20251104-143025.tar.gz .git/hook-logs/complete.log | less
```

### 3. **Search Archives**

```bash
# Search for specific error in all archives
for archive in .git/hook-logs-archive-*.tar.gz; do
    echo "=== $archive ==="
    tar -xzOf "$archive" .git/hook-logs/complete.log | grep -i "error"
done
```

### 4. **Find Archives by Date**

```bash
# List all archives with details
ls -lh .git/hook-logs-archive-*.tar.gz

# Find archives from specific month
ls .git/hook-logs-archive-202511*.tar.gz
```

### 5. **Clean Old Archives**

```bash
# Remove archives older than 30 days
find .git -name "hook-logs-archive-*.tar.gz" -mtime +30 -delete

# Remove archives older than 90 days
find .git -name "hook-logs-archive-*.tar.gz" -mtime +90 -delete

# Remove specific archive
rm .git/hook-logs-archive-20251104-143025.tar.gz
```

---

## Manual Archiving

You can create archives manually before cleanup:

### Archive Hook Logs

```bash
# Archive all current hook logs
tar -czf .git/hook-logs-archive-$(date +%Y%m%d-%H%M%S).tar.gz .git/hook-logs/

# Archive and remove original logs
tar -czf .git/hook-logs-archive-$(date +%Y%m%d-%H%M%S).tar.gz .git/hook-logs/
rm -f .git/hook-logs/*.log
```

### Archive Test Logs

```bash
# Archive test logs
tar -czf .githooks/test/test-logs-archive-$(date +%Y%m%d-%H%M%S).tar.gz .githooks/test/logs/

# Archive and remove test logs
tar -czf .githooks/test/test-logs-archive-$(date +%Y%m%d-%H%M%S).tar.gz .githooks/test/logs/
rm -f .githooks/test/logs/*.log
```

### Archive Installation Logs

```bash
# Archive installation logs
tar -czf .githooks/logs/install-logs-archive-$(date +%Y%m%d-%H%M%S).tar.gz .githooks/logs/install-*.log

# Archive all logs (install + uninstall)
tar -czf .githooks/logs/all-logs-archive-$(date +%Y%m%d-%H%M%S).tar.gz .githooks/logs/*.log
```

---

## Archive Management Best Practices

### 1. **Regular Cleanup Schedule**

**Recommended Schedule**:
- **Daily**: Run `bash .githooks/clean.sh` (automated via cron/scheduler)
- **Weekly**: Review and extract important logs before archiving
- **Monthly**: Remove archives older than 30-90 days

**Automated Cleanup (Linux/macOS - crontab)**:
```bash
# Add to crontab: Run cleanup daily at 3 AM
0 3 * * * cd /path/to/repo && bash .githooks/clean.sh
```

**Automated Cleanup (Windows - Task Scheduler)**:
```batch
# Create scheduled task
schtasks /create /tn "Git Hooks Cleanup" /tr "bash .githooks/clean.sh" /sc daily /st 03:00
```

### 2. **Archive Retention Policy**

**Conservative** (Development/Production):
- Keep hook execution logs: 30 days
- Keep test logs: 14 days
- Keep archives: 90 days
- Keep installation logs: Indefinitely

**Aggressive** (Personal Projects):
- Keep hook execution logs: 14 days
- Keep test logs: 7 days
- Keep archives: 30 days
- Keep installation logs: 30 days

### 3. **Disk Space Management**

```bash
# Check archive sizes
du -sh .git/hook-logs-archive-*.tar.gz
du -sh .githooks/test/test-logs-archive-*.tar.gz

# Find largest archives
find .git -name "hook-logs-archive-*.tar.gz" -exec du -h {} \; | sort -h

# Total space used by archives
du -ch .git/hook-logs-archive-*.tar.gz | tail -1
```

### 4. **Backup Critical Archives**

Before deleting old archives, backup critical ones:

```bash
# Copy to backup location
cp .git/hook-logs-archive-*.tar.gz /path/to/backup/

# Or use rsync
rsync -av .git/hook-logs-archive-*.tar.gz backup@server:/backups/git-hooks/
```

---

## Troubleshooting

### Issue 1: Archive Not Created During Uninstall

**Cause**: `tar` command not available

**Solution**:
```bash
# Check if tar is available
command -v tar

# Install tar (Windows - Git Bash includes tar)
# Install tar (Linux)
sudo apt-get install tar

# Install tar (macOS - included by default)
```

### Issue 2: Cannot Extract Archive

**Error**: `tar: Error opening archive: Failed to open`

**Solution**:
```bash
# Check if file exists and is readable
ls -l .git/hook-logs-archive-20251104-143025.tar.gz

# Check file permissions
chmod 644 .git/hook-logs-archive-20251104-143025.tar.gz

# Try verbose extraction
tar -xzvf .git/hook-logs-archive-20251104-143025.tar.gz
```

### Issue 3: Archive Too Large

**Cause**: Logs accumulated before rotation

**Solution**:
```bash
# Check archive size
du -h .git/hook-logs-archive-*.tar.gz

# Split large archive
tar -xzf large-archive.tar.gz
tar -czf smaller-archive-1.tar.gz .git/hook-logs/complete*.log
tar -czf smaller-archive-2.tar.gz .git/hook-logs/pre-*.log
```

### Issue 4: Cannot Find Old Logs

**Cause**: Logs archived and deleted

**Solution**:
```bash
# List all archives by date
ls -lt .git/hook-logs-archive-*.tar.gz

# Search all archives for specific content
for archive in .git/hook-logs-archive-*.tar.gz; do
    echo "Checking: $archive"
    tar -xzOf "$archive" .git/hook-logs/complete.log | grep "your-search-term"
done
```

---

## Quick Reference

### Common Commands

```bash
# View current logs
tail -f .git/hook-logs/complete.log

# Create manual archive
tar -czf .git/hook-logs-archive-$(date +%Y%m%d-%H%M%S).tar.gz .git/hook-logs/

# Extract archive
tar -xzf .git/hook-logs-archive-20251104-143025.tar.gz

# List archive contents
tar -tzf .git/hook-logs-archive-20251104-143025.tar.gz

# View log from archive without extracting
tar -xzOf .git/hook-logs-archive-20251104-143025.tar.gz .git/hook-logs/complete.log | less

# Run log cleanup
bash .githooks/clean.sh

# Remove old archives (30+ days)
find .git -name "hook-logs-archive-*.tar.gz" -mtime +30 -delete

# Check archive sizes
du -sh .git/hook-logs-archive-*.tar.gz
```

### Archive Locations Summary

| Type | Location | Pattern |
|------|----------|---------|
| Hook Logs | `.git/` | `hook-logs-archive-YYYYMMDD-HHMMSS.tar.gz` |
| Test Logs | `.githooks/test/` | `test-logs-archive-YYYYMMDD-HHMMSS.tar.gz` |
| Install Logs | `.githooks/logs/` | `install-YYYYMMDD_HHMMSS.log` (not archived) |
| Uninstall Logs | `.githooks/logs/` | `uninstall-YYYYMMDD_HHMMSS.log` (not archived) |

---

## Summary

The hook-logs-archive system provides:

1. ✅ **Automatic archiving** during uninstall
2. ✅ **Timestamped archives** for easy identification
3. ✅ **Automatic log rotation** (256 KB threshold, 2 copies, 21 day retention)
4. ✅ **Manual archiving** capabilities
5. ✅ **Easy extraction** and search
6. ✅ **Space management** with automated cleanup
7. ✅ **Preserved history** while keeping working logs clean

Archives are stored in `.gitignore`, so they won't be committed to version control, keeping your repository clean while preserving historical log data locally.
