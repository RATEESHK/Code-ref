#!/usr/bin/env bash

# ============================================================================
# Rollback Testing Script
# Purpose: Test the installation script's rollback capability
# Tests: Various failure scenarios to ensure complete rollback
# ============================================================================

set -euo pipefail

# Color codes
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly MAGENTA='\033[0;35m'
readonly CYAN='\033[0;36m'
readonly NC='\033[0m'
readonly BOLD='\033[1m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || echo ".")"

echo -e "${CYAN}${BOLD}"
echo "╔════════════════════════════════════════════════════════════════════╗"
echo "║            Installation Rollback Test Suite                        ║"
echo "╚════════════════════════════════════════════════════════════════════╝"
echo -e "${NC}\n"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

#######################################
# Test Functions
#######################################

run_test() {
    local test_name="$1"
    local test_func="$2"
    
    TESTS_RUN=$((TESTS_RUN + 1))
    
    echo -e "${BLUE}${BOLD}Test $TESTS_RUN: $test_name${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    if $test_func; then
        TESTS_PASSED=$((TESTS_PASSED + 1))
        echo -e "${GREEN}✓ PASSED${NC}\n"
    else
        TESTS_FAILED=$((TESTS_FAILED + 1))
        echo -e "${RED}✗ FAILED${NC}\n"
    fi
}

# Save current git config state
save_git_state() {
    local state_file="$1"
    {
        echo "# Git Configuration Snapshot"
        echo "# Generated: $(date)"
        echo ""
        git config --list | grep ^hooks. || echo "# No hooks.* configs found"
        git config --get core.hooksPath || echo "# core.hooksPath not set"
    } > "$state_file"
}

# Compare git states
compare_git_state() {
    local before="$1"
    local after="$2"
    
    diff -u "$before" "$after" || return 1
    return 0
}

#######################################
# Test Scenarios
#######################################

test_normal_installation() {
    echo -e "${YELLOW}Testing normal installation (should succeed)...${NC}"
    
    # Save state
    local state_before="/tmp/git-state-before-$$.txt"
    save_git_state "$state_before"
    
    # Run installation with auto-yes
    if echo "y" | bash "$SCRIPT_DIR/install-hooks.sh" > /tmp/install-output-$$.log 2>&1; then
        echo -e "${GREEN}✓ Installation succeeded${NC}"
        
        # Verify configurations were set
        if git config core.hooksPath | grep -q ".githooks"; then
            echo -e "${GREEN}✓ Hooks path configured${NC}"
        else
            echo -e "${RED}✗ Hooks path not configured${NC}"
            return 1
        fi
        
        # Uninstall to restore
        echo "y" | bash "$SCRIPT_DIR/uninstall-hooks.sh" > /tmp/uninstall-output-$$.log 2>&1
        
        return 0
    else
        echo -e "${RED}✗ Installation failed unexpectedly${NC}"
        return 1
    fi
}

test_gitignore_creation() {
    echo -e "${YELLOW}Testing .gitignore creation (missing file)...${NC}"
    
    # Backup and remove .gitignore
    if [ -f "$REPO_ROOT/.gitignore" ]; then
        mv "$REPO_ROOT/.gitignore" "$REPO_ROOT/.gitignore.test-backup"
    fi
    
    # Run installation with auto-yes to create .gitignore
    if echo "y" | bash "$SCRIPT_DIR/install-hooks.sh" > /tmp/install-gitignore-$$.log 2>&1; then
        echo -e "${GREEN}✓ Installation succeeded${NC}"
        
        # Verify .gitignore was created
        if [ -f "$REPO_ROOT/.gitignore" ]; then
            echo -e "${GREEN}✓ .gitignore file created${NC}"
            
            # Verify it contains hook patterns
            if grep -q "Git Hooks - Custom Ignores" "$REPO_ROOT/.gitignore"; then
                echo -e "${GREEN}✓ Hook patterns added to .gitignore${NC}"
            else
                echo -e "${RED}✗ Hook patterns not found in .gitignore${NC}"
                restore_gitignore_backup
                return 1
            fi
        else
            echo -e "${RED}✗ .gitignore file not created${NC}"
            restore_gitignore_backup
            return 1
        fi
        
        # Cleanup: uninstall and restore
        echo "y" | bash "$SCRIPT_DIR/uninstall-hooks.sh" > /dev/null 2>&1
        restore_gitignore_backup
        
        return 0
    else
        echo -e "${RED}✗ Installation failed${NC}"
        restore_gitignore_backup
        return 1
    fi
}

restore_gitignore_backup() {
    if [ -f "$REPO_ROOT/.gitignore.test-backup" ]; then
        mv "$REPO_ROOT/.gitignore.test-backup" "$REPO_ROOT/.gitignore"
    fi
}

test_gitignore_update() {
    echo -e "${YELLOW}Testing .gitignore update (missing patterns)...${NC}"
    
    # Backup .gitignore
    if [ -f "$REPO_ROOT/.gitignore" ]; then
        cp "$REPO_ROOT/.gitignore" "$REPO_ROOT/.gitignore.test-backup"
    fi
    
    # Create .gitignore without hook patterns
    cat > "$REPO_ROOT/.gitignore" << 'EOF'
# Basic ignores
node_modules/
*.log
EOF
    
    # Run installation with auto-yes to add patterns
    if echo "y" | bash "$SCRIPT_DIR/install-hooks.sh" > /tmp/install-update-$$.log 2>&1; then
        echo -e "${GREEN}✓ Installation succeeded${NC}"
        
        # Verify patterns were added
        if grep -q "Git Hooks - Custom Ignores" "$REPO_ROOT/.gitignore"; then
            echo -e "${GREEN}✓ Hook patterns added to existing .gitignore${NC}"
        else
            echo -e "${RED}✗ Hook patterns not added${NC}"
            restore_gitignore_backup
            return 1
        fi
        
        # Cleanup
        echo "y" | bash "$SCRIPT_DIR/uninstall-hooks.sh" > /dev/null 2>&1
        restore_gitignore_backup
        
        return 0
    else
        echo -e "${RED}✗ Installation failed${NC}"
        restore_gitignore_backup
        return 1
    fi
}

test_rollback_on_interrupt() {
    echo -e "${YELLOW}Testing rollback on user interrupt...${NC}"
    
    # Save state
    local state_before="/tmp/git-state-interrupt-$$.txt"
    save_git_state "$state_before"
    
    # This test is manual - just document the process
    echo -e "${CYAN}Manual test required:${NC}"
    echo "  1. Run: bash .githooks/install-hooks.sh"
    echo "  2. Press Ctrl+C during installation"
    echo "  3. Verify rollback message appears"
    echo "  4. Run: git config --list | grep hooks"
    echo "  5. Verify no hooks.* configs remain"
    
    echo -e "${YELLOW}⚠ Manual verification required${NC}"
    return 0
}

test_idempotent_installation() {
    echo -e "${YELLOW}Testing idempotent installation (run twice)...${NC}"
    
    # Run installation twice
    echo "y" | bash "$SCRIPT_DIR/install-hooks.sh" > /tmp/install-first-$$.log 2>&1
    
    if echo "y" | bash "$SCRIPT_DIR/install-hooks.sh" > /tmp/install-second-$$.log 2>&1; then
        echo -e "${GREEN}✓ Second installation succeeded${NC}"
        
        # Verify configurations are still correct
        if git config core.hooksPath | grep -q ".githooks"; then
            echo -e "${GREEN}✓ Configuration still valid after re-install${NC}"
        else
            echo -e "${RED}✗ Configuration corrupted${NC}"
            return 1
        fi
        
        # Cleanup
        echo "y" | bash "$SCRIPT_DIR/uninstall-hooks.sh" > /dev/null 2>&1
        
        return 0
    else
        echo -e "${RED}✗ Second installation failed${NC}"
        return 1
    fi
}

test_log_creation() {
    echo -e "${YELLOW}Testing log file creation...${NC}"
    
    # Run installation
    echo "y" | bash "$SCRIPT_DIR/install-hooks.sh" > /dev/null 2>&1
    
    # Check for log files
    local log_count=$(ls -1 "$SCRIPT_DIR/logs/install-"*.log 2>/dev/null | wc -l)
    
    if [ "$log_count" -gt 0 ]; then
        echo -e "${GREEN}✓ Installation log created ($log_count files)${NC}"
        
        # Check latest log content
        local latest_log=$(ls -t "$SCRIPT_DIR/logs/install-"*.log 2>/dev/null | head -1)
        if [ -n "$latest_log" ] && [ -f "$latest_log" ]; then
            if grep -q "Installation completed successfully" "$latest_log"; then
                echo -e "${GREEN}✓ Log contains success marker${NC}"
            else
                echo -e "${YELLOW}⚠ Log may not contain success marker${NC}"
            fi
        fi
        
        # Cleanup
        echo "y" | bash "$SCRIPT_DIR/uninstall-hooks.sh" > /dev/null 2>&1
        
        return 0
    else
        echo -e "${RED}✗ No installation log created${NC}"
        return 1
    fi
}

test_rollback_file_cleanup() {
    echo -e "${YELLOW}Testing rollback file cleanup on success...${NC}"
    
    # Run installation
    echo "y" | bash "$SCRIPT_DIR/install-hooks.sh" > /dev/null 2>&1
    
    # Check for leftover rollback files
    local rollback_count=$(ls -1 "$SCRIPT_DIR/logs/.rollback-"*.sh 2>/dev/null | wc -l)
    
    if [ "$rollback_count" -eq 0 ]; then
        echo -e "${GREEN}✓ No rollback files left after successful installation${NC}"
        
        # Cleanup
        echo "y" | bash "$SCRIPT_DIR/uninstall-hooks.sh" > /dev/null 2>&1
        
        return 0
    else
        echo -e "${RED}✗ Rollback files not cleaned up ($rollback_count files)${NC}"
        echo "y" | bash "$SCRIPT_DIR/uninstall-hooks.sh" > /dev/null 2>&1
        return 1
    fi
}

#######################################
# Run All Tests
#######################################

echo -e "${MAGENTA}${BOLD}Running Rollback Test Suite...${NC}\n"

run_test "Normal Installation" test_normal_installation
run_test ".gitignore Creation" test_gitignore_creation
run_test ".gitignore Pattern Update" test_gitignore_update
run_test "Idempotent Installation" test_idempotent_installation
run_test "Log File Creation" test_log_creation
run_test "Rollback File Cleanup" test_rollback_file_cleanup
run_test "Manual Interrupt Test" test_rollback_on_interrupt

#######################################
# Test Summary
#######################################

echo -e "\n${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}${BOLD}                        Test Summary${NC}"
echo -e "${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}\n"

echo -e "${BLUE}Total Tests:${NC}   $TESTS_RUN"
echo -e "${GREEN}Passed:${NC}        $TESTS_PASSED"
echo -e "${RED}Failed:${NC}        $TESTS_FAILED"
echo ""

if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "${GREEN}${BOLD}✓ All tests passed!${NC}\n"
    exit 0
else
    echo -e "${RED}${BOLD}✗ Some tests failed!${NC}\n"
    exit 1
fi
