#!/usr/bin/env bash

#######################################
# Git Hooks - Comprehensive Test Runner
# 
# This script runs the complete test suite with:
# - Automatic environment setup/cleanup
# - Detailed logging
# - State preservation
# - Branch independence
# - Test enablement checks
#######################################

set -euo pipefail

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source test configuration
source "${SCRIPT_DIR}/test-config.sh"

# Colors
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly CYAN='\033[0;36m'
readonly MAGENTA='\033[0;35m'
readonly BOLD='\033[1m'
readonly NC='\033[0m'

# Test results tracking
declare -a TEST_CATEGORIES=()
declare -a TEST_RESULTS=()
declare -a TEST_DURATIONS=()

#######################################
# Logging Functions
#######################################

log_msg() {
    local msg="$*"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    
    # Log to file if LOG_FILE is set
    if [[ -n "${LOG_FILE:-}" ]]; then
        echo "[$timestamp] $msg" | sed 's/\x1b\[[0-9;]*m//g' >> "$LOG_FILE"
    fi
    
    # Display to console
    echo -e "$msg"
}

#######################################
# Test Execution Functions
#######################################

run_test_category() {
    local category="$1"
    local description="$2"
    local test_file="$3"
    
    log_msg "${BLUE}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
    log_msg "${YELLOW}${BOLD}Running: $description${NC}"
    log_msg "${BLUE}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
    
    local start_time=$(date +%s)
    
    # Check if test file exists
    if [[ ! -f "$test_file" ]]; then
        log_msg "${YELLOW}⊘${NC} Test file not found: $test_file"
        TEST_CATEGORIES+=("$category")
        TEST_RESULTS+=("SKIPPED")
        TEST_DURATIONS+=("0")
        return 0
    fi
    
    # Run the test
    local test_output
    local exit_code=0
    
    if test_output=$(bash "$test_file" 2>&1); then
        exit_code=0
    else
        exit_code=$?
    fi
    
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    
    # Log output
    log_msg "$test_output"
    
    # Record results
    TEST_CATEGORIES+=("$category")
    TEST_DURATIONS+=("$duration")
    
    if [[ $exit_code -eq 0 ]]; then
        log_msg "${GREEN}${BOLD}✓ $description - PASSED${NC} (${duration}s)"
        TEST_RESULTS+=("PASSED")
        return 0
    else
        log_msg "${RED}${BOLD}✗ $description - FAILED${NC} (exit code: $exit_code)"
        TEST_RESULTS+=("FAILED")
        return 1
    fi
}

#######################################
# Summary Functions
#######################################

print_final_summary() {
    local total=${#TEST_CATEGORIES[@]}
    local passed=0
    local failed=0
    local skipped=0
    local total_duration=0
    
    # Count results
    for result in "${TEST_RESULTS[@]}"; do
        case "$result" in
            PASSED) ((passed++)) ;;
            FAILED) ((failed++)) ;;
            SKIPPED) ((skipped++)) ;;
        esac
    done
    
    # Calculate total duration
    for duration in "${TEST_DURATIONS[@]}"; do
        total_duration=$((total_duration + duration))
    done
    
    log_msg ""
    log_msg "${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
    log_msg "${BOLD}                 COMPREHENSIVE TEST SUMMARY${NC}"
    log_msg "${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
    log_msg ""
    log_msg "${BOLD}Total Test Categories:${NC}  $total"
    log_msg "${GREEN}${BOLD}Passed:${NC}                 $passed"
    log_msg "${RED}${BOLD}Failed:${NC}                 $failed"
    log_msg "${YELLOW}${BOLD}Skipped:${NC}                $skipped"
    log_msg "${BOLD}Total Duration:${NC}         ${total_duration}s"
    log_msg ""
    
    # Detailed results table
    if [[ $total -gt 0 ]]; then
        log_msg "${BOLD}Detailed Results:${NC}"
        log_msg "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        log_msg "$(printf '%-30s %-12s %-10s' 'Category' 'Result' 'Duration')"
        log_msg "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        
        for i in "${!TEST_CATEGORIES[@]}"; do
            local category="${TEST_CATEGORIES[$i]}"
            local result="${TEST_RESULTS[$i]}"
            local duration="${TEST_DURATIONS[$i]}"
            
            local result_display
            case "$result" in
                PASSED)
                    result_display="${GREEN}✓ PASSED${NC}"
                    ;;
                FAILED)
                    result_display="${RED}✗ FAILED${NC}"
                    ;;
                SKIPPED)
                    result_display="${YELLOW}⊘ SKIPPED${NC}"
                    ;;
            esac
            
            log_msg "$(printf '%-30s %b %-10s' "$category" "$result_display" "${duration}s")"
        done
        
        log_msg "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    fi
    
    log_msg ""
    
    # Final status
    if [[ $failed -eq 0 ]]; then
        log_msg "${GREEN}${BOLD}✓ ALL TESTS PASSED!${NC}"
        log_msg ""
        return 0
    else
        log_msg "${RED}${BOLD}✗ SOME TESTS FAILED!${NC}"
        log_msg ""
        return 1
    fi
}

#######################################
# Main Test Execution
#######################################

main() {
    echo -e "${CYAN}${BOLD}"
    echo "╔════════════════════════════════════════════════════════════════════╗"
    echo "║                                                                    ║"
    echo "║         Git Hooks - Comprehensive Test Suite Runner               ║"
    echo "║                                                                    ║"
    echo "╚════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    # Step 1: Check if tests are enabled
    log_msg "${BOLD}Step 1: Checking test configuration...${NC}"
    if ! is_test_enabled; then
        log_msg "${RED}✗${NC} Tests are not enabled!"
        log_msg ""
        log_msg "${YELLOW}Enable tests with one of:${NC}"
        log_msg "  ${CYAN}git config hooks.tests.enabled true${NC}"
        log_msg "  ${CYAN}export GITHOOKS_TESTS_ENABLED=true${NC}"
        log_msg "  ${CYAN}bash .githooks/test/test-config.sh enable${NC}"
        log_msg ""
        log_msg "${YELLOW}Quick setup for development:${NC}"
        log_msg "  ${CYAN}bash .githooks/test/test-config.sh setup-dev${NC}"
        return 1
    fi
    log_msg "${GREEN}✓${NC} Tests enabled"
    log_msg ""
    
    # Step 2: Display configuration
    log_msg "${BOLD}Step 2: Test configuration...${NC}"
    log_msg "  Base Branch:       ${BOLD}$(get_test_base_branch)${NC}"
    log_msg "  Log Verbosity:     ${BOLD}$(get_log_verbosity)${NC}"
    log_msg "  Auto Cleanup:      ${BOLD}$(is_cleanup_enabled && echo 'enabled' || echo 'disabled')${NC}"
    log_msg "  Preserve State:    ${BOLD}$(is_state_preservation_enabled && echo 'enabled' || echo 'disabled')${NC}"
    log_msg "  Test Categories:   ${BOLD}$(get_test_categories)${NC}"
    log_msg ""
    
    # Step 3: Setup test environment
    log_msg "${BOLD}Step 3: Setting up test environment...${NC}"
    if ! bash "${SCRIPT_DIR}/setup-test-environment.sh"; then
        log_msg "${RED}✗${NC} Failed to setup test environment"
        return 1
    fi
    log_msg ""
    
    # Load log file from setup
    if [[ -f "${SCRIPT_DIR}/.test-state" ]]; then
        source "${SCRIPT_DIR}/.test-state"
    fi
    
    log_msg "${BOLD}Log File:${NC} ${LOG_FILE:-none}"
    log_msg ""
    
    # Step 4: Run all test categories
    log_msg "${BOLD}Step 4: Running test categories...${NC}"
    log_msg ""
    
    local test_start_time=$(date +%s)
    local overall_result=0
    
    # Define test categories
    run_test_category "branch-naming" \
        "Branch Naming & Validation" \
        "${SCRIPT_DIR}/test-scenarios/branch-tests.sh" || overall_result=1
    
    run_test_category "commit-validation" \
        "Commit Message Validation" \
        "${SCRIPT_DIR}/test-scenarios/commit-tests.sh" || overall_result=1
    
    run_test_category "security-checks" \
        "Security & Secrets Detection" \
        "${SCRIPT_DIR}/test-scenarios/security-tests.sh" || overall_result=1
    
    run_test_category "protected-branches" \
        "Protected Branch Enforcement" \
        "${SCRIPT_DIR}/test-scenarios/protected-tests.sh" || overall_result=1
    
    run_test_category "hook-commands" \
        "Hook Command Integration" \
        "${SCRIPT_DIR}/test-scenarios/command-tests.sh" || overall_result=1
    
    run_test_category "logging-system" \
        "Logging & Audit Trail" \
        "${SCRIPT_DIR}/test-scenarios/logging-tests.sh" || overall_result=1
    
    run_test_category "base-branch-enforcement" \
        "Base Branch Validation" \
        "${SCRIPT_DIR}/test-scenarios/base-branch-tests.sh" || overall_result=1
    
    run_test_category "bypass-mechanism" \
        "Hook Bypass & Override" \
        "${SCRIPT_DIR}/test-scenarios/bypass-tests.sh" || overall_result=1
    
    run_test_category "hook-execution" \
        "Direct Hook Execution" \
        "${SCRIPT_DIR}/test-scenarios/hook-execution-tests.sh" || overall_result=1
    
    local test_end_time=$(date +%s)
    local test_duration=$((test_end_time - test_start_time))
    
    log_msg ""
    log_msg "${BOLD}Step 5: Test execution complete${NC} (${test_duration}s)"
    log_msg ""
    
    # Step 6: Print summary
    log_msg "${BOLD}Step 6: Generating test summary...${NC}"
    log_msg ""
    print_final_summary || overall_result=1
    
    # Step 7: Cleanup test environment
    log_msg "${BOLD}Step 7: Cleaning up test environment...${NC}"
    if ! bash "${SCRIPT_DIR}/cleanup-test-environment.sh"; then
        log_msg "${YELLOW}⚠${NC} Cleanup had warnings (continuing)"
    fi
    log_msg ""
    
    # Final status
    log_msg "${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
    if [[ $overall_result -eq 0 ]]; then
        log_msg "${GREEN}${BOLD}✓ TEST SUITE COMPLETED SUCCESSFULLY${NC}"
    else
        log_msg "${RED}${BOLD}✗ TEST SUITE COMPLETED WITH FAILURES${NC}"
    fi
    log_msg "${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
    log_msg ""
    
    if [[ -n "${LOG_FILE:-}" ]]; then
        log_msg "${BOLD}Complete log saved to:${NC} $LOG_FILE"
        log_msg ""
    fi
    
    return $overall_result
}

# Run main
main "$@"
