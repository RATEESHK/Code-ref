#!/usr/bin/env bash
# Security Scanning Test Scenarios
# Tests secret detection and sensitive file checks

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FIXTURES_DIR="$SCRIPT_DIR/../test-fixtures"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test result tracker
pass_test() {
    ((TESTS_PASSED++))
    ((TESTS_RUN++))
    echo -e "${GREEN}✓${NC} $1"
}

fail_test() {
    ((TESTS_FAILED++))
    ((TESTS_RUN++))
    echo -e "${RED}✗${NC} $1"
    echo "  Error: $2"
}

# Test: Detect AWS Access Key
test_detect_aws_access_key() {
    local test_file=$(mktemp)
    echo "AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE" > "$test_file"
    
    if grep -q "AKIA[0-9A-Z]{16}" "$test_file"; then
        pass_test "AWS Access Key detection"
    else
        fail_test "AWS Access Key detection" "Pattern not matched"
    fi
    
    rm -f "$test_file"
}

# Test: Detect AWS Secret Key
test_detect_aws_secret_key() {
    local test_file=$(mktemp)
    echo "AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY" > "$test_file"
    
    if grep -qE "AWS_SECRET(_ACCESS)?_KEY.*['\"]?[A-Za-z0-9/+=]{40}['\"]?" "$test_file"; then
        pass_test "AWS Secret Key detection"
    else
        fail_test "AWS Secret Key detection" "Pattern not matched"
    fi
    
    rm -f "$test_file"
}

# Test: Detect GitHub Token
test_detect_github_token() {
    local test_file=$(mktemp)
    echo "GITHUB_TOKEN=ghp_1234567890abcdefghijklmnopqrstuvwxyz" > "$test_file"
    
    if grep -q "ghp_[0-9a-zA-Z]{36}" "$test_file"; then
        pass_test "GitHub Token detection"
    else
        fail_test "GitHub Token detection" "Pattern not matched"
    fi
    
    rm -f "$test_file"
}

# Test: Detect Slack Webhook
test_detect_slack_webhook() {
    local test_file=$(mktemp)
    echo "SLACK_WEBHOOK_URL=https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXX" > "$test_file"
    
    if grep -q "https://hooks.slack.com/services/T[A-Z0-9]{8}/B[A-Z0-9]{8}/[A-Za-z0-9]{24}" "$test_file"; then
        pass_test "Slack Webhook detection"
    else
        fail_test "Slack Webhook detection" "Pattern not matched"
    fi
    
    rm -f "$test_file"
}

# Test: Detect Google API Key
test_detect_google_api_key() {
    local test_file=$(mktemp)
    echo "GOOGLE_API_KEY=AIzaSyDaGmWKa4JsXZ-HjGw7ISLn_3namBGewQe" > "$test_file"
    
    if grep -q "AIza[0-9A-Za-z\-_]{35}" "$test_file"; then
        pass_test "Google API Key detection"
    else
        fail_test "Google API Key detection" "Pattern not matched"
    fi
    
    rm -f "$test_file"
}

# Test: Detect Private Key
test_detect_private_key() {
    local test_file=$(mktemp)
    echo "-----BEGIN RSA PRIVATE KEY-----" > "$test_file"
    echo "MIIEpAIBAAKCAQEA1234567890abcdef" >> "$test_file"
    echo "-----END RSA PRIVATE KEY-----" >> "$test_file"
    
    if grep -q "BEGIN.*PRIVATE KEY" "$test_file"; then
        pass_test "Private Key detection"
    else
        fail_test "Private Key detection" "Pattern not matched"
    fi
    
    rm -f "$test_file"
}

# Test: Detect Password
test_detect_password() {
    local test_file=$(mktemp)
    echo "database_password=MySecretP@ssw0rd123" > "$test_file"
    
    if grep -qiE "password.*=.*['\"]?[^ '\"]{8,}['\"]?" "$test_file"; then
        pass_test "Password detection"
    else
        fail_test "Password detection" "Pattern not matched"
    fi
    
    rm -f "$test_file"
}

# Test: Detect JWT Token
test_detect_jwt_token() {
    local test_file=$(mktemp)
    echo "JWT_TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.SflKxwRJSMeKKF2Q" > "$test_file"
    
    if grep -q "eyJ[A-Za-z0-9_-]*\.eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*" "$test_file"; then
        pass_test "JWT Token detection"
    else
        fail_test "JWT Token detection" "Pattern not matched"
    fi
    
    rm -f "$test_file"
}

# Test: Detect Sensitive File - .env
test_detect_env_file() {
    local test_file=".env"
    touch "$test_file"
    
    if [[ "$test_file" =~ \.env(\..+)?$ ]]; then
        pass_test "Sensitive file detection (.env)"
    else
        fail_test "Sensitive file detection (.env)" "Pattern not matched"
    fi
    
    rm -f "$test_file"
}

# Test: Detect Sensitive File - private key
test_detect_key_file() {
    local test_file="private.key"
    touch "$test_file"
    
    if [[ "$test_file" =~ \.(key|pem)$ ]]; then
        pass_test "Sensitive file detection (.key)"
    else
        fail_test "Sensitive file detection (.key)" "Pattern not matched"
    fi
    
    rm -f "$test_file"
}

# Test: Detect Sensitive File - credentials
test_detect_credentials_file() {
    local test_file="credentials.json"
    touch "$test_file"
    
    if [[ "$test_file" =~ credentials\.(json|xml|yml|yaml)$ ]]; then
        pass_test "Sensitive file detection (credentials)"
    else
        fail_test "Sensitive file detection (credentials)" "Pattern not matched"
    fi
    
    rm -f "$test_file"
}

# Test: Allow non-sensitive files
test_allow_safe_files() {
    local test_file="config.json"
    touch "$test_file"
    
    if ! [[ "$test_file" =~ \.env|\.(key|pem)$|credentials|secrets|\.(cer|crt|pfx)$|password ]]; then
        pass_test "Allow safe files (config.json)"
    else
        fail_test "Allow safe files (config.json)" "Incorrectly flagged as sensitive"
    fi
    
    rm -f "$test_file"
}

# Test: Full secret scan with fixture file
test_full_secret_scan() {
    if [[ -f "$FIXTURES_DIR/secret-patterns.txt" ]]; then
        local matches=$(grep -cE "AKIA[0-9A-Z]{16}|AWS_SECRET|ghp_|hooks\.slack\.com|AIza[0-9A-Za-z\-_]{35}|BEGIN.*PRIVATE KEY|password.*=|eyJ[A-Za-z0-9_-]*\.eyJ" "$FIXTURES_DIR/secret-patterns.txt" || true)
        
        if [[ $matches -gt 5 ]]; then
            pass_test "Full secret scan (found $matches patterns)"
        else
            fail_test "Full secret scan" "Expected >5 matches, got $matches"
        fi
    else
        fail_test "Full secret scan" "Fixture file not found"
    fi
}

# Test: Performance on large file
test_scan_performance() {
    local test_file=$(mktemp)
    local start_time end_time duration
    
    # Create large file (1000 lines)
    for i in {1..1000}; do
        echo "Line $i: Some normal code without secrets" >> "$test_file"
    done
    
    start_time=$(date +%s%N)
    grep -qE "AKIA[0-9A-Z]{16}|ghp_|eyJ[A-Za-z0-9_-]*\.eyJ" "$test_file" || true
    end_time=$(date +%s%N)
    
    duration=$(((end_time - start_time) / 1000000)) # Convert to milliseconds
    
    if [[ $duration -lt 1000 ]]; then # Less than 1 second
        pass_test "Performance test (${duration}ms)"
    else
        fail_test "Performance test" "Scan took ${duration}ms (>1000ms)"
    fi
    
    rm -f "$test_file"
}

# Run all tests
main() {
    echo "========================================"
    echo "Security Scanning Test Scenarios"
    echo "========================================"
    echo ""
    
    test_detect_aws_access_key
    test_detect_aws_secret_key
    test_detect_github_token
    test_detect_slack_webhook
    test_detect_google_api_key
    test_detect_private_key
    test_detect_password
    test_detect_jwt_token
    test_detect_env_file
    test_detect_key_file
    test_detect_credentials_file
    test_allow_safe_files
    test_full_secret_scan
    test_scan_performance
    
    echo ""
    echo "========================================"
    echo "Test Results"
    echo "========================================"
    echo "Tests run: $TESTS_RUN"
    echo -e "Passed: ${GREEN}$TESTS_PASSED${NC}"
    echo -e "Failed: ${RED}$TESTS_FAILED${NC}"
    
    if [[ $TESTS_FAILED -eq 0 ]]; then
        echo -e "${GREEN}All tests passed!${NC}"
        exit 0
    else
        echo -e "${RED}Some tests failed${NC}"
        exit 1
    fi
}

main "$@"
