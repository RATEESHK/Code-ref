#!/bin/bash

#######################################
# Git Hooks Test Configuration
# 
# This file controls test execution behavior, logging, and cleanup.
# Configure these settings via git config or environment variables.
#######################################

set -euo pipefail

# Color codes
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly CYAN='\033[0;36m'
readonly BOLD='\033[1m'
readonly NC='\033[0m'

#######################################
# Test Execution Control
#######################################

# Check if tests are enabled
# Priority: Environment variable > Git config > Default (disabled)
is_test_enabled() {
    # Check environment variable first
    if [[ -n "${GITHOOKS_TESTS_ENABLED:-}" ]]; then
        [[ "${GITHOOKS_TESTS_ENABLED}" == "true" || "${GITHOOKS_TESTS_ENABLED}" == "1" ]]
        return $?
    fi
    
    # Check git config
    local enabled=$(git config --get hooks.tests.enabled 2>/dev/null || echo "false")
    [[ "$enabled" == "true" ]]
}

# Enable tests
enable_tests() {
    git config hooks.tests.enabled "true"
    echo -e "${GREEN}✓${NC} Tests enabled"
}

# Disable tests
disable_tests() {
    git config hooks.tests.enabled "false"
    echo -e "${YELLOW}✓${NC} Tests disabled"
}

#######################################
# Test Base Branch Configuration
#######################################

# Get the base branch to run tests from
# Priority: Environment variable > Git config > Default (develop)
get_test_base_branch() {
    if [[ -n "${GITHOOKS_TEST_BASE_BRANCH:-}" ]]; then
        echo "${GITHOOKS_TEST_BASE_BRANCH}"
    else
        git config --get hooks.tests.baseBranch 2>/dev/null || echo "develop"
    fi
}

# Set the base branch for tests
set_test_base_branch() {
    local branch="$1"
    git config hooks.tests.baseBranch "$branch"
    echo -e "${GREEN}✓${NC} Test base branch set to: ${BOLD}$branch${NC}"
}

#######################################
# Logging Configuration
#######################################

# Get log directory
get_log_dir() {
    local script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    echo "${script_dir}/logs"
}

# Get log verbosity level
# Priority: Environment variable > Git config > Default (normal)
# Levels: quiet (0), normal (1), verbose (2), debug (3)
get_log_verbosity() {
    if [[ -n "${GITHOOKS_TEST_LOG_LEVEL:-}" ]]; then
        echo "${GITHOOKS_TEST_LOG_LEVEL}"
    else
        git config --get hooks.tests.logVerbosity 2>/dev/null || echo "normal"
    fi
}

# Set log verbosity
set_log_verbosity() {
    local level="$1"
    case "$level" in
        quiet|normal|verbose|debug)
            git config hooks.tests.logVerbosity "$level"
            echo -e "${GREEN}✓${NC} Log verbosity set to: ${BOLD}$level${NC}"
            ;;
        *)
            echo -e "${RED}✗${NC} Invalid log level: $level (use: quiet, normal, verbose, debug)"
            return 1
            ;;
    esac
}

# Get log file path for current test run
get_current_log_file() {
    local log_dir="$(get_log_dir)"
    local timestamp=$(date +"%Y%m%d_%H%M%S")
    echo "${log_dir}/test-run-${timestamp}.log"
}

# Check if logging is enabled
is_logging_enabled() {
    local verbosity=$(get_log_verbosity)
    [[ "$verbosity" != "quiet" ]]
}

#######################################
# Cleanup Configuration
#######################################

# Check if auto-cleanup is enabled
# Priority: Environment variable > Git config > Default (true)
is_cleanup_enabled() {
    if [[ -n "${GITHOOKS_TEST_CLEANUP:-}" ]]; then
        [[ "${GITHOOKS_TEST_CLEANUP}" == "true" || "${GITHOOKS_TEST_CLEANUP}" == "1" ]]
        return $?
    fi
    
    local cleanup=$(git config --get hooks.tests.autoCleanup 2>/dev/null || echo "true")
    [[ "$cleanup" == "true" ]]
}

# Enable auto-cleanup
enable_cleanup() {
    git config hooks.tests.autoCleanup "true"
    echo -e "${GREEN}✓${NC} Auto-cleanup enabled"
}

# Disable auto-cleanup
disable_cleanup() {
    git config hooks.tests.autoCleanup "false"
    echo -e "${YELLOW}✓${NC} Auto-cleanup disabled (test artifacts will remain)"
}

#######################################
# Test Category Configuration
#######################################

# Get enabled test categories
# Priority: Environment variable > Git config > Default (all)
get_test_categories() {
    if [[ -n "${GITHOOKS_TEST_CATEGORIES:-}" ]]; then
        echo "${GITHOOKS_TEST_CATEGORIES}"
    else
        git config --get hooks.tests.categories 2>/dev/null || echo "all"
    fi
}

# Set test categories
set_test_categories() {
    local categories="$1"
    git config hooks.tests.categories "$categories"
    echo -e "${GREEN}✓${NC} Test categories set to: ${BOLD}$categories${NC}"
}

#######################################
# State Preservation Configuration
#######################################

# Check if state preservation is enabled (save/restore branch, stash)
# Priority: Environment variable > Git config > Default (true)
is_state_preservation_enabled() {
    if [[ -n "${GITHOOKS_TEST_PRESERVE_STATE:-}" ]]; then
        [[ "${GITHOOKS_TEST_PRESERVE_STATE}" == "true" || "${GITHOOKS_TEST_PRESERVE_STATE}" == "1" ]]
        return $?
    fi
    
    local preserve=$(git config --get hooks.tests.preserveState 2>/dev/null || echo "true")
    [[ "$preserve" == "true" ]]
}

#######################################
# Configuration Display
#######################################

# Display current configuration
show_config() {
    echo -e "${BOLD}${CYAN}Git Hooks Test Configuration${NC}"
    echo -e "${CYAN}════════════════════════════════════════${NC}"
    
    echo -e "\n${BOLD}Execution Control:${NC}"
    if is_test_enabled; then
        echo -e "  Tests Enabled:        ${GREEN}YES${NC}"
    else
        echo -e "  Tests Enabled:        ${RED}NO${NC}"
    fi
    
    echo -e "\n${BOLD}Test Environment:${NC}"
    echo -e "  Base Branch:          ${BOLD}$(get_test_base_branch)${NC}"
    if is_state_preservation_enabled; then
        echo -e "  Preserve State:       ${GREEN}YES${NC}"
    else
        echo -e "  Preserve State:       ${YELLOW}NO${NC}"
    fi
    
    echo -e "\n${BOLD}Logging:${NC}"
    echo -e "  Verbosity:            ${BOLD}$(get_log_verbosity)${NC}"
    echo -e "  Log Directory:        $(get_log_dir)"
    
    echo -e "\n${BOLD}Cleanup:${NC}"
    if is_cleanup_enabled; then
        echo -e "  Auto-cleanup:         ${GREEN}ENABLED${NC}"
    else
        echo -e "  Auto-cleanup:         ${YELLOW}DISABLED${NC}"
    fi
    
    echo -e "\n${BOLD}Test Categories:${NC}"
    echo -e "  Categories:           ${BOLD}$(get_test_categories)${NC}"
    
    echo -e "\n${CYAN}════════════════════════════════════════${NC}"
    echo -e "${BOLD}Configuration Commands:${NC}"
    echo -e "  Enable tests:         ${CYAN}git config hooks.tests.enabled true${NC}"
    echo -e "  Set base branch:      ${CYAN}git config hooks.tests.baseBranch <branch>${NC}"
    echo -e "  Set log level:        ${CYAN}git config hooks.tests.logVerbosity <level>${NC}"
    echo -e "  Set categories:       ${CYAN}git config hooks.tests.categories <categories>${NC}"
    echo -e "  Disable cleanup:      ${CYAN}git config hooks.tests.autoCleanup false${NC}"
    
    echo -e "\n${BOLD}Environment Variables:${NC}"
    echo -e "  GITHOOKS_TESTS_ENABLED=true"
    echo -e "  GITHOOKS_TEST_BASE_BRANCH=develop"
    echo -e "  GITHOOKS_TEST_LOG_LEVEL=verbose"
    echo -e "  GITHOOKS_TEST_CLEANUP=true"
    echo -e "  GITHOOKS_TEST_CATEGORIES=all"
    echo ""
}

#######################################
# Quick Setup Functions
#######################################

# Quick setup for development testing
setup_dev_testing() {
    enable_tests
    set_test_base_branch "develop"
    set_log_verbosity "verbose"
    enable_cleanup
    set_test_categories "all"
    echo -e "${GREEN}✓${NC} Development testing configured"
}

# Quick setup for CI/CD testing
setup_ci_testing() {
    enable_tests
    set_test_base_branch "main"
    set_log_verbosity "normal"
    enable_cleanup
    set_test_categories "all"
    echo -e "${GREEN}✓${NC} CI/CD testing configured"
}

# Reset all configuration to defaults
reset_config() {
    git config --unset hooks.tests.enabled 2>/dev/null || true
    git config --unset hooks.tests.baseBranch 2>/dev/null || true
    git config --unset hooks.tests.logVerbosity 2>/dev/null || true
    git config --unset hooks.tests.autoCleanup 2>/dev/null || true
    git config --unset hooks.tests.categories 2>/dev/null || true
    git config --unset hooks.tests.preserveState 2>/dev/null || true
    echo -e "${GREEN}✓${NC} Test configuration reset to defaults"
}

#######################################
# Main Entry Point (for direct execution)
#######################################

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-show}" in
        show|config)
            show_config
            ;;
        enable)
            enable_tests
            ;;
        disable)
            disable_tests
            ;;
        setup-dev)
            setup_dev_testing
            show_config
            ;;
        setup-ci)
            setup_ci_testing
            show_config
            ;;
        reset)
            reset_config
            ;;
        *)
            echo -e "${RED}✗${NC} Unknown command: $1"
            echo -e "\nUsage: $0 {show|enable|disable|setup-dev|setup-ci|reset}"
            exit 1
            ;;
    esac
fi
