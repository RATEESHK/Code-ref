#!/bin/bash

#######################################
# Test Environment Cleanup Script
# 
# This script cleans up after test execution by:
# 1. Removing test branches and artifacts
# 2. Restoring original branch
# 3. Popping stashed changes
# 4. Archiving test logs
# 5. Restoring git configurations
#######################################

set -euo pipefail

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source configuration
source "${SCRIPT_DIR}/test-config.sh"

# Color codes
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly CYAN='\033[0;36m'
readonly BOLD='\033[1m'
readonly NC='\033[0m'

# State file to track saved state
readonly STATE_FILE="${SCRIPT_DIR}/.test-state"

#######################################
# Logging Functions
#######################################

log() {
    local level="$1"
    shift
    local message="$*"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    
    # Log to file if LOG_FILE is set
    if [[ -n "${LOG_FILE:-}" && -f "$LOG_FILE" ]]; then
        echo "[$timestamp] [$level] $message" >> "$LOG_FILE"
    fi
    
    # Log to console based on verbosity
    local verbosity=$(get_log_verbosity)
    case "$level" in
        ERROR)
            echo -e "${RED}✗${NC} $message" >&2
            ;;
        WARN)
            echo -e "${YELLOW}⚠${NC} $message"
            ;;
        INFO)
            if [[ "$verbosity" != "quiet" ]]; then
                echo -e "${BLUE}ℹ${NC} $message"
            fi
            ;;
        SUCCESS)
            if [[ "$verbosity" != "quiet" ]]; then
                echo -e "${GREEN}✓${NC} $message"
            fi
            ;;
        DEBUG)
            if [[ "$verbosity" == "debug" || "$verbosity" == "verbose" ]]; then
                echo -e "${CYAN}[DEBUG]${NC} $message"
            fi
            ;;
    esac
}

#######################################
# Load Saved State
#######################################

load_state() {
    log "INFO" "Loading saved state..."
    
    if [[ ! -f "$STATE_FILE" ]]; then
        log "WARN" "No state file found (tests may not have been setup properly)"
        return 1
    fi
    
    # Source the state file to load variables
    source "$STATE_FILE"
    
    log "DEBUG" "State loaded from: $STATE_FILE"
    log "DEBUG" "Original branch: ${CURRENT_BRANCH:-unknown}"
    log "DEBUG" "Stash created: ${STASH_CREATED:-false}"
    log "DEBUG" "Log file: ${LOG_FILE:-none}"
    
    return 0
}

#######################################
# Clean Test Artifacts
#######################################

clean_test_artifacts() {
    if ! is_cleanup_enabled; then
        log "INFO" "Auto-cleanup disabled, skipping artifact cleanup"
        return 0
    fi
    
    log "INFO" "Cleaning test artifacts..."
    
    local cleaned=0
    
    # Get list of test branches (common patterns)
    local test_branch_patterns=(
        "test-*"
        "feat-*-test"
        "feature-*-test"
        "bugfix-*-test"
        "hotfix-*-test"
        "temp-test-*"
    )
    
    for pattern in "${test_branch_patterns[@]}"; do
        while IFS= read -r branch; do
            if [[ -n "$branch" ]]; then
                log "DEBUG" "Deleting test branch: $branch"
                git branch -D "$branch" 2>/dev/null || true
                ((cleaned++))
            fi
        done < <(git branch --list "$pattern" 2>/dev/null | sed 's/^[* ]*//' || true)
    done
    
    # Clean test tags
    while IFS= read -r tag; do
        if [[ -n "$tag" ]]; then
            log "DEBUG" "Deleting test tag: $tag"
            git tag -d "$tag" 2>/dev/null || true
            ((cleaned++))
        fi
    done < <(git tag -l "test-*" 2>/dev/null || true)
    
    # Clean temporary test files
    local test_files=(
        "${SCRIPT_DIR}/.test-temp-*"
        "${SCRIPT_DIR}/test-scenarios/.test-*"
        "${SCRIPT_DIR}/test-fixtures/.test-*"
    )
    
    for pattern in "${test_files[@]}"; do
        for file in $pattern 2>/dev/null; do
            if [[ -f "$file" ]]; then
                log "DEBUG" "Removing test file: $file"
                rm -f "$file"
                ((cleaned++))
            fi
        done
    done
    
    if [[ $cleaned -gt 0 ]]; then
        log "SUCCESS" "Cleaned $cleaned test artifacts"
    else
        log "DEBUG" "No test artifacts to clean"
    fi
    
    return 0
}

#######################################
# Restore Original Branch
#######################################

restore_branch() {
    if ! is_state_preservation_enabled; then
        log "INFO" "State preservation disabled, skipping branch restore"
        return 0
    fi
    
    log "INFO" "Restoring original branch..."
    
    local original_branch="${CURRENT_BRANCH:-}"
    
    if [[ -z "$original_branch" ]]; then
        log "WARN" "No original branch to restore"
        return 0
    fi
    
    local current_branch=$(git symbolic-ref --short HEAD 2>/dev/null || echo "")
    
    if [[ "$current_branch" == "$original_branch" ]]; then
        log "INFO" "Already on original branch: $original_branch"
        return 0
    fi
    
    log "DEBUG" "Switching from '$current_branch' to '$original_branch'"
    
    # Try to checkout the original branch
    if git checkout "$original_branch" > /dev/null 2>&1; then
        log "SUCCESS" "Restored original branch: $original_branch"
    else
        log "WARN" "Could not restore original branch: $original_branch"
        log "INFO" "You may need to manually switch back with: git checkout $original_branch"
    fi
    
    return 0
}

#######################################
# Restore Stashed Changes
#######################################

restore_stash() {
    if ! is_state_preservation_enabled; then
        log "INFO" "State preservation disabled, skipping stash restore"
        return 0
    fi
    
    local stash_created="${STASH_CREATED:-false}"
    
    if [[ "$stash_created" != "true" ]]; then
        log "DEBUG" "No stash to restore"
        return 0
    fi
    
    log "INFO" "Restoring stashed changes..."
    
    # Find the test stash
    local stash_ref=$(git stash list | grep "Githooks test environment backup" | head -n 1 | cut -d: -f1)
    
    if [[ -z "$stash_ref" ]]; then
        log "WARN" "Could not find test environment stash"
        return 0
    fi
    
    log "DEBUG" "Found stash: $stash_ref"
    
    # Try to apply the stash
    if git stash pop "$stash_ref" > /dev/null 2>&1; then
        log "SUCCESS" "Restored stashed changes"
    else
        log "WARN" "Could not apply stash (may have conflicts)"
        log "INFO" "Check stash manually with: git stash list"
    fi
    
    return 0
}

#######################################
# Restore Git Configurations
#######################################

restore_configs() {
    if ! is_state_preservation_enabled; then
        log "INFO" "State preservation disabled, skipping config restore"
        return 0
    fi
    
    log "INFO" "Restoring git configurations..."
    
    local max_commits="${CONFIG_MAX_COMMITS:-}"
    local auto_add="${CONFIG_AUTO_ADD:-}"
    local parallel="${CONFIG_PARALLEL:-}"
    
    local restored=0
    
    # Restore max commits config
    if [[ -n "$max_commits" ]]; then
        git config hooks.maxCommitsToPush "$max_commits"
        log "DEBUG" "Restored hooks.maxCommitsToPush=$max_commits"
        ((restored++))
    else
        git config --unset hooks.maxCommitsToPush 2>/dev/null || true
    fi
    
    # Restore auto add config
    if [[ -n "$auto_add" ]]; then
        git config hooks.autoAddAfterFix "$auto_add"
        log "DEBUG" "Restored hooks.autoAddAfterFix=$auto_add"
        ((restored++))
    else
        git config --unset hooks.autoAddAfterFix 2>/dev/null || true
    fi
    
    # Restore parallel execution config
    if [[ -n "$parallel" ]]; then
        git config hooks.parallelExecution "$parallel"
        log "DEBUG" "Restored hooks.parallelExecution=$parallel"
        ((restored++))
    else
        git config --unset hooks.parallelExecution 2>/dev/null || true
    fi
    
    if [[ $restored -gt 0 ]]; then
        log "SUCCESS" "Restored $restored configurations"
    else
        log "DEBUG" "No configurations to restore"
    fi
    
    return 0
}

#######################################
# Finalize Logs
#######################################

finalize_logs() {
    local log_file="${LOG_FILE:-}"
    
    if [[ -z "$log_file" || ! -f "$log_file" ]]; then
        log "DEBUG" "No log file to finalize"
        return 0
    fi
    
    log "INFO" "Finalizing test logs..."
    
    # Write log footer
    cat >> "$log_file" << EOF

================================================================================
Test Execution Completed
Finished: $(date +"%Y-%m-%d %H:%M:%S")
================================================================================
EOF
    
    # Display log location
    log "SUCCESS" "Test log saved to: $log_file"
    
    # Display log summary
    local log_dir=$(get_log_dir)
    local log_count=$(find "$log_dir" -name "test-run-*.log" 2>/dev/null | wc -l)
    log "INFO" "Total test runs logged: $log_count"
    
    return 0
}

#######################################
# Clean State File
#######################################

clean_state_file() {
    if [[ -f "$STATE_FILE" ]]; then
        log "DEBUG" "Removing state file: $STATE_FILE"
        rm -f "$STATE_FILE"
        log "SUCCESS" "State file cleaned"
    fi
    
    return 0
}

#######################################
# Main Cleanup Process
#######################################

main() {
    echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BOLD}${CYAN}        Git Hooks Test Environment Cleanup${NC}"
    echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo ""
    
    # Step 1: Load saved state
    local state_loaded=false
    if load_state; then
        state_loaded=true
    fi
    
    # Step 2: Clean test artifacts
    if ! clean_test_artifacts; then
        log "WARN" "Failed to clean some test artifacts"
    fi
    
    # Step 3: Restore original branch
    if $state_loaded; then
        if ! restore_branch; then
            log "WARN" "Failed to restore original branch"
        fi
    fi
    
    # Step 4: Restore stashed changes
    if $state_loaded; then
        if ! restore_stash; then
            log "WARN" "Failed to restore stashed changes"
        fi
    fi
    
    # Step 5: Restore git configurations
    if $state_loaded; then
        if ! restore_configs; then
            log "WARN" "Failed to restore some configurations"
        fi
    fi
    
    # Step 6: Finalize logs
    if ! finalize_logs; then
        log "WARN" "Failed to finalize logs"
    fi
    
    # Step 7: Clean state file
    if ! clean_state_file; then
        log "WARN" "Failed to clean state file"
    fi
    
    echo ""
    echo -e "${BOLD}${GREEN}✓ Test environment cleanup complete${NC}"
    echo ""
    
    if is_cleanup_enabled; then
        echo -e "${BOLD}Cleanup:${NC}          All test artifacts removed"
    else
        echo -e "${BOLD}Cleanup:${NC}          ${YELLOW}Disabled${NC} - test artifacts retained"
    fi
    
    if is_state_preservation_enabled; then
        echo -e "${BOLD}State:${NC}            Restored to original state"
    else
        echo -e "${BOLD}State:${NC}            ${YELLOW}Not preserved${NC}"
    fi
    
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    
    return 0
}

# Run main if executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
