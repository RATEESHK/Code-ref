# Git Hooks - Testing Guide

**Version**: 3.0  
**Status**: Production-Ready ✅  
**Last Updated**: November 4, 2025

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Test Infrastructure](#test-infrastructure)
3. [Installation & Setup](#installation--setup)
4. [Running Tests](#running-tests)
5. [Test Categories](#test-categories)
6. [Test Configuration](#test-configuration)
7. [Writing Tests](#writing-tests)
8. [Test State Management](#test-state-management)
9. [Debugging Tests](#debugging-tests)
10. [CI/CD Integration](#cicd-integration)

---

## Overview

### What is the Test Infrastructure?

The Git Hooks test infrastructure is a comprehensive testing framework that validates all hook functionality through automated tests. It includes:

- **84+ automated tests** across 9 categories
- **State management** for clean test execution
- **Branch independence** - tests don't affect working branch
- **Configurable execution** - run all or specific tests
- **Comprehensive logging** - detailed test results
- **Rollback testing** - validates installation rollback mechanism

### Test Philosophy

1. **Non-Destructive**: Tests never modify your working state permanently
2. **Isolated**: Each test runs in isolated environment
3. **Repeatable**: Tests can be run multiple times with same results
4. **Fast**: Optimized for quick feedback
5. **Comprehensive**: Cover all hook features and edge cases

### Test Coverage

```
Branch Naming Tests          : 15 tests
Commit Message Tests         : 12 tests
Security Scanning Tests      : 18 tests
Base Branch Enforcement Tests: 10 tests
History Curation Tests       : 8 tests
Protected Branch Tests       : 6 tests
Custom Commands Tests        : 7 tests
Hook Integration Tests       : 5 tests
Rollback Tests              : 7 tests
─────────────────────────────────────
Total                       : 88 tests
```

---

## Test Infrastructure

### File Structure

```
.githooks/test/
├── test-config.sh                    # Test configuration management
├── setup-test-environment.sh         # Pre-test setup
├── cleanup-test-environment.sh       # Post-test cleanup
├── run-comprehensive-tests.sh        # Main test runner
├── logs/                             # Test execution logs
│   ├── test-run-YYYYMMDD_HHMMSS.log
│   └── cleanup-YYYYMMDD_HHMMSS.log
├── .test-state                       # Test state file (temporary)
└── test-scenarios/                   # Individual test scripts
    ├── test-branch-naming.sh
    ├── test-commit-messages.sh
    ├── test-security-scanning.sh
    ├── test-base-branch.sh
    ├── test-history-curation.sh
    ├── test-protected-branches.sh
    ├── test-custom-commands.sh
    ├── test-hook-integration.sh
    └── test-rollback.sh
```

### Components

#### 1. Test Configuration (test-config.sh)

**Purpose**: Manage test infrastructure settings

**Functions**:
- `setup-dev` - Enable tests for development
- `setup-ci` - Enable tests for CI/CD
- `show` - Display current configuration
- `reset` - Reset all test settings
- `status` - Check if tests are enabled

**Configuration Keys**:
```bash
hooks.tests.enabled=true              # Enable/disable tests
hooks.tests.baseBranch=develop        # Base branch for resets
hooks.tests.logVerbosity=detailed     # Log verbosity
hooks.tests.autoCleanup=true          # Auto cleanup after tests
hooks.tests.categories=all            # Test categories to run
hooks.tests.preserveState=false       # Preserve state on failure
```

#### 2. Setup Script (setup-test-environment.sh)

**Purpose**: Prepare environment before test execution

**Operations**:
1. Save current repository state
2. Save current branch
3. Save staged files
4. Save working tree status
5. Create test state file
6. Configure test environment
7. Create test log directory

**State Saved**:
```bash
# .test-state format
ORIGINAL_BRANCH=main
ORIGINAL_COMMIT=abc123
STAGED_FILES=src/file1.js,src/file2.js
WORKING_CLEAN=true
TEST_START_TIME=2025-11-04 10:30:00
```

#### 3. Cleanup Script (cleanup-test-environment.sh)

**Purpose**: Restore environment after test execution

**Operations**:
1. Read test state file
2. Restore original branch
3. Restore staged files
4. Clean test branches
5. Clean test commits
6. Clean test artifacts
7. Remove test state file

**Cleanup Actions**:
- Delete test branches (`hook-test-*`)
- Remove test tags
- Restore working tree
- Archive test logs
- Clean temporary files

#### 4. Test Runner (run-comprehensive-tests.sh)

**Purpose**: Execute all or specific test categories

**Features**:
- Category selection
- Parallel execution
- Progress reporting
- Result summary
- Failure handling
- Log management

**Usage**:
```bash
# Run all tests
bash .githooks/test/run-comprehensive-tests.sh

# Run specific category
bash .githooks/test/run-comprehensive-tests.sh branch

# Run multiple categories
bash .githooks/test/run-comprehensive-tests.sh branch,commit,security

# Run with options
bash .githooks/test/run-comprehensive-tests.sh --verbose --no-cleanup
```

---

## Installation & Setup

### Quick Setup

```bash
# Method 1: During installation
bash .githooks/install-hooks.sh
# When prompted "Would you like to enable tests now? (y/N):" type 'y'

# Method 2: After installation
bash .githooks/test/test-config.sh setup-dev

# Method 3: Manual configuration
git config hooks.tests.enabled true
git config hooks.tests.baseBranch develop
git config hooks.tests.logVerbosity detailed
git config hooks.tests.autoCleanup true
```

### Setup for Development

```bash
# Full development setup
bash .githooks/test/test-config.sh setup-dev

# What it does:
# ✓ Enables test infrastructure
# ✓ Sets base branch to 'develop'
# ✓ Enables detailed logging
# ✓ Enables auto cleanup
# ✓ Configures all test categories
# ✓ Creates test log directory
```

### Setup for CI/CD

```bash
# CI/CD optimized setup
bash .githooks/test/test-config.sh setup-ci

# What it does:
# ✓ Enables test infrastructure
# ✓ Sets base branch from CI environment
# ✓ Enables minimal logging (faster)
# ✓ Enables strict cleanup
# ✓ Configures parallel execution
# ✓ Sets appropriate timeouts
```

### Verification

```bash
# Check if tests are enabled
bash .githooks/test/test-config.sh status
# Output: Tests are enabled

# Show configuration
bash .githooks/test/test-config.sh show
# Output: Complete configuration details

# Test basic functionality
bash .githooks/test/run-comprehensive-tests.sh branch
# Should run branch naming tests
```

### Disabling Tests

```bash
# Disable tests
git config hooks.tests.enabled false

# Or reset completely
bash .githooks/test/test-config.sh reset
```

---

## Running Tests

### Run All Tests

```bash
# Run complete test suite
bash .githooks/test/run-comprehensive-tests.sh

# Expected output:
# ╔════════════════════════════════════════════════════════════════════╗
# ║              Git Hooks Comprehensive Test Suite                    ║
# ╚════════════════════════════════════════════════════════════════════╝
# 
# Running 84 tests across 9 categories...
# 
# [1/9] Branch Naming Tests (15 tests)
# ✓ Test 1: Valid feature branch name
# ✓ Test 2: Valid bugfix branch name
# ...
# 
# [9/9] Rollback Tests (7 tests)
# ✓ Test 1: Rollback on installation failure
# ...
# 
# ═══════════════════════════════════════════════════════════════════
#                         Test Summary
# ═══════════════════════════════════════════════════════════════════
# Total Tests:    84
# Passed:         84
# Failed:         0
# Skipped:        0
# Duration:       45 seconds
# 
# ✓ All tests passed!
```

### Run Specific Category

```bash
# Run branch naming tests only
bash .githooks/test/run-comprehensive-tests.sh branch

# Run commit message tests
bash .githooks/test/run-comprehensive-tests.sh commit

# Run security tests
bash .githooks/test/run-comprehensive-tests.sh security

# Available categories:
# - branch        : Branch naming validation
# - commit        : Commit message validation
# - security      : Secret scanning and sensitive files
# - basebranch    : Base branch enforcement
# - history       : History curation (commit limits)
# - protected     : Protected branch detection
# - commands      : Custom command execution
# - integration   : Hook integration tests
# - rollback      : Installation rollback tests
```

### Run Multiple Categories

```bash
# Run multiple specific categories
bash .githooks/test/run-comprehensive-tests.sh branch,commit,security

# Run all except rollback tests
bash .githooks/test/run-comprehensive-tests.sh branch,commit,security,basebranch,history,protected,commands,integration
```

### Run Individual Test Script

```bash
# Run specific test script directly
bash .githooks/test/test-scenarios/test-branch-naming.sh

# Run with custom environment
HOOK_TEST_MODE=1 bash .githooks/test/test-scenarios/test-branch-naming.sh
```

### Run with Options

```bash
# Verbose output
bash .githooks/test/run-comprehensive-tests.sh --verbose

# Skip cleanup (for debugging)
bash .githooks/test/run-comprehensive-tests.sh --no-cleanup

# Preserve state on failure
bash .githooks/test/run-comprehensive-tests.sh --preserve-on-fail

# Stop on first failure
bash .githooks/test/run-comprehensive-tests.sh --fail-fast

# Dry run (show what would be tested)
bash .githooks/test/run-comprehensive-tests.sh --dry-run
```

### View Test Logs

```bash
# View latest test run log
cat .githooks/test/logs/test-run-*.log | tail -100

# View specific category log
cat .githooks/test/logs/test-branch-naming-*.log

# View all test logs
ls -la .githooks/test/logs/

# Follow test log in real-time
tail -f .githooks/test/logs/test-run-*.log
```

---

## Test Categories

### 1. Branch Naming Tests

**Purpose**: Validate branch naming conventions

**Tests** (15 total):
1. Valid feature branch (`feat-ABC-123-description`)
2. Valid bugfix branch (`fix-BUG-456-description`)
3. Valid hotfix branch (`hotfix-CRIT-789-description`)
4. Invalid branch - missing type
5. Invalid branch - missing JIRA ID
6. Invalid branch - lowercase JIRA ID
7. Invalid branch - wrong separator
8. Long-lived branch - main (allowed)
9. Long-lived branch - develop (allowed)
10. Long-lived branch - release/* (allowed)
11. Branch name with numbers in description
12. Branch name with multiple hyphens
13. Very long branch name (edge case)
14. Branch name with special characters
15. Branch name case sensitivity

**Run**:
```bash
bash .githooks/test/run-comprehensive-tests.sh branch
```

**Example Test**:
```bash
# Test: Valid feature branch
git checkout -b feat-PROJ-123-user-authentication
# Expected: Success, no warnings

# Test: Invalid branch - missing JIRA ID
git checkout -b feat-user-authentication
# Expected: Failure with clear error message
```

### 2. Commit Message Tests

**Purpose**: Validate commit message format

**Tests** (12 total):
1. Valid feat commit
2. Valid fix commit
3. Valid chore commit
4. Invalid - missing type
5. Invalid - missing JIRA ID
6. Invalid - lowercase JIRA ID
7. Invalid - wrong type
8. Invalid - missing description
9. Valid multi-line message
10. Auto-prefill from branch name
11. Commit message length validation
12. Special characters in description

**Run**:
```bash
bash .githooks/test/run-comprehensive-tests.sh commit
```

**Example Test**:
```bash
# Test: Valid feat commit
git commit -m "feat: PROJ-123 Add user authentication"
# Expected: Success

# Test: Invalid - missing JIRA ID
git commit -m "feat: Add authentication"
# Expected: Failure with error message
```

### 3. Security Scanning Tests

**Purpose**: Validate secret detection and sensitive file blocking

**Tests** (18 total):
1. AWS access key detection
2. AWS secret key detection
3. GitHub token detection
4. Slack token detection
5. Private key detection
6. JWT token detection
7. Generic API key detection
8. Database password detection
9. .env file blocking
10. .pem file blocking
11. Private SSH key blocking
12. Multiple secrets in one file
13. False positive handling
14. Binary file warning (5MB+)
15. Sensitive file patterns
16. Secret in JSON format
17. Secret in YAML format
18. Encoded secret detection

**Run**:
```bash
bash .githooks/test/run-comprehensive-tests.sh security
```

**Example Test**:
```bash
# Test: AWS access key detection
echo 'AWS_KEY="AKIAIOSFODNN7EXAMPLE"' > config.js
git add config.js
git commit -m "feat: PROJ-123 Add config"
# Expected: Failure, secret detected

# Test: .env file blocking
touch .env
git add .env
git commit -m "feat: PROJ-123 Add env"
# Expected: Failure, sensitive file blocked
```

### 4. Base Branch Enforcement Tests

**Purpose**: Validate branches are created from correct base

**Tests** (10 total):
1. Feat branch from develop (correct)
2. Feat branch from main (incorrect, warning)
3. Hotfix branch from main (correct)
4. Hotfix branch from develop (incorrect, warning)
5. Bugfix branch from develop (correct)
6. Custom branch mapping
7. Missing base branch mapping
8. Base branch detection with detached HEAD
9. Base branch detection with merge commits
10. Base branch detection with rebased branches

**Run**:
```bash
bash .githooks/test/run-comprehensive-tests.sh basebranch
```

**Example Test**:
```bash
# Test: Feat branch from correct base
git checkout develop
git checkout -b feat-PROJ-123-feature
# Expected: Success, no warnings

# Test: Feat branch from wrong base
git checkout main
git checkout -b feat-PROJ-456-feature
# Expected: Warning about wrong base
```

### 5. History Curation Tests

**Purpose**: Validate commit count limits and history cleanliness

**Tests** (8 total):
1. Within commit limit (5 commits)
2. Exceeds commit limit (6+ commits)
3. Custom commit limit configuration
4. Merge commit detection
5. Squash requirement message
6. Linear history enforcement
7. Commit count with merge base
8. Commit count with multiple remotes

**Run**:
```bash
bash .githooks/test/run-comprehensive-tests.sh history
```

**Example Test**:
```bash
# Test: Within commit limit
# Create branch with 5 commits
git checkout -b feat-PROJ-789-test develop
for i in {1..5}; do
    git commit --allow-empty -m "feat: PROJ-789 Commit $i"
done
git push
# Expected: Success

# Test: Exceeds commit limit
# Add one more commit
git commit --allow-empty -m "feat: PROJ-789 Commit 6"
git push
# Expected: Failure, too many commits
```

### 6. Protected Branch Tests

**Purpose**: Validate protection of main/develop branches

**Tests** (6 total):
1. Direct commit to main blocked
2. Direct commit to develop blocked
3. Direct commit to release/* blocked
4. Protected branch bypass with flag
5. Protected branch detection
6. Allowed branches (feature branches)

**Run**:
```bash
bash .githooks/test/run-comprehensive-tests.sh protected
```

**Example Test**:
```bash
# Test: Direct commit to main blocked
git checkout main
git commit --allow-empty -m "feat: PROJ-123 Direct commit"
# Expected: Failure, protected branch

# Test: Bypass protection
ALLOW_DIRECT_PROTECTED=1 git commit --allow-empty -m "Emergency"
# Expected: Success with bypass
```

### 7. Custom Commands Tests

**Purpose**: Validate custom command execution framework

**Tests** (7 total):
1. Execute single command
2. Execute multiple commands
3. Command priority ordering
4. Mandatory vs optional commands
5. Command timeout handling
6. Parallel execution
7. Command failure handling

**Run**:
```bash
bash .githooks/test/run-comprehensive-tests.sh commands
```

**Example Test**:
```bash
# Test: Execute single command
echo "pre-commit:1:true:10:echo 'test':Test command" > .githooks/commands.conf
git add .
git commit -m "feat: PROJ-123 Test"
# Expected: Command executes, success

# Test: Command timeout
echo "pre-commit:1:true:1:sleep 10:Slow command" > .githooks/commands.conf
git commit -m "feat: PROJ-123 Test"
# Expected: Timeout error after 1 second
```

### 8. Hook Integration Tests

**Purpose**: Validate hook interoperability and workflow

**Tests** (5 total):
1. Pre-commit → commit-msg → pre-push flow
2. Branch creation → commit → push flow
3. Multiple commits in sequence
4. Hook log aggregation
5. Hook state preservation

**Run**:
```bash
bash .githooks/test/run-comprehensive-tests.sh integration
```

**Example Test**:
```bash
# Test: Complete workflow
git checkout -b feat-PROJ-999-integration develop
echo "test" > test.js
git add test.js
git commit -m "feat: PROJ-999 Test integration"
git push origin feat-PROJ-999-integration
# Expected: All hooks pass in sequence
```

### 9. Rollback Tests

**Purpose**: Validate installation rollback mechanism

**Tests** (7 total):
1. Normal installation (should succeed)
2. .gitignore creation
3. .gitignore pattern update
4. Rollback on installation failure
5. Rollback on user interruption
6. Idempotent installation
7. Rollback file cleanup

**Run**:
```bash
bash .githooks/test/test-rollback.sh
# Or
bash .githooks/test/run-comprehensive-tests.sh rollback
```

**Example Test**:
```bash
# Test: Rollback on failure
# Modify install script to fail at step 5
bash .githooks/install-hooks.sh
# Expected: Rollback executes, state restored

# Verify:
git config core.hooksPath
# Expected: Empty or previous value
```

---

## Test Configuration

### Configuration Management

#### View Current Configuration

```bash
# Show all test settings
bash .githooks/test/test-config.sh show

# Output:
# Git Hooks Test Configuration
# ══════════════════════════════════════
# Test Infrastructure: ENABLED
# Base Branch: develop
# Log Verbosity: detailed
# Auto Cleanup: true
# Test Categories: all
# Preserve State: false
```

#### Check Test Status

```bash
# Check if tests are enabled
bash .githooks/test/test-config.sh status

# Output (if enabled):
# Tests are enabled

# Output (if disabled):
# Tests are not enabled
# Enable with: bash .githooks/test/test-config.sh setup-dev
```

#### Setup for Different Environments

```bash
# Development environment
bash .githooks/test/test-config.sh setup-dev
# - Detailed logging
# - Auto cleanup enabled
# - All categories enabled
# - Preserves state on failure (optional)

# CI/CD environment
bash .githooks/test/test-config.sh setup-ci
# - Minimal logging (faster)
# - Strict cleanup
# - Parallel execution
# - Fails fast
```

#### Reset Configuration

```bash
# Reset all test settings
bash .githooks/test/test-config.sh reset

# What it does:
# ✓ Disables tests
# ✓ Removes all test configurations
# ✓ Cleans test state files
# ✓ Archives test logs (optional)
```

### Configuration Options

#### Base Branch

```bash
# Set base branch for test resets
git config hooks.tests.baseBranch main

# Or for develop
git config hooks.tests.baseBranch develop

# View current setting
git config hooks.tests.baseBranch
```

**Purpose**: Determines which branch to reset to after tests

#### Log Verbosity

```bash
# Detailed logging (development)
git config hooks.tests.logVerbosity detailed

# Minimal logging (CI/CD)
git config hooks.tests.logVerbosity minimal

# View current setting
git config hooks.tests.logVerbosity
```

**Levels**:
- `detailed`: Full test output, debug information, timing
- `minimal`: Test results only, no debug output

#### Auto Cleanup

```bash
# Enable auto cleanup
git config hooks.tests.autoCleanup true

# Disable (for debugging)
git config hooks.tests.autoCleanup false

# View current setting
git config hooks.tests.autoCleanup
```

**Purpose**: Automatically clean up test artifacts after execution

#### Test Categories

```bash
# Run all categories (default)
git config hooks.tests.categories all

# Run specific categories
git config hooks.tests.categories "branch,commit,security"

# View current setting
git config hooks.tests.categories
```

**Available categories**: `branch`, `commit`, `security`, `basebranch`, `history`, `protected`, `commands`, `integration`, `rollback`

#### Preserve State

```bash
# Preserve state on test failure (debugging)
git config hooks.tests.preserveState true

# Don't preserve state (default)
git config hooks.tests.preserveState false

# View current setting
git config hooks.tests.preserveState
```

**Purpose**: Keep failed test state for debugging instead of cleaning up

### Environment-Specific Configurations

#### Local Development

```bash
git config hooks.tests.enabled true
git config hooks.tests.baseBranch develop
git config hooks.tests.logVerbosity detailed
git config hooks.tests.autoCleanup true
git config hooks.tests.categories all
git config hooks.tests.preserveState false
```

#### CI/CD Pipeline

```bash
git config hooks.tests.enabled true
git config hooks.tests.baseBranch ${CI_DEFAULT_BRANCH}
git config hooks.tests.logVerbosity minimal
git config hooks.tests.autoCleanup true
git config hooks.tests.categories all
git config hooks.tests.preserveState false
```

#### Debugging Failed Tests

```bash
git config hooks.tests.enabled true
git config hooks.tests.baseBranch develop
git config hooks.tests.logVerbosity detailed
git config hooks.tests.autoCleanup false      # Don't cleanup
git config hooks.tests.preserveState true     # Preserve state
git config hooks.tests.categories "branch"    # Single category
```

---

## Writing Tests

### Test Script Template

```bash
#!/usr/bin/env bash

# ============================================================================
# Test Script Template
# Purpose: [Describe what this test validates]
# ============================================================================

set -euo pipefail

# Test configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(git rev-parse --show-toplevel)"

# Load test utilities
source "$SCRIPT_DIR/../lib/test-utils.sh"

# Test counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test functions
run_test() {
    local test_name="$1"
    local test_func="$2"
    
    TESTS_RUN=$((TESTS_RUN + 1))
    log_test "Running: $test_name"
    
    if $test_func; then
        TESTS_PASSED=$((TESTS_PASSED + 1))
        log_success "PASSED: $test_name"
    else
        TESTS_FAILED=$((TESTS_FAILED + 1))
        log_error "FAILED: $test_name"
    fi
}

# Individual tests
test_example_success() {
    # Setup
    local test_branch="hook-test-example-$$"
    
    # Execute
    git checkout -b "$test_branch" develop 2>&1
    local result=$?
    
    # Verify
    if [ $result -eq 0 ]; then
        # Cleanup
        git checkout develop
        git branch -D "$test_branch"
        return 0
    else
        return 1
    fi
}

test_example_failure() {
    # This should fail
    git checkout -b invalid-branch-name
    local result=$?
    
    # Verify failure expected
    if [ $result -ne 0 ]; then
        return 0  # Test passed (failure was expected)
    else
        return 1  # Test failed (should have failed)
    fi
}

# Main execution
main() {
    log_header "Example Test Suite"
    
    run_test "Valid branch creation" test_example_success
    run_test "Invalid branch name" test_example_failure
    
    log_summary "$TESTS_RUN" "$TESTS_PASSED" "$TESTS_FAILED"
    
    [ $TESTS_FAILED -eq 0 ] && exit 0 || exit 1
}

main
```

### Test Utilities

#### Available Functions

```bash
# Logging
log_header "Test Suite Name"
log_test "Running test..."
log_success "Test passed"
log_error "Test failed"
log_warning "Warning message"
log_info "Information"
log_summary <total> <passed> <failed>

# State management
save_test_state
restore_test_state
cleanup_test_artifacts

# Assertions
assert_equals <expected> <actual> <message>
assert_not_equals <expected> <actual> <message>
assert_contains <string> <substring> <message>
assert_file_exists <path> <message>
assert_command_success <command> <message>
assert_command_fails <command> <message>

# Test branches
create_test_branch <name> [base]
cleanup_test_branches

# Test commits
create_test_commit <message> [file]
cleanup_test_commits
```

### Example Tests

#### Test 1: Valid Branch Name

```bash
test_valid_feature_branch() {
    local branch="feat-TEST-123-example"
    
    # Create branch
    git checkout -b "$branch" develop 2>&1
    
    # Should succeed
    if [ $? -eq 0 ]; then
        # Cleanup
        git checkout develop
        git branch -D "$branch"
        return 0
    fi
    
    return 1
}
```

#### Test 2: Invalid Commit Message

```bash
test_invalid_commit_message() {
    # Setup
    local branch="feat-TEST-456-commit-test"
    git checkout -b "$branch" develop
    
    # Try invalid commit
    git commit --allow-empty -m "bad message" 2>&1
    local result=$?
    
    # Should fail
    if [ $result -ne 0 ]; then
        # Cleanup
        git checkout develop
        git branch -D "$branch"
        return 0  # Test passed (commit failed as expected)
    fi
    
    # Cleanup
    git checkout develop
    git branch -D "$branch"
    return 1  # Test failed (commit should have failed)
}
```

#### Test 3: Secret Detection

```bash
test_aws_key_detection() {
    # Setup
    local branch="feat-TEST-789-security"
    git checkout -b "$branch" develop
    
    # Create file with secret
    echo 'AWS_ACCESS_KEY="AKIAIOSFODNN7EXAMPLE"' > test-file.js
    git add test-file.js
    
    # Try to commit
    git commit -m "feat: TEST-789 Add config" 2>&1
    local result=$?
    
    # Cleanup
    git reset HEAD test-file.js
    rm test-file.js
    git checkout develop
    git branch -D "$branch"
    
    # Should fail (secret detected)
    [ $result -ne 0 ] && return 0 || return 1
}
```

### Best Practices

1. **Always Clean Up**
   ```bash
   # Use trap to ensure cleanup
   cleanup() {
       git checkout develop 2>/dev/null || true
       git branch -D "$test_branch" 2>/dev/null || true
   }
   trap cleanup EXIT
   ```

2. **Use Unique Names**
   ```bash
   # Use PID for unique test branches
   test_branch="hook-test-example-$$"
   ```

3. **Test Both Success and Failure**
   ```bash
   # Test valid input
   test_valid_input() { ... }
   
   # Test invalid input (should fail)
   test_invalid_input() { ... }
   ```

4. **Provide Clear Messages**
   ```bash
   log_test "Testing branch name validation with special characters"
   assert_equals "feat-TEST-123-test" "$actual" "Branch name should match expected format"
   ```

5. **Isolate Tests**
   ```bash
   # Each test should be independent
   # Don't rely on state from previous tests
   setup_test() {
       # Fresh state for this test
   }
   ```

---

## Test State Management

### State File

**Location**: `.githooks/test/.test-state`

**Format**:
```bash
ORIGINAL_BRANCH=main
ORIGINAL_COMMIT=abc123def456
STAGED_FILES=src/file1.js,src/file2.js
WORKING_CLEAN=true
TEST_START_TIME=2025-11-04 10:30:00
TEST_PID=12345
```

### State Operations

#### Save State

```bash
# Automatically done by setup script
bash .githooks/test/setup-test-environment.sh

# What gets saved:
# - Current branch
# - Current commit
# - Staged files
# - Working tree status
# - Start timestamp
```

#### Restore State

```bash
# Automatically done by cleanup script
bash .githooks/test/cleanup-test-environment.sh

# What gets restored:
# - Original branch
# - Original commit (if changed)
# - Staged files
# - Working tree
```

#### Manual State Management

```bash
# Save state manually
source .githooks/test/lib/test-utils.sh
save_test_state

# Restore state manually
restore_test_state

# Clean test artifacts
cleanup_test_artifacts
```

### State Preservation

#### On Test Success

- State is automatically restored
- Test branches are deleted
- Test commits are removed
- Logs are archived

#### On Test Failure

**Default behavior** (`preserveState=false`):
- State is restored
- Test artifacts cleaned
- Error is logged

**Debug behavior** (`preserveState=true`):
```bash
git config hooks.tests.preserveState true

# On failure:
# - State is NOT restored
# - Test branches remain
# - Can inspect failure manually

# Manual cleanup after inspection:
bash .githooks/test/cleanup-test-environment.sh
```

### Cleanup Operations

#### Automatic Cleanup

```bash
# Enabled by default
git config hooks.tests.autoCleanup true

# Cleans:
# - Test branches (hook-test-*)
# - Test tags
# - Test commits
# - Test state file
# - Temporary files
```

#### Manual Cleanup

```bash
# Clean test branches
git branch | grep "hook-test-" | xargs git branch -D

# Clean test tags
git tag | grep "hook-test-" | xargs git tag -d

# Clean test logs
rm -f .githooks/test/logs/test-*.log

# Clean test state
rm -f .githooks/test/.test-state

# Complete cleanup
bash .githooks/test/cleanup-test-environment.sh
```

#### Forced Cleanup

```bash
# Nuclear option: Clean everything
git checkout develop
git branch | grep -v "main\|develop" | xargs git branch -D
rm -rf .githooks/test/logs/*.log
rm -f .githooks/test/.test-state
git reset --hard origin/develop
```

---

## Debugging Tests

### Enable Verbose Logging

```bash
# Run tests with verbose output
bash .githooks/test/run-comprehensive-tests.sh --verbose

# Or set verbosity
git config hooks.tests.logVerbosity detailed
bash .githooks/test/run-comprehensive-tests.sh
```

### Disable Cleanup

```bash
# Keep test state after failure
bash .githooks/test/run-comprehensive-tests.sh --no-cleanup

# Or configure
git config hooks.tests.autoCleanup false
git config hooks.tests.preserveState true
```

### Run Single Test

```bash
# Run specific test script
bash .githooks/test/test-scenarios/test-branch-naming.sh

# Run with bash debug mode
bash -x .githooks/test/test-scenarios/test-branch-naming.sh
```

### Inspect Failed State

```bash
# After failed test with preserveState=true

# Check current branch
git branch

# Check test branches
git branch | grep hook-test-

# Check commits
git log --oneline

# Check staged files
git status

# Check test state file
cat .githooks/test/.test-state

# Manual cleanup when done
bash .githooks/test/cleanup-test-environment.sh
```

### View Test Logs

```bash
# View latest test run
cat .githooks/test/logs/test-run-*.log | tail -100

# View specific category
cat .githooks/test/logs/test-branch-naming-*.log

# Follow log in real-time
tail -f .githooks/test/logs/test-run-*.log

# Search for failures
grep -i "failed\|error" .githooks/test/logs/test-run-*.log
```

### Debug Specific Test

```bash
# Add debug output to test
test_example() {
    echo "DEBUG: Starting test"
    echo "DEBUG: Current branch: $(git branch --show-current)"
    
    # Test code...
    
    echo "DEBUG: Test result: $result"
    return $result
}

# Run test
bash .githooks/test/test-scenarios/test-example.sh
```

### Common Issues

#### Issue 1: Test Branches Not Cleaned

```bash
# Symptom: Many hook-test-* branches remain
git branch | grep hook-test-

# Solution: Force cleanup
git branch | grep hook-test- | xargs git branch -D
```

#### Issue 2: State Not Restored

```bash
# Symptom: Still on test branch after tests
git branch --show-current

# Solution: Manual restore
git checkout develop
bash .githooks/test/cleanup-test-environment.sh
```

#### Issue 3: Test Logs Filling Disk

```bash
# Check log size
du -sh .githooks/test/logs/

# Archive old logs
tar -czf test-logs-archive-$(date +%Y%m%d).tar.gz .githooks/test/logs/
rm -f .githooks/test/logs/*.log

# Or delete directly
rm -f .githooks/test/logs/*.log
```

---

## CI/CD Integration

### GitHub Actions

```yaml
name: Git Hooks Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Test Environment
        run: bash .githooks/test/test-config.sh setup-ci
      
      - name: Run All Tests
        run: bash .githooks/test/run-comprehensive-tests.sh
      
      - name: Upload Test Logs
        if: failure()
        uses: actions/upload-artifact@v3
        with:
          name: test-logs
          path: .githooks/test/logs/
```

### GitLab CI

```yaml
test-hooks:
  stage: test
  script:
    - bash .githooks/test/test-config.sh setup-ci
    - bash .githooks/test/run-comprehensive-tests.sh
  artifacts:
    when: on_failure
    paths:
      - .githooks/test/logs/
```

### Jenkins

```groovy
pipeline {
    agent any
    
    stages {
        stage('Setup') {
            steps {
                sh 'bash .githooks/test/test-config.sh setup-ci'
            }
        }
        
        stage('Test') {
            steps {
                sh 'bash .githooks/test/run-comprehensive-tests.sh'
            }
        }
    }
    
    post {
        always {
            archiveArtifacts artifacts: '.githooks/test/logs/**/*.log', allowEmptyArchive: true
        }
    }
}
```

### Azure Pipelines

```yaml
trigger:
  - main
  - develop

pool:
  vmImage: 'ubuntu-latest'

steps:
  - bash: bash .githooks/test/test-config.sh setup-ci
    displayName: 'Setup Test Environment'
  
  - bash: bash .githooks/test/run-comprehensive-tests.sh
    displayName: 'Run Git Hooks Tests'
  
  - task: PublishBuildArtifacts@1
    condition: failed()
    inputs:
      pathToPublish: '.githooks/test/logs'
      artifactName: 'test-logs'
```

### Local Pre-Commit Integration

```bash
# Add test run to pre-commit hook
# (Only run specific fast tests)
cat >> .githooks/pre-commit << 'EOF'

# Run fast tests before commit
if [ "$(git config hooks.tests.enabled)" = "true" ]; then
    echo "Running quick hook tests..."
    bash .githooks/test/run-comprehensive-tests.sh branch,commit --fail-fast
fi
EOF
```

---

## Quick Reference

### Commands

```bash
# Setup
bash .githooks/test/test-config.sh setup-dev      # Enable for development
bash .githooks/test/test-config.sh setup-ci       # Enable for CI/CD
bash .githooks/test/test-config.sh show           # Show configuration
bash .githooks/test/test-config.sh status         # Check status
bash .githooks/test/test-config.sh reset          # Reset configuration

# Run Tests
bash .githooks/test/run-comprehensive-tests.sh                  # All tests
bash .githooks/test/run-comprehensive-tests.sh branch           # Single category
bash .githooks/test/run-comprehensive-tests.sh branch,commit    # Multiple categories
bash .githooks/test/run-comprehensive-tests.sh --verbose        # Verbose output
bash .githooks/test/run-comprehensive-tests.sh --no-cleanup     # Skip cleanup

# View Logs
cat .githooks/test/logs/test-run-*.log                          # Latest run
tail -f .githooks/test/logs/test-run-*.log                      # Follow log

# Cleanup
bash .githooks/test/cleanup-test-environment.sh                 # Clean state
rm -f .githooks/test/logs/*.log                                 # Clean logs
git branch -D $(git branch | grep hook-test-)                   # Clean branches
```

### Test Categories

- `branch` - Branch naming (15 tests)
- `commit` - Commit messages (12 tests)
- `security` - Security scanning (18 tests)
- `basebranch` - Base branch enforcement (10 tests)
- `history` - History curation (8 tests)
- `protected` - Protected branches (6 tests)
- `commands` - Custom commands (7 tests)
- `integration` - Hook integration (5 tests)
- `rollback` - Installation rollback (7 tests)

---

**See Also**:
- [GITHOOKS_README.md](GITHOOKS_README.md) - Complete documentation
- [GITHOOKS_TROUBLESHOOTING.md](GITHOOKS_TROUBLESHOOTING.md) - Troubleshooting guide
- [GITHOOKS_CONTRIBUTING.md](GITHOOKS_CONTRIBUTING.md) - Contributing guide

---

**Version**: 3.0  
**Status**: Production-Ready ✅  
**Last Updated**: November 4, 2025
