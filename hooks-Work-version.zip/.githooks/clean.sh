#!/usr/bin/env bash

# ============================================================================
# Log Cleanup Script
# Purpose: Rotate large logs and delete old logs
# ============================================================================

set -euo pipefail

LOG_DIR=".git/hook-logs"
MAX_SIZE=262144  # 256KB in bytes
MAX_ARCHIVES=2
MAX_AGE_DAYS=21

# Check if log directory exists
if [ ! -d "$LOG_DIR" ]; then
    exit 0
fi

# Get file size (cross-platform)
get_file_size() {
    local file="$1"
    if [ ! -f "$file" ]; then
        echo "0"
        return
    fi
    
    # Try stat (Linux)
    if stat -c%s "$file" 2>/dev/null; then
        return
    fi
    
    # Try stat (macOS)
    if stat -f%z "$file" 2>/dev/null; then
        return
    fi
    
    # Fallback
    wc -c < "$file" 2>/dev/null || echo "0"
}

# Rotate log file
rotate_log() {
    local log_file="$1"
    local base_name=$(basename "$log_file" .log)
    
    if [ ! -f "$log_file" ]; then
        return 0
    fi
    
    local size=$(get_file_size "$log_file")
    
    if [ "$size" -gt "$MAX_SIZE" ]; then
        # Shift existing archives
        for i in $(seq $((MAX_ARCHIVES-1)) -1 1); do
            if [ -f "${LOG_DIR}/${base_name}.${i}.log" ]; then
                mv "${LOG_DIR}/${base_name}.${i}.log" "${LOG_DIR}/${base_name}.$((i+1)).log" 2>/dev/null || true
            fi
        done
        
        # Move current to .1
        mv "$log_file" "${LOG_DIR}/${base_name}.1.log" 2>/dev/null || true
        
        # Remove oldest if exceeds MAX_ARCHIVES
        if [ -f "${LOG_DIR}/${base_name}.$((MAX_ARCHIVES+1)).log" ]; then
            rm -f "${LOG_DIR}/${base_name}.$((MAX_ARCHIVES+1)).log" 2>/dev/null || true
        fi
        
        # Create new empty log
        touch "$log_file" 2>/dev/null || true
    fi
}

# Delete old logs
delete_old_logs() {
    # Try find command if available
    if command -v find >/dev/null 2>&1; then
        find "$LOG_DIR" -name "*.log" -type f -mtime +$MAX_AGE_DAYS -delete 2>/dev/null || true
    fi
}

# Main cleanup
for log_file in "$LOG_DIR"/*.log; do
    [ -f "$log_file" ] && rotate_log "$log_file"
done

delete_old_logs

exit 0
