# Test Management Guide

## Quick Commands

### Enable Tests
```bash
# Setup for development (recommended)
bash .githooks/test/test-config.sh setup-dev

# Or just enable tests with default settings
bash .githooks/test/test-config.sh enable
```

### Disable Tests
```bash
# Disable tests to do normal development work
bash .githooks/test/test-config.sh disable
```

### View Current Configuration
```bash
bash .githooks/test/test-config.sh show
```

### Reset Configuration
```bash
# Reset all test settings to defaults
bash .githooks/test/test-config.sh reset
```

## When to Enable/Disable Tests

### Enable Tests When:
- Testing hook functionality
- Validating changes to hooks
- Running comprehensive test suite
- CI/CD pipeline execution
- Before committing hook changes

### Disable Tests When:
- Doing normal development work
- Tests are interfering with workflow
- Need to commit quickly (use with caution)
- Working on non-hook related features

## Available Commands

| Command | Description |
|---------|-------------|
| `setup-dev` | Enable tests with development settings (verbose logging, all categories) |
| `setup-ci` | Enable tests with CI/CD settings (normal logging, all categories) |
| `enable` | Enable tests with current settings |
| `disable` | Disable tests |
| `show` | Display current test configuration |
| `reset` | Reset all test settings to defaults |

## Configuration Details

### What Gets Configured:
- **hooks.tests.enabled**: true/false
- **hooks.tests.baseBranch**: Base branch for testing (e.g., develop)
- **hooks.tests.logVerbosity**: verbose/normal/quiet
- **hooks.tests.autoCleanup**: true/false (cleanup after tests)
- **hooks.tests.categories**: Test categories to run (all/security/branch/commit)

### Manual Configuration:
```bash
# Enable/disable tests
git config hooks.tests.enabled true
git config hooks.tests.enabled false

# Set base branch
git config hooks.tests.baseBranch develop

# Set log verbosity
git config hooks.tests.logVerbosity verbose

# Set test categories
git config hooks.tests.categories all
```

## Running Tests

### Run All Tests:
```bash
bash .githooks/test/run-comprehensive-tests.sh
```

### Run Specific Test Categories:
```bash
# Set categories first
git config hooks.tests.categories "security,branch"

# Then run tests
bash .githooks/test/run-comprehensive-tests.sh
```

## Examples

### Example 1: Enable for Hook Development
```bash
# Enable tests with development settings
bash .githooks/test/test-config.sh setup-dev

# Run tests
bash .githooks/test/run-comprehensive-tests.sh

# Disable when done
bash .githooks/test/test-config.sh disable
```

### Example 2: Quick Enable/Disable
```bash
# Enable tests
bash .githooks/test/test-config.sh enable

# Do your testing...

# Disable tests
bash .githooks/test/test-config.sh disable
```

### Example 3: Check Current Status
```bash
# View current configuration
bash .githooks/test/test-config.sh show

# Or check just the enabled status
git config hooks.tests.enabled
```

## Environment Variables

You can also control tests via environment variables (higher priority than git config):

```bash
# Enable tests for current session only
export GITHOOKS_TESTS_ENABLED=true

# Set base branch
export GITHOOKS_TEST_BASE_BRANCH=develop

# Set log level
export GITHOOKS_TEST_LOG_LEVEL=verbose

# Enable cleanup
export GITHOOKS_TEST_CLEANUP=true

# Set categories
export GITHOOKS_TEST_CATEGORIES=all
```

## Troubleshooting

### Tests Won't Disable:
```bash
# Force disable
git config hooks.tests.enabled false

# Verify
git config hooks.tests.enabled
# Should show: false
```

### Reset Everything:
```bash
# Remove all test configurations
bash .githooks/test/test-config.sh reset

# Verify
git config --get-regexp hooks.tests
# Should show nothing
```

### Tests Still Running After Disable:
Check if environment variable is set (it overrides git config):
```bash
# Check environment
echo $GITHOOKS_TESTS_ENABLED

# Unset if needed
unset GITHOOKS_TESTS_ENABLED
```

## Best Practices

1. **Always disable tests** when doing normal development work
2. **Enable tests** only when working on hooks or running test suite
3. **Use `setup-dev`** for quick development testing setup
4. **Use `show`** to verify current configuration
5. **Use `reset`** if you want to start fresh

## Quick Reference

```bash
# Enable for development
bash .githooks/test/test-config.sh setup-dev

# Disable for normal work
bash .githooks/test/test-config.sh disable

# Check status
bash .githooks/test/test-config.sh show

# Reset everything
bash .githooks/test/test-config.sh reset
```

---

**Remember**: Tests are meant for hook validation, not normal development. Disable them when you're done testing!
