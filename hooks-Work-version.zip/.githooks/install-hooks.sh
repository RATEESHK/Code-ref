#!/usr/bin/env bash

set -euo pipefail

# ============================================================================
# Git Hooks Installation Script v3.0
# Purpose: Configure repository to use .githooks with rollback capabilities
# Features: 
# - Automatic .gitignore management
# - Complete rollback on failure
# - Comprehensive error handling
# - Full audit logging
# ============================================================================

# Color codes
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly MAGENTA='\033[0;35m'
readonly CYAN='\033[0;36m'
readonly NC='\033[0m'
readonly BOLD='\033[1m'

# Setup logging
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || echo ".")"
LOG_DIR="${SCRIPT_DIR}/logs"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOG_FILE="${LOG_DIR}/install-${TIMESTAMP}.log"
ROLLBACK_FILE="${LOG_DIR}/.rollback-${TIMESTAMP}.sh"

# Rollback tracking
declare -a ROLLBACK_STACK=()
INSTALLATION_FAILED=0

#######################################
# Logging Functions
#######################################

log() {
    local msg="$*"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    # Strip ANSI color codes before writing to log file (handles both \033 and \x1b formats)
    echo -e "[$timestamp] $msg" | sed -E 's/\\033\[[0-9;]*m//g; s/\x1b\[[0-9;]*m//g; s/\\n/ /g' >> "$LOG_FILE" 2>/dev/null || true
    echo -e "$msg"
}

log_error() {
    local msg="$*"
    log "${RED}✗ ERROR:${NC} $msg"
}

log_success() {
    local msg="$*"
    log "${GREEN}✓${NC} $msg"
}

log_warn() {
    local msg="$*"
    log "${YELLOW}⚠${NC} $msg"
}

log_info() {
    local msg="$*"
    log "${BLUE}ℹ${NC} $msg"
}

#######################################
# Rollback Functions
#######################################

# Add operation to rollback stack
add_rollback() {
    local operation="$1"
    ROLLBACK_STACK+=("$operation")
    echo "$operation" >> "$ROLLBACK_FILE" 2>/dev/null || true
    log_info "[ROLLBACK] Registered: $operation"
}

# Execute rollback
execute_rollback() {
    log ""
    log "${YELLOW}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
    log "${YELLOW}${BOLD}         INSTALLATION FAILED - EXECUTING ROLLBACK${NC}"
    log "${YELLOW}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
    log ""
    
    INSTALLATION_FAILED=1
    
    local rollback_count=${#ROLLBACK_STACK[@]}
    
    if [ $rollback_count -eq 0 ]; then
        log_warn "No operations to rollback"
        return 0
    fi
    
    log_info "Rolling back $rollback_count operations..."
    log ""
    
    # Execute in reverse order
    for ((i=${#ROLLBACK_STACK[@]}-1; i>=0; i--)); do
        local cmd="${ROLLBACK_STACK[$i]}"
        log_info "[ROLLBACK $((rollback_count - i))/$rollback_count] Executing: $cmd"
        
        if eval "$cmd" 2>&1 | tee -a "$LOG_FILE"; then
            log_success "Rollback step completed"
        else
            log_error "Rollback step failed (continuing): $cmd"
        fi
    done
    
    log ""
    log_success "Rollback completed - repository restored to previous state"
    log ""
    
    # Clean up rollback file
    rm -f "$ROLLBACK_FILE" 2>/dev/null || true
}

# Cleanup on success
cleanup_rollback() {
    if [ $INSTALLATION_FAILED -eq 0 ]; then
        rm -f "$ROLLBACK_FILE" 2>/dev/null || true
        ROLLBACK_STACK=()
    fi
}

# Trap for errors and interruptions
trap 'execute_rollback; exit 1' ERR INT TERM

#######################################
# Helper Functions
#######################################

# Save git config value before modifying
save_git_config() {
    local key="$1"
    local old_value=$(git config --get "$key" 2>/dev/null || echo "")
    
    if [ -n "$old_value" ]; then
        # Config exists, save for restoration
        add_rollback "git config '$key' '$old_value'"
    else
        # Config doesn't exist, unset on rollback
        add_rollback "git config --unset '$key' 2>/dev/null || true"
    fi
}

# Track directory creation
track_directory() {
    local dir="$1"
    if [ ! -d "$dir" ]; then
        add_rollback "rm -rf '$dir' 2>/dev/null || true"
    fi
}

# Track file creation
track_file() {
    local file="$1"
    if [ ! -f "$file" ]; then
        add_rollback "rm -f '$file' 2>/dev/null || true"
    else
        # Backup existing file
        local backup="${file}.backup-${TIMESTAMP}"
        cp "$file" "$backup" 2>/dev/null || true
        add_rollback "mv '$backup' '$file' 2>/dev/null || true"
    fi
}

#######################################
# Main Installation Functions
#######################################

# Create log directory
mkdir -p "$LOG_DIR"

# Installation header
log "${CYAN}${BOLD}"
log "╔════════════════════════════════════════════════════════════════════╗"
log "║           Git Hooks Installation Script v3.0                       ║"
log "║     Production-Ready with Rollback & Auto .gitignore               ║"
log "╚════════════════════════════════════════════════════════════════════╝"
log "${NC}\n"

log "${BLUE}Installation Log: ${BOLD}$LOG_FILE${NC}"
log "${BLUE}Rollback Script:  ${BOLD}$ROLLBACK_FILE${NC}\n"

# Verify Git repository
if [ ! -d .git ]; then
    log_error "Not a git repository"
    log_info "Solution: Run from repository root or initialize with: git init"
    exit 1
fi

# Get repository info
REPO_NAME=$(basename "$(git rev-parse --show-toplevel)")
USER_NAME=$(git config user.name 2>/dev/null || echo "Unknown")
USER_EMAIL=$(git config user.email 2>/dev/null || echo "Unknown")
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "Unknown")

log "${BLUE}${BOLD}Repository Information:${NC}"
log "  ${CYAN}Name:${NC}    $REPO_NAME"
log "  ${CYAN}User:${NC}    $USER_NAME <$USER_EMAIL>"
log "  ${CYAN}Branch:${NC}  $CURRENT_BRANCH"
log ""

#######################################
# Step 0: Handle .gitignore
#######################################

log "${YELLOW}[0/11]${NC} ${BOLD}Checking .gitignore configuration...${NC}"

GITIGNORE_FILE="${REPO_ROOT}/.gitignore"

# Required patterns for git hooks
HOOK_PATTERNS=(
    "# Git Hooks - Custom Ignores"
    ".git/hook-logs/"
    ".git/hook-logs-archive-*.tar.gz"
    ".githooks/test/logs/"
    ".githooks/test/.test-state"
    ".githooks/logs/"
)

handle_gitignore() {
    if [ ! -f "$GITIGNORE_FILE" ]; then
        log_warn ".gitignore file not found!"
        log ""
        log "${YELLOW}${BOLD}CRITICAL: .gitignore file is missing${NC}"
        log "Git hooks generate logs that should not be committed to the repository."
        log ""
        log "Options:"
        log "  ${CYAN}1)${NC} Create .gitignore with hook patterns (recommended)"
        log "  ${CYAN}2)${NC} Cancel installation and create .gitignore manually"
        log ""
        
        read -p "Would you like to create .gitignore now? (y/N): " -n 1 -r
        log ""
        
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log_error "Installation cancelled - .gitignore required"
            log_info "Create .gitignore file and run installation again"
            exit 1
        fi
        
        log_info "Creating .gitignore with hook patterns..."
        
        # Track file creation for rollback
        track_file "$GITIGNORE_FILE"
        
        # Create .gitignore with hook patterns
        cat > "$GITIGNORE_FILE" << 'EOF'
# ==============================================================================
# Git Hooks - Custom Ignores
# ==============================================================================

# Git hooks logs
.git/hook-logs/
.git/hook-logs-archive-*.tar.gz

# Git hooks test infrastructure  
.githooks/test/logs/
.githooks/test/.test-state

# Git hooks installation logs
.githooks/logs/
EOF
        
        log_success ".gitignore created with hook patterns"
        
    else
        log_success ".gitignore file found"
        
        # Check if hook patterns exist
        local missing_patterns=()
        local has_hook_section=0
        
        if grep -q "# Git Hooks - Custom Ignores" "$GITIGNORE_FILE" 2>/dev/null; then
            has_hook_section=1
            log_info "Git Hooks section already exists in .gitignore"
        fi
        
        # Check each pattern
        for pattern in "${HOOK_PATTERNS[@]}"; do
            if ! grep -qF "$pattern" "$GITIGNORE_FILE" 2>/dev/null; then
                missing_patterns+=("$pattern")
            fi
        done
        
        if [ ${#missing_patterns[@]} -gt 0 ]; then
            log_warn "Some hook patterns are missing from .gitignore"
            log ""
            log "Missing patterns:"
            for pattern in "${missing_patterns[@]}"; do
                log "  - $pattern"
            done
            log ""
            
            read -p "Add missing patterns to .gitignore? (Y/n): " -n 1 -r
            log ""
            
            if [[ ! $REPLY =~ ^[Nn]$ ]]; then
                log_info "Adding hook patterns to .gitignore..."
                
                # Backup original file
                track_file "$GITIGNORE_FILE"
                
                # Add patterns
                {
                    echo ""
                    echo "# =============================================================================="
                    echo "# Git Hooks - Custom Ignores"
                    echo "# =============================================================================="
                    echo ""
                    echo "# Git hooks logs"
                    echo ".git/hook-logs/"
                    echo ".git/hook-logs-archive-*.tar.gz"
                    echo ""
                    echo "# Git hooks test infrastructure"
                    echo ".githooks/test/logs/"
                    echo ".githooks/test/.test-state"
                    echo ""
                    echo "# Git hooks installation logs"
                    echo ".githooks/logs/"
                } >> "$GITIGNORE_FILE"
                
                log_success "Hook patterns added to .gitignore"
            else
                log_warn "Proceeding without adding patterns (logs may be committed)"
            fi
        else
            log_success "All hook patterns present in .gitignore"
        fi
    fi
    
    log ""
}

# Execute .gitignore handling
if ! handle_gitignore; then
    log_error ".gitignore handling failed"
    exit 1
fi

#######################################
# Step 1: Set hooks path
#######################################

log "${YELLOW}[1/11]${NC} Setting Git hooks path..."
save_git_config "core.hooksPath"
git config core.hooksPath .githooks
log_success "Hooks path configured: .githooks/"

#######################################
# Step 2: Enable rebase autosquash
#######################################

log "${YELLOW}[2/11]${NC} Enabling rebase autosquash..."
save_git_config "rebase.autosquash"
git config rebase.autosquash true
log_success "Autosquash enabled for interactive rebases"

#######################################
# Step 3: Enable fetch prune
#######################################

log "${YELLOW}[3/11]${NC} Enabling automatic remote pruning..."
save_git_config "fetch.prune"
git config fetch.prune true
log_success "Auto-prune enabled (cleans stale remote refs)"

#######################################
# Step 4: Set default max commits
#######################################

log "${YELLOW}[4/11]${NC} Configuring commit limits..."
if [ -z "$(git config hooks.maxCommits 2>/dev/null)" ]; then
    save_git_config "hooks.maxCommits"
    git config hooks.maxCommits 5
    log_success "Max commits set to 5 (default)"
else
    MAX_COMMITS=$(git config hooks.maxCommits)
    log_success "Max commits already configured: $MAX_COMMITS"
fi

#######################################
# Step 5: Configure auto-restage
#######################################

log "${YELLOW}[5/11]${NC} Configuring auto-restage after fixes..."
if [ -z "$(git config hooks.autoAddAfterFix 2>/dev/null)" ]; then
    save_git_config "hooks.autoAddAfterFix"
    git config hooks.autoAddAfterFix false
    log_success "Auto-restage disabled (set to true to enable)"
else
    AUTO_ADD=$(git config hooks.autoAddAfterFix)
    log_success "Auto-restage: $AUTO_ADD"
fi

#######################################
# Step 6: Configure branch base mappings
#######################################

log "${YELLOW}[6/11]${NC} Configuring branch base mappings..."

mappings_set=0

# Set hotfix → origin/main
if [ -z "$(git config hooks.branchMapping.hotfix 2>/dev/null)" ]; then
    save_git_config "hooks.branchMapping.hotfix"
    git config hooks.branchMapping.hotfix "origin/main"
    mappings_set=$((mappings_set + 1))
fi

# Set all develop-based branches
for branch_type in feat feature bugfix fix techdebt perf refactor revert style test build chore ci docs; do
    if [ -z "$(git config hooks.branchMapping.$branch_type 2>/dev/null)" ]; then
        save_git_config "hooks.branchMapping.$branch_type"
        git config hooks.branchMapping.$branch_type "origin/develop"
        mappings_set=$((mappings_set + 1))
    fi
done

if [ $mappings_set -gt 0 ]; then
    log_success "Configured $mappings_set branch type mappings"
    log_info "  • hotfix → origin/main"
    log_info "  • feat, bugfix, fix, etc. → origin/develop"
else
    log_success "Branch mappings already configured"
fi
log_info "Customize: git config hooks.branchMapping.<type> <base>"

#######################################
# Step 7: Make hooks executable
#######################################

log "${YELLOW}[7/11]${NC} Making hooks executable..."
if command -v chmod >/dev/null 2>&1; then
    chmod +x .githooks/* 2>/dev/null || true
    chmod +x .githooks/lib/* 2>/dev/null || true
    chmod +x .githooks/test/*.sh 2>/dev/null || true
    chmod +x .githooks/test/test-scenarios/*.sh 2>/dev/null || true
    log_success "All hook files are now executable"
else
    log_warn "chmod not available (Windows), files may need manual permissions"
fi

#######################################
# Step 8: Create log directory
#######################################

log "${YELLOW}[8/11]${NC} Setting up logging infrastructure..."
track_directory ".git/hook-logs"
mkdir -p .git/hook-logs 2>/dev/null || true
touch .git/hook-logs/complete.log 2>/dev/null || true
log_success "Log directory created: .git/hook-logs/"

#######################################
# Step 9: Add logs to gitignore
#######################################

log "${YELLOW}[9/11]${NC} Excluding logs from version control..."
if ! grep -q "^hook-logs/" .git/info/exclude 2>/dev/null; then
    echo "hook-logs/" >> .git/info/exclude 2>/dev/null || true
fi
log_success "Logs excluded from Git tracking"

#######################################
# Step 10: Setup test infrastructure
#######################################

log "${YELLOW}[10/11]${NC} Setting up test infrastructure..."

track_directory ".githooks/test/logs"
mkdir -p .githooks/test/logs 2>/dev/null || true
log_success "Test log directory created"

log ""
log "${CYAN}${BOLD}Test Infrastructure Available:${NC}"
log "  The hook test suite can verify all hook functionality."
log "  Tests require explicit enablement for safety."
log ""
read -p "  Would you like to enable tests now? (y/N): " -n 1 -r
log ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log_info "Enabling test infrastructure..."
    
    # Track test configurations
    save_git_config "hooks.tests.enabled"
    save_git_config "hooks.tests.baseBranch"
    save_git_config "hooks.tests.logVerbosity"
    save_git_config "hooks.tests.autoCleanup"
    save_git_config "hooks.tests.categories"
    
    if bash .githooks/test/test-config.sh setup-dev 2>&1 | sed -E 's/\\033\[[0-9;]*m//g; s/\x1b\[[0-9;]*m//g' >> "$LOG_FILE"; then
        log_success "Tests enabled (run with: bash .githooks/test/run-comprehensive-tests.sh)"
    else
        log_warn "Test setup encountered issues (check log)"
    fi
else
    log_info "Tests not enabled"
    log_info "Enable later with: bash .githooks/test/test-config.sh setup-dev"
fi
log ""

#######################################
# Step 11: Create example commands.conf
#######################################

log "${YELLOW}[11/11]${NC} Setting up custom command framework..."
if [ ! -f .githooks/commands.conf ]; then
    track_file ".githooks/commands.conf"
    
    cat > .githooks/commands.conf << 'EOF'
# Git Hooks Custom Commands Configuration
# Format: HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
#
# HOOK      - Hook name (pre-commit, commit-msg, pre-push)
# PRIORITY  - Execution order (lower runs first)
# MANDATORY - true=block on failure, false=warn only
# TIMEOUT   - Max seconds to run (0=no timeout)
# COMMAND   - Shell command to execute (use {staged} for staged files)
# DESCRIPTION - Human-readable description
#
# Examples:
# pre-commit:1:true:30:npx lint-staged:Lint and format staged files
# pre-commit:2:false:60:npx tsc --noEmit:TypeScript type checking
# pre-commit:3:true:30:node scripts/check-casing.js:Check file casing
# pre-push:1:true:300:npm test:Run test suite
# pre-push:2:false:600:npm run build:Build verification
# commit-msg:1:false:10:node scripts/validate-ticket.js:Validate ticket format
#
# Uncomment and customize the lines below:
# pre-commit:1:true:60:npx lint-staged:Lint and Format
# pre-push:1:true:300:npm test:Test Suite
EOF
    log_success "Example commands.conf created"
else
    log_success "commands.conf already exists"
fi

# Create legacy extension file for backward compatibility
if [ ! -f .githooks/run-commands.sh ]; then
    track_file ".githooks/run-commands.sh"
    
    cat > .githooks/run-commands.sh << 'EOF'
#!/usr/bin/env bash

# ============================================================================
# Legacy Extension Framework (Deprecated - Use commands.conf instead)
# Purpose: Backward compatibility for custom hook extensions
# ============================================================================

# Uncomment and implement these functions for custom logic:

# precommit_extra() {
#     local files=("$@")
#     echo "[Extension] Running pre-commit checks on ${#files[@]} files..."
#     # Add your custom pre-commit logic here
#     return 0
# }

# commitmsg_extra() {
#     local msg_file="$1"
#     echo "[Extension] Additional commit message validation..."
#     # Add your custom commit message validation here
#     return 0
# }

# prepush_extra() {
#     local branch="$1"
#     local base="$2"
#     local ahead="$3"
#     local limit="$4"
#     echo "[Extension] Running pre-push checks..."
#     # Add your custom pre-push logic here
#     return 0
# }
EOF
    chmod +x .githooks/run-commands.sh 2>/dev/null || true
fi

#######################################
# Installation Complete
#######################################

# Clear error trap
trap - ERR INT TERM

# Clean up rollback tracking
cleanup_rollback

# Write summary to log
log ""
echo "" >> "$LOG_FILE"
echo "============================================================================" >> "$LOG_FILE"
echo "Installation Summary" >> "$LOG_FILE"
echo "============================================================================" >> "$LOG_FILE"
echo "Timestamp: $(date)" >> "$LOG_FILE"
echo "Repository: $REPO_NAME" >> "$LOG_FILE"
echo "User: $USER_NAME <$USER_EMAIL>" >> "$LOG_FILE"
echo "Branch: $CURRENT_BRANCH" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"
echo "Configured Settings:" >> "$LOG_FILE"
echo "  - Hooks Path: .githooks" >> "$LOG_FILE"
echo "  - Max Commits: $(git config hooks.maxCommits)" >> "$LOG_FILE"
echo "  - Auto Add After Fix: $(git config hooks.autoAddAfterFix)" >> "$LOG_FILE"
echo "  - Branch Mappings: 15 types configured" >> "$LOG_FILE"
echo "  - Tests Enabled: $(git config hooks.tests.enabled 2>/dev/null || echo 'false')" >> "$LOG_FILE"
echo "  - .gitignore: Configured with hook patterns" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"
echo "Installation completed successfully" >> "$LOG_FILE"
echo "============================================================================" >> "$LOG_FILE"

# Print success summary
log "\n${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
log "${GREEN}${BOLD}✓ Installation Complete!${NC}"
log "${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}\n"

# Configuration summary
log "${MAGENTA}${BOLD}📋 Enforced Rules:${NC}\n"

log "${BLUE}${BOLD}1. Branch Naming:${NC}"
log "   ${CYAN}Long-lived:${NC}"
log "     • main, develop, release/*"
log "   ${CYAN}Short-lived:${NC}"
log "     • <type>-<JIRA>-<description>"
log "     • Example: ${BOLD}feat-ABC-123-user-authentication${NC}"
log ""

log "${BLUE}${BOLD}2. Branch Base Rules:${NC}"
log "   ${CYAN}Enforced at branch creation:${NC}"
log "   • feat, feature, bugfix, fix, techdebt, perf, refactor,"
log "     revert, style, test, build, chore, ci, docs → ${BOLD}origin/develop${NC}"
log "   • hotfix → ${BOLD}origin/main${NC}"
log "   ${YELLOW}Customize:${NC} git config hooks.branchMapping.<type> <base>"
log ""

log "${BLUE}${BOLD}3. Commit Messages:${NC}"
log "   • Format: ${CYAN}<type>: <JIRA-ID> <description>${NC}"
log "   • Types: feat, fix, chore, break, tests"
log "   • Example: ${BOLD}feat: ABC-123 Add user login${NC}"
log "   • Auto-prefill from branch name ✓"
log ""

log "${BLUE}${BOLD}4. Security:${NC}"
log "   • Secret scanning (AWS, GitHub, API keys, etc.)"
log "   • Sensitive file blocking (.env, *.pem, *.key, etc.)"
log ""

log "${BLUE}${BOLD}5. History Curation:${NC}"
log "   • Max commits per branch: ${BOLD}$(git config hooks.maxCommits)${NC}"
log "   • Enforce rebase (no merge commits to protected)"
log "   • Squash before push for clean history"
log ""

# Bypass options
log "${MAGENTA}${BOLD}🔓 Bypass Options:${NC}"
log "   ${YELLOW}BYPASS_HOOKS=1${NC}             Skip all hooks (emergency)"
log "   ${YELLOW}ALLOW_DIRECT_PROTECTED=1${NC}   Allow commit to protected branch"
log ""

# Configuration commands
log "${MAGENTA}${BOLD}⚙️  Configuration:${NC}"
log "   ${CYAN}git config hooks.maxCommits <number>${NC}              Set commit limit"
log "   ${CYAN}git config hooks.autoAddAfterFix true${NC}             Auto-restage after fixes"
log "   ${CYAN}git config hooks.parallelExecution true${NC}           Run commands in parallel"
log "   ${CYAN}git config hooks.branchMapping.<type> <base>${NC}      Custom branch base mapping"
log "     Example: ${BOLD}git config hooks.branchMapping.feat origin/staging${NC}"
log ""

# Log locations
log "${MAGENTA}${BOLD}📝 Log Locations:${NC}"
log "   • Hook execution: ${CYAN}.git/hook-logs/complete.log${NC}"
log "   • Hook-specific: ${CYAN}.git/hook-logs/<hook-name>.log${NC}"
log "   • Installation: ${CYAN}.githooks/logs/install-*.log${NC}"
log "   • Test runs: ${CYAN}.githooks/test/logs/test-run-*.log${NC}"
log "   • View logs: ${CYAN}tail -f .git/hook-logs/complete.log${NC}"
log ""

# Test infrastructure
log "${MAGENTA}${BOLD}🧪 Test Infrastructure:${NC}"
if [[ "$(git config hooks.tests.enabled 2>/dev/null)" == "true" ]]; then
    log "   ${GREEN}✓ Tests are enabled${NC}"
    log "   • Run tests: ${CYAN}bash .githooks/test/run-comprehensive-tests.sh${NC}"
    log "   • View config: ${CYAN}bash .githooks/test/test-config.sh show${NC}"
    log "   • Disable tests: ${CYAN}bash .githooks/test/test-config.sh disable${NC}"
    log "   • Test documentation: ${CYAN}.githooks/test/README.md${NC}"
else
    log "   ${YELLOW}Tests are not enabled${NC}"
    log "   • Enable tests: ${CYAN}bash .githooks/test/test-config.sh setup-dev${NC}"
    log "   • Documentation: ${CYAN}.githooks/test/README.md${NC}"
fi
log ""

# Test commands
log "${MAGENTA}${BOLD}🧪 Test Commands:${NC}\n"

log "${YELLOW}Test branch creation:${NC}"
log "  ${CYAN}git checkout -b test-invalid-branch${NC}          # Should warn"
log "  ${CYAN}git checkout -b feat-ABC-123-test-feature${NC}    # Should pass"
log ""

log "${YELLOW}Test commit message:${NC}"
log "  ${CYAN}git commit -m \"bad message\"${NC}                   # Should fail"
log "  ${CYAN}git commit -m \"feat: ABC-123 Good message\"${NC}    # Should pass"
log ""

log "${YELLOW}Test with bypass:${NC}"
log "  ${CYAN}BYPASS_HOOKS=1 git commit -m \"Emergency\"${NC}      # Skip all hooks"
log ""

log "${YELLOW}Add custom commands:${NC}"
log "  ${CYAN}nano .githooks/commands.conf${NC}                  # Edit config"
log "  ${CYAN}# Add: pre-commit:1:true:30:npm run lint:Linting${NC}"
log ""

log "${YELLOW}View recent logs:${NC}"
log "  ${CYAN}tail -20 .git/hook-logs/complete.log${NC}"
log "  ${CYAN}tail -20 .git/hook-logs/pre-commit.log${NC}"
log "  ${CYAN}cat .githooks/logs/install-${TIMESTAMP}.log${NC}"
log ""

# Installation verification
log "${MAGENTA}${BOLD}✅ Verify Installation:${NC}"
log "  ${CYAN}git config core.hooksPath${NC}                    # Should show: .githooks"
log "  ${CYAN}ls -la .githooks/${NC}                            # View hook files"
log "  ${CYAN}cat .githooks/commands.conf${NC}                  # View custom commands"
log "  ${CYAN}cat .gitignore | grep -A 6 'Git Hooks'${NC}       # Verify .gitignore"
log ""

log "${GREEN}${BOLD}🎉 Ready to use! Happy coding!${NC}\n"

log "${CYAN}${BOLD}Installation log saved to:${NC} ${BOLD}$LOG_FILE${NC}\n"

# Log installation to hook logs
if [ -d .git/hook-logs ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] [install] Hooks installed by $USER_NAME <$USER_EMAIL>" >> .git/hook-logs/complete.log
fi
