# Git Hooks - Troubleshooting Guide

**Version**: 3.0  
**Status**: Production-Ready ✅  
**Last Updated**: November 4, 2025

---

## 📋 Table of Contents

1. [Quick Diagnosis](#quick-diagnosis)
2. [Installation Issues](#installation-issues)
3. [Hook Execution Problems](#hook-execution-problems)
4. [Configuration Errors](#configuration-errors)
5. [Test Failures](#test-failures)
6. [Performance Issues](#performance-issues)
7. [Platform-Specific Issues](#platform-specific-issues)
8. [Common Errors](#common-errors)
9. [Debug Procedures](#debug-procedures)
10. [FAQ](#faq)

---

## Quick Diagnosis

### Is the Problem with Installation or Execution?

```bash
# Check if hooks are installed
git config core.hooksPath
# Expected: .githooks

# Check if hooks are executable
ls -l .githooks/pre-commit .githooks/commit-msg .githooks/pre-push
# Expected: -rwxr-xr-x (executable permissions)

# Check if hooks can run
bash .githooks/pre-commit --version 2>&1
# Expected: Version information or help message

# Quick test
git commit --allow-empty -m "test: TEST-123 Quick check"
# Should trigger hooks
```

### Quick Fixes

```bash
# Fix 1: Reset hooks path
git config core.hooksPath .githooks

# Fix 2: Fix permissions
chmod +x .githooks/pre-commit .githooks/commit-msg .githooks/pre-push

# Fix 3: Reinstall
bash .githooks/install-hooks.sh

# Fix 4: Complete reset
bash .githooks/uninstall-hooks.sh
bash .githooks/install-hooks.sh
```

### Check Installation Status

```bash
# View installation summary
cat .githooks/.installation-summary

# Check configuration
git config --list | grep hooks

# Check log files
ls -l .githooks/logs/

# View latest installation log
cat .githooks/logs/install-*.log | tail -50
```

---

## Installation Issues

### Issue 1: Installation Script Not Found

**Symptom**:
```bash
$ bash .githooks/install-hooks.sh
bash: .githooks/install-hooks.sh: No such file or directory
```

**Cause**: Script not in repository or wrong directory

**Solutions**:

1. **Check current directory**:
   ```bash
   pwd
   # Should be in repository root
   
   ls -la | grep .githooks
   # Should see .githooks directory
   ```

2. **Navigate to repository root**:
   ```bash
   cd $(git rev-parse --show-toplevel)
   bash .githooks/install-hooks.sh
   ```

3. **Clone repository fresh**:
   ```bash
   git clone <repository-url>
   cd <repository-name>
   bash .githooks/install-hooks.sh
   ```

### Issue 2: Permission Denied

**Symptom**:
```bash
$ bash .githooks/install-hooks.sh
bash: .githooks/install-hooks.sh: Permission denied
```

**Cause**: Script not executable

**Solutions**:

1. **Make script executable**:
   ```bash
   chmod +x .githooks/install-hooks.sh
   bash .githooks/install-hooks.sh
   ```

2. **Run with bash explicitly**:
   ```bash
   bash .githooks/install-hooks.sh
   # Works even without execute permission
   ```

3. **Fix all hook permissions**:
   ```bash
   chmod +x .githooks/*.sh
   chmod +x .githooks/pre-commit
   chmod +x .githooks/commit-msg
   chmod +x .githooks/pre-push
   ```

### Issue 3: Installation Fails Midway

**Symptom**:
```bash
Step 5/11: Setting up logging
ERROR: Failed to create log directory
Rolling back...
Installation failed. Check .githooks/logs/install-*.log for details
```

**Cause**: Various - permissions, disk space, existing files

**Solutions**:

1. **Check installation log**:
   ```bash
   cat .githooks/logs/install-*.log | grep -i error
   # Shows specific error
   ```

2. **Check disk space**:
   ```bash
   df -h .
   # Ensure sufficient space
   ```

3. **Check permissions**:
   ```bash
   ls -ld .githooks
   # Should be writable
   
   # Fix if needed
   chmod -R u+w .githooks
   ```

4. **Clean previous installation**:
   ```bash
   bash .githooks/uninstall-hooks.sh
   rm -rf .githooks/logs
   bash .githooks/install-hooks.sh
   ```

### Issue 4: .gitignore Not Updated

**Symptom**:
Installation completes but `.gitignore` doesn't contain hook patterns

**Cause**: Step 0 failed or .gitignore permissions

**Solutions**:

1. **Check .gitignore**:
   ```bash
   cat .gitignore | grep -A5 "Git Hooks"
   # Should see hook patterns
   ```

2. **Manually add patterns**:
   ```bash
   cat >> .gitignore << 'EOF'
   
   # Git Hooks - Local Files (DO NOT COMMIT)
   .githooks/.installation-summary
   .githooks/logs/
   .githooks/backup/
   .githooks/test/.test-state
   .githooks/test/logs/
   EOF
   ```

3. **Verify .gitignore is tracked**:
   ```bash
   git ls-files .gitignore
   # Should show .gitignore
   
   # If not tracked:
   git add .gitignore
   git commit -m "chore: Add .gitignore"
   ```

4. **Reinstall with verbose output**:
   ```bash
   bash .githooks/install-hooks.sh 2>&1 | tee install-debug.log
   # Check step 0 output
   ```

### Issue 5: Rollback Fails

**Symptom**:
```bash
Rolling back...
ERROR: Failed to restore git config
Rollback incomplete
```

**Cause**: Corrupted state or permissions

**Solutions**:

1. **Manual rollback**:
   ```bash
   # Reset hooks path
   git config --unset core.hooksPath
   
   # Remove configurations
   git config --unset-all hooks.branchNaming.enabled
   git config --remove-section hooks.branchNaming
   git config --remove-section hooks.commitMessage
   git config --remove-section hooks.security
   
   # Clean files
   rm -f .githooks/.installation-summary
   rm -rf .githooks/logs
   ```

2. **Check rollback log**:
   ```bash
   cat .githooks/logs/install-*.log | grep -A20 "ROLLBACK"
   # Shows what failed
   ```

3. **Nuclear option**:
   ```bash
   # Complete reset
   git config --remove-section hooks 2>/dev/null || true
   git config --unset core.hooksPath 2>/dev/null || true
   rm -rf .githooks/logs .githooks/backup
   rm -f .githooks/.installation-summary
   
   # Fresh install
   bash .githooks/install-hooks.sh
   ```

---

## Hook Execution Problems

### Issue 1: Hooks Not Running

**Symptom**:
Commits go through without any hook validation

**Diagnosis**:
```bash
# Check hooks path
git config core.hooksPath
# Expected: .githooks

# Check hook files exist
ls -l .githooks/pre-commit .githooks/commit-msg .githooks/pre-push

# Check if hooks are executable
file .githooks/pre-commit
# Expected: ...executable...
```

**Solutions**:

1. **Fix hooks path**:
   ```bash
   git config core.hooksPath .githooks
   ```

2. **Fix permissions**:
   ```bash
   chmod +x .githooks/pre-commit
   chmod +x .githooks/commit-msg
   chmod +x .githooks/pre-push
   ```

3. **Check if hooks are disabled**:
   ```bash
   git config hooks.enabled
   # Should NOT be "false"
   
   # If disabled, enable:
   git config --unset hooks.enabled
   ```

4. **Test manually**:
   ```bash
   # Should show output
   bash .githooks/pre-commit
   echo $?
   # Should show exit code
   ```

### Issue 2: Hook Fails with "Command Not Found"

**Symptom**:
```bash
$ git commit -m "test"
.githooks/pre-commit: line 45: jq: command not found
Hook failed
```

**Cause**: Missing dependencies

**Solutions**:

1. **Install jq**:
   ```bash
   # Ubuntu/Debian
   sudo apt-get install jq
   
   # macOS
   brew install jq
   
   # Windows (Git Bash)
   choco install jq
   ```

2. **Check other dependencies**:
   ```bash
   which bash git sed awk grep
   # All should return paths
   ```

3. **Add dependencies to PATH**:
   ```bash
   export PATH="/usr/local/bin:$PATH"
   # Add to ~/.bashrc or ~/.zshrc
   ```

### Issue 3: Hook Fails Silently

**Symptom**:
Hook doesn't show error but commit fails

**Diagnosis**:
```bash
# Run hook manually with verbose output
bash -x .githooks/pre-commit 2>&1 | tee hook-debug.log

# Check exit code
echo $?
# Non-zero indicates failure
```

**Solutions**:

1. **Check hook log**:
   ```bash
   cat .githooks/logs/pre-commit-*.log | tail -50
   # Shows recent hook executions
   ```

2. **Enable verbose mode**:
   ```bash
   git config hooks.verbose true
   # Hooks will show more output
   ```

3. **Check for suppressed output**:
   ```bash
   # Remove output redirection
   git commit -m "test" 2>&1
   # Shows all output
   ```

### Issue 4: Hook Takes Too Long

**Symptom**:
Hook runs but takes minutes to complete

**Diagnosis**:
```bash
# Time the hook
time bash .githooks/pre-commit

# Check what's slow
bash -x .githooks/pre-commit 2>&1 | tee hook-trace.log
# Look for slow commands
```

**Solutions**:

1. **Optimize security scanning**:
   ```bash
   # Reduce max file size
   git config hooks.security.maxFileSizeMB 5
   # Default is 10
   
   # Skip binary files
   git config hooks.security.skipBinaryFiles true
   ```

2. **Disable slow checks temporarily**:
   ```bash
   # Disable security scanning
   git config hooks.security.enabled false
   
   # Re-enable later
   git config hooks.security.enabled true
   ```

3. **Use parallel processing**:
   ```bash
   # Enable parallel commands
   git config hooks.commands.parallel true
   ```

4. **Reduce command timeout**:
   ```bash
   # Faster timeout (seconds)
   git config hooks.commands.timeout 5
   ```

---

## Configuration Errors

### Issue 1: Invalid Configuration Value

**Symptom**:
```bash
$ git commit -m "test"
ERROR: Invalid value for hooks.branchNaming.pattern
```

**Cause**: Malformed regex or invalid configuration

**Solutions**:

1. **Check current configuration**:
   ```bash
   git config hooks.branchNaming.pattern
   # Shows current value
   ```

2. **Reset to default**:
   ```bash
   git config hooks.branchNaming.pattern '^(feat|fix|hotfix|chore|refactor|test)-[A-Z]+-[0-9]+-[a-zA-Z0-9-]+$'
   ```

3. **Test regex**:
   ```bash
   # Test pattern
   echo "feat-ABC-123-test" | grep -E '^(feat|fix)-[A-Z]+-[0-9]+-[a-zA-Z0-9-]+$'
   # Should match
   ```

4. **View all configurations**:
   ```bash
   git config --list | grep hooks
   # Shows all hook configs
   ```

### Issue 2: Configuration Not Taking Effect

**Symptom**:
Changed configuration but hook still uses old value

**Cause**: Configuration cache or wrong scope

**Solutions**:

1. **Check configuration scope**:
   ```bash
   # Local (repository)
   git config hooks.branchNaming.enabled
   
   # Global (user)
   git config --global hooks.branchNaming.enabled
   
   # System
   git config --system hooks.branchNaming.enabled
   ```

2. **Force local configuration**:
   ```bash
   git config --local hooks.branchNaming.enabled true
   ```

3. **Remove conflicting global config**:
   ```bash
   git config --global --unset hooks.branchNaming.enabled
   ```

4. **Verify configuration**:
   ```bash
   git config --show-origin hooks.branchNaming.enabled
   # Shows which config file sets this value
   ```

### Issue 3: commands.conf Not Loaded

**Symptom**:
Custom commands in `commands.conf` don't execute

**Cause**: File format or permissions

**Solutions**:

1. **Check file exists**:
   ```bash
   ls -l .githooks/commands.conf
   # Should exist
   ```

2. **Check file format**:
   ```bash
   cat .githooks/commands.conf
   # Format: hook:priority:mandatory:timeout:command:description
   # Example: pre-commit:1:true:10:npm test:Run tests
   ```

3. **Validate format**:
   ```bash
   # Check for errors
   while IFS=: read -r hook priority mandatory timeout command desc; do
       echo "Hook: $hook, Command: $command"
   done < .githooks/commands.conf
   ```

4. **Enable custom commands**:
   ```bash
   git config hooks.commands.enabled true
   ```

---

## Test Failures

### Issue 1: All Tests Fail

**Symptom**:
```bash
$ bash .githooks/test/run-comprehensive-tests.sh
ERROR: Tests are not enabled
```

**Solutions**:

1. **Enable tests**:
   ```bash
   bash .githooks/test/test-config.sh setup-dev
   ```

2. **Check test configuration**:
   ```bash
   bash .githooks/test/test-config.sh show
   ```

3. **Verify test files**:
   ```bash
   ls -l .githooks/test/test-scenarios/
   # All test scripts should exist
   ```

### Issue 2: Specific Test Category Fails

**Symptom**:
```bash
[1/9] Branch Naming Tests
✗ Test 1: Valid feature branch (FAILED)
✗ Test 2: Valid bugfix branch (FAILED)
...
```

**Diagnosis**:
```bash
# Run category directly
bash .githooks/test/test-scenarios/test-branch-naming.sh

# Check logs
cat .githooks/test/logs/test-branch-naming-*.log
```

**Solutions**:

1. **Check hook is enabled**:
   ```bash
   git config hooks.branchNaming.enabled
   # Should be "true"
   ```

2. **Check test configuration**:
   ```bash
   git config hooks.tests.enabled
   git config hooks.tests.baseBranch
   ```

3. **Reset test environment**:
   ```bash
   bash .githooks/test/cleanup-test-environment.sh
   bash .githooks/test/setup-test-environment.sh
   ```

### Issue 3: Tests Leave Dirty State

**Symptom**:
After tests, repository has uncommitted changes or test branches

**Solutions**:

1. **Enable auto cleanup**:
   ```bash
   git config hooks.tests.autoCleanup true
   ```

2. **Manual cleanup**:
   ```bash
   bash .githooks/test/cleanup-test-environment.sh
   ```

3. **Force cleanup**:
   ```bash
   git checkout develop
   git branch | grep hook-test- | xargs git branch -D
   git reset --hard
   git clean -fd
   ```

### Issue 4: Rollback Tests Fail

**Symptom**:
```bash
[9/9] Rollback Tests
✗ Test 1: Normal installation (FAILED)
```

**Diagnosis**:
```bash
# Check rollback log
cat .githooks/logs/install-*.log | grep -i rollback
```

**Solutions**:

1. **Uninstall first**:
   ```bash
   bash .githooks/uninstall-hooks.sh
   bash .githooks/test/test-rollback.sh
   ```

2. **Check for conflicting installation**:
   ```bash
   git config core.hooksPath
   # Should be empty or .githooks
   
   # Clear if wrong
   git config --unset core.hooksPath
   ```

3. **Test manually**:
   ```bash
   # Backup state
   git config core.hooksPath > /tmp/hooks-backup
   
   # Run installation
   bash .githooks/install-hooks.sh
   
   # Check rollback file
   cat .githooks/.rollback-state
   ```

---

## Performance Issues

### Issue 1: Commits Take Too Long

**Symptom**:
Commits take 10+ seconds to complete

**Diagnosis**:
```bash
# Time the hooks
time git commit --allow-empty -m "test: PERF-123 Test"

# Profile individual hooks
time bash .githooks/pre-commit
time bash .githooks/commit-msg
```

**Solutions**:

1. **Optimize security scanning**:
   ```bash
   # Reduce file size limit
   git config hooks.security.maxFileSizeMB 5
   
   # Skip large files
   git config hooks.security.skipBinaryFiles true
   
   # Reduce pattern complexity
   git config hooks.security.scanDepth basic
   ```

2. **Disable verbose logging**:
   ```bash
   git config hooks.verbose false
   ```

3. **Optimize custom commands**:
   ```bash
   # Reduce timeout
   git config hooks.commands.timeout 5
   
   # Enable parallel execution
   git config hooks.commands.parallel true
   ```

4. **Profile slow commands**:
   ```bash
   # Add timing to hooks
   git config hooks.profiling true
   
   # Check logs
   cat .githooks/logs/pre-commit-*.log | grep "Time:"
   ```

### Issue 2: Security Scanning Too Slow

**Symptom**:
Pre-commit hook hangs on large files

**Solutions**:

1. **Check file sizes**:
   ```bash
   git diff --cached --name-only | xargs ls -lh
   # Identify large files
   ```

2. **Exclude large files**:
   ```bash
   # Add to .githooks/security-excludes
   echo "large-file.bin" >> .githooks/security-excludes
   ```

3. **Reduce max file size**:
   ```bash
   git config hooks.security.maxFileSizeMB 5
   ```

4. **Skip binary files**:
   ```bash
   git config hooks.security.skipBinaryFiles true
   ```

### Issue 3: Push Hook Timeout

**Symptom**:
```bash
$ git push
Checking commit count...
ERROR: Operation timed out
```

**Solutions**:

1. **Increase timeout**:
   ```bash
   git config hooks.push.timeout 30
   # Default is 10 seconds
   ```

2. **Disable history curation**:
   ```bash
   git config hooks.historyCuration.enabled false
   ```

3. **Increase commit limit**:
   ```bash
   git config hooks.historyCuration.maxCommits 10
   # Default is 5
   ```

---

## Platform-Specific Issues

### Windows

#### Issue 1: Line Ending Problems

**Symptom**:
```bash
.githooks/pre-commit: line 2: $'\r': command not found
```

**Cause**: Windows line endings (CRLF) instead of Unix (LF)

**Solutions**:

1. **Fix line endings**:
   ```bash
   # Convert all hook files
   dos2unix .githooks/pre-commit
   dos2unix .githooks/commit-msg
   dos2unix .githooks/pre-push
   dos2unix .githooks/install-hooks.sh
   ```

2. **Configure git**:
   ```bash
   git config core.autocrlf input
   # Checkout as LF, commit as LF
   ```

3. **Fix all files**:
   ```bash
   find .githooks -type f -name "*.sh" -exec dos2unix {} \;
   find .githooks -type f ! -name "*.md" ! -name "*.log" -exec dos2unix {} \;
   ```

#### Issue 2: Bash Not Found

**Symptom**:
```bash
'bash' is not recognized as an internal or external command
```

**Solutions**:

1. **Install Git Bash**:
   - Download from https://git-scm.com/downloads
   - Install with default options
   - Restart terminal

2. **Use Git Bash**:
   ```bash
   # Open Git Bash (not CMD or PowerShell)
   cd /e/BasicAngularApp
   bash .githooks/install-hooks.sh
   ```

3. **Add bash to PATH**:
   ```bash
   # Add Git bin directory to PATH
   # C:\Program Files\Git\bin
   ```

#### Issue 3: Permission Errors

**Symptom**:
```bash
chmod: changing permissions of '.githooks/pre-commit': Operation not permitted
```

**Solutions**:

1. **Run as Administrator**:
   - Right-click Git Bash
   - Select "Run as Administrator"
   - Run install script

2. **Disable Windows permissions check**:
   ```bash
   git config core.fileMode false
   ```

3. **Use icacls instead**:
   ```bash
   icacls .githooks\pre-commit /grant Everyone:RX
   ```

### macOS

#### Issue 1: Gatekeeper Blocks Execution

**Symptom**:
```bash
"pre-commit" cannot be opened because it is from an unidentified developer
```

**Solutions**:

1. **Allow execution**:
   ```bash
   xattr -d com.apple.quarantine .githooks/pre-commit
   xattr -d com.apple.quarantine .githooks/commit-msg
   xattr -d com.apple.quarantine .githooks/pre-push
   ```

2. **Disable Gatekeeper for hooks**:
   ```bash
   xattr -dr com.apple.quarantine .githooks
   ```

#### Issue 2: BSD vs GNU Tools

**Symptom**:
```bash
sed: illegal option -- r
```

**Cause**: macOS uses BSD versions of tools

**Solutions**:

1. **Install GNU tools**:
   ```bash
   brew install coreutils gnu-sed grep
   ```

2. **Update PATH**:
   ```bash
   export PATH="/usr/local/opt/gnu-sed/libexec/gnubin:$PATH"
   export PATH="/usr/local/opt/grep/libexec/gnubin:$PATH"
   # Add to ~/.zshrc or ~/.bash_profile
   ```

3. **Use compatible syntax**:
   - Hooks already use portable syntax
   - If custom commands, test on macOS

### Linux

#### Issue 1: SELinux Blocks Execution

**Symptom**:
```bash
Permission denied (SELinux)
```

**Solutions**:

1. **Check SELinux status**:
   ```bash
   getenforce
   # Shows: Enforcing, Permissive, or Disabled
   ```

2. **Set correct context**:
   ```bash
   chcon -t bin_t .githooks/pre-commit
   chcon -t bin_t .githooks/commit-msg
   chcon -t bin_t .githooks/pre-push
   ```

3. **Or disable SELinux for git** (not recommended):
   ```bash
   semanage fcontext -a -t bin_t ".githooks/.*"
   restorecon -R .githooks
   ```

#### Issue 2: Missing Dependencies

**Symptom**:
```bash
jq: command not found
```

**Solutions**:

```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install jq git bash

# CentOS/RHEL
sudo yum install jq git bash

# Fedora
sudo dnf install jq git bash

# Arch
sudo pacman -S jq git bash
```

---

## Common Errors

### Error 1: "Hooks path not set"

**Message**:
```
ERROR: Git hooks path is not configured
```

**Solution**:
```bash
git config core.hooksPath .githooks
```

### Error 2: "Branch name does not match pattern"

**Message**:
```
ERROR: Branch name 'my-feature' does not match required pattern
```

**Solution**:
```bash
# Use correct format
git checkout -b feat-ABC-123-my-feature

# Or disable validation
git config hooks.branchNaming.enabled false
```

### Error 3: "Commit message missing JIRA ID"

**Message**:
```
ERROR: Commit message must include JIRA ID (e.g., PROJ-123)
```

**Solution**:
```bash
# Use correct format
git commit -m "feat: PROJ-123 Add feature"

# Or disable validation
git config hooks.commitMessage.enabled false
```

### Error 4: "Secret detected in commit"

**Message**:
```
ERROR: Potential secret detected: AWS_ACCESS_KEY
```

**Solution**:
```bash
# Remove secret from file
# Or add to .githooks/security-whitelist
echo "aws_access_key_id = AKIAIOSFODNN7EXAMPLE" >> .githooks/security-whitelist

# Or disable temporarily
git config hooks.security.enabled false
git commit ...
git config hooks.security.enabled true
```

### Error 5: "Too many commits"

**Message**:
```
ERROR: Branch has 6 commits. Maximum allowed is 5.
Please squash your commits.
```

**Solution**:
```bash
# Squash commits
git rebase -i develop

# Or increase limit
git config hooks.historyCuration.maxCommits 10

# Or disable
git config hooks.historyCuration.enabled false
```

### Error 6: "Direct commit to protected branch"

**Message**:
```
ERROR: Direct commits to 'main' are not allowed
```

**Solution**:
```bash
# Create feature branch
git checkout -b feat-ABC-123-feature main
git commit ...

# Or bypass (emergency only)
ALLOW_DIRECT_PROTECTED=1 git commit ...
```

### Error 7: "Log file with color codes"

**Message**:
Log files contain `\033[0;36m` and other ANSI codes

**Solution**:
```bash
# Already fixed in v3.0
# If still seeing issues:

# Check log() function in install-hooks.sh
grep -A5 "^log()" .githooks/install-hooks.sh
# Should contain: sed 's/\x1b\[[0-9;]*m//g'

# Manual fix if needed:
sed -i 's/\x1b\[[0-9;]*m//g' .githooks/logs/*.log
```

---

## Debug Procedures

### Procedure 1: Full Diagnostic

```bash
#!/bin/bash
# Save as: debug-hooks.sh

echo "=== Git Hooks Diagnostic ==="
echo

echo "1. Repository Info"
git rev-parse --show-toplevel
git branch --show-current
echo

echo "2. Hooks Configuration"
git config core.hooksPath
git config --list | grep hooks
echo

echo "3. Hook Files"
ls -l .githooks/pre-commit .githooks/commit-msg .githooks/pre-push
echo

echo "4. Hook Executability"
file .githooks/pre-commit
bash -n .githooks/pre-commit && echo "Syntax OK" || echo "Syntax ERROR"
echo

echo "5. Dependencies"
which bash git jq sed awk grep
echo

echo "6. Recent Logs"
ls -lt .githooks/logs/*.log | head -5
echo

echo "7. Test Hook Execution"
bash .githooks/pre-commit --version 2>&1
echo "Exit code: $?"
```

### Procedure 2: Clean Reinstall

```bash
#!/bin/bash
# Complete clean reinstall

echo "Step 1: Backup configuration"
git config --list | grep hooks > hooks-config-backup.txt

echo "Step 2: Uninstall"
bash .githooks/uninstall-hooks.sh

echo "Step 3: Clean all artifacts"
rm -rf .githooks/logs .githooks/backup .githooks/.installation-summary

echo "Step 4: Reset configuration"
git config --remove-section hooks 2>/dev/null || true
git config --unset core.hooksPath 2>/dev/null || true

echo "Step 5: Fresh install"
bash .githooks/install-hooks.sh

echo "Step 6: Restore configuration (if needed)"
echo "Review hooks-config-backup.txt and restore needed configs"
```

### Procedure 3: Test Individual Components

```bash
# Test branch naming
git checkout -b feat-TEST-999-debug develop
# Should succeed

# Test commit message
git commit --allow-empty -m "feat: TEST-999 Test commit"
# Should succeed

# Test security scanning
echo 'API_KEY="test123"' > test.js
git add test.js
git commit -m "feat: TEST-999 Add test"
# Should fail (secret detected)

# Cleanup
git reset HEAD test.js
rm test.js
git checkout develop
git branch -D feat-TEST-999-debug
```

### Procedure 4: Analyze Logs

```bash
# Find all recent errors
grep -i error .githooks/logs/*.log

# Show last hook execution
ls -t .githooks/logs/pre-commit-*.log | head -1 | xargs cat

# Show installation summary
cat .githooks/.installation-summary

# Show rollback state (if exists)
cat .githooks/.rollback-state
```

---

## FAQ

### Q1: Can I disable hooks temporarily?

**A**: Yes, multiple ways:

```bash
# Method 1: Disable entirely
git config core.hooksPath ""
# Re-enable: git config core.hooksPath .githooks

# Method 2: Use git flag
git commit --no-verify -m "message"

# Method 3: Disable specific feature
git config hooks.branchNaming.enabled false
```

### Q2: Can I customize validation rules?

**A**: Yes, all rules are configurable:

```bash
# Custom branch pattern
git config hooks.branchNaming.pattern '^(feature|bugfix)/.*'

# Custom commit pattern
git config hooks.commitMessage.pattern '^(feat|fix):\\s*\\[JIRA-[0-9]+\\]'

# Custom commit limit
git config hooks.historyCuration.maxCommits 10
```

### Q3: How do I add exceptions for specific files?

**A**: Use whitelist files:

```bash
# Security exceptions
echo "config/secrets-example.json" >> .githooks/security-whitelist

# Large file exceptions
echo "data/large-dataset.csv" >> .githooks/security-excludes
```

### Q4: Can hooks work in CI/CD?

**A**: Yes, but with considerations:

```bash
# Option 1: Run tests instead
bash .githooks/test/run-comprehensive-tests.sh

# Option 2: Enable hooks in CI
git config core.hooksPath .githooks
# Then normal git commands work

# Option 3: Run hooks manually
bash .githooks/pre-commit
bash .githooks/commit-msg .git/COMMIT_EDITMSG
```

### Q5: What if I get a false positive from security scanning?

**A**: Add to whitelist:

```bash
# Add specific string
echo "EXAMPLE_KEY_NOT_REAL" >> .githooks/security-whitelist

# Or disable temporarily
git config hooks.security.enabled false
git commit ...
git config hooks.security.enabled true
```

### Q6: How do I completely remove hooks?

**A**: Use uninstall script:

```bash
# Clean uninstall
bash .githooks/uninstall-hooks.sh

# Nuclear option
git config --remove-section hooks
git config --unset core.hooksPath
rm -rf .githooks
```

### Q7: Can I use different settings per branch?

**A**: Not directly, but workarounds:

```bash
# Option 1: Use branch-specific configs (manual)
if [ "$(git branch --show-current)" = "main" ]; then
    git config hooks.historyCuration.maxCommits 3
fi

# Option 2: Disable on specific branches
if [ "$(git branch --show-current)" = "hotfix" ]; then
    git config hooks.branchNaming.enabled false
fi
```

### Q8: What's the performance impact?

**A**: Typically 0.5-2 seconds per commit:

```bash
# Measure yourself
time git commit --allow-empty -m "test: PERF-123 Test"

# Optimize if needed:
git config hooks.security.maxFileSizeMB 5
git config hooks.verbose false
git config hooks.commands.parallel true
```

### Q9: Are hooks shared with the team?

**A**: Yes, hooks are in `.githooks/` directory:

```bash
# Shared (committed to repo):
- Hook scripts
- Configuration templates
- Test infrastructure

# Local only (in .gitignore):
- .installation-summary
- logs/
- backup/
```

### Q10: What happens during merge conflicts?

**A**: Hooks still run but with considerations:

```bash
# During merge:
# - Branch naming: skipped (already on branch)
# - Commit message: validates merge message
# - Security: scans merged changes
# - History: checks combined history

# Resume after resolving conflicts:
git add resolved-file.js
git commit  # Hooks run normally
```

---

## Getting Help

### Check Documentation

- [GITHOOKS_README.md](GITHOOKS_README.md) - Main documentation
- [GITHOOKS_TESTING.md](GITHOOKS_TESTING.md) - Testing guide
- [GITHOOKS_CONTRIBUTING.md](GITHOOKS_CONTRIBUTING.md) - Development guide

### Enable Debug Mode

```bash
# Verbose output
git config hooks.verbose true

# Trace execution
bash -x .githooks/pre-commit

# Save debug output
git commit ... 2>&1 | tee debug.log
```

### Create Issue Report

```bash
# Collect information
cat > issue-report.txt << EOF
## Environment
- OS: $(uname -a)
- Git: $(git --version)
- Bash: $(bash --version | head -1)

## Configuration
$(git config --list | grep hooks)

## Hook Status
$(ls -l .githooks/pre-commit .githooks/commit-msg .githooks/pre-push)

## Recent Logs
$(ls -t .githooks/logs/*.log | head -3 | xargs tail -20)

## Error
[Paste error message here]

## Steps to Reproduce
1. [Step 1]
2. [Step 2]
3. [Error occurs]
EOF

# Submit with issue report
```

---

**Version**: 3.0  
**Status**: Production-Ready ✅  
**Last Updated**: November 4, 2025

**See Also**:
- [GITHOOKS_README.md](GITHOOKS_README.md) - Complete documentation  
- [GITHOOKS_TESTING.md](GITHOOKS_TESTING.md) - Testing guide
- [GITHOOKS_CONTRIBUTING.md](GITHOOKS_CONTRIBUTING.md) - Contributing guide
