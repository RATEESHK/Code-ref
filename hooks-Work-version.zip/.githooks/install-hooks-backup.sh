#!/usr/bin/env bash

set -euo pipefail

# ============================================================================
# Git Hooks Installation Script
# Purpose: Configure repository to use .githooks
# ============================================================================

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'
BOLD='\033[1m'

# Setup logging
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="${SCRIPT_DIR}/logs"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOG_FILE="${LOG_DIR}/install-${TIMESTAMP}.log"

# Create log directory
mkdir -p "$LOG_DIR"

# Logging function
log() {
    local msg="$*"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] $msg" >> "$LOG_FILE"
    echo -e "$msg"
}

# Installation header
log "${CYAN}${BOLD}"
log "╔════════════════════════════════════════════════════════════════════╗"
log "║              Git Hooks Installation Script v2.0                    ║"
log "║          Production-Ready Cross-Platform Hook Suite               ║"
log "╚════════════════════════════════════════════════════════════════════╝"
log "${NC}\n"

log "${BLUE}Installation Log: ${BOLD}$LOG_FILE${NC}\n"

# Verify Git repository
if [ ! -d .git ]; then
    log "${RED}${BOLD}Error:${NC} Not a git repository"
    log "${YELLOW}Solution:${NC} Run from repository root or initialize with: ${CYAN}git init${NC}"
    exit 1
fi

# Get repository info
REPO_NAME=$(basename "$(git rev-parse --show-toplevel)")
USER_NAME=$(git config user.name 2>/dev/null || echo "Unknown")
USER_EMAIL=$(git config user.email 2>/dev/null || echo "Unknown")
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "Unknown")

log "${BLUE}${BOLD}Repository Information:${NC}"
log "  ${CYAN}Name:${NC}    $REPO_NAME"
log "  ${CYAN}User:${NC}    $USER_NAME <$USER_EMAIL>"
log "  ${CYAN}Branch:${NC}  $CURRENT_BRANCH"
log ""

# Step 1: Set hooks path
log "${YELLOW}[1/10]${NC} Setting Git hooks path..."
git config core.hooksPath .githooks
log "${GREEN}  ✓${NC} Hooks path configured: ${BOLD}.githooks/${NC}"

# Step 2: Enable rebase autosquash
log "${YELLOW}[2/10]${NC} Enabling rebase autosquash..."
git config rebase.autosquash true
log "${GREEN}  ✓${NC} Autosquash enabled for interactive rebases"

# Step 3: Enable fetch prune
log "${YELLOW}[3/10]${NC} Enabling automatic remote pruning..."
git config fetch.prune true
log "${GREEN}  ✓${NC} Auto-prune enabled (cleans stale remote refs)"

# Step 4: Set default max commits
log "${YELLOW}[4/10]${NC} Configuring commit limits..."
if [ -z "$(git config hooks.maxCommits 2>/dev/null)" ]; then
    git config hooks.maxCommits 5
    log "${GREEN}  ✓${NC} Max commits set to ${BOLD}5${NC} (default)"
else
    MAX_COMMITS=$(git config hooks.maxCommits)
    log "${GREEN}  ✓${NC} Max commits already configured: ${BOLD}$MAX_COMMITS${NC}"
fi

# Step 5: Configure auto-restage (optional)
log "${YELLOW}[5/10]${NC} Configuring auto-restage after fixes..."
if [ -z "$(git config hooks.autoAddAfterFix 2>/dev/null)" ]; then
    git config hooks.autoAddAfterFix false
    log "${GREEN}  ✓${NC} Auto-restage disabled (set to ${BOLD}true${NC} to enable)"
else
    AUTO_ADD=$(git config hooks.autoAddAfterFix)
    log "${GREEN}  ✓${NC} Auto-restage: ${BOLD}$AUTO_ADD${NC}"
fi

# Step 5.5: Configure branch base mappings
log "${YELLOW}[5.5/10]${NC} Configuring branch base mappings..."

# Simple approach without complex syntax
mappings_set=0

# Set hotfix → origin/main
if [ -z "$(git config hooks.branchMapping.hotfix 2>/dev/null)" ]; then
    git config hooks.branchMapping.hotfix "origin/main"
    mappings_set=$((mappings_set + 1))
fi

# Set all develop-based branches
for branch_type in feat feature bugfix fix techdebt perf refactor revert style test build chore ci docs; do
    if [ -z "$(git config hooks.branchMapping.$branch_type 2>/dev/null)" ]; then
        git config hooks.branchMapping.$branch_type "origin/develop"
        mappings_set=$((mappings_set + 1))
    fi
done

if [ $mappings_set -gt 0 ]; then
    log "${GREEN}  ✓${NC} Configured ${BOLD}$mappings_set${NC} branch type mappings"
    log "${CYAN}    • hotfix → origin/main${NC}"
    log "${CYAN}    • feat, bugfix, fix, etc. → origin/develop${NC}"
else
    log "${GREEN}  ✓${NC} Branch mappings already configured"
fi
log "${YELLOW}    Customize: ${BOLD}git config hooks.branchMapping.<type> <base>${NC}"

# Step 6: Make hooks executable
log "${YELLOW}[6/10]${NC} Making hooks executable..."
if command -v chmod >/dev/null 2>&1; then
    chmod +x .githooks/* 2>/dev/null || true
    chmod +x .githooks/lib/* 2>/dev/null || true
    chmod +x .githooks/test/*.sh 2>/dev/null || true
    chmod +x .githooks/test/test-scenarios/*.sh 2>/dev/null || true
    log "${GREEN}  ✓${NC} All hook files are now executable"
else
    log "${YELLOW}  ⚠${NC} chmod not available (Windows), files may need manual permissions"
fi

# Step 7: Create log directory
log "${YELLOW}[7/10]${NC} Setting up logging infrastructure..."
mkdir -p .git/hook-logs 2>/dev/null || true
touch .git/hook-logs/complete.log 2>/dev/null || true
log "${GREEN}  ✓${NC} Log directory created: ${BOLD}.git/hook-logs/${NC}"

# Step 8: Add logs to gitignore
log "${YELLOW}[8/10]${NC} Excluding logs from version control..."
if ! grep -q "^hook-logs/" .git/info/exclude 2>/dev/null; then
    echo "hook-logs/" >> .git/info/exclude 2>/dev/null || true
fi
log "${GREEN}  ✓${NC} Logs excluded from Git tracking"

# Step 9: Setup test infrastructure
log "${YELLOW}[9/10]${NC} Setting up test infrastructure..."

# Create test log directory
mkdir -p .githooks/test/logs 2>/dev/null || true
log "${GREEN}  ✓${NC} Test log directory created"

# Test configuration prompt
log ""
log "${CYAN}${BOLD}Test Infrastructure Available:${NC}"
log "  The hook test suite can verify all hook functionality."
log "  Tests require explicit enablement for safety."
log ""
read -p "  Would you like to enable tests now? (y/N): " -n 1 -r
log ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log "  ${YELLOW}Enabling test infrastructure...${NC}"
    bash .githooks/test/test-config.sh setup-dev >> "$LOG_FILE" 2>&1 || true
    log "${GREEN}  ✓${NC} Tests enabled (run with: ${BOLD}bash .githooks/test/run-comprehensive-tests.sh${NC})"
else
    log "${CYAN}  ℹ${NC} Tests not enabled"
    log "  ${YELLOW}Enable later with:${NC} bash .githooks/test/test-config.sh setup-dev"
fi
log ""

# Step 10: Create example commands.conf if not exists
log "${YELLOW}[10/10]${NC} Setting up custom command framework..."
if [ ! -f .githooks/commands.conf ]; then
    cat > .githooks/commands.conf << 'EOF'
# Git Hooks Custom Commands Configuration
# Format: HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
#
# HOOK      - Hook name (pre-commit, commit-msg, pre-push)
# PRIORITY  - Execution order (lower runs first)
# MANDATORY - true=block on failure, false=warn only
# TIMEOUT   - Max seconds to run (0=no timeout)
# COMMAND   - Shell command to execute (use {staged} for staged files)
# DESCRIPTION - Human-readable description
#
# Examples:
# pre-commit:1:true:30:npx lint-staged:Lint and format staged files
# pre-commit:2:false:60:npx tsc --noEmit:TypeScript type checking
# pre-commit:3:true:30:node scripts/check-casing.js:Check file casing
# pre-push:1:true:300:npm test:Run test suite
# pre-push:2:false:600:npm run build:Build verification
# commit-msg:1:false:10:node scripts/validate-ticket.js:Validate ticket format
#
# Uncomment and customize the lines below:
# pre-commit:1:true:60:npx lint-staged:Lint and Format
# pre-push:1:true:300:npm test:Test Suite
EOF
    log "${GREEN}  ✓${NC} Example commands.conf created"
else
    log "${GREEN}  ✓${NC} commands.conf already exists"
fi

# Create legacy extension file for backward compatibility
if [ ! -f .githooks/run-commands.sh ]; then
    cat > .githooks/run-commands.sh << 'EOF'
#!/usr/bin/env bash

# ============================================================================
# Legacy Extension Framework (Deprecated - Use commands.conf instead)
# Purpose: Backward compatibility for custom hook extensions
# ============================================================================

# Uncomment and implement these functions for custom logic:

# precommit_extra() {
#     local files=("$@")
#     echo "[Extension] Running pre-commit checks on ${#files[@]} files..."
#     # Add your custom pre-commit logic here
#     return 0
# }

# commitmsg_extra() {
#     local msg_file="$1"
#     echo "[Extension] Additional commit message validation..."
#     # Add your custom commit message validation here
#     return 0
# }

# prepush_extra() {
#     local branch="$1"
#     local base="$2"
#     local ahead="$3"
#     local limit="$4"
#     echo "[Extension] Running pre-push checks..."
#     # Add your custom pre-push logic here
#     return 0
# }
EOF
    chmod +x .githooks/run-commands.sh 2>/dev/null || true
fi

# Print success summary
log "\n${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
log "${GREEN}${BOLD}✓ Installation Complete!${NC}"
log "${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}\n"

# Write summary to log
echo "" >> "$LOG_FILE"
echo "============================================================================" >> "$LOG_FILE"
echo "Installation Summary" >> "$LOG_FILE"
echo "============================================================================" >> "$LOG_FILE"
echo "Timestamp: $(date)" >> "$LOG_FILE"
echo "Repository: $REPO_NAME" >> "$LOG_FILE"
echo "User: $USER_NAME <$USER_EMAIL>" >> "$LOG_FILE"
echo "Branch: $CURRENT_BRANCH" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"
echo "Configured Settings:" >> "$LOG_FILE"
echo "  - Hooks Path: .githooks" >> "$LOG_FILE"
echo "  - Max Commits: $(git config hooks.maxCommits)" >> "$LOG_FILE"
echo "  - Auto Add After Fix: $(git config hooks.autoAddAfterFix)" >> "$LOG_FILE"
echo "  - Branch Mappings: 15 types configured" >> "$LOG_FILE"
echo "  - Tests Enabled: $(git config hooks.tests.enabled 2>/dev/null || echo 'false')" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"
echo "Installation completed successfully" >> "$LOG_FILE"
echo "============================================================================" >> "$LOG_FILE"

# Configuration summary
log "${MAGENTA}${BOLD}📋 Enforced Rules:${NC}\n"

log "${BLUE}${BOLD}1. Branch Naming:${NC}"
log "   ${CYAN}Long-lived:${NC}"
log "     • main, develop, release/*"
log "   ${CYAN}Short-lived:${NC}"
log "     • <type>-<JIRA>-<description>"
log "     • Example: ${BOLD}feat-ABC-123-user-authentication${NC}"
log ""

log "${BLUE}${BOLD}2. Branch Base Rules:${NC}"
log "   ${CYAN}Enforced at branch creation:${NC}"
log "   • feat, feature, bugfix, fix, techdebt, perf, refactor,"
log "     revert, style, test, build, chore, ci, docs → ${BOLD}origin/develop${NC}"
log "   • hotfix → ${BOLD}origin/main${NC}"
log "   ${YELLOW}Customize:${NC} git config hooks.branchMapping.<type> <base>"
log ""

log "${BLUE}${BOLD}3. Commit Messages:${NC}"
log "   • Format: ${CYAN}<type>: <JIRA-ID> <description>${NC}"
log "   • Types: feat, fix, chore, break, tests"
log "   • Example: ${BOLD}feat: ABC-123 Add user login${NC}"
log "   • Auto-prefill from branch name ✓"
log ""

log "${BLUE}${BOLD}4. Security:${NC}"
log "   • Secret scanning (AWS, GitHub, API keys, etc.)"
log "   • Sensitive file blocking (.env, *.pem, *.key, etc.)"
log ""

log "${BLUE}${BOLD}5. History Curation:${NC}"
log "   • Max commits per branch: ${BOLD}$(git config hooks.maxCommits)${NC}"
log "   • Enforce rebase (no merge commits to protected)"
log "   • Squash before push for clean history"
log ""

# Bypass options
log "${MAGENTA}${BOLD}🔓 Bypass Options:${NC}"
log "   ${YELLOW}BYPASS_HOOKS=1${NC}             Skip all hooks (emergency)"
log "   ${YELLOW}ALLOW_DIRECT_PROTECTED=1${NC}   Allow commit to protected branch"
log ""

# Configuration commands
log "${MAGENTA}${BOLD}⚙️  Configuration:${NC}"
log "   ${CYAN}git config hooks.maxCommits <number>${NC}              Set commit limit"
log "   ${CYAN}git config hooks.autoAddAfterFix true${NC}             Auto-restage after fixes"
log "   ${CYAN}git config hooks.parallelExecution true${NC}           Run commands in parallel"
log "   ${CYAN}git config hooks.branchMapping.<type> <base>${NC}      Custom branch base mapping"
log "     Example: ${BOLD}git config hooks.branchMapping.feat origin/staging${NC}"
log ""

# Log locations
log "${MAGENTA}${BOLD}📝 Log Locations:${NC}"
log "   • Hook execution: ${CYAN}.git/hook-logs/complete.log${NC}"
log "   • Hook-specific: ${CYAN}.git/hook-logs/<hook-name>.log${NC}"
log "   • Installation: ${CYAN}.githooks/logs/install-*.log${NC}"
log "   • Test runs: ${CYAN}.githooks/test/logs/test-run-*.log${NC}"
log "   • View logs: ${CYAN}tail -f .git/hook-logs/complete.log${NC}"
log ""

# Test infrastructure
log "${MAGENTA}${BOLD}🧪 Test Infrastructure:${NC}"
if [[ "$(git config hooks.tests.enabled 2>/dev/null)" == "true" ]]; then
    log "   ${GREEN}✓ Tests are enabled${NC}"
    log "   • Run tests: ${CYAN}bash .githooks/test/run-comprehensive-tests.sh${NC}"
    log "   • View config: ${CYAN}bash .githooks/test/test-config.sh show${NC}"
    log "   • Test documentation: ${CYAN}.githooks/test/README.md${NC}"
else
    log "   ${YELLOW}Tests are not enabled${NC}"
    log "   • Enable tests: ${CYAN}bash .githooks/test/test-config.sh setup-dev${NC}"
    log "   • Documentation: ${CYAN}.githooks/test/README.md${NC}"
fi
log ""

# Test commands
log "${MAGENTA}${BOLD}🧪 Test Commands:${NC}\n"

log "${YELLOW}Test branch creation:${NC}"
log "  ${CYAN}git checkout -b test-invalid-branch${NC}          # Should warn"
log "  ${CYAN}git checkout -b feat-ABC-123-test-feature${NC}    # Should pass"
log ""

log "${YELLOW}Test commit message:${NC}"
log "  ${CYAN}git commit -m \"bad message\"${NC}                   # Should fail"
log "  ${CYAN}git commit -m \"feat: ABC-123 Good message\"${NC}    # Should pass"
log ""

log "${YELLOW}Test with bypass:${NC}"
log "  ${CYAN}BYPASS_HOOKS=1 git commit -m \"Emergency\"${NC}      # Skip all hooks"
log ""

log "${YELLOW}Add custom commands:${NC}"
log "  ${CYAN}nano .githooks/commands.conf${NC}                  # Edit config"
log "  ${CYAN}# Add: pre-commit:1:true:30:npm run lint:Linting${NC}"
log ""

log "${YELLOW}View recent logs:${NC}"
log "  ${CYAN}tail -20 .git/hook-logs/complete.log${NC}"
log "  ${CYAN}tail -20 .git/hook-logs/pre-commit.log${NC}"
log  "  ${CYAN}cat .githooks/logs/install-${TIMESTAMP}.log${NC}"
log ""

# Installation verification
log "${MAGENTA}${BOLD}✅ Verify Installation:${NC}"
log "  ${CYAN}git config core.hooksPath${NC}                    # Should show: .githooks"
log "  ${CYAN}ls -la .githooks/${NC}                            # View hook files"
log "  ${CYAN}cat .githooks/commands.conf${NC}                  # View custom commands"
log ""

log "${GREEN}${BOLD}🎉 Ready to use! Happy coding!${NC}\n"

log "${CYAN}${BOLD}Installation log saved to:${NC} ${BOLD}$LOG_FILE${NC}\n"

# Log installation to hook logs
if [ -d .git/hook-logs ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] [install] Hooks installed by $USER_NAME <$USER_EMAIL>" >> .git/hook-logs/complete.log
fi
