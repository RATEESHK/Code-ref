# Git Hooks - Complete Documentation

**Version**: 3.0  
**Status**: Production-Ready ✅  
**Last Updated**: November 4, 2025

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Quick Start](#quick-start)
3. [Installation](#installation)
4. [Uninstallation](#uninstallation)
5. [Configuration](#configuration)
6. [Hook Features](#hook-features)
7. [Usage Examples](#usage-examples)
8. [Reset & Cleanup](#reset--cleanup)
9. [Advanced Topics](#advanced-topics)
10. [Reference](#reference)

---

## Overview

### What Are Git Hooks?

This repository includes a comprehensive Git hooks system that enforces code quality, security, and team workflows. The hooks run automatically at specific Git lifecycle events (commit, push, branch creation, etc.) to validate and enforce standards.

### Key Features

✅ **Automatic Branch Naming** - Enforces conventional branch naming (`type-JIRA-description`)  
✅ **Commit Message Validation** - Ensures commits follow format (`type: JIRA-ID description`)  
✅ **Base Branch Enforcement** - Validates branches are created from correct base (develop/main)  
✅ **Secret Scanning** - Prevents committing sensitive data (API keys, passwords, tokens)  
✅ **History Curation** - Limits commits per branch to keep history clean  
✅ **Custom Commands** - Extensible framework for linters, formatters, tests  
✅ **Production-Ready Rollback** - Complete installation rollback on any failure  
✅ **Automatic .gitignore** - Manages .gitignore patterns automatically  
✅ **Comprehensive Logging** - Full audit trail of all operations  
✅ **Test Infrastructure** - Built-in testing framework with 84+ tests  

### System Architecture

```
Repository Root
├── .githooks/              # Hook scripts directory
│   ├── pre-commit          # Runs before commit
│   ├── commit-msg          # Validates commit messages
│   ├── post-checkout       # Validates branch creation
│   ├── pre-push            # Validates before push
│   ├── install-hooks.sh    # Installation script
│   ├── uninstall-hooks.sh  # Uninstallation script
│   ├── commands.conf       # Custom command configuration
│   ├── lib/                # Shared hook library functions
│   ├── test/               # Test infrastructure
│   └── logs/               # Installation/uninstall logs
├── .git/
│   └── hook-logs/          # Hook execution logs
└── .gitignore              # Auto-managed ignore patterns
```

---

## Quick Start

### Installation (3 Steps)

```bash
# 1. Navigate to repository
cd /path/to/your/repository

# 2. Run installation script
bash .githooks/install-hooks.sh

# 3. Follow prompts (creates/updates .gitignore, configures hooks)
```

### Verification

```bash
# Check hooks are configured
git config core.hooksPath
# Expected output: .githooks

# Test branch creation
git checkout -b feat-TEST-123-verify-installation
# Should pass with valid naming

# Test commit
git commit --allow-empty -m "feat: TEST-123 Verify hooks working"
# Should pass with valid message

# Cleanup
git checkout main
git branch -D feat-TEST-123-verify-installation
```

### Uninstallation (If Needed)

```bash
bash .githooks/uninstall-hooks.sh
```

---

## Installation

### Prerequisites

- **Git** 2.9+ (for core.hooksPath support)
- **Bash** 4.0+ (Git Bash on Windows, native on Linux/macOS)
- **Basic Unix tools** (sed, grep, awk - included in Git Bash)

### Installation Process

The installation script performs **12 steps**:

#### Step 0: .gitignore Management
- **Detects** if `.gitignore` exists
- **Checks** if hook patterns are present
- **Prompts** to create if missing
- **Adds** required patterns if needed
- **Backs up** original file before changes
- **Required patterns**:
  ```gitignore
  # Git Hooks - Custom Ignores
  .git/hook-logs/
  .git/hook-logs-archive-*.tar.gz
  .githooks/test/logs/
  .githooks/test/.test-state
  .githooks/logs/
  ```

#### Step 1: Set Hooks Path
- **Configures** `git config core.hooksPath .githooks`
- **Enables** custom hooks directory
- **Rollback**: Restores old value or unsets

#### Step 2: Enable Rebase Autosquash
- **Configures** `git config rebase.autosquash true`
- **Purpose**: Automatically apply fixup!/squash! commits during interactive rebase
- **Rollback**: Restores old value

#### Step 3: Enable Auto-Prune
- **Configures** `git config fetch.prune true`
- **Purpose**: Removes stale remote-tracking branches on fetch
- **Rollback**: Restores old value

#### Step 4: Set Commit Limits
- **Configures** `git config hooks.maxCommits 5`
- **Purpose**: Maximum commits allowed per feature branch
- **Rollback**: Unsets or restores old value

#### Step 5: Configure Auto-Restage
- **Configures** `git config hooks.autoAddAfterFix false`
- **Purpose**: Whether to automatically re-stage files after hook fixes
- **Rollback**: Unsets or restores old value

#### Step 6: Branch Base Mappings
- **Configures** 15 branch type mappings:
  - `hotfix` → `origin/main`
  - `feat, feature, bugfix, fix, techdebt, perf, refactor, revert, style, test, build, chore, ci, docs` → `origin/develop`
- **Purpose**: Enforces correct base branch for each branch type
- **Rollback**: Unsets all mappings

#### Step 7: Make Hooks Executable
- **Sets** execute permissions on all hook files
- **Note**: May require manual permissions on Windows
- **Rollback**: N/A (permissions retained)

#### Step 8: Create Log Directory
- **Creates** `.git/hook-logs/` directory
- **Purpose**: Store hook execution logs
- **Rollback**: Removes directory

#### Step 9: Exclude Logs from Git
- **Adds** `hook-logs/` to `.git/info/exclude`
- **Purpose**: Prevents logs from being tracked
- **Rollback**: N/A (local exclude file)

#### Step 10: Test Infrastructure Setup
- **Creates** `.githooks/test/logs/` directory
- **Prompts** to enable test infrastructure (optional)
- **Configures** test settings if enabled
- **Rollback**: Removes directory and unsets test configs

#### Step 11: Custom Command Framework
- **Creates** `commands.conf` example file
- **Creates** `run-commands.sh` legacy support
- **Purpose**: Extensible custom command execution
- **Rollback**: Removes created files

### Installation Options

#### Silent Installation (Auto-Accept Defaults)

```bash
# Auto-accept all prompts (creates .gitignore, skips tests)
yes | bash .githooks/install-hooks.sh
```

#### Enable Tests During Installation

```bash
# Answer 'y' when prompted for test infrastructure
bash .githooks/install-hooks.sh
# At prompt "Would you like to enable tests now? (y/N):" type 'y'
```

#### Custom Installation Path

```bash
# If your hooks are in a different directory
git config core.hooksPath /path/to/custom/hooks
```

### Rollback Mechanism

The installation script includes **complete rollback** on any failure:

#### When Rollback Triggers
- **Any error** during installation
- **User interruption** (Ctrl+C)
- **System termination** (TERM signal)

#### What Gets Rolled Back
| Operation | Rollback Action |
|-----------|----------------|
| Git config set | Restore original value |
| Git config added | Unset (remove) |
| Directory created | Remove directory |
| File created | Remove file |
| File modified | Restore from backup |
| .gitignore modified | Restore from backup |

#### Rollback Example
```bash
[5/11] Configuring auto-restage...
  ✗ ERROR: Permission denied

═══════════════════════════════════════════════════════════════
         INSTALLATION FAILED - EXECUTING ROLLBACK
═══════════════════════════════════════════════════════════════

ℹ Rolling back 5 operations...
ℹ [ROLLBACK 1/5] Executing: git config --unset 'hooks.maxCommits'
✓ Rollback step completed
...
✓ Rollback completed - repository restored to previous state
```

### Installation Verification

#### 1. Check Hooks Path
```bash
git config core.hooksPath
# Expected: .githooks
```

#### 2. Check Configuration
```bash
git config --list | grep hooks.
# Expected output:
# hooks.maxcommits=5
# hooks.autoaddafterfix=false
# hooks.branchmapping.hotfix=origin/main
# hooks.branchmapping.feat=origin/develop
# ... (more mappings)
```

#### 3. Check .gitignore
```bash
cat .gitignore | grep -A 10 "Git Hooks"
# Expected: Hook-related ignore patterns
```

#### 4. Check Logs
```bash
cat .githooks/logs/install-*.log | tail -50
# Expected: "Installation completed successfully"
```

#### 5. Test Branch Creation
```bash
git checkout -b test-verify-hooks
# Should fail (invalid naming)

git checkout -b feat-TEST-001-verify-hooks
# Should succeed (valid naming)
```

#### 6. Test Commit
```bash
git commit --allow-empty -m "test commit"
# Should fail (invalid format)

git commit --allow-empty -m "feat: TEST-001 Verify hooks"
# Should succeed (valid format)
```

#### 7. Cleanup
```bash
git checkout main
git branch -D feat-TEST-001-verify-hooks
```

### Installation Logs

All installation operations are logged to:
- **Installation log**: `.githooks/logs/install-YYYYMMDD_HHMMSS.log`
- **Rollback script**: `.githooks/logs/.rollback-YYYYMMDD_HHMMSS.sh` (temporary)

**View latest installation log:**
```bash
cat .githooks/logs/install-*.log | tail -100
```

---

## Uninstallation

### Uninstallation Process

The uninstallation script performs **6 steps**:

#### Step 1: Remove Hooks Path
- **Unsets** `git config --unset core.hooksPath`
- **Effect**: Disables custom hooks

#### Step 2: Test Infrastructure Cleanup
- **Detects** if tests are enabled
- **Prompts** to remove test logs
- **Archives** logs before deletion (optional)
- **Removes** test state files

#### Step 3: Remove Autosquash Setting
- **Unsets** `git config --unset rebase.autosquash`

#### Step 4: Remove Hook Configurations
- **Unsets** all `hooks.*` configurations:
  - `hooks.maxCommits`
  - `hooks.autoAddAfterFix`
  - `hooks.branchMapping.*` (all 15 mappings)
  - `hooks.tests.*` (all test configs)
  - `hooks.parallelExecution`

#### Step 5: Remove Branch Mappings
- **Unsets** all branch base mappings
- **Lists** removed mappings

#### Step 6: Installation Log Management
- **Detects** installation log files
- **Prompts** to archive/remove
- **Creates** timestamped archive (optional)

### Running Uninstallation

```bash
# Interactive uninstallation
bash .githooks/uninstall-hooks.sh

# Follow prompts:
# - Confirm uninstallation
# - Choose to archive/remove test logs
# - Choose to archive/remove installation logs
```

### Uninstallation Options

#### Force Uninstallation (Skip Prompts)
```bash
# Auto-confirm all prompts
yes | bash .githooks/uninstall-hooks.sh
```

#### Preserve Logs
```bash
# When prompted, choose 'n' to keep logs
# Test logs: Answer 'n' to archive prompt
# Installation logs: Answer 'n' to archive prompt
```

### Uninstallation Verification

#### 1. Check Hooks Path Removed
```bash
git config core.hooksPath
# Expected: Empty output or error
```

#### 2. Check Configurations Removed
```bash
git config --list | grep hooks.
# Expected: No output (all removed)
```

#### 3. Check Files Remain
```bash
ls -la .githooks/
# Expected: Hook files still present (not deleted)
```

#### 4. Test Hook Disabled
```bash
git checkout -b invalid-branch-name
# Should succeed (hooks not running)
git checkout main
git branch -D invalid-branch-name
```

### What Gets Removed vs. Kept

#### Removed
- ✅ Git configuration (`core.hooksPath`, `hooks.*`)
- ✅ Test logs (optional, with prompt)
- ✅ Installation logs (optional, with prompt)
- ✅ Test state files

#### Kept
- ✅ Hook script files (`.githooks/` directory)
- ✅ Hook execution logs (`.git/hook-logs/`)
- ✅ Custom configurations (`commands.conf`, etc.)
- ✅ Documentation files

### Re-Installation After Uninstallation

```bash
# Simply run installation again
bash .githooks/install-hooks.sh
# All previous configurations will be restored
```

### Uninstallation Logs

All uninstallation operations are logged to:
- **Uninstall log**: `.githooks/logs/uninstall-YYYYMMDD_HHMMSS.log`

**View latest uninstallation log:**
```bash
cat .githooks/logs/uninstall-*.log
```

---

## Configuration

### Git Configuration Keys

#### Core Hook Settings

##### `core.hooksPath`
- **Type**: String (path)
- **Default**: `.git/hooks`
- **Custom**: `.githooks`
- **Purpose**: Directory containing hook scripts
- **Set by**: Installation script
- **Example**:
  ```bash
  git config core.hooksPath .githooks
  git config --get core.hooksPath  # View current value
  ```

#### Hook Behavior Settings

##### `hooks.maxCommits`
- **Type**: Integer
- **Default**: `5`
- **Purpose**: Maximum commits allowed per feature branch
- **Used by**: `pre-push` hook
- **Example**:
  ```bash
  git config hooks.maxCommits 10        # Allow 10 commits
  git config hooks.maxCommits 3         # Strict: only 3 commits
  git config --get hooks.maxCommits     # View current value
  ```

##### `hooks.autoAddAfterFix`
- **Type**: Boolean (`true`/`false`)
- **Default**: `false`
- **Purpose**: Auto-restage files after hook auto-fixes
- **Used by**: `pre-commit` hook
- **Example**:
  ```bash
  git config hooks.autoAddAfterFix true      # Enable auto-restage
  git config hooks.autoAddAfterFix false     # Disable auto-restage
  ```

##### `hooks.parallelExecution`
- **Type**: Boolean (`true`/`false`)
- **Default**: `false`
- **Purpose**: Run custom commands in parallel
- **Used by**: All hooks running custom commands
- **Example**:
  ```bash
  git config hooks.parallelExecution true    # Enable parallel execution
  ```

#### Branch Base Mappings

##### `hooks.branchMapping.<type>`
- **Type**: String (branch name)
- **Purpose**: Define which base branch each branch type should be created from
- **Set by**: Installation script (15 default mappings)

**Default Mappings:**
```bash
# Hotfix branches must be created from main
hooks.branchMapping.hotfix=origin/main

# All feature-related branches from develop
hooks.branchMapping.feat=origin/develop
hooks.branchMapping.feature=origin/develop
hooks.branchMapping.bugfix=origin/develop
hooks.branchMapping.fix=origin/develop
hooks.branchMapping.techdebt=origin/develop
hooks.branchMapping.perf=origin/develop
hooks.branchMapping.refactor=origin/develop
hooks.branchMapping.revert=origin/develop
hooks.branchMapping.style=origin/develop
hooks.branchMapping.test=origin/develop
hooks.branchMapping.build=origin/develop
hooks.branchMapping.chore=origin/develop
hooks.branchMapping.ci=origin/develop
hooks.branchMapping.docs=origin/develop
```

**Custom Mappings:**
```bash
# Set custom base for specific branch type
git config hooks.branchMapping.feat origin/staging

# Set custom base for new branch type
git config hooks.branchMapping.experimental origin/develop

# View all mappings
git config --get-regexp hooks.branchMapping.

# Remove a mapping
git config --unset hooks.branchMapping.feat
```

#### Test Infrastructure Settings

##### `hooks.tests.enabled`
- **Type**: Boolean (`true`/`false`)
- **Default**: `false`
- **Purpose**: Enable/disable test infrastructure
- **Example**:
  ```bash
  git config hooks.tests.enabled true
  ```

##### `hooks.tests.baseBranch`
- **Type**: String (branch name)
- **Default**: `develop`
- **Purpose**: Base branch for test state reset
- **Example**:
  ```bash
  git config hooks.tests.baseBranch main
  ```

##### `hooks.tests.logVerbosity`
- **Type**: String (`minimal`/`detailed`)
- **Default**: `detailed`
- **Purpose**: Test log verbosity level
- **Example**:
  ```bash
  git config hooks.tests.logVerbosity minimal
  ```

##### `hooks.tests.autoCleanup`
- **Type**: Boolean (`true`/`false`)
- **Default**: `true`
- **Purpose**: Automatically clean up test artifacts
- **Example**:
  ```bash
  git config hooks.tests.autoCleanup false
  ```

##### `hooks.tests.categories`
- **Type**: String (comma-separated)
- **Default**: `all`
- **Purpose**: Test categories to run
- **Example**:
  ```bash
  git config hooks.tests.categories "branch,commit,security"
  ```

##### `hooks.tests.preserveState`
- **Type**: Boolean (`true`/`false`)
- **Default**: `false`
- **Purpose**: Preserve repository state after test failures
- **Example**:
  ```bash
  git config hooks.tests.preserveState true
  ```

### Custom Commands Configuration

#### commands.conf File

The `commands.conf` file allows you to add custom commands that run during hook execution.

**Location**: `.githooks/commands.conf`

**Format**:
```
HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
```

**Fields**:
- **HOOK**: Hook name (`pre-commit`, `commit-msg`, `pre-push`)
- **PRIORITY**: Execution order (lower runs first, 1-999)
- **MANDATORY**: `true` = block on failure, `false` = warn only
- **TIMEOUT**: Maximum seconds to run (0 = no timeout)
- **COMMAND**: Shell command to execute (use `{staged}` for staged files)
- **DESCRIPTION**: Human-readable description

**Examples**:

```bash
# Lint staged files before commit
pre-commit:1:true:30:npx lint-staged:Lint and format staged files

# TypeScript type checking
pre-commit:2:false:60:npx tsc --noEmit:TypeScript type checking

# Check file casing
pre-commit:3:true:30:node scripts/check-casing.js:Check file casing

# Run test suite before push
pre-push:1:true:300:npm test:Run test suite

# Build verification (non-blocking)
pre-push:2:false:600:npm run build:Build verification

# Validate ticket ID in commit message
commit-msg:1:false:10:node scripts/validate-ticket.js:Validate ticket format
```

**Creating commands.conf**:

```bash
# Create from example
cat > .githooks/commands.conf << 'EOF'
# Pre-commit checks
pre-commit:1:true:60:npm run lint:Lint code
pre-commit:2:true:30:npm run format:Format code
pre-commit:3:false:120:npm run test:unit:Unit tests

# Pre-push checks
pre-push:1:true:300:npm test:Full test suite
pre-push:2:false:600:npm run build:Build project
EOF
```

**Disabling commands**:
```bash
# Comment out lines in commands.conf
# pre-commit:1:true:60:npm run lint:Lint code
```

**Testing commands**:
```bash
# Dry-run to see what would execute
bash .githooks/pre-commit --dry-run
```

### Environment Variables

#### Hook Bypass

##### `BYPASS_HOOKS`
- **Type**: Boolean (any non-empty value = true)
- **Purpose**: Skip all hook validation (emergency use)
- **Scope**: All hooks
- **Example**:
  ```bash
  BYPASS_HOOKS=1 git commit -m "Emergency fix"
  BYPASS_HOOKS=1 git push
  ```

##### `ALLOW_DIRECT_PROTECTED`
- **Type**: Boolean (any non-empty value = true)
- **Purpose**: Allow direct commits to protected branches
- **Scope**: `pre-commit` hook
- **Example**:
  ```bash
  ALLOW_DIRECT_PROTECTED=1 git commit -m "Hotfix on main"
  ```

#### Test Environment

##### `HOOK_TEST_MODE`
- **Type**: Boolean (`1` = true)
- **Purpose**: Enable test mode (used by test infrastructure)
- **Scope**: All hooks
- **Example**:
  ```bash
  HOOK_TEST_MODE=1 bash .githooks/pre-commit
  ```

### Configuration Commands Reference

#### View All Hook Configurations
```bash
git config --list | grep hooks.
```

#### View Specific Configuration
```bash
git config hooks.maxCommits
git config hooks.branchMapping.feat
```

#### Set Configuration
```bash
git config hooks.maxCommits 10
git config hooks.branchMapping.feat origin/staging
```

#### Unset Configuration
```bash
git config --unset hooks.maxCommits
git config --unset hooks.branchMapping.feat
```

#### Remove All Hook Configurations
```bash
git config --remove-section hooks
```

#### Export Configuration
```bash
# Save current configuration
git config --get-regexp hooks. > hooks-config-backup.txt

# Restore configuration
while IFS=' ' read -r key value; do
    git config "$key" "$value"
done < hooks-config-backup.txt
```

---

## Hook Features

### 1. Branch Naming Validation

#### Enforced Patterns

**Long-lived branches** (no restrictions):
- `main`
- `master`
- `develop`
- `development`
- `release/*`
- `hotfix/*`

**Short-lived branches** (must follow pattern):
```
<type>-<JIRA-ID>-<description>
```

**Valid types**:
- `feat`, `feature` - New features
- `fix`, `bugfix` - Bug fixes
- `hotfix` - Critical production fixes
- `chore` - Maintenance tasks
- `docs` - Documentation changes
- `refactor` - Code refactoring
- `test` - Test additions/changes
- `style` - Code style changes
- `perf` - Performance improvements
- `build` - Build system changes
- `ci` - CI/CD changes
- `revert` - Revert previous changes
- `techdebt` - Technical debt reduction

**Examples**:
```bash
# ✅ Valid
git checkout -b feat-ABC-123-user-authentication
git checkout -b fix-XYZ-456-login-bug
git checkout -b hotfix-CRIT-789-security-patch
git checkout -b chore-TASK-100-update-dependencies

# ❌ Invalid
git checkout -b new-feature           # Missing JIRA ID
git checkout -b ABC-123-feature       # Missing type
git checkout -b feat-abc-123-test     # JIRA ID must be uppercase
git checkout -b feature_test          # Wrong separator (use hyphens)
```

#### Branch Base Enforcement

**Validated at branch creation** (post-checkout hook):
- Checks if branch was created from correct base
- Warns if created from wrong base
- Suggests correct base branch

**Configuration**:
```bash
# View current mappings
git config --get-regexp hooks.branchMapping.

# Customize mapping
git config hooks.branchMapping.feat origin/develop
git config hooks.branchMapping.hotfix origin/main
```

**Example validation**:
```bash
# On main branch
git checkout -b feat-ABC-123-new-feature
# ⚠️  Warning: feat branches should be created from origin/develop
# Current: origin/main → feat-ABC-123-new-feature
# Expected: origin/develop → feat-ABC-123-new-feature
```

### 2. Commit Message Validation

#### Enforced Format

```
<type>: <JIRA-ID> <description>
```

**Valid commit types**:
- `feat` - New feature
- `fix` - Bug fix
- `break` - Breaking change
- `chore` - Maintenance
- `docs` - Documentation
- `refactor` - Code refactoring
- `test` - Test changes
- `style` - Code style
- `perf` - Performance
- `build` - Build changes
- `ci` - CI/CD changes
- `revert` - Revert commit

**JIRA ID format**: `[A-Z]+-[0-9]+` (e.g., `ABC-123`, `PROJ-456`)

**Examples**:
```bash
# ✅ Valid
git commit -m "feat: ABC-123 Add user authentication"
git commit -m "fix: XYZ-456 Resolve login bug"
git commit -m "break: CRIT-789 Change API response format"
git commit -m "chore: TASK-100 Update dependencies"

# ❌ Invalid
git commit -m "Add user authentication"           # Missing type and JIRA ID
git commit -m "feat: Add authentication"          # Missing JIRA ID
git commit -m "ABC-123 Add authentication"        # Missing type
git commit -m "feat: abc-123 Add auth"            # JIRA ID must be uppercase
git commit -m "feature: ABC-123 Add auth"         # Invalid type (use 'feat')
```

#### Auto-Prefill from Branch Name

If your branch name follows the pattern `<type>-<JIRA-ID>-<description>`, the commit message template will be auto-prefilled:

```bash
# On branch: feat-ABC-123-user-auth
git commit
# Editor opens with prefilled:
# feat: ABC-123
```

#### Commit Message Length

- **Subject line**: Maximum 72 characters (warning), 100 characters (hard limit)
- **Body**: Wrapped at 72 characters (recommended)

### 3. Security Scanning

#### Secret Detection

**Prevents committing**:
- **AWS Access Keys**: `AKIA[0-9A-Z]{16}`
- **AWS Secret Keys**: 40-character strings after `aws_secret`
- **GitHub Tokens**: `ghp_[a-zA-Z0-9]{36}`
- **GitHub OAuth**: `gho_[a-zA-Z0-9]{36}`
- **Slack Tokens**: `xox[baprs]-[0-9a-zA-Z]{10,}`
- **Private Keys**: `-----BEGIN RSA PRIVATE KEY-----`
- **JWT Tokens**: `eyJ[A-Za-z0-9-_=]+\.eyJ[A-Za-z0-9-_=]+\.[A-Za-z0-9-_.+/=]*`
- **API Keys**: `api[_-]?key["\s:=]+[a-zA-Z0-9]{32,}`
- **Generic Secrets**: `secret["\s:=]+[a-zA-Z0-9]{16,}`
- **Database Passwords**: `password["\s:=]+.{8,}`

**Example**:
```bash
# File contains: AWS_ACCESS_KEY="AKIAIOSFODNN7EXAMPLE"
git commit -m "feat: ABC-123 Add config"
# ❌ Error: Potential secret detected in config.js:5
# AWS access key pattern found
```

#### Sensitive File Blocking

**Prevents committing**:
- `.env`, `.env.*` - Environment files
- `*.pem`, `*.key`, `*.p12`, `*.pfx` - Certificate/key files
- `id_rsa`, `id_dsa`, `id_ecdsa`, `id_ed25519` - SSH private keys
- `*.credentials` - Credential files
- `secrets.yml`, `secrets.json` - Secret configuration files

**Example**:
```bash
git add .env
git commit -m "feat: ABC-123 Add env file"
# ❌ Error: Sensitive file detected: .env
# This file should not be committed
```

#### Binary File Warnings

**Warns about large binary files**:
- Files > 5MB trigger warning
- Common binary extensions checked (`.exe`, `.dll`, `.so`, `.dylib`, etc.)

### 4. History Curation

#### Commit Limit Per Branch

**Purpose**: Keep feature branches focused and history clean

**Default**: 5 commits per branch

**Configuration**:
```bash
git config hooks.maxCommits 10    # Allow 10 commits
git config hooks.maxCommits 3     # Strict: 3 commits
```

**Enforcement**:
```bash
# On feat-ABC-123-feature with 6 commits
git push
# ❌ Error: Too many commits (6) for branch feat-ABC-123-feature
# Maximum allowed: 5 commits ahead of origin/develop
# 
# Please squash commits using:
#   git rebase -i origin/develop
```

**Squashing commits**:
```bash
# Interactive rebase to squash commits
git rebase -i origin/develop

# Or use auto-squash with fixup commits
git commit --fixup <commit-hash>
git rebase -i --autosquash origin/develop
```

#### Merge Commit Prevention

**Prevents merge commits to protected branches**:
- Detects merge commits in push
- Requires rebasing instead of merging
- Keeps history linear

**Example**:
```bash
# After merging develop into feature branch
git push
# ❌ Error: Merge commits detected
# Please rebase instead of merging:
#   git rebase origin/develop
```

### 5. Custom Command Execution

#### How It Works

1. Hooks read `commands.conf` file
2. Filter commands for current hook
3. Sort by priority
4. Execute in order
5. Check mandatory vs. optional failures

#### Command Placeholders

**`{staged}`**: Replaced with space-separated list of staged files

**Example**:
```bash
pre-commit:1:true:30:eslint {staged}:Lint staged files
# Becomes:
# eslint src/file1.js src/file2.js lib/file3.js
```

#### Timeout Handling

- Commands exceeding timeout are terminated
- Error message shows timeout occurred
- Mandatory commands cause commit/push to fail

#### Parallel Execution

**Enable**:
```bash
git config hooks.parallelExecution true
```

**Behavior**:
- Commands with same priority run in parallel
- Faster execution for independent checks
- Results collected and displayed together

### 6. Protected Branch Detection

#### Protected Branches

- `main`, `master`
- `develop`, `development`
- `release/*`
- `staging`
- `production`

#### Protection

- **Direct commits blocked**: Cannot commit directly to protected branches
- **Bypass available**: Use `ALLOW_DIRECT_PROTECTED=1` for emergencies
- **Suggestion**: Create feature branch instead

**Example**:
```bash
# On main branch
git commit -m "feat: ABC-123 Quick fix"
# ❌ Error: Cannot commit directly to protected branch 'main'
# 
# Create a feature branch instead:
#   git checkout -b hotfix-ABC-123-quick-fix
#   git commit -m "feat: ABC-123 Quick fix"
# 
# Or use bypass for emergency:
#   ALLOW_DIRECT_PROTECTED=1 git commit -m "..."
```

---

## Usage Examples

### Common Workflows

#### 1. Starting New Feature

```bash
# 1. Update develop branch
git checkout develop
git pull origin develop

# 2. Create feature branch (hook validates naming)
git checkout -b feat-PROJ-123-user-dashboard

# 3. Make changes
echo "new feature" > feature.js
git add feature.js

# 4. Commit (hook validates message format)
git commit -m "feat: PROJ-123 Add user dashboard component"

# 5. Push (hook validates commit count and history)
git push origin feat-PROJ-123-user-dashboard
```

#### 2. Fixing a Bug

```bash
# 1. Create bugfix branch
git checkout -b fix-BUG-456-login-error develop

# 2. Fix the bug
nano src/auth/login.js
git add src/auth/login.js

# 3. Commit with descriptive message
git commit -m "fix: BUG-456 Resolve null pointer in login validation"

# 4. Push
git push origin fix-BUG-456-login-error
```

#### 3. Squashing Commits

```bash
# If you have too many commits (> maxCommits)

# 1. Check commit count
git rev-list --count HEAD ^origin/develop
# Output: 7 (too many, limit is 5)

# 2. Interactive rebase
git rebase -i origin/develop

# 3. In editor, change 'pick' to 'squash' or 'fixup' for commits 2-7
# Keep first commit as 'pick'

# 4. Save and push
git push --force-with-lease origin feat-PROJ-123-feature
```

#### 4. Emergency Hotfix

```bash
# 1. Create hotfix from main
git checkout -b hotfix-CRIT-789-security-patch main

# 2. Apply fix
nano src/security/auth.js
git add src/security/auth.js

# 3. Commit
git commit -m "fix: CRIT-789 Patch XSS vulnerability"

# 4. Push
git push origin hotfix-CRIT-789-security-patch

# 5. After merge, tag release
git tag -a v1.2.3 -m "Security patch release"
git push origin v1.2.3
```

#### 5. Using Custom Commands

```bash
# 1. Add linter to commands.conf
echo "pre-commit:1:true:30:npm run lint:Lint code" >> .githooks/commands.conf

# 2. Add formatter
echo "pre-commit:2:true:20:npm run format:Format code" >> .githooks/commands.conf

# 3. Test without committing
bash .githooks/pre-commit --dry-run

# 4. Commit (commands run automatically)
git commit -m "feat: PROJ-123 Add feature"
# [Hook] Running custom command: Lint code
# [Hook] Running custom command: Format code
```

#### 6. Bypassing Hooks (Emergency)

```bash
# Skip all hook validation
BYPASS_HOOKS=1 git commit -m "Emergency fix"
BYPASS_HOOKS=1 git push

# Allow direct commit to protected branch
ALLOW_DIRECT_PROTECTED=1 git commit -m "Hotfix on main"
```

### Advanced Examples

#### 1. Branch from Wrong Base (Correcting)

```bash
# Created feat branch from main (should be from develop)
git checkout -b feat-PROJ-123-feature main
# ⚠️  Warning: feat branches should be created from origin/develop

# Correct it:
git checkout develop
git branch -D feat-PROJ-123-feature
git checkout -b feat-PROJ-123-feature
# ✓ Branch created from correct base
```

#### 2. Using Fixup Commits

```bash
# Initial commit
git commit -m "feat: PROJ-123 Add dashboard"

# Found issue, create fixup commit
git commit --fixup HEAD
# Or target specific commit
git commit --fixup abc1234

# Before push, auto-squash
git rebase -i --autosquash origin/develop

# Push
git push
```

#### 3. Handling Failed Security Scan

```bash
# Accidentally added secret
echo 'API_KEY="abc123secret456"' > config.js
git add config.js
git commit -m "feat: PROJ-123 Add config"
# ❌ Error: Potential secret detected

# Fix: Remove secret, use environment variable
echo 'API_KEY=process.env.API_KEY' > config.js
git add config.js
git commit -m "feat: PROJ-123 Add config (use env var)"
# ✓ Commit successful
```

#### 4. Testing Hooks Before Commit

```bash
# Dry-run custom commands
bash .githooks/pre-commit --dry-run

# Test hook with specific files
bash .githooks/pre-commit src/file1.js src/file2.js

# Test commit message validation
echo "feat: PROJ-123 Test message" > /tmp/msg.txt
bash .githooks/commit-msg /tmp/msg.txt
```

---

## Reset & Cleanup

### Cleanup Operations

#### 1. Clean Hook Logs

```bash
# Remove all hook execution logs
rm -f .git/hook-logs/*.log

# Or archive before removing
tar -czf hook-logs-archive-$(date +%Y%m%d).tar.gz .git/hook-logs/*.log
rm -f .git/hook-logs/*.log

# Remove archived logs older than 30 days
find .git -name "hook-logs-archive-*.tar.gz" -mtime +30 -delete
```

#### 2. Clean Installation Logs

```bash
# Remove installation logs
rm -f .githooks/logs/install-*.log

# Remove uninstallation logs
rm -f .githooks/logs/uninstall-*.log

# Remove all logs
rm -rf .githooks/logs/
mkdir -p .githooks/logs/
```

#### 3. Clean Test Logs

```bash
# Remove test logs
rm -f .githooks/test/logs/*.log

# Remove test state
rm -f .githooks/test/.test-state

# Archive test logs before removing
tar -czf test-logs-archive-$(date +%Y%m%d).tar.gz .githooks/test/logs/
rm -f .githooks/test/logs/*.log
```

#### 4. Clean All Logs

```bash
# Clean everything (installation, hooks, tests)
bash .githooks/clean.sh

# Manual cleanup
rm -f .git/hook-logs/*.log
rm -f .githooks/logs/*.log
rm -f .githooks/test/logs/*.log
rm -f .githooks/test/.test-state
```

### Reset Operations

#### 1. Reset Hook Configuration

```bash
# Remove all hook configurations
git config --remove-section hooks

# Or selectively remove
git config --unset hooks.maxCommits
git config --unset hooks.autoAddAfterFix
git config --unset-all hooks.branchMapping
```

#### 2. Reset to Fresh Installation

```bash
# 1. Uninstall
bash .githooks/uninstall-hooks.sh

# 2. Clean logs
rm -rf .githooks/logs/
rm -rf .git/hook-logs/
rm -rf .githooks/test/logs/

# 3. Reinstall
bash .githooks/install-hooks.sh
```

#### 3. Reset Test Configuration

```bash
# Disable tests
git config hooks.tests.enabled false

# Remove all test configurations
git config --unset hooks.tests.enabled
git config --unset hooks.tests.baseBranch
git config --unset hooks.tests.logVerbosity
git config --unset hooks.tests.autoCleanup
git config --unset hooks.tests.categories
git config --unset hooks.tests.preserveState

# Or use test config script
bash .githooks/test/test-config.sh reset
```

#### 4. Reset Branch Mappings

```bash
# Remove all branch mappings
git config --get-regexp hooks.branchMapping. | cut -d. -f3 | while read type; do
    git config --unset hooks.branchMapping.$type
done

# Restore defaults (reinstall does this)
bash .githooks/install-hooks.sh
```

### Complete System Reset

```bash
# Nuclear option: Complete reset to clean state

# 1. Uninstall hooks
bash .githooks/uninstall-hooks.sh

# 2. Remove all configurations
git config --remove-section hooks 2>/dev/null || true
git config --unset core.hooksPath 2>/dev/null || true
git config --unset rebase.autosquash 2>/dev/null || true
git config --unset fetch.prune 2>/dev/null || true

# 3. Clean all logs
rm -rf .git/hook-logs/
rm -rf .githooks/logs/
rm -rf .githooks/test/logs/
rm -f .githooks/test/.test-state

# 4. Clean test artifacts
find .git -name "hook-test-*" -delete

# 5. Verify clean state
git config --list | grep hooks.
# Should return nothing

# 6. Reinstall from scratch
bash .githooks/install-hooks.sh
```

### Backup & Restore

#### Backup Configuration

```bash
# Save current configuration
git config --get-regexp hooks. > hooks-config-backup.txt

# Save commands.conf
cp .githooks/commands.conf .githooks/commands.conf.backup

# Create complete backup
tar -czf hooks-backup-$(date +%Y%m%d).tar.gz \
    .githooks/commands.conf \
    hooks-config-backup.txt \
    .git/hook-logs/ \
    .githooks/logs/
```

#### Restore Configuration

```bash
# Restore git configuration
while IFS=' ' read -r key value; do
    git config "$key" "$value"
done < hooks-config-backup.txt

# Restore commands.conf
cp .githooks/commands.conf.backup .githooks/commands.conf

# Extract complete backup
tar -xzf hooks-backup-YYYYMMDD.tar.gz
```

---

## Advanced Topics

### Rollback Mechanism Details

#### Architecture

The installation script uses a **rollback stack** to track all operations:

```bash
declare -a ROLLBACK_STACK=()

# Each operation adds to stack
add_rollback "git config --unset 'hooks.maxCommits'"
add_rollback "mv .gitignore.backup .gitignore"

# On failure, execute in reverse order
for ((i=${#ROLLBACK_STACK[@]}-1; i>=0; i--)); do
    eval "${ROLLBACK_STACK[$i]}"
done
```

#### Tracked Operations

1. **Git Config Changes**
   ```bash
   # Before: git config core.hooksPath .githooks
   # Rollback: git config core.hooksPath <old-value>
   ```

2. **File Modifications**
   ```bash
   # Before: Modify .gitignore
   # Rollback: mv .gitignore.backup .gitignore
   ```

3. **Directory Creation**
   ```bash
   # Before: mkdir .git/hook-logs
   # Rollback: rm -rf .git/hook-logs
   ```

4. **File Creation**
   ```bash
   # Before: touch commands.conf
   # Rollback: rm -f commands.conf
   ```

#### Rollback File

During installation, a rollback script is created:
- **Location**: `.githooks/logs/.rollback-YYYYMMDD_HHMMSS.sh`
- **Purpose**: Executable script to reverse all changes
- **Lifecycle**: Created at start, deleted on success, executed on failure

**Example rollback script**:
```bash
#!/usr/bin/env bash
# Rollback script for installation
git config --unset 'hooks.tests.enabled'
git config 'hooks.maxCommits' '3'
git config --unset 'core.hooksPath'
mv .gitignore.backup.12345 .gitignore
rm -rf .git/hook-logs
```

### Hook Execution Flow

#### Pre-Commit Hook

```
1. Check if BYPASS_HOOKS is set → Exit
2. Detect repository root
3. Check if on protected branch → Warn/block
4. Get list of staged files
5. Run security scans:
   - Secret detection
   - Sensitive file check
   - Binary file check
6. Run custom commands from commands.conf
7. Check for auto-add files
8. Log all operations
9. Exit with status (0 = success, 1 = failure)
```

#### Commit-Msg Hook

```
1. Check if BYPASS_HOOKS is set → Exit
2. Read commit message from file
3. Extract branch name for auto-prefill
4. Validate format: <type>: <JIRA-ID> <description>
5. Check commit type is valid
6. Check JIRA ID format
7. Validate description length
8. Run custom commands (if any)
9. Log validation result
10. Exit with status
```

#### Post-Checkout Hook

```
1. Check if BYPASS_HOOKS is set → Exit
2. Detect if branch creation (vs checkout)
3. Get new branch name
4. Validate branch naming convention
5. Detect base branch (where created from)
6. Check if base matches expected base for branch type
7. Display warning if wrong base
8. Log branch creation
9. Always exit 0 (warnings only, never block)
```

#### Pre-Push Hook

```
1. Check if BYPASS_HOOKS is set → Exit
2. Get current branch
3. Get list of commits ahead of remote
4. Check commit count vs maxCommits limit
5. Check for merge commits
6. Run custom commands (tests, builds, etc.)
7. Log push attempt
8. Exit with status
```

### Logging System

#### Log Levels

- **INFO**: Informational messages
- **WARN**: Warnings (don't block operations)
- **ERROR**: Errors (block operations)

#### Log Locations

```
.git/hook-logs/
├── complete.log           # All hooks, all operations
├── pre-commit.log         # Pre-commit hook only
├── commit-msg.log         # Commit-msg hook only
├── post-checkout.log      # Post-checkout hook only
└── pre-push.log           # Pre-push hook only

.githooks/logs/
├── install-*.log          # Installation logs
└── uninstall-*.log        # Uninstallation logs

.githooks/test/logs/
├── test-run-*.log         # Test execution logs
└── test-*.log             # Individual test logs
```

#### Log Format

```
[YYYY-MM-DD HH:MM:SS] [LEVEL] [HOOK] Message
```

**Example**:
```
[2025-11-04 10:30:15] [INFO] [pre-commit] Starting pre-commit validation
[2025-11-04 10:30:15] [INFO] [pre-commit] Staged files: 3
[2025-11-04 10:30:16] [INFO] [pre-commit] Running security scans...
[2025-11-04 10:30:16] [ERROR] [pre-commit] Secret detected in config.js:12
```

#### Log Rotation

```bash
# Archive old logs (30+ days)
find .git/hook-logs -name "*.log" -mtime +30 -exec \
    tar -czf .git/hook-logs-archive-$(date +%Y%m%d).tar.gz {} +

# Remove archived logs (90+ days)
find .git -name "hook-logs-archive-*.tar.gz" -mtime +90 -delete
```

### Performance Optimization

#### Parallel Command Execution

```bash
# Enable parallel execution
git config hooks.parallelExecution true

# Commands with same priority run in parallel
pre-commit:1:true:30:npm run lint:Lint
pre-commit:1:true:30:npm run format:Format
# Both run simultaneously

pre-commit:2:true:60:npm test:Test
# Runs after priority 1 completes
```

#### Command Timeouts

```bash
# Set aggressive timeouts for fast feedback
pre-commit:1:true:10:quick-lint {staged}:Quick lint
pre-commit:2:true:30:full-lint {staged}:Full lint
pre-push:1:true:60:npm test:unit:Unit tests only
```

#### Caching

```bash
# Use tool caching
pre-commit:1:true:30:npx --cache lint-staged:Lint (cached)
pre-commit:2:true:30:npx --cache tsc --noEmit:Type check (cached)
```

### Security Considerations

#### Secret Scanning Patterns

**Customizing patterns** (modify in `lib/shared-functions.sh`):

```bash
# Add custom secret pattern
check_secrets() {
    # ... existing patterns ...
    
    # Custom API key pattern
    if echo "$content" | grep -qE "CUSTOM_API_[a-zA-Z0-9]{32}"; then
        echo "Custom API key detected"
        return 1
    fi
}
```

#### Sensitive File Patterns

**Customizing** (modify in `pre-commit` hook):

```bash
# Add custom sensitive file patterns
SENSITIVE_PATTERNS=(
    "*.env*"
    "*.pem"
    "*.key"
    "credentials*"
    "secrets*"
    # Add custom patterns
    "*.config.local"
    "database.yml"
)
```

#### Bypass Security

**Use with extreme caution**:
```bash
# Only for absolute emergencies
BYPASS_HOOKS=1 git commit -m "Emergency: Critical production fix"
```

---

## Reference

### Git Configuration Quick Reference

```bash
# Core
core.hooksPath=.githooks

# Hook Behavior
hooks.maxCommits=5
hooks.autoAddAfterFix=false
hooks.parallelExecution=false

# Branch Mappings
hooks.branchMapping.hotfix=origin/main
hooks.branchMapping.feat=origin/develop
hooks.branchMapping.bugfix=origin/develop
# ... (12 more)

# Test Configuration
hooks.tests.enabled=true
hooks.tests.baseBranch=develop
hooks.tests.logVerbosity=detailed
hooks.tests.autoCleanup=true
hooks.tests.categories=all
hooks.tests.preserveState=false
```

### Environment Variables Quick Reference

```bash
BYPASS_HOOKS=1              # Skip all hooks
ALLOW_DIRECT_PROTECTED=1    # Allow protected branch commits
HOOK_TEST_MODE=1            # Enable test mode
```

### Command Quick Reference

```bash
# Installation
bash .githooks/install-hooks.sh

# Uninstallation
bash .githooks/uninstall-hooks.sh

# View configuration
git config --list | grep hooks.

# Set configuration
git config hooks.maxCommits 10

# Unset configuration
git config --unset hooks.maxCommits

# Clean logs
rm -rf .git/hook-logs/*.log

# Test hooks
bash .githooks/pre-commit --dry-run

# Bypass hooks (emergency)
BYPASS_HOOKS=1 git commit -m "Emergency"
```

### File Structure Reference

```
.githooks/
├── pre-commit              # Pre-commit hook
├── commit-msg              # Commit message validation
├── post-checkout           # Branch creation validation
├── pre-push                # Pre-push validation
├── install-hooks.sh        # Installation script
├── uninstall-hooks.sh      # Uninstallation script
├── clean.sh                # Log cleanup script
├── commands.conf           # Custom commands
├── run-commands.sh         # Command executor
├── lib/                    # Shared libraries
│   └── shared-functions.sh
├── test/                   # Test infrastructure
│   ├── test-config.sh
│   ├── setup-test-environment.sh
│   ├── cleanup-test-environment.sh
│   ├── run-comprehensive-tests.sh
│   └── test-scenarios/
└── logs/                   # Installation logs
```

### Exit Codes

- **0**: Success
- **1**: General failure
- **2**: Configuration error
- **3**: Validation error
- **124**: Timeout
- **130**: Interrupted (Ctrl+C)

### Hook Naming Conventions

```
pre-commit      - Before commit is created
commit-msg      - After commit message written
post-commit     - After commit is created
pre-push        - Before push to remote
post-checkout   - After checkout/branch creation
pre-rebase      - Before rebase
post-merge      - After merge
```

---

## See Also

- **[GITHOOKS_TESTING.md](GITHOOKS_TESTING.md)** - Complete testing guide
- **[GITHOOKS_TROUBLESHOOTING.md](GITHOOKS_TROUBLESHOOTING.md)** - Troubleshooting and FAQ
- **[GITHOOKS_CONTRIBUTING.md](GITHOOKS_CONTRIBUTING.md)** - Contributing and development guide

---

**Questions or Issues?**  
See [GITHOOKS_TROUBLESHOOTING.md](GITHOOKS_TROUBLESHOOTING.md) for common issues and solutions.

**Want to Contribute?**  
See [GITHOOKS_CONTRIBUTING.md](GITHOOKS_CONTRIBUTING.md) for development guidelines.

**Need to Test?**  
See [GITHOOKS_TESTING.md](GITHOOKS_TESTING.md) for complete testing documentation.

---

**Version**: 3.0  
**Status**: Production-Ready ✅  
**Last Updated**: November 4, 2025
