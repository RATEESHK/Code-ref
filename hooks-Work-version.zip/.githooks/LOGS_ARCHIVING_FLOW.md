# Hook Logs Archive - Visual Flow Diagram

## Archive Creation Flow (During Uninstall)

```
┌─────────────────────────────────────────────────────────────────┐
│                  RUN UNINSTALL SCRIPT                            │
│          bash .githooks/uninstall-hooks.sh                       │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│  STEP 1: CHECK FOR HOOK EXECUTION LOGS                          │
│  Does .git/hook-logs/ directory exist?                          │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                ┌─────────┴──────────┐
                │                    │
            YES │                    │ NO
                │                    │
                ▼                    ▼
┌───────────────────────────┐   ┌──────────────────────────┐
│ Create Timestamped Archive│   │ Skip to STEP 2           │
│ .git/hook-logs-archive-   │   │ (No logs to archive)     │
│ YYYYMMDD-HHMMSS.tar.gz    │   └──────────────────────────┘
└───────────┬───────────────┘
            │
            ▼
┌───────────────────────────────────────────────────────────┐
│ Archive Contents:                                          │
│  ├── complete.log       (all hook executions)             │
│  ├── pre-commit.log     (pre-commit hook logs)            │
│  ├── commit-msg.log     (commit message validation)       │
│  ├── pre-push.log       (pre-push hook logs)              │
│  └── *.1.log, *.2.log   (rotated logs if any)             │
└───────────┬───────────────────────────────────────────────┘
            │
            ▼
┌───────────────────────────────────────────────────────────┐
│ ASK USER: Delete hook execution log directory? (y/N)      │
└───────────┬───────────────────────────────────────────────┘
            │
    ┌───────┴────────┐
    │                │
 YES│                │NO
    │                │
    ▼                ▼
┌──────────────┐  ┌─────────────────────────────────────┐
│ Delete       │  │ Keep Both:                          │
│ .git/        │  │  - Original: .git/hook-logs/*.log   │
│ hook-logs/   │  │  - Archive:  .git/hook-logs-archive │
└──────────────┘  └─────────────────────────────────────┘
    │                │
    │                │
    └────────┬───────┘
             │
             ▼
┌─────────────────────────────────────────────────────────────────┐
│  STEP 2: CHECK FOR TEST LOGS                                    │
│  Are tests enabled? (git config hooks.tests.enabled)            │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                ┌─────────┴──────────┐
                │                    │
            YES │                    │ NO
                │                    │
                ▼                    ▼
┌───────────────────────────┐   ┌──────────────────────────┐
│ ASK USER:                 │   │ Skip test archiving      │
│ Remove test logs? (y/N)   │   │                          │
└───────────┬───────────────┘   └──────────────────────────┘
            │
    ┌───────┴────────┐
    │                │
 YES│                │NO
    │                │
    ▼                ▼
┌──────────────────────────┐  ┌─────────────────────────┐
│ Create Archive:          │  │ Keep test logs          │
│ .githooks/test/          │  │ No archive created      │
│ test-logs-archive-       │  └─────────────────────────┘
│ YYYYMMDD-HHMMSS.tar.gz   │
└───────────┬──────────────┘
            │
            ▼
┌──────────────────────────────────────────────────────────┐
│ Remove test log files:                                   │
│  rm -rf .githooks/test/logs/*.log                        │
└──────────────────────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────────┐
│  CONTINUE WITH OTHER UNINSTALL STEPS...                         │
│  (Reset git config, remove .gitignore entries, etc.)            │
└─────────────────────────────────────────────────────────────────┘
```

---

## Log Rotation Flow (Automatic Cleanup)

```
┌─────────────────────────────────────────────────────────────────┐
│                   RUN CLEANUP SCRIPT                             │
│              bash .githooks/clean.sh                             │
│                  (or runs automatically)                         │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│  FOR EACH LOG FILE in .git/hook-logs/                           │
│  (complete.log, pre-commit.log, commit-msg.log, pre-push.log)   │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│  CHECK FILE SIZE                                                 │
│  Is file size > 256 KB (MAX_SIZE)?                               │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                ┌─────────┴──────────┐
                │                    │
            YES │                    │ NO
                │                    │
                ▼                    ▼
┌───────────────────────────┐   ┌──────────────────────────┐
│ ROTATE LOG FILE           │   │ Skip rotation            │
│                           │   │ (File under size limit)  │
└───────────┬───────────────┘   └──────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────────┐
│  ROTATION PROCESS:                                               │
│                                                                  │
│  Step 1: Shift existing archives                                │
│    complete.1.log → complete.2.log                               │
│    complete.2.log → complete.3.log (will be deleted)            │
│                                                                  │
│  Step 2: Move current to .1                                     │
│    complete.log → complete.1.log                                │
│                                                                  │
│  Step 3: Create new empty log                                   │
│    touch complete.log                                           │
│                                                                  │
│  Step 4: Delete oldest archive                                  │
│    rm complete.3.log (exceeds MAX_ARCHIVES=2)                   │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│  DELETE OLD LOGS                                                 │
│  find .git/hook-logs/ -name "*.log" -mtime +21 -delete          │
│  (Removes logs older than MAX_AGE_DAYS=21)                      │
└─────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                     CLEANUP COMPLETE                             │
└─────────────────────────────────────────────────────────────────┘
```

---

## Archive Storage Structure

```
Repository Root
│
├── .git/
│   ├── hook-logs/                              ← Active logs
│   │   ├── complete.log                        ← Current (0-256 KB)
│   │   ├── complete.1.log                      ← Rotated (previous)
│   │   ├── complete.2.log                      ← Rotated (older)
│   │   ├── pre-commit.log
│   │   ├── pre-commit.1.log
│   │   ├── commit-msg.log
│   │   └── pre-push.log
│   │
│   ├── hook-logs-archive-20251103-120000.tar.gz  ← Old archive
│   ├── hook-logs-archive-20251104-143025.tar.gz  ← Recent archive
│   └── hook-logs-archive-20251104-160000.tar.gz  ← Latest archive
│
└── .githooks/
    ├── logs/                                   ← Install/Uninstall logs
    │   ├── install-20251103_120000.log
    │   ├── install-20251104_143025.log
    │   ├── uninstall-20251103_150000.log
    │   └── .rollback-*.sh
    │
    └── test/
        ├── logs/                               ← Active test logs
        │   ├── test-run-20251103_120000.log
        │   └── test-run-20251104_143025.log
        │
        ├── test-logs-archive-20251103-120000.tar.gz  ← Test archives
        └── test-logs-archive-20251104-143025.tar.gz
```

---

## Archive Lifecycle Timeline

```
┌──────────────────────────────────────────────────────────────────┐
│                         DAY 1                                     │
│  Hooks installed, logs start accumulating                        │
│  .git/hook-logs/complete.log: 0 KB                               │
└──────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────────┐
│                         DAY 5                                     │
│  Normal usage, logs growing                                      │
│  .git/hook-logs/complete.log: 150 KB                             │
└──────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────────┐
│                         DAY 10                                    │
│  Log exceeds size threshold → ROTATION TRIGGERED                 │
│  complete.log: 300 KB → complete.1.log                           │
│  New complete.log: 0 KB                                          │
└──────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────────┐
│                         DAY 18                                    │
│  Another rotation needed                                         │
│  complete.log: 280 KB → complete.1.log                           │
│  complete.1.log: 300 KB → complete.2.log                         │
│  New complete.log: 0 KB                                          │
└──────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────────┐
│                         DAY 25                                    │
│  Third rotation                                                  │
│  complete.log: 320 KB → complete.1.log                           │
│  complete.1.log: 280 KB → complete.2.log                         │
│  complete.2.log: 300 KB → DELETED (exceeds MAX_ARCHIVES=2)      │
│  New complete.log: 0 KB                                          │
└──────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────────┐
│                         DAY 32                                    │
│  Cleanup runs: Logs older than 21 days deleted                  │
│  complete.1.log from Day 25: KEPT (7 days old)                  │
│  complete.2.log from Day 18: KEPT (14 days old)                 │
└──────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────────┐
│                         DAY 45                                    │
│  User runs uninstall → ARCHIVE CREATED                           │
│  .git/hook-logs-archive-20251119-120000.tar.gz                   │
│  Contains: complete.log, complete.1.log, pre-commit.log, etc.   │
│  Original logs deleted (if user confirms)                        │
└──────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────────┐
│                         DAY 75                                    │
│  Old archives cleanup                                            │
│  find .git -name "hook-logs-archive-*.tar.gz" -mtime +30 -delete│
│  Archives older than 30 days removed                             │
└──────────────────────────────────────────────────────────────────┘
```

---

## Archive File Contents Example

### Extracting and Viewing Archive:

```bash
$ tar -tzf .git/hook-logs-archive-20251104-143025.tar.gz

.git/hook-logs/
.git/hook-logs/complete.log
.git/hook-logs/complete.1.log
.git/hook-logs/complete.2.log
.git/hook-logs/pre-commit.log
.git/hook-logs/pre-commit.1.log
.git/hook-logs/commit-msg.log
.git/hook-logs/pre-push.log
```

### Size Distribution Example:

```bash
$ du -h .git/hook-logs-archive-*.tar.gz

2.5M    .git/hook-logs-archive-20251103-120000.tar.gz
1.8M    .git/hook-logs-archive-20251104-143025.tar.gz
3.1M    .git/hook-logs-archive-20251104-160000.tar.gz
```

---

## Configuration Constants

```bash
# From .githooks/clean.sh

MAX_SIZE=262144        # 256 KB - When to rotate
MAX_ARCHIVES=2         # Keep 2 rotated copies
MAX_AGE_DAYS=21        # Delete logs older than 21 days
```

### Customization:

To change rotation settings, edit `.githooks/clean.sh`:

```bash
# Increase rotation threshold to 512 KB
MAX_SIZE=524288

# Keep more archives (3 copies)
MAX_ARCHIVES=3

# Keep logs longer (30 days)
MAX_AGE_DAYS=30
```

---

## Summary

The archive system provides:

1. **Automatic archiving** during uninstall (timestamped .tar.gz files)
2. **Automatic rotation** when logs exceed 256 KB
3. **Retention management** (2 rotated copies, 21 day cleanup)
4. **User control** (choose to delete or keep original logs)
5. **Easy extraction** (standard tar.gz format)
6. **Space efficiency** (compressed archives, automatic cleanup)

All archives are excluded from version control via `.gitignore`, keeping your repository clean while preserving local history.
