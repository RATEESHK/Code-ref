#!/usr/bin/env bash

set -euo pipefail

# ============================================================================
# Git Hooks Uninstallation Script v3.0
# Purpose: Remove hook configuration and optionally archive logs
# Matches: install-hooks.sh v3.0 (complete cleanup)
# ============================================================================

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'
BOLD='\033[1m'

# Setup logging
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="${SCRIPT_DIR}/logs"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOG_FILE="${LOG_DIR}/uninstall-${TIMESTAMP}.log"

# Create log directory
mkdir -p "$LOG_DIR" 2>/dev/null || true

# Logging function
log() {
    local msg="$*"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    # Strip ANSI color codes (both \033 and \x1b formats) before logging
    echo "[$timestamp] $msg" | sed -E 's/\\033\[[0-9;]*m//g; s/\x1b\[[0-9;]*m//g; s/\\n/ /g' >> "$LOG_FILE" 2>/dev/null || true
    echo -e "$msg"
}

log "${CYAN}${BOLD}"
log "╔════════════════════════════════════════════════════════════════════╗"
log "║              Git Hooks Uninstallation Script                       ║"
log "╚════════════════════════════════════════════════════════════════════╝"
log "${NC}\n"

log "${BLUE}Uninstallation Log: ${BOLD}$LOG_FILE${NC}\n"

# Verify Git repository
if [ ! -d .git ]; then
    log "${RED}${BOLD}Error:${NC} Not a git repository"
    exit 1
fi

# Get repository info for logging
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || echo ".")"
REPO_NAME=$(basename "$REPO_ROOT" 2>/dev/null || echo "Unknown")
USER_NAME=$(git config user.name 2>/dev/null || echo "Unknown")
USER_EMAIL=$(git config user.email 2>/dev/null || echo "Unknown")

log "${BLUE}${BOLD}Repository Information:${NC}"
log "  ${CYAN}Name:${NC}    $REPO_NAME"
log "  ${CYAN}User:${NC}    $USER_NAME <$USER_EMAIL>"
log ""

# Confirmation
log "${YELLOW}${BOLD}Warning:${NC} This will remove all Git hook configurations"
log "${CYAN}Current hooks path:${NC} $(git config core.hooksPath 2>/dev/null || echo 'default')"
log ""
read -p "Are you sure you want to uninstall? (y/N): " -n 1 -r
log ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    log "${CYAN}Uninstallation cancelled${NC}"
    exit 0
fi

log ""

# Archive logs
if [ -d .git/hook-logs ]; then
    log "${YELLOW}[1/6]${NC} Archiving hook execution logs..."
    ARCHIVE_NAME=".git/hook-logs-archive-$(date +%Y%m%d-%H%M%S).tar.gz"
    
    if command -v tar >/dev/null 2>&1; then
        tar -czf "$ARCHIVE_NAME" .git/hook-logs/ 2>/dev/null || true
        log "${GREEN}  ✓${NC} Logs archived to: $ARCHIVE_NAME"
    else
        log "${YELLOW}  ⚠${NC} tar not available, skipping archive"
    fi
    
    read -p "Delete hook execution log directory? (y/N): " -n 1 -r
    log ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -rf .git/hook-logs/
        log "${GREEN}  ✓${NC} Log directory deleted"
    else
        log "${CYAN}  ℹ${NC} Log directory kept"
    fi
else
    log "${YELLOW}[1/6]${NC} No hook execution logs found"
fi

# Handle test infrastructure
log "${YELLOW}[2/6]${NC} Handling test infrastructure..."

# Check if tests are enabled
if [[ "$(git config hooks.tests.enabled 2>/dev/null)" == "true" ]]; then
    log "${CYAN}  Tests are currently enabled${NC}"
    read -p "  Remove test logs? (y/N): " -n 1 -r
    log ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        if [ -d .githooks/test/logs ]; then
            log "  ${YELLOW}Archiving test logs...${NC}"
            TEST_ARCHIVE=".githooks/test/test-logs-archive-$(date +%Y%m%d-%H%M%S).tar.gz"
            if command -v tar >/dev/null 2>&1; then
                tar -czf "$TEST_ARCHIVE" .githooks/test/logs/ 2>/dev/null || true
                log "${GREEN}    ✓${NC} Test logs archived to: $TEST_ARCHIVE"
            fi
            rm -rf .githooks/test/logs/*.log 2>/dev/null || true
            log "${GREEN}    ✓${NC} Test logs removed"
        fi
    else
        log "${CYAN}    ℹ${NC} Test logs kept"
    fi
    
    # Clean test state file
    if [ -f .githooks/test/.test-state ]; then
        rm -f .githooks/test/.test-state
        log "${GREEN}  ✓${NC} Test state file removed"
    fi
else
    log "${CYAN}  ℹ${NC} Tests not enabled"
fi

# Reset hooks path
log "${YELLOW}[3/6]${NC} Resetting Git hooks path..."
git config --unset core.hooksPath 2>/dev/null || true
log "${GREEN}  ✓${NC} Hooks path reset to default (.git/hooks)"

# Remove hook configurations
log "${YELLOW}[4/6]${NC} Removing hook configurations..."
git config --unset hooks.maxCommits 2>/dev/null || true
git config --unset hooks.autoAddAfterFix 2>/dev/null || true
git config --unset hooks.parallelExecution 2>/dev/null || true

# Remove branch mapping configurations (NEW - matches install-hooks.sh step 5.5)
log "${CYAN}  Removing branch base mappings...${NC}"
removed_count=0
for branch_type in hotfix feat feature bugfix fix techdebt perf refactor revert style test build chore ci docs; do
    if git config --unset hooks.branchMapping.$branch_type 2>/dev/null; then
        removed_count=$((removed_count + 1))
    fi
done

if [ $removed_count -gt 0 ]; then
    log "${GREEN}  ✓${NC} Removed ${BOLD}$removed_count${NC} branch type mappings"
else
    log "${CYAN}  ℹ${NC} No branch mappings to remove"
fi

# Remove test configurations
log "${CYAN}  Removing test configurations...${NC}"
test_configs_removed=0
for config in enabled baseBranch logVerbosity autoCleanup categories preserveState; do
    if git config --unset hooks.tests.$config 2>/dev/null; then
        test_configs_removed=$((test_configs_removed + 1))
    fi
done

if [ $test_configs_removed -gt 0 ]; then
    log "${GREEN}  ✓${NC} Removed ${BOLD}$test_configs_removed${NC} test configurations"
else
    log "${CYAN}  ℹ${NC} No test configurations to remove"
fi

log "${GREEN}  ✓${NC} Hook configurations removed"

# Restore other settings
log "${YELLOW}[5/11]${NC} Reverting other Git settings..."
read -p "Reset rebase.autosquash? (y/N): " -n 1 -r
log ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    git config --unset rebase.autosquash 2>/dev/null || true
    log "${GREEN}  ✓${NC} rebase.autosquash reset"
fi

read -p "Reset fetch.prune? (y/N): " -n 1 -r
log ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    git config --unset fetch.prune 2>/dev/null || true
    log "${GREEN}  ✓${NC} fetch.prune reset"
fi

# Clean .git/info/exclude (NEW - Step 9 from install)
log "${YELLOW}[6/11]${NC} Cleaning .git/info/exclude..."
if [ -f .git/info/exclude ]; then
    if grep -q "^hook-logs/" .git/info/exclude 2>/dev/null; then
        log "${CYAN}  Found hook-logs/ entry in .git/info/exclude${NC}"
        read -p "  Remove entry? (y/N): " -n 1 -r
        log ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            # Remove the line - use grep method (more portable)
            if grep -v "^hook-logs/$" .git/info/exclude > .git/info/exclude.tmp 2>/dev/null; then
                mv .git/info/exclude.tmp .git/info/exclude
                log "${GREEN}    ✓${NC} Entry removed from .git/info/exclude"
            else
                # Fallback: manual removal
                rm -f .git/info/exclude.tmp 2>/dev/null || true
                log "${YELLOW}    ⚠${NC} Could not remove automatically, please edit manually"
            fi
        else
            log "${CYAN}    ℹ${NC} Entry kept"
        fi
    else
        log "${CYAN}  ℹ${NC} No hook-logs/ entry found"
    fi
else
    log "${CYAN}  ℹ${NC} .git/info/exclude does not exist"
fi

# Clean .gitignore patterns (NEW - Step 0 from install)
log "${YELLOW}[7/11]${NC} Cleaning .gitignore patterns..."
GITIGNORE_FILE="${REPO_ROOT}/.gitignore"

if [ -f "$GITIGNORE_FILE" ]; then
    if grep -q "# Git Hooks - Custom Ignores" "$GITIGNORE_FILE" 2>/dev/null; then
        log "${CYAN}  Found Git Hooks section in .gitignore${NC}"
        log "${YELLOW}  This section contains:${NC}"
        log "    - .git/hook-logs/"
        log "    - .git/hook-logs-archive-*.tar.gz"
        log "    - .githooks/test/logs/"
        log "    - .githooks/test/.test-state"
        log "    - .githooks/logs/"
        log ""
        read -p "  Remove Git Hooks section from .gitignore? (y/N): " -n 1 -r
        log ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            # Backup .gitignore
            cp "$GITIGNORE_FILE" "${GITIGNORE_FILE}.backup-$(date +%Y%m%d_%H%M%S)" 2>/dev/null || true
            
            # Remove the entire Git Hooks section
            # This removes from "# Git Hooks - Custom Ignores" until the next blank line after patterns
            if command -v awk >/dev/null 2>&1; then
                awk '
                    /^# ==============================================================================/ && getline && /^# Git Hooks - Custom Ignores/ {
                        skip = 1
                        next
                    }
                    skip && /^$/ && getline && /^$/ {
                        skip = 0
                        next
                    }
                    !skip
                ' "$GITIGNORE_FILE" > "${GITIGNORE_FILE}.tmp" && mv "${GITIGNORE_FILE}.tmp" "$GITIGNORE_FILE"
                
                log "${GREEN}    ✓${NC} Git Hooks section removed from .gitignore"
                log "${CYAN}    ℹ${NC} Backup saved: ${GITIGNORE_FILE}.backup-*"
            else
                log "${YELLOW}    ⚠${NC} awk not available, manual cleanup needed"
                log "${CYAN}    ℹ${NC} Search for '# Git Hooks - Custom Ignores' in .gitignore"
            fi
        else
            log "${CYAN}    ℹ${NC} .gitignore patterns kept"
        fi
    else
        log "${CYAN}  ℹ${NC} No Git Hooks section found in .gitignore"
    fi
else
    log "${CYAN}  ℹ${NC} .gitignore file not found"
fi

# Clean generated files (NEW - Step 11 from install)
log "${YELLOW}[8/11]${NC} Handling generated files..."

generated_files=()
[ -f .githooks/commands.conf ] && generated_files+=(".githooks/commands.conf")
[ -f .githooks/run-commands.sh ] && generated_files+=(".githooks/run-commands.sh")

if [ ${#generated_files[@]} -gt 0 ]; then
    log "${CYAN}  Found ${#generated_files[@]} generated file(s):${NC}"
    for file in "${generated_files[@]}"; do
        log "    - $file"
    done
    log ""
    log "${YELLOW}  Note:${NC} These may contain your custom configurations"
    read -p "  Remove generated files? (y/N): " -n 1 -r
    log ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        for file in "${generated_files[@]}"; do
            # Backup before removing
            if [ -f "$file" ]; then
                cp "$file" "${file}.backup-$(date +%Y%m%d_%H%M%S)" 2>/dev/null || true
                rm -f "$file"
                log "${GREEN}    ✓${NC} Removed: $file"
            fi
        done
        log "${CYAN}    ℹ${NC} Backups saved with .backup-* extension"
    else
        log "${CYAN}    ℹ${NC} Generated files kept"
    fi
else
    log "${CYAN}  ℹ${NC} No generated files found"
fi

# Clean rollback files (NEW)
log "${YELLOW}[9/11]${NC} Cleaning rollback files..."
if [ -d .githooks/logs ]; then
    rollback_files=$(find .githooks/logs -name ".rollback-*.sh" 2>/dev/null || true)
    rollback_count=$(echo "$rollback_files" | grep -c ".sh" 2>/dev/null || echo "0")
    
    if [ "$rollback_count" -gt 0 ]; then
        log "${CYAN}  Found $rollback_count rollback file(s)${NC}"
        rm -f .githooks/logs/.rollback-*.sh 2>/dev/null || true
        log "${GREEN}  ✓${NC} Rollback files removed"
    else
        log "${CYAN}  ℹ${NC} No rollback files found"
    fi
else
    log "${CYAN}  ℹ${NC} No logs directory"
fi

# Clean backup files (NEW)
log "${YELLOW}[10/11]${NC} Cleaning backup files..."
backup_files=$(find .githooks -name "*.backup-*" 2>/dev/null | head -10 || true)
backup_count=$(echo "$backup_files" | grep -c "backup-" 2>/dev/null || echo "0")

if [ "$backup_count" -gt 0 ]; then
    log "${CYAN}  Found $backup_count backup file(s)${NC}"
    if [ "$backup_count" -le 5 ]; then
        echo "$backup_files" | while read -r file; do
            [ -n "$file" ] && log "    - $file"
        done
    else
        echo "$backup_files" | head -5 | while read -r file; do
            [ -n "$file" ] && log "    - $file"
        done
        log "    ... and $((backup_count - 5)) more"
    fi
    log ""
    read -p "  Remove all backup files? (y/N): " -n 1 -r
    log ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        find .githooks -name "*.backup-*" -type f -delete 2>/dev/null || true
        log "${GREEN}  ✓${NC} Backup files removed"
    else
        log "${CYAN}  ℹ${NC} Backup files kept"
    fi
else
    log "${CYAN}  ℹ${NC} No backup files found"
fi

# Clean installation logs
log "${YELLOW}[11/11]${NC} Handling installation logs..."
if [ -d .githooks/logs ]; then
    log_count=$(find .githooks/logs -name "*.log" 2>/dev/null | wc -l)
    if [ $log_count -gt 0 ]; then
        log "${CYAN}  Found $log_count installation log files${NC}"
        read -p "  Archive and remove installation logs? (y/N): " -n 1 -r
        log ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            INSTALL_ARCHIVE=".githooks/installation-logs-archive-$(date +%Y%m%d-%H%M%S).tar.gz"
            if command -v tar >/dev/null 2>&1; then
                tar -czf "$INSTALL_ARCHIVE" .githooks/logs/ 2>/dev/null || true
                log "${GREEN}    ✓${NC} Installation logs archived to: $INSTALL_ARCHIVE"
            fi
            rm -rf .githooks/logs/*.log 2>/dev/null || true
            log "${GREEN}    ✓${NC} Installation logs removed"
        else
            log "${CYAN}    ℹ${NC} Installation logs kept"
        fi
    else
        log "${CYAN}  ℹ${NC} No installation logs found"
    fi
else
    log "${CYAN}  ℹ${NC} No installation log directory found"
fi

# Write summary to log
log ""
echo "" >> "$LOG_FILE"
echo "============================================================================" >> "$LOG_FILE"
echo "Uninstallation Summary" >> "$LOG_FILE"
echo "============================================================================" >> "$LOG_FILE"
echo "Timestamp: $(date)" >> "$LOG_FILE"
echo "Repository: $REPO_NAME" >> "$LOG_FILE"
echo "User: $USER_NAME <$USER_EMAIL>" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"
echo "Removed Configurations:" >> "$LOG_FILE"
echo "  - Hooks Path: Reset to default" >> "$LOG_FILE"
echo "  - Branch Mappings: $removed_count types removed" >> "$LOG_FILE"
echo "  - Test Configurations: $test_configs_removed settings removed" >> "$LOG_FILE"
echo "  - Generated Files: Cleaned" >> "$LOG_FILE"
echo "  - Rollback Files: Cleaned" >> "$LOG_FILE"
echo "  - Backup Files: Cleaned" >> "$LOG_FILE"
echo "  - .git/info/exclude: Cleaned" >> "$LOG_FILE"
echo "  - .gitignore: Cleaned (optional)" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"
echo "Uninstallation completed successfully" >> "$LOG_FILE"
echo "============================================================================" >> "$LOG_FILE"

log "\n${GREEN}${BOLD}✓ Uninstallation complete!${NC}\n"

log "${CYAN}${BOLD}What was removed:${NC}"
log "  ✓ Git hook configurations"
log "  ✓ Branch base mappings ($removed_count types)"
log "  ✓ Test configurations ($test_configs_removed settings)"
log "  ✓ Hook execution logs (archived)"
log "  ✓ Test logs (archived)"
log "  ✓ Installation logs (archived)"
log "  ✓ Rollback files"
log "  ✓ Backup files"
log "  ✓ .git/info/exclude entry"
log "  ✓ .gitignore patterns (if selected)"
log ""

log "${CYAN}${BOLD}What was kept:${NC}"
log "  • Hook scripts (.githooks/ directory)"
log "  • Test infrastructure (.githooks/test/)"
log "  • Documentation files"
log "  • Archived logs (*-archive-*.tar.gz)"
log ""

log "${YELLOW}${BOLD}To completely remove hooks:${NC}"
log "  ${CYAN}rm -rf .githooks${NC}  (deletes all hook files)"
log ""

log "${GREEN}${BOLD}To reinstall:${NC}"
log "  ${CYAN}bash .githooks/install-hooks.sh${NC}"
log ""

log "${CYAN}Uninstallation log saved to:${NC} ${BOLD}$LOG_FILE${NC}"
log ""

# Log uninstallation to hook logs if they still exist
if [ -d .git/hook-logs ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] [uninstall] Hooks uninstalled by $USER_NAME <$USER_EMAIL>" >> .git/hook-logs/complete.log 2>/dev/null || true
fi
