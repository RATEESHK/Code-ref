#!/usr/bin/env bash

# ============================================================================
# Command Runner Framework
# Purpose: Execute custom commands from commands.conf with proper error handling
# ============================================================================

# Source common library
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh"

# Command execution statistics
declare -A COMMAND_STATUS
declare -A COMMAND_OUTPUT
declare -A COMMAND_DURATION
COMMANDS_RUN=0
COMMANDS_PASSED=0
COMMANDS_FAILED=0

# Parse commands.conf file
parse_commands_conf() {
    local hook_name="$1"
    local commands_file=".githooks/commands.conf"
    
    if [ ! -f "$commands_file" ]; then
        log_message $LOG_TRACE "$hook_name" "No commands.conf file found"
        return 0
    fi
    
    # Read commands for this hook
    while IFS=: read -r cmd_hook priority mandatory timeout command description; do
        # Skip comments and empty lines
        [[ "$cmd_hook" =~ ^#.*$ ]] && continue
        [[ -z "$cmd_hook" ]] && continue
        
        # Only process commands for this hook
        if [ "$cmd_hook" = "$hook_name" ]; then
            echo "$priority:$mandatory:$timeout:$command:$description"
        fi
    done < "$commands_file" | sort -t: -k1 -n
}

# Execute a single command
execute_command() {
    local hook_name="$1"
    local priority="$2"
    local mandatory="$3"
    local timeout="$4"
    local command="$5"
    local description="$6"
    
    ((COMMANDS_RUN++))
    
    log_message $LOG_INFO "$hook_name" "Running: $description (priority: $priority, mandatory: $mandatory, timeout: ${timeout}s)"
    echo -e "${BLUE}[${COMMANDS_RUN}]${NC} Running: ${BOLD}$description${NC}"
    
    # Replace placeholders
    local staged_files=$(get_staged_files | tr '\n' ' ')
    command="${command//\{staged\}/$staged_files}"
    
    # Set environment variables
    export STAGED_FILES="$staged_files"
    export GIT_HOOK_NAME="$hook_name"
    export GIT_USER_NAME="$(git config user.name 2>/dev/null || echo 'unknown')"
    export GIT_USER_EMAIL="$(git config user.email 2>/dev/null || echo 'unknown')"
    
    # Execute with timeout
    local start_time=$(date +%s)
    local output_file=$(mktemp)
    local exit_code=0
    
    if command -v timeout >/dev/null 2>&1; then
        # GNU timeout
        timeout "$timeout" bash -c "$command" > "$output_file" 2>&1 || exit_code=$?
    elif command -v gtimeout >/dev/null 2>&1; then
        # macOS gtimeout (from coreutils)
        gtimeout "$timeout" bash -c "$command" > "$output_file" 2>&1 || exit_code=$?
    else
        # Fallback without timeout
        bash -c "$command" > "$output_file" 2>&1 || exit_code=$?
    fi
    
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    
    # Store results
    local cmd_key="${COMMANDS_RUN}"
    COMMAND_STATUS["$cmd_key"]=$exit_code
    COMMAND_OUTPUT["$cmd_key"]=$(cat "$output_file")
    COMMAND_DURATION["$cmd_key"]=$duration
    
    # Log output
    if [ -s "$output_file" ]; then
        log_message $LOG_DEBUG "$hook_name" "Command output: $(cat "$output_file")"
    fi
    
    rm -f "$output_file"
    
    # Check result
    if [ $exit_code -eq 0 ]; then
        ((COMMANDS_PASSED++))
        echo -e "  ${GREEN}✓${NC} $description ${CYAN}(${duration}s)${NC}"
        log_message $LOG_INFO "$hook_name" "Command passed: $description (exit: $exit_code, duration: ${duration}s)"
        return 0
    elif [ $exit_code -eq 124 ] || [ $exit_code -eq 143 ]; then
        # Timeout
        ((COMMANDS_FAILED++))
        echo -e "  ${RED}✗${NC} $description ${YELLOW}(timeout after ${timeout}s)${NC}"
        log_message $LOG_ERROR "$hook_name" "Command timeout: $description (timeout: ${timeout}s)"
        
        if [ "$mandatory" = "true" ]; then
            return 1
        fi
        return 0
    else
        ((COMMANDS_FAILED++))
        echo -e "  ${RED}✗${NC} $description ${YELLOW}(exit code: $exit_code, ${duration}s)${NC}"
        log_message $LOG_ERROR "$hook_name" "Command failed: $description (exit: $exit_code, duration: ${duration}s)"
        
        # Show output if command failed
        if [ -n "${COMMAND_OUTPUT[$cmd_key]}" ]; then
            echo -e "${YELLOW}Output:${NC}"
            echo "${COMMAND_OUTPUT[$cmd_key]}" | head -20
        fi
        
        if [ "$mandatory" = "true" ]; then
            return 1
        fi
        return 0
    fi
}

# Auto-restage files after fixes
auto_restage_files() {
    local hook_name="$1"
    local auto_add=$(git config hooks.autoAddAfterFix || echo "false")
    
    if [ "$auto_add" = "true" ]; then
        log_message $LOG_INFO "$hook_name" "Auto-restaging modified files"
        echo -e "${CYAN}[Info]${NC} Re-staging modified files..."
        
        # Get files that were staged and are now modified
        local modified_staged=$(git diff --name-only --diff-filter=M)
        
        if [ -n "$modified_staged" ]; then
            while IFS= read -r file; do
                git add "$file"
                echo -e "  ${GREEN}✓${NC} Restaged: $file"
                log_message $LOG_INFO "$hook_name" "Restaged file: $file"
            done <<< "$modified_staged"
        fi
    fi
}

# Run all commands for a hook
run_hook_commands() {
    local hook_name="$1"
    
    log_message $LOG_INFO "$hook_name" "Starting custom command execution"
    echo -e "\n${CYAN}${BOLD}[Custom Commands]${NC} Running configured checks for $hook_name\n"
    
    # Reset counters
    COMMANDS_RUN=0
    COMMANDS_PASSED=0
    COMMANDS_FAILED=0
    declare -gA COMMAND_STATUS
    declare -gA COMMAND_OUTPUT
    declare -gA COMMAND_DURATION
    
    # Parse and execute commands
    local commands=$(parse_commands_conf "$hook_name")
    
    if [ -z "$commands" ]; then
        log_message $LOG_INFO "$hook_name" "No custom commands configured"
        echo -e "${CYAN}[Info]${NC} No custom commands configured for $hook_name"
        return 0
    fi
    
    local failed_mandatory=0
    local parallel_execution=$(git config hooks.parallelExecution || echo "false")
    
    # Check if parallel execution is enabled
    if [ "$parallel_execution" = "true" ]; then
        log_message $LOG_INFO "$hook_name" "Parallel execution enabled"
    fi
    
    local current_priority=""
    declare -a parallel_pids=()
    
    while IFS=: read -r priority mandatory timeout command description; do
        # If priority changed and parallel execution is enabled, wait for previous group
        if [ "$parallel_execution" = "true" ] && [ -n "$current_priority" ] && [ "$current_priority" != "$priority" ]; then
            for pid in "${parallel_pids[@]}"; do
                wait "$pid" || true
            done
            parallel_pids=()
        fi
        
        current_priority="$priority"
        
        if [ "$parallel_execution" = "true" ]; then
            # Execute in background
            execute_command "$hook_name" "$priority" "$mandatory" "$timeout" "$command" "$description" &
            parallel_pids+=($!)
        else
            # Execute synchronously
            if ! execute_command "$hook_name" "$priority" "$mandatory" "$timeout" "$command" "$description"; then
                if [ "$mandatory" = "true" ]; then
                    failed_mandatory=1
                fi
            fi
        fi
    done <<< "$commands"
    
    # Wait for any remaining parallel commands
    if [ "$parallel_execution" = "true" ]; then
        for pid in "${parallel_pids[@]}"; do
            wait "$pid" || true
        done
    fi
    
    # Auto-restage if needed
    auto_restage_files "$hook_name"
    
    # Print summary
    echo -e "\n${CYAN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BOLD}Summary:${NC} $COMMANDS_RUN total, ${GREEN}$COMMANDS_PASSED passed${NC}, ${RED}$COMMANDS_FAILED failed${NC}"
    echo -e "${CYAN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
    
    log_message $LOG_INFO "$hook_name" "Command execution complete: $COMMANDS_RUN total, $COMMANDS_PASSED passed, $COMMANDS_FAILED failed"
    
    if [ $failed_mandatory -ne 0 ]; then
        echo -e "${RED}${BOLD}Hook Failed!${NC}"
        echo -e "${YELLOW}To bypass (emergency only):${NC} BYPASS_HOOKS=1 git $hook_name"
        log_message $LOG_ERROR "$hook_name" "Hook failed due to mandatory command failures"
        return 1
    fi
    
    if [ $COMMANDS_FAILED -gt 0 ]; then
        echo -e "${YELLOW}[Warning]${NC} Some optional checks failed but commit is allowed"
        log_message $LOG_WARNING "$hook_name" "Optional commands failed but hook passed"
    fi
    
    return 0
}

# Legacy support - run extension functions from run-commands.sh
run_extension() {
    local hook_name="$1"
    local func_name="$2"
    shift 2
    local args=("$@")
    
    local extension_file=".githooks/run-commands.sh"
    if [ -f "$extension_file" ]; then
        source "$extension_file"
        if declare -f "$func_name" >/dev/null 2>&1; then
            log_message $LOG_INFO "$hook_name" "Running legacy extension: $func_name"
            "$func_name" "${args[@]}"
            local result=$?
            if [ $result -ne 0 ]; then
                log_message $LOG_ERROR "$hook_name" "Extension $func_name failed with code $result"
            fi
            return $result
        fi
    fi
    return 0
}
