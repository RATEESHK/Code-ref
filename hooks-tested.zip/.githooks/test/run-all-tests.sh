#!/usr/bin/env bash

# ============================================================================
# Git Hooks - Run All Tests with Logging
# Purpose: Execute complete test suite and generate detailed logs
# ============================================================================

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
NC='\033[0m'
BOLD='\033[1m'

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
LOG_DIR="$ROOT_DIR/.githooks/test/logs"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOG_FILE="$LOG_DIR/test-run-$TIMESTAMP.log"

# Create log directory
mkdir -p "$LOG_DIR"

# Print header
print_header() {
    echo -e "${CYAN}${BOLD}"
    echo "╔════════════════════════════════════════════════════════════════════╗"
    echo "║           Git Hooks - Comprehensive Test Execution                ║"
    echo "║                    With Detailed Logging                          ║"
    echo "╚════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}\n"
}

# Log and display
log_msg() {
    local msg="$1"
    echo -e "$msg" | tee -a "$LOG_FILE"
}

# Run test category
run_test_category() {
    local category="$1"
    local description="$2"
    
    log_msg "${BLUE}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
    log_msg "${YELLOW}${BOLD}Running: $description${NC}"
    log_msg "${BLUE}${BOLD}═══════════════════════════════════════════════════════════════════${NC}\n"
    
    if [ -f "$SCRIPT_DIR/test-scenarios/${category}-tests.sh" ]; then
        # Run scenario-specific test
        bash "$SCRIPT_DIR/test-scenarios/${category}-tests.sh" 2>&1 | tee -a "$LOG_FILE"
    else
        # Run from main test suite
        bash "$SCRIPT_DIR/test-suite.sh" --category "$category" --verbose 2>&1 | tee -a "$LOG_FILE"
    fi
    
    local exit_code=${PIPESTATUS[0]}
    
    if [ $exit_code -eq 0 ]; then
        log_msg "${GREEN}${BOLD}✓ $description - PASSED${NC}\n"
        return 0
    else
        log_msg "${RED}${BOLD}✗ $description - FAILED${NC}\n"
        return 1
    fi
}

# Main test execution
main() {
    print_header | tee "$LOG_FILE"
    
    log_msg "${MAGENTA}${BOLD}Test Execution Started${NC}"
    log_msg "${CYAN}Date: $(date)${NC}"
    log_msg "${CYAN}Log File: $LOG_FILE${NC}"
    log_msg "${CYAN}Repository: $(git rev-parse --show-toplevel 2>/dev/null || echo 'Unknown')${NC}"
    log_msg "${CYAN}Branch: $(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo 'Unknown')${NC}\n"
    
    # Test counters
    local total_categories=0
    local passed_categories=0
    local failed_categories=0
    
    # Track individual results
    declare -a failed_tests=()
    
    # ========================================================================
    # 1. Branch Naming Tests
    # ========================================================================
    ((total_categories++))
    if run_test_category "branch" "Branch Naming & Validation Tests"; then
        ((passed_categories++))
    else
        ((failed_categories++))
        failed_tests+=("Branch Naming Tests")
    fi
    
    # ========================================================================
    # 2. Security Scanning Tests
    # ========================================================================
    ((total_categories++))
    if run_test_category "security" "Security Scanning Tests"; then
        ((passed_categories++))
    else
        ((failed_categories++))
        failed_tests+=("Security Scanning Tests")
    fi
    
    # ========================================================================
    # 3. Base Branch Enforcement Tests
    # ========================================================================
    ((total_categories++))
    if run_test_category "base-branch" "Base Branch Enforcement Tests"; then
        ((passed_categories++))
    else
        ((failed_categories++))
        failed_tests+=("Base Branch Enforcement Tests")
    fi
    
    # ========================================================================
    # 4. Commit Message Tests
    # ========================================================================
    ((total_categories++))
    if run_test_category "commit" "Commit Message Validation Tests"; then
        ((passed_categories++))
    else
        ((failed_categories++))
        failed_tests+=("Commit Message Tests")
    fi
    
    # ========================================================================
    # 5. Protected Branch Tests
    # ========================================================================
    ((total_categories++))
    if run_test_category "protected" "Protected Branch Tests"; then
        ((passed_categories++))
    else
        ((failed_categories++))
        failed_tests+=("Protected Branch Tests")
    fi
    
    # ========================================================================
    # 6. Custom Commands Tests
    # ========================================================================
    ((total_categories++))
    if run_test_category "commands" "Custom Commands Framework Tests"; then
        ((passed_categories++))
    else
        ((failed_categories++))
        failed_tests+=("Custom Commands Tests")
    fi
    
    # ========================================================================
    # 7. Logging Tests
    # ========================================================================
    ((total_categories++))
    if run_test_category "logging" "Logging Infrastructure Tests"; then
        ((passed_categories++))
    else
        ((failed_categories++))
        failed_tests+=("Logging Tests")
    fi
    
    # ========================================================================
    # 8. Bypass Mechanism Tests
    # ========================================================================
    ((total_categories++))
    if run_test_category "bypass" "Bypass Mechanism Tests"; then
        ((passed_categories++))
    else
        ((failed_categories++))
        failed_tests+=("Bypass Mechanism Tests")
    fi
    
    # ========================================================================
    # Final Summary
    # ========================================================================
    log_msg "\n${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
    log_msg "${MAGENTA}${BOLD}           COMPREHENSIVE TEST EXECUTION SUMMARY${NC}"
    log_msg "${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}\n"
    
    log_msg "${BOLD}Test Categories:${NC}"
    log_msg "  Total:    ${BOLD}$total_categories${NC}"
    log_msg "  ${GREEN}Passed:   $passed_categories${NC}"
    log_msg "  ${RED}Failed:   $failed_categories${NC}\n"
    
    if [ $failed_categories -gt 0 ]; then
        log_msg "${RED}${BOLD}Failed Test Categories:${NC}"
        for test in "${failed_tests[@]}"; do
            log_msg "  ${RED}✗${NC} $test"
        done
        log_msg ""
    fi
    
    log_msg "${CYAN}${BOLD}Test Results Summary:${NC}"
    log_msg "  Start Time:   $(head -5 "$LOG_FILE" | grep "Date:" | cut -d: -f2-)"
    log_msg "  End Time:     $(date)"
    log_msg "  Log File:     $LOG_FILE"
    log_msg "  Log Size:     $(du -h "$LOG_FILE" | cut -f1)\n"
    
    # ========================================================================
    # Configuration Verification
    # ========================================================================
    log_msg "${CYAN}${BOLD}Configuration Verification:${NC}"
    log_msg "  Hooks Path:      $(git config core.hooksPath || echo 'Not set')"
    log_msg "  Max Commits:     $(git config hooks.maxCommits || echo 'Not set')"
    log_msg "  Auto-restage:    $(git config hooks.autoAddAfterFix || echo 'Not set')"
    log_msg "  Branch Mappings: $(git config --get-regexp hooks.branchMapping 2>/dev/null | wc -l || echo '0') configured\n"
    
    # ========================================================================
    # Final Status
    # ========================================================================
    if [ $failed_categories -eq 0 ]; then
        log_msg "${GREEN}${BOLD}╔════════════════════════════════════════════════════════════════════╗${NC}"
        log_msg "${GREEN}${BOLD}║                 ✓ ALL TESTS PASSED!                               ║${NC}"
        log_msg "${GREEN}${BOLD}╚════════════════════════════════════════════════════════════════════╝${NC}\n"
        exit 0
    else
        log_msg "${RED}${BOLD}╔════════════════════════════════════════════════════════════════════╗${NC}"
        log_msg "${RED}${BOLD}║                 ✗ SOME TESTS FAILED                               ║${NC}"
        log_msg "${RED}${BOLD}╚════════════════════════════════════════════════════════════════════╝${NC}\n"
        log_msg "${YELLOW}Review log file for details: $LOG_FILE${NC}\n"
        exit 1
    fi
}

# Run with error handling
trap 'echo -e "\n${RED}Test execution interrupted${NC}" | tee -a "$LOG_FILE"' INT TERM
main "$@"
