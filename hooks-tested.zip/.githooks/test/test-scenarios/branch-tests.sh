#!/usr/bin/env bash
# Branch Validation Test Scenarios
# Tests branch naming and validation rules

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FIXTURES_DIR="$SCRIPT_DIR/../test-fixtures"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

# Counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test result tracker
pass_test() {
    ((TESTS_PASSED++))
    ((TESTS_RUN++))
    echo -e "${GREEN}✓${NC} $1"
}

fail_test() {
    ((TESTS_FAILED++))
    ((TESTS_RUN++))
    echo -e "${RED}✗${NC} $1"
    echo "  Error: $2"
}

# Branch naming regex patterns
LONG_LIVED_PATTERN="^(main|develop|release($|/.*))$"
SHORT_LIVED_PATTERN="^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$"

# Test: Validate main branch
test_main_branch() {
    local branch="main"
    if [[ "$branch" =~ $LONG_LIVED_PATTERN ]]; then
        pass_test "Long-lived branch: main"
    else
        fail_test "Long-lived branch: main" "Pattern not matched"
    fi
}

# Test: Validate develop branch
test_develop_branch() {
    local branch="develop"
    if [[ "$branch" =~ $LONG_LIVED_PATTERN ]]; then
        pass_test "Long-lived branch: develop"
    else
        fail_test "Long-lived branch: develop" "Pattern not matched"
    fi
}

# Test: Validate release branch
test_release_branch() {
    local branch="release/v1.0.0"
    if [[ "$branch" =~ $LONG_LIVED_PATTERN ]]; then
        pass_test "Long-lived branch: release/v1.0.0"
    else
        fail_test "Long-lived branch: release/v1.0.0" "Pattern not matched"
    fi
}

# Test: Reject master branch
test_reject_master() {
    local branch="master"
    if ! [[ "$branch" =~ $LONG_LIVED_PATTERN ]]; then
        pass_test "Reject 'master' (use 'main')"
    else
        fail_test "Reject 'master'" "Should not match"
    fi
}

# Test: Valid feature branch
test_valid_feature_branch() {
    local branch="feat-PROJ-123-add-user-authentication"
    if [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
        pass_test "Valid feature branch: $branch"
    else
        fail_test "Valid feature branch" "Pattern not matched"
    fi
}

# Test: Valid bugfix branch
test_valid_bugfix_branch() {
    local branch="bugfix-BUG-456-fix-memory-leak"
    if [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
        pass_test "Valid bugfix branch: $branch"
    else
        fail_test "Valid bugfix branch" "Pattern not matched"
    fi
}

# Test: Valid hotfix branch
test_valid_hotfix_branch() {
    local branch="hotfix-CRIT-789-security-patch"
    if [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
        pass_test "Valid hotfix branch: $branch"
    else
        fail_test "Valid hotfix branch" "Pattern not matched"
    fi
}

# Test: Invalid branch - no JIRA ID
test_invalid_no_jira() {
    local branch="feature-add-login"
    if ! [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
        pass_test "Reject branch without JIRA ID"
    else
        fail_test "Reject branch without JIRA ID" "Should not match"
    fi
}

# Test: Invalid branch - wrong separator
test_invalid_separator() {
    local branch="feat_PROJ_123_add_user"
    if ! [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
        pass_test "Reject branch with underscores"
    else
        fail_test "Reject branch with underscores" "Should not match"
    fi
}

# Test: Invalid branch - uppercase project code
test_invalid_uppercase_type() {
    local branch="Feat-PROJ-123-add-user"
    if ! [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
        pass_test "Reject branch with uppercase type"
    else
        fail_test "Reject branch with uppercase type" "Should not match"
    fi
}

# Test: Invalid branch - lowercase project code
test_invalid_lowercase_project() {
    local branch="feat-proj-123-add-user"
    if ! [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
        pass_test "Reject branch with lowercase project code"
    else
        fail_test "Reject branch with lowercase project code" "Should not match"
    fi
}

# Test: Invalid branch - no description
test_invalid_no_description() {
    local branch="feat-PROJ-123"
    if ! [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
        pass_test "Reject branch without description"
    else
        fail_test "Reject branch without description" "Should not match"
    fi
}

# Test: Edge case - minimum description
test_minimum_description() {
    local branch="feat-AB-1-x"
    if [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
        pass_test "Accept minimum description (1 char)"
    else
        fail_test "Accept minimum description" "Pattern not matched"
    fi
}

# Test: Edge case - maximum project code
test_maximum_project_code() {
    local branch="feat-ABCDEFGHIJ-999-test"
    if [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
        pass_test "Accept maximum project code (10 chars)"
    else
        fail_test "Accept maximum project code" "Pattern not matched"
    fi
}

# Test: Edge case - project code too long
test_project_code_too_long() {
    local branch="feat-ABCDEFGHIJK-999-test"
    if ! [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
        pass_test "Reject project code >10 chars"
    else
        fail_test "Reject project code >10 chars" "Should not match"
    fi
}

# Test: Edge case - project code too short
test_project_code_too_short() {
    local branch="feat-A-123-test"
    if ! [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
        pass_test "Reject project code <2 chars"
    else
        fail_test "Reject project code <2 chars" "Should not match"
    fi
}

# Test: All valid types
test_all_valid_types() {
    local types=("build" "chore" "ci" "docs" "feat" "feature" "techdebt" "bugfix" "fix" "perf" "refactor" "revert" "style" "test" "hotfix")
    local failed_types=()
    
    for type in "${types[@]}"; do
        local branch="${type}-PROJ-123-test"
        if ! [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
            failed_types+=("$type")
        fi
    done
    
    if [[ ${#failed_types[@]} -eq 0 ]]; then
        pass_test "All valid types accepted (${#types[@]} types)"
    else
        fail_test "All valid types" "Failed types: ${failed_types[*]}"
    fi
}

# Test: Base branch mapping - feature
test_base_branch_feature() {
    local branch="feat-PROJ-123-test"
    local expected_base="origin/develop"
    local actual_base
    
    if [[ "$branch" =~ ^(feat|feature|bugfix|fix|techdebt)- ]]; then
        actual_base="origin/develop"
    fi
    
    if [[ "$actual_base" == "$expected_base" ]]; then
        pass_test "Base branch mapping: feature → develop"
    else
        fail_test "Base branch mapping: feature" "Expected $expected_base, got $actual_base"
    fi
}

# Test: Base branch mapping - hotfix
test_base_branch_hotfix() {
    local branch="hotfix-CRIT-999-emergency"
    local expected_base="origin/main"
    local actual_base
    
    if [[ "$branch" =~ ^hotfix- ]]; then
        actual_base="origin/main"
    fi
    
    if [[ "$actual_base" == "$expected_base" ]]; then
        pass_test "Base branch mapping: hotfix → main"
    else
        fail_test "Base branch mapping: hotfix" "Expected $expected_base, got $actual_base"
    fi
}

# Test: Batch validation with fixture file
test_batch_validation() {
    if [[ -f "$FIXTURES_DIR/branch-names.txt" ]]; then
        local total=0 correct=0
        
        while IFS=' ' read -r expected branch reason; do
            [[ "$expected" =~ ^# ]] && continue
            [[ -z "$expected" ]] && continue
            
            ((total++))
            
            local is_valid=false
            if [[ "$branch" =~ $LONG_LIVED_PATTERN ]] || [[ "$branch" =~ $SHORT_LIVED_PATTERN ]]; then
                is_valid=true
            fi
            
            if { [[ "$expected" == "valid" ]] && $is_valid; } || { [[ "$expected" == "invalid" ]] && ! $is_valid; }; then
                ((correct++))
            fi
        done < "$FIXTURES_DIR/branch-names.txt"
        
        if [[ $correct -eq $total ]]; then
            pass_test "Batch validation ($correct/$total branches)"
        else
            fail_test "Batch validation" "$correct/$total branches validated correctly"
        fi
    else
        fail_test "Batch validation" "Fixture file not found"
    fi
}

# Run all tests
main() {
    echo "========================================"
    echo "Branch Validation Test Scenarios"
    echo "========================================"
    echo ""
    
    test_main_branch
    test_develop_branch
    test_release_branch
    test_reject_master
    test_valid_feature_branch
    test_valid_bugfix_branch
    test_valid_hotfix_branch
    test_invalid_no_jira
    test_invalid_separator
    test_invalid_uppercase_type
    test_invalid_lowercase_project
    test_invalid_no_description
    test_minimum_description
    test_maximum_project_code
    test_project_code_too_long
    test_project_code_too_short
    test_all_valid_types
    test_base_branch_feature
    test_base_branch_hotfix
    test_batch_validation
    
    echo ""
    echo "========================================"
    echo "Test Results"
    echo "========================================"
    echo "Tests run: $TESTS_RUN"
    echo -e "Passed: ${GREEN}$TESTS_PASSED${NC}"
    echo -e "Failed: ${RED}$TESTS_FAILED${NC}"
    
    if [[ $TESTS_FAILED -eq 0 ]]; then
        echo -e "${GREEN}All tests passed!${NC}"
        exit 0
    else
        echo -e "${RED}Some tests failed${NC}"
        exit 1
    fi
}

main "$@"
