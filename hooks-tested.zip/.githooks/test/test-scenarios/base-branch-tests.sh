#!/usr/bin/env bash
# Base Branch Enforcement Test Scenarios
# Tests that branches are created from correct base branches

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# Counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test result tracker
pass_test() {
    ((TESTS_PASSED++))
    ((TESTS_RUN++))
    echo -e "${GREEN}✓${NC} $1"
}

fail_test() {
    ((TESTS_FAILED++))
    ((TESTS_RUN++))
    echo -e "${RED}✗${NC} $1"
    echo "  Error: $2"
}

# Setup: Save current branch and create test repo state
setup_test_environment() {
    echo -e "${CYAN}Setting up test environment...${NC}"
    
    # Save current branch
    ORIGINAL_BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "main")
    
    # Ensure main and develop branches exist
    if ! git show-ref --verify --quiet refs/heads/main; then
        git checkout -b main 2>/dev/null || git checkout main 2>/dev/null || true
    fi
    
    if ! git show-ref --verify --quiet refs/heads/develop; then
        git checkout main 2>/dev/null || true
        git checkout -b develop 2>/dev/null || git checkout develop 2>/dev/null || true
    fi
    
    echo -e "${GREEN}✓${NC} Test environment ready"
    echo ""
}

# Cleanup: Return to original branch and remove test branches
cleanup_test_environment() {
    echo ""
    echo -e "${CYAN}Cleaning up test branches...${NC}"
    
    # Return to original branch
    git checkout "$ORIGINAL_BRANCH" 2>/dev/null || git checkout main 2>/dev/null || true
    
    # Delete test branches (suppress errors)
    git branch -D test-feat-valid 2>/dev/null || true
    git branch -D test-feat-invalid 2>/dev/null || true
    git branch -D test-hotfix-valid 2>/dev/null || true
    git branch -D test-hotfix-invalid 2>/dev/null || true
    git branch -D test-bugfix-valid 2>/dev/null || true
    git branch -D test-custom-mapping 2>/dev/null || true
    
    echo -e "${GREEN}✓${NC} Cleanup complete"
}

# Test: feat branch from develop (should pass)
test_feat_from_develop() {
    git checkout develop >/dev/null 2>&1 || return 1
    
    # Create branch (capture output)
    if git checkout -b test-feat-valid 2>&1 | grep -q "Base branch validated"; then
        pass_test "feat branch from develop (valid)"
        git checkout develop >/dev/null 2>&1 || true
        git branch -D test-feat-valid >/dev/null 2>&1 || true
        return 0
    else
        fail_test "feat branch from develop (valid)" "Should have been allowed"
        return 1
    fi
}

# Test: feat branch from main (should fail)
test_feat_from_main() {
    git checkout main >/dev/null 2>&1 || return 1
    
    # Try to create branch (should fail)
    if git checkout -b test-feat-invalid 2>&1 | grep -q "Invalid Base Branch"; then
        pass_test "feat branch from main (should fail)"
        git checkout main >/dev/null 2>&1 || true
        git branch -D test-feat-invalid >/dev/null 2>&1 || true
        return 0
    else
        fail_test "feat branch from main (should fail)" "Should have been blocked"
        git checkout main >/dev/null 2>&1 || true
        git branch -D test-feat-invalid >/dev/null 2>&1 || true
        return 1
    fi
}

# Test: hotfix branch from main (should pass)
test_hotfix_from_main() {
    git checkout main >/dev/null 2>&1 || return 1
    
    # Create branch (capture output)
    if git checkout -b test-hotfix-valid 2>&1 | grep -q "Base branch validated"; then
        pass_test "hotfix branch from main (valid)"
        git checkout main >/dev/null 2>&1 || true
        git branch -D test-hotfix-valid >/dev/null 2>&1 || true
        return 0
    else
        fail_test "hotfix branch from main (valid)" "Should have been allowed"
        return 1
    fi
}

# Test: hotfix branch from develop (should fail)
test_hotfix_from_develop() {
    git checkout develop >/dev/null 2>&1 || return 1
    
    # Try to create branch (should fail)
    if git checkout -b test-hotfix-invalid 2>&1 | grep -q "Invalid Base Branch"; then
        pass_test "hotfix branch from develop (should fail)"
        git checkout develop >/dev/null 2>&1 || true
        git branch -D test-hotfix-invalid >/dev/null 2>&1 || true
        return 0
    else
        fail_test "hotfix branch from develop (should fail)" "Should have been blocked"
        git checkout develop >/dev/null 2>&1 || true
        git branch -D test-hotfix-invalid >/dev/null 2>&1 || true
        return 1
    fi
}

# Test: bugfix branch from develop (should pass)
test_bugfix_from_develop() {
    git checkout develop >/dev/null 2>&1 || return 1
    
    # Create branch
    if git checkout -b test-bugfix-valid 2>&1 | grep -q "Base branch validated"; then
        pass_test "bugfix branch from develop (valid)"
        git checkout develop >/dev/null 2>&1 || true
        git branch -D test-bugfix-valid >/dev/null 2>&1 || true
        return 0
    else
        fail_test "bugfix branch from develop (valid)" "Should have been allowed"
        return 1
    fi
}

# Test: Configuration reading
test_config_reading() {
    local hotfix_base=$(git config hooks.branchMapping.hotfix 2>/dev/null || echo "")
    local feat_base=$(git config hooks.branchMapping.feat 2>/dev/null || echo "")
    
    if [[ "$hotfix_base" == "origin/main" ]] && [[ "$feat_base" == "origin/develop" ]]; then
        pass_test "Configuration reading (hotfix=$hotfix_base, feat=$feat_base)"
        return 0
    else
        fail_test "Configuration reading" "Expected hotfix=origin/main, feat=origin/develop"
        return 1
    fi
}

# Test: All branch types have mappings
test_all_mappings_configured() {
    local types=("hotfix" "feat" "feature" "bugfix" "fix" "techdebt" "perf" "refactor" "revert" "style" "test" "build" "chore" "ci" "docs")
    local missing=0
    local missing_types=""
    
    for type in "${types[@]}"; do
        if [ -z "$(git config hooks.branchMapping.$type 2>/dev/null)" ]; then
            ((missing++))
            missing_types="$missing_types $type"
        fi
    done
    
    if [ $missing -eq 0 ]; then
        pass_test "All 15 branch type mappings configured"
        return 0
    else
        fail_test "All branch type mappings configured" "Missing: $missing_types"
        return 1
    fi
}

# Test: Custom mapping override
test_custom_mapping() {
    # Save original
    local original=$(git config hooks.branchMapping.feat 2>/dev/null || echo "")
    
    # Set custom mapping
    git config hooks.branchMapping.feat "origin/staging"
    
    local new_value=$(git config hooks.branchMapping.feat 2>/dev/null || echo "")
    
    # Restore original
    if [ -n "$original" ]; then
        git config hooks.branchMapping.feat "$original"
    fi
    
    if [[ "$new_value" == "origin/staging" ]]; then
        pass_test "Custom mapping override (feat → staging)"
        return 0
    else
        fail_test "Custom mapping override" "Failed to set custom value"
        return 1
    fi
}

# Test: Long-lived branches have no base requirement
test_long_lived_no_base() {
    git checkout develop >/dev/null 2>&1 || return 1
    git checkout main >/dev/null 2>&1 || return 1
    
    # Main and develop shouldn't trigger base validation
    if git checkout develop 2>&1 | grep -q "Invalid Base Branch"; then
        fail_test "Long-lived branches have no base requirement" "develop triggered validation"
        return 1
    else
        pass_test "Long-lived branches have no base requirement"
        return 0
    fi
}

# Test: Normalized branch name matching
test_normalized_matching() {
    # Test that both 'develop' and 'origin/develop' are accepted
    git checkout develop >/dev/null 2>&1 || return 1
    
    if git checkout -b test-normalized-feat 2>&1 | grep -q "Base branch validated"; then
        pass_test "Normalized branch name matching (develop = origin/develop)"
        git checkout develop >/dev/null 2>&1 || true
        git branch -D test-normalized-feat >/dev/null 2>&1 || true
        return 0
    else
        fail_test "Normalized branch name matching" "develop should match origin/develop"
        return 1
    fi
}

# Test: Error message contains recovery steps
test_error_message_quality() {
    git checkout main >/dev/null 2>&1 || return 1
    
    local output=$(git checkout -b test-error-quality 2>&1)
    
    if echo "$output" | grep -q "Delete this branch" && \
       echo "$output" | grep -q "Switch to correct base" && \
       echo "$output" | grep -q "Create branch again"; then
        pass_test "Error message contains recovery steps"
    else
        fail_test "Error message quality" "Missing recovery instructions"
    fi
    
    git checkout main >/dev/null 2>&1 || true
    git branch -D test-error-quality >/dev/null 2>&1 || true
}

# Test: Confirmation message on success
test_success_message() {
    git checkout develop >/dev/null 2>&1 || return 1
    
    if git checkout -b test-success-msg 2>&1 | grep -q "Base branch validated"; then
        pass_test "Success message displayed on valid branch creation"
        git checkout develop >/dev/null 2>&1 || true
        git branch -D test-success-msg >/dev/null 2>&1 || true
        return 0
    else
        fail_test "Success message" "No confirmation shown"
        return 1
    fi
}

# Test: post-checkout hook exists and is executable
test_hook_exists() {
    if [ -f ".githooks/post-checkout" ] && [ -x ".githooks/post-checkout" ]; then
        pass_test "post-checkout hook exists and is executable"
        return 0
    else
        fail_test "post-checkout hook" "File missing or not executable"
        return 1
    fi
}

# Test: common.sh has required functions
test_common_functions() {
    if grep -q "get_base_branch" .githooks/lib/common.sh && \
       grep -q "validate_branch_base" .githooks/lib/common.sh; then
        pass_test "common.sh has required functions"
        return 0
    else
        fail_test "common.sh functions" "Missing required functions"
        return 1
    fi
}

# Run all tests
main() {
    echo "========================================"
    echo "Base Branch Enforcement Test Suite"
    echo "========================================"
    echo ""
    
    # Setup
    setup_test_environment
    
    echo "${CYAN}${BOLD}Running Base Branch Enforcement Tests...${NC}"
    echo ""
    
    # Infrastructure tests
    echo -e "${YELLOW}Infrastructure Tests:${NC}"
    test_hook_exists
    test_common_functions
    echo ""
    
    # Configuration tests
    echo -e "${YELLOW}Configuration Tests:${NC}"
    test_config_reading
    test_all_mappings_configured
    test_custom_mapping
    echo ""
    
    # Validation tests
    echo -e "${YELLOW}Branch Validation Tests:${NC}"
    test_feat_from_develop
    test_feat_from_main
    test_hotfix_from_main
    test_hotfix_from_develop
    test_bugfix_from_develop
    test_long_lived_no_base
    test_normalized_matching
    echo ""
    
    # Message quality tests
    echo -e "${YELLOW}Message Quality Tests:${NC}"
    test_error_message_quality
    test_success_message
    echo ""
    
    # Cleanup
    cleanup_test_environment
    
    echo ""
    echo "========================================"
    echo "Test Results"
    echo "========================================"
    echo "Tests run: $TESTS_RUN"
    echo -e "Passed: ${GREEN}$TESTS_PASSED${NC}"
    echo -e "Failed: ${RED}$TESTS_FAILED${NC}"
    
    if [[ $TESTS_FAILED -eq 0 ]]; then
        echo -e "${GREEN}${BOLD}All tests passed!${NC}"
        exit 0
    else
        echo -e "${RED}${BOLD}Some tests failed${NC}"
        exit 1
    fi
}

# Run with error handling
trap cleanup_test_environment EXIT
main "$@"
