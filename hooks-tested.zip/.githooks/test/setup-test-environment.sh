#!/bin/bash

#######################################
# Test Environment Setup Script
# 
# This script prepares the repository for test execution by:
# 1. Checking if tests are enabled
# 2. Saving current state (branch, stash, configs)
# 3. Cleaning previous test artifacts
# 4. Switching to test base branch
# 5. Verifying hooks are installed
# 6. Creating log directory structure
#######################################

set -euo pipefail

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source configuration
source "${SCRIPT_DIR}/test-config.sh"

# Note: Color codes are defined in test-config.sh

# State file to track saved state
readonly STATE_FILE="${SCRIPT_DIR}/.test-state"

#######################################
# Logging Functions
#######################################

log() {
    local level="$1"
    shift
    local message="$*"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    
    # Log to file if enabled
    if is_logging_enabled; then
        local log_file="${LOG_FILE:-}"
        if [[ -n "$log_file" ]]; then
            echo "[$timestamp] [$level] $message" >> "$log_file"
        fi
    fi
    
    # Log to console based on verbosity
    local verbosity=$(get_log_verbosity)
    case "$level" in
        ERROR)
            echo -e "${RED}✗${NC} $message" >&2
            ;;
        WARN)
            echo -e "${YELLOW}⚠${NC} $message"
            ;;
        INFO)
            if [[ "$verbosity" != "quiet" ]]; then
                echo -e "${BLUE}ℹ${NC} $message"
            fi
            ;;
        SUCCESS)
            if [[ "$verbosity" != "quiet" ]]; then
                echo -e "${GREEN}✓${NC} $message"
            fi
            ;;
        DEBUG)
            if [[ "$verbosity" == "debug" || "$verbosity" == "verbose" ]]; then
                echo -e "${CYAN}[DEBUG]${NC} $message"
            fi
            ;;
    esac
}

#######################################
# Check Prerequisites
#######################################

check_prerequisites() {
    log "INFO" "Checking prerequisites..."
    
    # Check if we're in a git repository
    if ! git rev-parse --git-dir > /dev/null 2>&1; then
        log "ERROR" "Not in a git repository"
        return 1
    fi
    
    # Check if tests are enabled
    if ! is_test_enabled; then
        log "ERROR" "Tests are not enabled"
        log "INFO" "Enable tests with: git config hooks.tests.enabled true"
        log "INFO" "Or set environment variable: export GITHOOKS_TESTS_ENABLED=true"
        return 1
    fi
    
    # Check if hooks are installed
    local hooks_path=$(git config core.hooksPath 2>/dev/null || echo "")
    if [[ -z "$hooks_path" || ! -d "$hooks_path" ]]; then
        log "WARN" "Git hooks not configured"
        log "INFO" "Run: bash .githooks/install-hooks.sh"
    fi
    
    log "SUCCESS" "Prerequisites check passed"
    return 0
}

#######################################
# Save Current State
#######################################

save_state() {
    log "INFO" "Saving current repository state..."
    
    # Create state file
    : > "$STATE_FILE"
    
    # Save current branch
    local current_branch=$(git symbolic-ref --short HEAD 2>/dev/null || git rev-parse --short HEAD 2>/dev/null || echo "")
    echo "CURRENT_BRANCH=$current_branch" >> "$STATE_FILE"
    log "DEBUG" "Current branch: $current_branch"
    
    # Check for uncommitted changes
    if ! git diff-index --quiet HEAD -- 2>/dev/null; then
        log "INFO" "Uncommitted changes detected, stashing..."
        git stash push -u -m "Githooks test environment backup - $(date)" > /dev/null 2>&1 || true
        echo "STASH_CREATED=true" >> "$STATE_FILE"
        log "SUCCESS" "Changes stashed"
    else
        echo "STASH_CREATED=false" >> "$STATE_FILE"
        log "DEBUG" "No uncommitted changes"
    fi
    
    # Save important git configs that might be modified
    local max_commits=$(git config --get hooks.maxCommitsToPush 2>/dev/null || echo "")
    local auto_add=$(git config --get hooks.autoAddAfterFix 2>/dev/null || echo "")
    local parallel=$(git config --get hooks.parallelExecution 2>/dev/null || echo "")
    
    echo "CONFIG_MAX_COMMITS=$max_commits" >> "$STATE_FILE"
    echo "CONFIG_AUTO_ADD=$auto_add" >> "$STATE_FILE"
    echo "CONFIG_PARALLEL=$parallel" >> "$STATE_FILE"
    
    log "SUCCESS" "State saved to: $STATE_FILE"
    return 0
}

#######################################
# Clean Previous Test Artifacts
#######################################

clean_test_artifacts() {
    log "INFO" "Cleaning previous test artifacts..."
    
    local cleaned=0
    
    # Get list of test branches (common patterns)
    local test_branch_patterns=(
        "test-*"
        "feat-*-test"
        "feature-*-test"
        "bugfix-*-test"
        "hotfix-*-test"
        "temp-test-*"
    )
    
    for pattern in "${test_branch_patterns[@]}"; do
        while IFS= read -r branch; do
            if [[ -n "$branch" ]]; then
                log "DEBUG" "Deleting test branch: $branch"
                git branch -D "$branch" 2>/dev/null || true
                ((cleaned++))
            fi
        done < <(git branch --list "$pattern" 2>/dev/null | sed 's/^[* ]*//' || true)
    done
    
    # Clean test tags
    while IFS= read -r tag; do
        if [[ -n "$tag" ]]; then
            log "DEBUG" "Deleting test tag: $tag"
            git tag -d "$tag" 2>/dev/null || true
            ((cleaned++))
        fi
    done < <(git tag -l "test-*" 2>/dev/null || true)
    
    # Clean temporary test files
    local test_files=(
        "${SCRIPT_DIR}/.test-temp-*"
        "${SCRIPT_DIR}/test-scenarios/.test-*"
        "${SCRIPT_DIR}/test-fixtures/.test-*"
    )
    
    for pattern in "${test_files[@]}"; do
        # Use find to safely handle glob patterns
        if compgen -G "$pattern" > /dev/null 2>&1; then
            for file in $pattern; do
                if [[ -f "$file" ]]; then
                    log "DEBUG" "Removing test file: $file"
                    rm -f "$file" 2>/dev/null || true
                    ((cleaned++))
                fi
            done
        fi
    done
    
    if [[ $cleaned -gt 0 ]]; then
        log "SUCCESS" "Cleaned $cleaned test artifacts"
    else
        log "DEBUG" "No test artifacts to clean"
    fi
    
    return 0
}

#######################################
# Switch to Test Base Branch
#######################################

switch_to_base_branch() {
    log "INFO" "Switching to test base branch..."
    
    local base_branch=$(get_test_base_branch)
    local current_branch=$(git symbolic-ref --short HEAD 2>/dev/null || echo "")
    
    log "DEBUG" "Target base branch: $base_branch"
    log "DEBUG" "Current branch: $current_branch"
    
    # If already on the base branch, just ensure it's clean
    if [[ "$current_branch" == "$base_branch" ]]; then
        log "INFO" "Already on base branch: $base_branch"
        return 0
    fi
    
    # Check if base branch exists
    if ! git rev-parse --verify "$base_branch" > /dev/null 2>&1; then
        log "ERROR" "Base branch '$base_branch' does not exist"
        log "INFO" "Available branches:"
        git branch -a | sed 's/^/  /'
        return 1
    fi
    
    # Switch to base branch
    if git checkout "$base_branch" > /dev/null 2>&1; then
        log "SUCCESS" "Switched to base branch: $base_branch"
    else
        log "ERROR" "Failed to switch to base branch: $base_branch"
        return 1
    fi
    
    # Pull latest changes if it's a remote-tracking branch
    if git config "branch.$base_branch.remote" > /dev/null 2>&1; then
        log "INFO" "Pulling latest changes from remote..."
        if git pull --ff-only > /dev/null 2>&1; then
            log "SUCCESS" "Updated base branch from remote"
        else
            log "WARN" "Could not pull from remote (continuing with local state)"
        fi
    fi
    
    return 0
}

#######################################
# Verify Hooks Installation
#######################################

verify_hooks() {
    log "INFO" "Verifying hooks installation..."
    
    local hooks_path=$(git config core.hooksPath 2>/dev/null || echo "")
    
    if [[ -z "$hooks_path" ]]; then
        log "WARN" "Hooks path not configured"
        return 0
    fi
    
    local hooks=(
        "pre-commit"
        "commit-msg"
        "prepare-commit-msg"
        "post-checkout"
        "pre-push"
        "post-rewrite"
        "pre-rebase"
        "applypatch-msg"
    )
    
    local missing=0
    for hook in "${hooks[@]}"; do
        local hook_file="${hooks_path}/${hook}"
        if [[ ! -f "$hook_file" ]]; then
            log "WARN" "Hook not found: $hook"
            ((missing++))
        else
            log "DEBUG" "Hook found: $hook"
        fi
    done
    
    if [[ $missing -eq 0 ]]; then
        log "SUCCESS" "All hooks are installed"
    else
        log "WARN" "$missing hooks are missing"
    fi
    
    return 0
}

#######################################
# Setup Logging Infrastructure
#######################################

setup_logging() {
    log "INFO" "Setting up logging infrastructure..."
    
    local log_dir=$(get_log_dir)
    
    # Create log directory if it doesn't exist
    if [[ ! -d "$log_dir" ]]; then
        mkdir -p "$log_dir"
        log "SUCCESS" "Created log directory: $log_dir"
    else
        log "DEBUG" "Log directory exists: $log_dir"
    fi
    
    # Create gitignore for logs
    local gitignore_file="${log_dir}/.gitignore"
    if [[ ! -f "$gitignore_file" ]]; then
        cat > "$gitignore_file" << 'EOF'
# Ignore all log files
*.log

# Keep directory structure
!.gitignore
EOF
        log "SUCCESS" "Created .gitignore for logs"
    fi
    
    # Archive old logs (keep last 10 runs)
    local log_count=$(find "$log_dir" -name "test-run-*.log" 2>/dev/null | wc -l)
    if [[ $log_count -gt 10 ]]; then
        log "INFO" "Archiving old logs (keeping last 10)..."
        find "$log_dir" -name "test-run-*.log" -type f | sort | head -n -10 | xargs rm -f 2>/dev/null || true
        log "SUCCESS" "Archived old logs"
    fi
    
    # Set the current log file for this test run
    export LOG_FILE=$(get_current_log_file)
    echo "LOG_FILE=$LOG_FILE" >> "$STATE_FILE"
    log "SUCCESS" "Log file: $LOG_FILE"
    
    # Write log header
    cat > "$LOG_FILE" << EOF
================================================================================
Git Hooks Test Execution Log
Started: $(date +"%Y-%m-%d %H:%M:%S")
================================================================================

Configuration:
  Base Branch:       $(get_test_base_branch)
  Log Verbosity:     $(get_log_verbosity)
  Auto Cleanup:      $(is_cleanup_enabled && echo "enabled" || echo "disabled")
  Test Categories:   $(get_test_categories)
  Preserve State:    $(is_state_preservation_enabled && echo "enabled" || echo "disabled")

Repository State:
  Current Branch:    $(git symbolic-ref --short HEAD 2>/dev/null || echo "detached")
  Latest Commit:     $(git log -1 --oneline 2>/dev/null || echo "none")
  Hooks Path:        $(git config core.hooksPath 2>/dev/null || echo "not configured")

================================================================================

EOF
    
    return 0
}

#######################################
# Main Setup Process
#######################################

main() {
    echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BOLD}${CYAN}         Git Hooks Test Environment Setup${NC}"
    echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo ""
    
    # Step 1: Check prerequisites
    if ! check_prerequisites; then
        log "ERROR" "Prerequisites check failed"
        return 1
    fi
    
    # Step 2: Setup logging first (so we can log everything)
    if ! setup_logging; then
        log "ERROR" "Failed to setup logging"
        return 1
    fi
    
    # Step 3: Save current state (if state preservation is enabled)
    if is_state_preservation_enabled; then
        if ! save_state; then
            log "ERROR" "Failed to save state"
            return 1
        fi
    else
        log "INFO" "State preservation disabled"
    fi
    
    # Step 4: Clean test artifacts
    if ! clean_test_artifacts; then
        log "WARN" "Failed to clean some test artifacts (continuing)"
    fi
    
    # Step 5: Switch to base branch
    if ! switch_to_base_branch; then
        log "ERROR" "Failed to switch to base branch"
        return 1
    fi
    
    # Step 6: Verify hooks
    if ! verify_hooks; then
        log "WARN" "Hook verification had warnings (continuing)"
    fi
    
    echo ""
    echo -e "${BOLD}${GREEN}✓ Test environment setup complete${NC}"
    echo ""
    echo -e "${BOLD}State File:${NC}       $STATE_FILE"
    echo -e "${BOLD}Log File:${NC}         $LOG_FILE"
    echo -e "${BOLD}Base Branch:${NC}      $(get_test_base_branch)"
    echo -e "${BOLD}Test Categories:${NC}  $(get_test_categories)"
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    
    return 0
}

# Run main if executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
