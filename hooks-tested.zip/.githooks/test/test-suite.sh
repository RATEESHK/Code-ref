#!/usr/bin/env bash

# ============================================================================
# Git Hooks Test Suite
# Purpose: Comprehensive testing of all hook functionality
# ============================================================================

set -euo pipefail

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source test configuration
source "${SCRIPT_DIR}/test-config.sh"

# Note: Colors (RED, GREEN, YELLOW, BLUE, CYAN, BOLD, NC) are defined in test-config.sh

# Test counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0
TESTS_SKIPPED=0

# Test results
declare -a FAILED_TESTS=()
declare -a SKIPPED_TESTS=()

# Configuration
VERBOSE=${VERBOSE:-0}
STRICT_MODE=${STRICT_MODE:-0}
TEST_CATEGORY=${TEST_CATEGORY:-"all"}

# Test repository path
TEST_REPO_DIR="$(mktemp -d)"
ORIGINAL_DIR="$(pwd)"

# Cleanup on exit
cleanup() {
    cd "$ORIGINAL_DIR"
    if [ -d "$TEST_REPO_DIR" ]; then
        rm -rf "$TEST_REPO_DIR"
    fi
}
trap cleanup EXIT

# Print test header
print_header() {
    echo -e "${CYAN}${BOLD}"
    echo "╔════════════════════════════════════════════════════════════════════╗"
    echo "║                  Git Hooks Test Suite v2.0                        ║"
    echo "╚════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}\n"
}

# Log function
log_test() {
    local level="$1"
    local message="$2"
    
    case $level in
        "INFO")
            [ $VERBOSE -eq 1 ] && echo -e "${BLUE}[INFO]${NC} $message"
            ;;
        "PASS")
            echo -e "${GREEN}[✓]${NC} $message"
            ;;
        "FAIL")
            echo -e "${RED}[✗]${NC} $message"
            ;;
        "SKIP")
            echo -e "${YELLOW}[⊘]${NC} $message"
            ;;
        "WARN")
            echo -e "${YELLOW}[!]${NC} $message"
            ;;
    esac
}

# Setup test repository
setup_test_repo() {
    log_test "INFO" "Setting up test repository..."
    
    cd "$TEST_REPO_DIR"
    git init --initial-branch=main >/dev/null 2>&1
    git config user.name "Test User"
    git config user.email "test@example.com"
    
    # Copy hooks to test repo
    cp -r "$ORIGINAL_DIR/.githooks" "$TEST_REPO_DIR/"
    
    # Install hooks
    bash .githooks/install-hooks.sh >/dev/null 2>&1
    
    # Create initial commit
    echo "Initial commit" > README.md
    git add README.md
    git commit -m "Initial commit" >/dev/null 2>&1
    
    log_test "INFO" "Test repository ready at: $TEST_REPO_DIR"
}

# Run a single test
run_test() {
    local test_name="$1"
    local test_function="$2"
    
    ((TESTS_RUN++))
    
    echo -e "\n${CYAN}${BOLD}Test $TESTS_RUN:${NC} $test_name"
    
    # Run test in subshell to isolate failures
    if ( $test_function ); then
        ((TESTS_PASSED++))
        log_test "PASS" "$test_name"
        return 0
    else
        ((TESTS_FAILED++))
        FAILED_TESTS+=("$test_name")
        log_test "FAIL" "$test_name"
        return 1
    fi
}

# Skip a test
skip_test() {
    local test_name="$1"
    local reason="$2"
    
    ((TESTS_RUN++))
    ((TESTS_SKIPPED++))
    SKIPPED_TESTS+=("$test_name: $reason")
    log_test "SKIP" "$test_name - $reason"
}

# ============================================================================
# TEST CASES - Branch Naming
# ============================================================================

test_branch_invalid() {
    log_test "INFO" "Testing invalid branch name..."
    
    # Try to create invalid branch
    git checkout -b my-invalid-branch 2>/dev/null || true
    
    # Try to push (should fail)
    echo "test" > test.txt
    git add test.txt
    git commit -m "feat: TEST-123 Test" 2>/dev/null || true
    
    # This should fail at push
    if git push origin my-invalid-branch 2>&1 | grep -q "Invalid branch name"; then
        return 0
    fi
    
    # Alternative: check if branch name validation works
    if ! [[ "my-invalid-branch" =~ ^(main|develop|release($|/.*))$ ]] && \
       ! [[ "my-invalid-branch" =~ ^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$ ]]; then
        return 0
    fi
    
    return 1
}

test_branch_valid() {
    log_test "INFO" "Testing valid branch name..."
    
    git checkout -b feat-ABC-123-valid-branch 2>/dev/null
    
    # Check if branch was created
    if git rev-parse --verify feat-ABC-123-valid-branch >/dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

test_branch_protected() {
    log_test "INFO" "Testing protected branch..."
    
    # Protected branches should be allowed to create
    git checkout -b release/v1.0.0 2>/dev/null
    
    if git rev-parse --verify release/v1.0.0 >/dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

# ============================================================================
# TEST CASES - Commit Messages
# ============================================================================

test_commit_invalid() {
    log_test "INFO" "Testing invalid commit message..."
    
    git checkout -b feat-TEST-001-commit-test 2>/dev/null || true
    echo "test" > test1.txt
    git add test1.txt
    
    # Try invalid commit (should fail)
    if git commit -m "bad message" 2>&1 | grep -q "Invalid commit message"; then
        return 0
    fi
    
    return 1
}

test_commit_valid() {
    log_test "INFO" "Testing valid commit message..."
    
    git checkout -b feat-TEST-002-valid-commit 2>/dev/null || true
    echo "test" > test2.txt
    git add test2.txt
    
    # Valid commit should succeed
    if git commit -m "feat: TEST-002 Valid commit message" >/dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

test_commit_autofill() {
    log_test "INFO" "Testing commit message auto-fill..."
    
    git checkout -b feat-XYZ-789-autofill 2>/dev/null || true
    echo "test" > test3.txt
    git add test3.txt
    
    # Create commit (should auto-fill JIRA ID)
    git commit -m "test message" 2>/dev/null || true
    
    # Check if JIRA ID was added
    last_msg=$(git log -1 --pretty=%B)
    if echo "$last_msg" | grep -q "XYZ-789"; then
        return 0
    fi
    
    return 1
}

test_commit_merge() {
    log_test "INFO" "Testing merge commit message..."
    
    echo "test" > test4.txt
    git add test4.txt
    
    # Merge messages should be allowed
    if git commit -m "Merge branch 'feature' into main" >/dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

test_commit_revert() {
    log_test "INFO" "Testing revert commit message..."
    
    echo "test" > test5.txt
    git add test5.txt
    
    # Revert messages should be allowed
    if git commit -m "Revert: ABC-123 Previous commit" >/dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

# ============================================================================
# TEST CASES - Security
# ============================================================================

test_aws_key_detection() {
    log_test "INFO" "Testing AWS key detection..."
    
    git checkout -b feat-TEST-003-security 2>/dev/null || true
    
    # Create file with AWS key
    echo "AWS_ACCESS_KEY=AKIAIOSFODNN7EXAMPLE" > config.txt
    git add config.txt
    
    # Commit should be blocked
    if git commit -m "feat: TEST-003 Add config" 2>&1 | grep -q "secret"; then
        return 0
    fi
    
    return 1
}

test_env_file_block() {
    log_test "INFO" "Testing .env file blocking..."
    
    git checkout -b feat-TEST-004-env-block 2>/dev/null || true
    
    # Create .env file
    echo "SECRET_KEY=test" > .env
    git add .env
    
    # Commit should be blocked
    if git commit -m "feat: TEST-004 Add env" 2>&1 | grep -q "Sensitive file"; then
        return 0
    fi
    
    return 1
}

test_private_key_block() {
    log_test "INFO" "Testing private key blocking..."
    
    git checkout -b feat-TEST-005-key-block 2>/dev/null || true
    
    # Create private key file
    cat > private.pem << 'EOF'
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA...
-----END RSA PRIVATE KEY-----
EOF
    git add private.pem
    
    # Commit should be blocked
    if git commit -m "feat: TEST-005 Add key" 2>&1 | grep -q "Sensitive file"; then
        return 0
    fi
    
    return 1
}

test_password_detection() {
    log_test "INFO" "Testing password detection..."
    
    git checkout -b feat-TEST-006-password 2>/dev/null || true
    
    # Create file with password
    echo 'password="mySecretPass123"' > config.js
    git add config.js
    
    # Commit should be blocked
    if git commit -m "feat: TEST-006 Add config" 2>&1 | grep -q "secret"; then
        return 0
    fi
    
    return 1
}

# ============================================================================
# TEST CASES - Protected Branches
# ============================================================================

test_direct_commit_block() {
    log_test "INFO" "Testing direct commit to protected branch..."
    
    git checkout main 2>/dev/null || true
    echo "test" > protected-test.txt
    git add protected-test.txt
    
    # Direct commit to main should be blocked
    if git commit -m "feat: TEST-007 Direct commit" 2>&1 | grep -q "protected branch"; then
        return 0
    fi
    
    return 1
}

test_direct_commit_bypass() {
    log_test "INFO" "Testing protected branch bypass..."
    
    git checkout main 2>/dev/null || true
    echo "test" > bypass-test.txt
    git add bypass-test.txt
    
    # With bypass flag, should succeed
    if ALLOW_DIRECT_PROTECTED=1 git commit -m "feat: TEST-008 Bypass commit" >/dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

# ============================================================================
# TEST CASES - Custom Commands
# ============================================================================

test_command_priority() {
    log_test "INFO" "Testing command priority ordering..."
    
    # Create commands.conf with priority
    cat > .githooks/commands.conf << 'EOF'
pre-commit:2:false:5:echo "Second":Second command
pre-commit:1:false:5:echo "First":First command
EOF
    
    git checkout -b feat-TEST-009-priority 2>/dev/null || true
    echo "test" > priority-test.txt
    git add priority-test.txt
    
    # Commit and check order
    output=$(git commit -m "feat: TEST-009 Priority test" 2>&1)
    
    # Check if "First" appears before "Second"
    if echo "$output" | grep -B1 "Second" | grep -q "First"; then
        return 0
    fi
    
    return 1
}

test_command_mandatory() {
    log_test "INFO" "Testing mandatory command failure..."
    
    # Create failing mandatory command
    cat > .githooks/commands.conf << 'EOF'
pre-commit:1:true:5:exit 1:Failing command
EOF
    
    git checkout -b feat-TEST-010-mandatory 2>/dev/null || true
    echo "test" > mandatory-test.txt
    git add mandatory-test.txt
    
    # Commit should fail
    if ! git commit -m "feat: TEST-010 Mandatory test" 2>&1 | grep -q "failed"; then
        return 1
    fi
    
    return 0
}

test_command_optional() {
    log_test "INFO" "Testing optional command failure..."
    
    # Create failing optional command
    cat > .githooks/commands.conf << 'EOF'
pre-commit:1:false:5:exit 1:Optional failing command
EOF
    
    git checkout -b feat-TEST-011-optional 2>/dev/null || true
    echo "test" > optional-test.txt
    git add optional-test.txt
    
    # Commit should succeed despite failure
    if git commit -m "feat: TEST-011 Optional test" 2>&1 | grep -q "optional"; then
        return 0
    fi
    
    return 1
}

# ============================================================================
# TEST CASES - Logging
# ============================================================================

test_complete_log() {
    log_test "INFO" "Testing complete log exists..."
    
    if [ -f ".git/hook-logs/complete.log" ]; then
        return 0
    fi
    
    return 1
}

test_individual_logs() {
    log_test "INFO" "Testing individual hook logs..."
    
    # Check if at least one hook log exists
    if ls .git/hook-logs/*.log >/dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

test_log_rotation() {
    log_test "INFO" "Testing log rotation..."
    
    # Create large log file
    for i in {1..10000}; do
        echo "Log entry $i" >> .git/hook-logs/test.log
    done
    
    # Run cleanup
    bash .githooks/clean.sh
    
    # Check if rotated
    if [ -f ".git/hook-logs/test.1.log" ] || [ $(wc -c < .git/hook-logs/test.log) -lt 100000 ]; then
        return 0
    fi
    
    return 1
}

# ============================================================================
# TEST CASES - Base Branch Enforcement
# ============================================================================

test_base_branch_feat_from_develop() {
    log_test "INFO" "Testing feat branch from develop..."
    
    # Create develop if it doesn't exist
    git checkout main >/dev/null 2>&1 || true
    git checkout -b develop >/dev/null 2>&1 || git checkout develop >/dev/null 2>&1
    
    # Try to create feat branch from develop (should pass)
    if git checkout -b test-feat-from-develop >/dev/null 2>&1; then
        git checkout develop >/dev/null 2>&1 || true
        git branch -D test-feat-from-develop >/dev/null 2>&1 || true
        return 0
    fi
    
    return 1
}

test_base_branch_feat_from_main() {
    log_test "INFO" "Testing feat branch from main (should fail)..."
    
    git checkout main >/dev/null 2>&1 || true
    
    # Try to create feat branch from main (should fail with exit code 1)
    if ! git checkout -b test-feat-from-main >/dev/null 2>&1; then
        git checkout main >/dev/null 2>&1 || true
        git branch -D test-feat-from-main >/dev/null 2>&1 || true
        return 0
    fi
    
    # If it didn't fail, that's incorrect
    git checkout main >/dev/null 2>&1 || true
    git branch -D test-feat-from-main >/dev/null 2>&1 || true
    return 1
}

test_base_branch_hotfix_from_main() {
    log_test "INFO" "Testing hotfix branch from main..."
    
    git checkout main >/dev/null 2>&1 || true
    
    # Try to create hotfix branch from main (should pass)
    if git checkout -b test-hotfix-from-main >/dev/null 2>&1; then
        git checkout main >/dev/null 2>&1 || true
        git branch -D test-hotfix-from-main >/dev/null 2>&1 || true
        return 0
    fi
    
    return 1
}

test_base_branch_hotfix_from_develop() {
    log_test "INFO" "Testing hotfix branch from develop (should fail)..."
    
    git checkout develop >/dev/null 2>&1 || git checkout -b develop >/dev/null 2>&1
    
    # Try to create hotfix branch from develop (should fail)
    if ! git checkout -b test-hotfix-from-develop >/dev/null 2>&1; then
        git checkout develop >/dev/null 2>&1 || true
        git branch -D test-hotfix-from-develop >/dev/null 2>&1 || true
        return 0
    fi
    
    # If it didn't fail, that's incorrect
    git checkout develop >/dev/null 2>&1 || true
    git branch -D test-hotfix-from-develop >/dev/null 2>&1 || true
    return 1
}

test_base_branch_config_exists() {
    log_test "INFO" "Testing branch mapping configuration..."
    
    # Check if mappings are configured
    local feat_base=$(git config hooks.branchMapping.feat 2>/dev/null || echo "")
    local hotfix_base=$(git config hooks.branchMapping.hotfix 2>/dev/null || echo "")
    
    if [[ "$feat_base" == "origin/develop" ]] && [[ "$hotfix_base" == "origin/main" ]]; then
        return 0
    fi
    
    return 1
}

# ============================================================================
# TEST CASES - Bypass
# ============================================================================

test_bypass_all() {
    log_test "INFO" "Testing BYPASS_HOOKS=1..."
    
    git checkout -b invalid-bypass-branch 2>/dev/null || true
    echo "test" > bypass-all.txt
    git add bypass-all.txt
    
    # Should succeed with bypass
    if BYPASS_HOOKS=1 git commit -m "bad message" >/dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

test_bypass_logging() {
    log_test "INFO" "Testing bypass logging..."
    
    BYPASS_HOOKS=1 git commit --allow-empty -m "bypass test" >/dev/null 2>&1
    
    # Check if bypass was logged
    if grep -q "bypassed" .git/hook-logs/complete.log; then
        return 0
    fi
    
    return 1
}

# ============================================================================
# Main Test Execution
# ============================================================================

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --all)
                TEST_CATEGORY="all"
                shift
                ;;
            --verbose|-v)
                VERBOSE=1
                shift
                ;;
            --strict)
                STRICT_MODE=1
                shift
                ;;
            --category)
                TEST_CATEGORY="$2"
                shift 2
                ;;
            --help|-h)
                show_help
                exit 0
                ;;
            *)
                echo "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
}

show_help() {
    echo "Git Hooks Test Suite"
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  --all              Run all tests (default)"
    echo "  --category <name>  Run specific category:"
    echo "                       branch, commit, security, protected,"
    echo "                       commands, logging, base-branch, bypass,"
    echo "                       hook-execution"
    echo "  --verbose, -v      Verbose output"
    echo "  --strict           Fail on first error"
    echo "  --help, -h         Show this help"
}

run_all_tests() {
    local category="${1:-all}"
    
    # Branch naming tests
    if [ "$category" = "all" ] || [ "$category" = "branch" ]; then
        echo -e "\n${BOLD}${CYAN}═══ Branch Naming Tests ═══${NC}"
        run_test "Invalid branch name should be rejected" test_branch_invalid
        run_test "Valid branch name should be accepted" test_branch_valid
        run_test "Protected branch should be allowed" test_branch_protected
    fi
    
    # Commit message tests
    if [ "$category" = "all" ] || [ "$category" = "commit" ]; then
        echo -e "\n${BOLD}${CYAN}═══ Commit Message Tests ═══${NC}"
        run_test "Invalid commit message should fail" test_commit_invalid
        run_test "Valid commit message should pass" test_commit_valid
        run_test "JIRA ID should auto-fill from branch" test_commit_autofill
        run_test "Merge commit message should be allowed" test_commit_merge
        run_test "Revert commit message should be allowed" test_commit_revert
    fi
    
    # Security tests
    if [ "$category" = "all" ] || [ "$category" = "security" ]; then
        echo -e "\n${BOLD}${CYAN}═══ Security Tests ═══${NC}"
        run_test "AWS key should be detected" test_aws_key_detection
        run_test ".env file should be blocked" test_env_file_block
        run_test "Private key file should be blocked" test_private_key_block
        run_test "Password in code should be detected" test_password_detection
    fi
    
    # Protected branch tests
    if [ "$category" = "all" ] || [ "$category" = "protected" ]; then
        echo -e "\n${BOLD}${CYAN}═══ Protected Branch Tests ═══${NC}"
        run_test "Direct commit to main should be blocked" test_direct_commit_block
        run_test "Bypass flag should allow protected commit" test_direct_commit_bypass
    fi
    
    # Custom command tests
    if [ "$category" = "all" ] || [ "$category" = "commands" ]; then
        echo -e "\n${BOLD}${CYAN}═══ Custom Command Tests ═══${NC}"
        run_test "Commands should execute in priority order" test_command_priority
        run_test "Mandatory command failure should block" test_command_mandatory
        run_test "Optional command failure should warn" test_command_optional
    fi
    
    # Logging tests
    if [ "$category" = "all" ] || [ "$category" = "logging" ]; then
        echo -e "\n${BOLD}${CYAN}═══ Logging Tests ═══${NC}"
        run_test "Complete log should exist" test_complete_log
        run_test "Individual hook logs should exist" test_individual_logs
        run_test "Log rotation should work" test_log_rotation
    fi
    
    # Base branch enforcement tests
    if [ "$category" = "all" ] || [ "$category" = "base-branch" ]; then
        echo -e "\n${BOLD}${CYAN}═══ Base Branch Enforcement Tests ═══${NC}"
        run_test "feat branch from develop should pass" test_base_branch_feat_from_develop
        run_test "feat branch from main should fail" test_base_branch_feat_from_main
        run_test "hotfix branch from main should pass" test_base_branch_hotfix_from_main
        run_test "hotfix branch from develop should fail" test_base_branch_hotfix_from_develop
        run_test "Branch mapping configuration should exist" test_base_branch_config_exists
    fi
    
    # Bypass tests
    if [ "$category" = "all" ] || [ "$category" = "bypass" ]; then
        echo -e "\n${BOLD}${CYAN}═══ Bypass Tests ═══${NC}"
        run_test "BYPASS_HOOKS=1 should skip all hooks" test_bypass_all
        run_test "Bypass should be logged" test_bypass_logging
    fi
    
    # Hook execution tests (NEW)
    if [ "$category" = "all" ] || [ "$category" = "hook-execution" ]; then
        echo -e "\n${BOLD}${CYAN}═══ Hook Execution Tests ═══${NC}"
        
        if [ -f "$ORIGINAL_DIR/.githooks/test/test-scenarios/hook-execution-tests.sh" ]; then
            log_test "INFO" "Running comprehensive hook execution tests..."
            if bash "$ORIGINAL_DIR/.githooks/test/test-scenarios/hook-execution-tests.sh"; then
                log_test "PASS" "All hook execution tests passed"
                ((TESTS_PASSED++))
            else
                log_test "FAIL" "Some hook execution tests failed"
                FAILED_TESTS+=("Hook execution tests")
                ((TESTS_FAILED++))
            fi
            ((TESTS_RUN++))
        else
            log_test "SKIP" "Hook execution test file not found"
            SKIPPED_TESTS+=("Hook execution tests")
            ((TESTS_SKIPPED++))
        fi
    fi
}

print_summary() {
    echo -e "\n${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}"
    echo -e "${BOLD}Test Summary${NC}"
    echo -e "${CYAN}${BOLD}═══════════════════════════════════════════════════════════════════${NC}\n"
    
    echo -e "Total Tests:    ${BOLD}$TESTS_RUN${NC}"
    echo -e "Passed:         ${GREEN}${BOLD}$TESTS_PASSED${NC}"
    echo -e "Failed:         ${RED}${BOLD}$TESTS_FAILED${NC}"
    echo -e "Skipped:        ${YELLOW}${BOLD}$TESTS_SKIPPED${NC}"
    
    if [ $TESTS_FAILED -gt 0 ]; then
        echo -e "\n${RED}${BOLD}Failed Tests:${NC}"
        for test in "${FAILED_TESTS[@]}"; do
            echo -e "  ${RED}✗${NC} $test"
        done
    fi
    
    if [ $TESTS_SKIPPED -gt 0 ]; then
        echo -e "\n${YELLOW}${BOLD}Skipped Tests:${NC}"
        for test in "${SKIPPED_TESTS[@]}"; do
            echo -e "  ${YELLOW}⊘${NC} $test"
        done
    fi
    
    echo ""
    
    if [ $TESTS_FAILED -eq 0 ]; then
        echo -e "${GREEN}${BOLD}✓ All tests passed!${NC}\n"
        return 0
    else
        echo -e "${RED}${BOLD}✗ Some tests failed!${NC}\n"
        return 1
    fi
}

# Main execution
main() {
    parse_args "$@"
    
    print_header
    
    echo -e "${BLUE}Setting up test environment...${NC}"
    setup_test_repo
    
    echo -e "${BLUE}Running tests (category: $TEST_CATEGORY)...${NC}"
    run_all_tests "$TEST_CATEGORY"
    
    print_summary
    exit $?
}

# Run if executed directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    main "$@"
fi
