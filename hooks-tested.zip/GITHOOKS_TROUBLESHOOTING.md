# Git Hooks - Troubleshooting Guide

## 📚 Table of Contents

1. [Quick Diagnosis](#quick-diagnosis)
2. [Installation Issues](#installation-issues)
3. [Hook Execution Issues](#hook-execution-issues)
4. [Configuration Issues](#configuration-issues)
5. [Error Messages](#error-messages)
6. [Performance Issues](#performance-issues)
7. [Platform-Specific Issues](#platform-specific-issues)
8. [Recovery Procedures](#recovery-procedures)
9. [Debugging Guide](#debugging-guide)
10. [FAQ](#faq)

---

## Quick Diagnosis

### Are Hooks Running?

```bash
# Test if hooks are installed
git config core.hooksPath

# Expected output: .githooks
# If empty or different, hooks are not installed

# Test a hook manually
bash .githooks/pre-commit

# Check recent hook execution
ls -lt .githooks/logs/hooks/

# Check for bypass
echo $BYPASS_HOOKS
# If "1", all hooks are bypassed
```

### Quick Health Check

```bash
# 1. Check installation
[ -d .githooks ] && echo "✓ Hooks directory exists" || echo "✗ Hooks directory missing"

# 2. Check Git config
git config core.hooksPath | grep -q ".githooks" && echo "✓ Hooks path configured" || echo "✗ Hooks path not configured"

# 3. Check executable permissions
[ -x .githooks/pre-commit ] && echo "✓ Hooks executable" || echo "✗ Hooks not executable"

# 4. Check logs directory
[ -d .githooks/logs ] && echo "✓ Logs directory exists" || echo "✗ Logs directory missing"

# 5. Test hook execution
echo "test" > .test-file && git add .test-file
if git commit -m "test: TEST-001 Test commit" --no-verify; then
    echo "✓ Hooks can be bypassed"
    git reset --soft HEAD~1
    git reset HEAD .test-file
    rm .test-file
else
    echo "✗ Issue with hook bypass"
fi
```

### Common Issues Checklist

Before diving deep, check these common issues:

- [ ] Did you run the installation script? (`bash .githooks/install-hooks.sh`)
- [ ] Are you in the repository root directory?
- [ ] Do hooks have execute permissions? (`chmod +x .githooks/*.sh`)
- [ ] Is `core.hooksPath` set correctly? (`git config core.hooksPath`)
- [ ] Are you using Git 2.13 or newer? (`git --version`)
- [ ] Is Bash 4.0 or newer available? (`bash --version`)
- [ ] Is `BYPASS_HOOKS` set? (`echo $BYPASS_HOOKS`)
- [ ] Check log files for errors (`cat .githooks/logs/hooks/*.log`)

---

## Installation Issues

### Issue: Installation Script Fails

**Symptoms:**
```
Error: Installation failed
Please check the installation log
```

**Diagnosis:**
```bash
# Check Git version
git --version
# Requires: git version 2.13.0 or newer

# Check Bash version
bash --version
# Requires: GNU bash, version 4.0 or newer

# Check permissions
ls -la .githooks/install-hooks.sh
# Should be executable (rwxr-xr-x)

# Check if already installed
git config core.hooksPath
```

**Solutions:**

1. **Upgrade Git:**
   ```bash
   # Ubuntu/Debian
   sudo apt-get update
   sudo apt-get install git
   
   # macOS
   brew upgrade git
   
   # Windows
   # Download latest Git for Windows
   ```

2. **Upgrade Bash:**
   ```bash
   # macOS (uses old Bash 3.2)
   brew install bash
   
   # Ubuntu/Debian
   sudo apt-get install bash
   ```

3. **Fix Permissions:**
   ```bash
   chmod +x .githooks/install-hooks.sh
   chmod +x .githooks/uninstall-hooks.sh
   chmod +x .githooks/*.sh
   chmod +x .githooks/lib/*.sh
   ```

4. **Run from Repository Root:**
   ```bash
   cd "$(git rev-parse --show-toplevel)"
   bash .githooks/install-hooks.sh
   ```

### Issue: Partial Installation (Rollback)

**Symptoms:**
```
Installation failed at step 5
Rolling back installation...
```

**What Happened:**
Installation encountered an error and automatically rolled back to prevent partial configuration.

**Diagnosis:**
```bash
# Check rollback file
cat .githooks/.rollback

# Check what was configured
git config --get-regexp hooks.
```

**Solution:**
1. Read the error message to identify the failed step
2. Fix the underlying issue
3. Retry installation:
   ```bash
   bash .githooks/install-hooks.sh
   ```

### Issue: .gitignore Conflicts

**Symptoms:**
```
Warning: .githooks/logs/ already exists in .gitignore
```

**Diagnosis:**
```bash
# Check .gitignore
cat .gitignore | grep -A2 -B2 ".githooks"

# Check for conflicts
cat .gitignore | grep ".githooks/logs"
```

**Solution:**

The installer handles this automatically, but if you have conflicts:

```bash
# Manual fix: Edit .gitignore
nano .gitignore

# Ensure these patterns exist (installer adds them):
# Git Hooks
.githooks/logs/**
!.githooks/logs/.gitignore
```

### Issue: Hooks Already Installed

**Symptoms:**
```
Hooks are already installed
```

**Diagnosis:**
```bash
# Check current hooks path
git config core.hooksPath

# Check installation timestamp
ls -la .githooks/.installed
```

**Solution:**

This is **intentional** - installation is idempotent (safe to run multiple times).

If you need to **reinstall**:
```bash
# Uninstall first
bash .githooks/uninstall-hooks.sh

# Then install
bash .githooks/install-hooks.sh
```

If you need to **update configuration only**:
```bash
# Just run installation again (safe)
bash .githooks/install-hooks.sh
```

### Issue: Permission Denied

**Symptoms:**
```bash
bash: .githooks/install-hooks.sh: Permission denied
```

**Solution:**
```bash
# Make executable
chmod +x .githooks/install-hooks.sh

# Run installation
bash .githooks/install-hooks.sh

# Fix all hook permissions
find .githooks -name "*.sh" -exec chmod +x {} \;
```

---

## Hook Execution Issues

### Issue: Hooks Not Running

**Symptoms:**
- Commits succeed that should be blocked
- No log files created
- No hook output

**Diagnosis:**
```bash
# 1. Check hooks path
git config core.hooksPath
# Should output: .githooks

# 2. Check if bypassed
echo $BYPASS_HOOKS
# Should be empty or 0

# 3. Test manual execution
bash .githooks/pre-commit
# Should run and show output

# 4. Check Git version
git --version
# Needs 2.13+ for core.hooksPath support
```

**Solutions:**

1. **Hooks Path Not Set:**
   ```bash
   git config core.hooksPath .githooks
   ```

2. **Bypassed Globally:**
   ```bash
   unset BYPASS_HOOKS
   
   # Check shell config files
   cat ~/.bashrc | grep BYPASS_HOOKS
   cat ~/.zshrc | grep BYPASS_HOOKS
   
   # Remove if found
   ```

3. **Wrong Directory:**
   ```bash
   # Run from repository root
   cd "$(git rev-parse --show-toplevel)"
   git commit ...
   ```

4. **Old Git Version:**
   ```bash
   # Upgrade Git to 2.13+
   git --version
   ```

### Issue: Hook Fails with "Command Not Found"

**Symptoms:**
```
.githooks/pre-commit: line 42: some_function: command not found
```

**Diagnosis:**
```bash
# Check if libraries are sourced
grep "source.*common.sh" .githooks/pre-commit

# Check library paths
ls -la .githooks/lib/

# Test library directly
bash .githooks/lib/common.sh
```

**Solution:**

1. **Fix Library Path:**
   ```bash
   # Libraries should be in .githooks/lib/
   ls .githooks/lib/common.sh
   ls .githooks/lib/runner.sh
   
   # If missing, reinstall
   bash .githooks/install-hooks.sh
   ```

2. **Check Sourcing:**
   ```bash
   # Each hook should have:
   HOOK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
   source "$HOOK_DIR/lib/common.sh"
   ```

### Issue: "No Such File or Directory"

**Symptoms:**
```
bash: .githooks/pre-commit: No such file or directory
```

**Diagnosis:**
```bash
# Check file exists
ls -la .githooks/pre-commit

# Check hooks path
git config core.hooksPath

# Check current directory
pwd
git rev-parse --show-toplevel
```

**Solution:**

1. **Hooks Not Installed:**
   ```bash
   bash .githooks/install-hooks.sh
   ```

2. **Wrong Working Directory:**
   ```bash
   # Git should be run from repo root or subdirectories
   # If hooks path is relative (.githooks), it must resolve
   
   # Use absolute path
   REPO_ROOT="$(git rev-parse --show-toplevel)"
   git config core.hooksPath "$REPO_ROOT/.githooks"
   ```

3. **Missing Files:**
   ```bash
   # Check what's missing
   ls .githooks/
   
   # Reinstall if files are missing
   bash .githooks/install-hooks.sh
   ```

### Issue: Hook Runs But Does Nothing

**Symptoms:**
- Hook executes
- No errors shown
- No validation occurs

**Diagnosis:**
```bash
# Run hook manually with verbose output
bash -x .githooks/pre-commit

# Check bypass configuration
git config hooks.bypass

# Check for early exits
grep "exit 0" .githooks/pre-commit

# Check bypass environment
env | grep -i bypass
```

**Solution:**

1. **Bypass Mechanism Active:**
   ```bash
   # Check all bypass methods
   echo $BYPASS_HOOKS                    # Should be empty
   echo $ALLOW_DIRECT_PROTECTED          # Should be empty
   git config hooks.bypass               # Should be false or empty
   
   # Disable bypass
   unset BYPASS_HOOKS
   unset ALLOW_DIRECT_PROTECTED
   git config --unset hooks.bypass
   ```

2. **Hook Logic Issue:**
   ```bash
   # Check hook actually has validation logic
   cat .githooks/pre-commit | grep -A5 "validate"
   
   # Reinstall if corrupted
   bash .githooks/uninstall-hooks.sh
   bash .githooks/install-hooks.sh
   ```

### Issue: Wrong Hook Triggered

**Symptoms:**
- Expected `pre-commit` but `prepare-commit-msg` runs
- Hook runs at unexpected times

**Understanding:**
Git hooks run at specific times:
- **pre-commit**: Before commit message editor opens
- **prepare-commit-msg**: Before commit message editor, prepares message
- **commit-msg**: After message written, before commit created
- **post-commit**: After commit created
- **pre-push**: Before push sent to remote
- **post-checkout**: After checkout completes
- **post-rewrite**: After commit rewritten (rebase, amend)
- **pre-rebase**: Before rebase starts
- **applypatch-msg**: When applying patches

**Solution:**

This is **normal Git behavior**. Multiple hooks can run for one operation:
```bash
# A commit triggers (in order):
# 1. pre-commit (validate staged changes)
# 2. prepare-commit-msg (auto-fill message)
# 3. commit-msg (validate message)
# 4. post-commit (logging/notifications)

# An amend triggers:
# 1. pre-commit
# 2. prepare-commit-msg
# 3. commit-msg
# 4. post-rewrite (rewrite notification)
```

---

## Configuration Issues

### Issue: Branch Mapping Not Working

**Symptoms:**
```
Error: Branch 'feat-ABC-123-test' should be created from 'develop'
Currently on 'main'
```

**Diagnosis:**
```bash
# Check branch mappings
git config --get-regexp hooks.baseBranch

# Expected for 'feat':
# hooks.baseBranch.feat develop

# Check current branch
git branch --show-current

# Check branch format
echo "feat-ABC-123-test" | grep -E "^(feat|bugfix|hotfix)-"
```

**Solution:**

1. **Mapping Not Configured:**
   ```bash
   # Set base branch for feat
   git config hooks.baseBranch.feat develop
   
   # Or reinstall (sets all mappings)
   bash .githooks/install-hooks.sh
   ```

2. **Wrong Current Branch:**
   ```bash
   # You're on 'main' but need to be on 'develop'
   git checkout develop
   git checkout -b feat-ABC-123-new-feature
   ```

3. **Override for Special Case:**
   ```bash
   # If you really need feat from main
   git config hooks.baseBranch.feat main
   
   # Or bypass this check once
   BYPASS_HOOKS=1 git checkout -b feat-ABC-123-exception
   ```

### Issue: Custom Commands Not Running

**Symptoms:**
- Created `.githooks/commands.conf`
- Commands don't execute

**Diagnosis:**
```bash
# Check file exists
ls -la .githooks/commands.conf

# Check format
cat .githooks/commands.conf

# Check logs
cat .githooks/logs/hooks/pre-commit.log | grep -i command

# Test command manually
bash -c "your-command"
```

**Solution:**

1. **File Format Issues:**
   ```bash
   # Correct format:
   cat > .githooks/commands.conf << 'EOF'
   # hook-name|priority|mandatory|timeout|description|command
   pre-commit|100|yes|30|Run linter|npm run lint
   pre-commit|90|no|60|Run tests|npm test
   EOF
   
   # Common mistakes:
   # - Missing pipes (|)
   # - Wrong hook name
   # - Invalid mandatory value (must be 'yes' or 'no')
   # - Invalid timeout (must be number)
   ```

2. **Command Not in PATH:**
   ```bash
   # Use full paths
   pre-commit|100|yes|30|Lint|/usr/local/bin/eslint .
   
   # Or ensure PATH is set
   pre-commit|100|yes|30|Lint|bash -c 'export PATH="/usr/local/bin:$PATH" && eslint .'
   ```

3. **Commands Not Loaded:**
   ```bash
   # Verify runner.sh is sourced
   grep "source.*runner.sh" .githooks/pre-commit
   
   # Verify run_hook_commands is called
   grep "run_hook_commands" .githooks/pre-commit
   ```

### Issue: Auto-Fill Not Working

**Symptoms:**
- Branch: `feat-ABC-123-my-feature`
- Commit message not auto-filled with `ABC-123`

**Diagnosis:**
```bash
# Check if prepare-commit-msg is executable
ls -la .githooks/prepare-commit-msg

# Check if it's being called
# Commit with verbose
GIT_TRACE=1 git commit -m "test"

# Check branch format
git branch --show-current
```

**Solution:**

1. **Hook Not Executable:**
   ```bash
   chmod +x .githooks/prepare-commit-msg
   ```

2. **Branch Format Wrong:**
   ```bash
   # Must be: <type>-<JIRA-ID>-<description>
   # Good: feat-ABC-123-my-feature
   # Bad: my-feature-ABC-123
   # Bad: ABC-123-my-feature
   
   # Create properly formatted branch
   git checkout -b feat-PROJ-456-proper-format
   ```

3. **Commit Template Set:**
   ```bash
   # If you have a commit template, it may override
   git config commit.template
   
   # Temporarily disable
   git config --unset commit.template
   ```

4. **Using -m Flag:**
   ```bash
   # Auto-fill works BEFORE editor opens
   # If using -m, message is already provided
   
   # For auto-fill, don't use -m:
   git commit
   # Editor opens with pre-filled JIRA ID
   ```

### Issue: Configuration Not Applied

**Symptoms:**
- Set configuration with `git config`
- Hook doesn't respect it

**Diagnosis:**
```bash
# Check if config is set
git config hooks.maxCommits
# Should show value

# Check where it's set
git config --show-origin hooks.maxCommits

# Check config scope
git config --local hooks.maxCommits    # Repository
git config --global hooks.maxCommits   # User
git config --system hooks.maxCommits   # System
```

**Solution:**

1. **Wrong Scope:**
   ```bash
   # Set in repository (recommended)
   git config --local hooks.maxCommits 10
   
   # Or global (all repos)
   git config --global hooks.maxCommits 10
   ```

2. **Typo in Config Key:**
   ```bash
   # Correct keys:
   hooks.maxCommits
   hooks.autoAddAfterFix
   hooks.baseBranch.<type>
   hooks.tests.enabled
   
   # Check spelling
   git config --get-regexp hooks.
   ```

3. **Hook Not Reading Config:**
   ```bash
   # Verify hook reads the config
   grep "git config hooks.maxCommits" .githooks/pre-push
   
   # Reinstall if missing
   bash .githooks/install-hooks.sh
   ```

---

## Error Messages

### Branch Validation Errors

**Error:**
```
❌ Error: Invalid branch name format
Expected: <type>-<JIRA-ID>-<description>
Examples: feat-ABC-123-add-feature, hotfix-CRIT-999-fix-bug
```

**Meaning:** Branch name doesn't follow the required format.

**Solution:**
```bash
# Check current branch
git branch --show-current

# Create properly formatted branch
git checkout -b feat-PROJ-123-descriptive-name

# Or rename current branch
git branch -m feat-PROJ-123-$(git branch --show-current)
```

**Error:**
```
❌ Error: Branch 'feat-ABC-123-test' should be created from 'develop'
Currently on 'main'
Please checkout 'develop' and create your branch from there
```

**Meaning:** Branch type requires specific base branch.

**Solution:**
```bash
# Option 1: Create from correct base
git checkout develop
git checkout -b feat-ABC-123-test

# Option 2: Bypass if intentional
BYPASS_HOOKS=1 git checkout -b feat-ABC-123-test
```

### Commit Message Errors

**Error:**
```
❌ Invalid commit message format
Expected format: <type>: <JIRA-ID> <description>
Example: feat: ABC-123 Add new feature
```

**Meaning:** Commit message doesn't follow format.

**Solution:**
```bash
# Amend commit with correct format
git commit --amend -m "feat: PROJ-123 Add user authentication"

# Valid types: feat, fix, chore, break, tests, refactor, docs, style, perf
```

**Error:**
```
❌ Invalid commit type: 'future'
Valid types: feat, fix, chore, break, tests, refactor, docs, style, perf
```

**Meaning:** Used invalid commit type.

**Solution:**
```bash
# Use valid type
git commit --amend -m "feat: PROJ-123 Your description"
```

### Security Errors

**Error:**
```
🚨 SECURITY ALERT: Possible secret detected in staged files!
File: config/prod.env
Pattern: AWS_SECRET_KEY=AKIAIOSFODNN7EXAMPLE
```

**Meaning:** Detected potential secret in staged files.

**Solution:**
```bash
# Option 1: Remove secret (RECOMMENDED)
# Edit file, remove secret, use environment variables
vim config/prod.env

# Restage
git add config/prod.env

# Option 2: Remove file from staging
git reset HEAD config/prod.env

# Option 3: Bypass if false positive (DANGEROUS)
BYPASS_HOOKS=1 git commit -m "..."

# Option 4: Add to .gitignore
echo "config/prod.env" >> .gitignore
git add .gitignore
```

**Error:**
```
🚨 SECURITY ALERT: Sensitive file detected!
File: certs/private-key.pem
Sensitive files should not be committed!
```

**Meaning:** Attempting to commit sensitive file.

**Solution:**
```bash
# Remove from staging
git reset HEAD certs/private-key.pem

# Add to .gitignore
echo "certs/*.pem" >> .gitignore
git add .gitignore

# Use git-crypt or secrets management instead
```

### Protected Branch Errors

**Error:**
```
❌ Error: Direct commits to 'main' are not allowed
Create a feature branch instead: git checkout -b feat-PROJ-123-description
```

**Meaning:** Attempting to commit directly to protected branch.

**Solution:**
```bash
# Option 1: Create feature branch (RECOMMENDED)
git checkout -b feat-PROJ-123-my-feature
# Your commit is still there, just on new branch

# Option 2: Allow if you're integrating (release manager)
ALLOW_DIRECT_PROTECTED=1 git commit -m "..."
```

### Push Errors

**Error:**
```
❌ Error: Unpushed commits: 15 (max: 10)
Please push your changes more frequently or increase hooks.maxCommits
```

**Meaning:** Too many local commits not pushed.

**Solution:**
```bash
# Option 1: Push commits
git push origin your-branch

# Option 2: Increase limit
git config hooks.maxCommits 20

# Option 3: Squash commits
git rebase -i HEAD~15
```

**Error:**
```
⚠️  Warning: Branch contains merge commits
Consider rebasing on base branch instead: git rebase origin/develop
```

**Meaning:** Feature branch has merge commits (suggests you merged develop into feature).

**Solution:**
```bash
# Rebase instead of merge
git rebase origin/develop

# If conflicts, resolve and continue
git rebase --continue

# Force push (you're rewriting history)
git push --force-with-lease
```

---

## Performance Issues

### Issue: Hooks Are Slow

**Symptoms:**
- Commits take a long time
- Push operations delayed
- Timeout errors

**Diagnosis:**
```bash
# Time hook execution
time bash .githooks/pre-commit

# Check what's running
bash -x .githooks/pre-commit 2>&1 | less

# Check for custom commands
cat .githooks/commands.conf

# Check file count
git diff --cached --name-only | wc -l
```

**Solutions:**

1. **Many Staged Files:**
   ```bash
   # Commit in smaller batches
   git add specific-files
   git commit
   
   # Or increase timeout
   # Edit commands.conf
   pre-commit|100|yes|120|Long task|...
   ```

2. **Slow Custom Commands:**
   ```bash
   # Profile commands
   time npm run lint
   time npm test
   
   # Optimize command
   # - Lint only staged files
   # - Run quick tests only in hook
   
   # Example: Lint only staged
   pre-commit|100|yes|30|Lint|eslint ${STAGED_FILES}
   ```

3. **Large Repository:**
   ```bash
   # Use git sparse-checkout
   git sparse-checkout set /your-working-area
   
   # Use shallow clone for CI
   git clone --depth 1 repo-url
   ```

4. **Security Scanning Large Files:**
   ```bash
   # Skip large files in hooks
   # Edit lib/common.sh scan_for_secrets function
   
   # Skip files over 1MB
   if [ $(stat -f%z "$file" 2>/dev/null || stat -c%s "$file" 2>/dev/null) -gt 1048576 ]; then
       continue
   fi
   ```

### Issue: Timeout Errors

**Symptoms:**
```
⏱  Timeout: Command exceeded 30 seconds
```

**Diagnosis:**
```bash
# Check command timeouts
cat .githooks/commands.conf | grep timeout

# Identify slow command
time bash -c "slow-command"
```

**Solution:**

1. **Increase Timeout:**
   ```bash
   # Edit .githooks/commands.conf
   # Change timeout (4th field)
   pre-commit|100|yes|120|Slow tests|npm test
   ```

2. **Make Command Faster:**
   ```bash
   # Run subset of tests
   pre-commit|100|yes|30|Quick tests|npm run test:unit
   
   # Parallelize
   pre-commit|100|yes|60|Tests|npm test --parallel
   ```

3. **Make Optional:**
   ```bash
   # Change mandatory to 'no'
   pre-commit|100|no|30|Slow check|npm run slow-check
   ```

---

## Platform-Specific Issues

### Windows (Git Bash)

**Issue: Line Endings**
```bash
# Error: $'\r': command not found
```

**Solution:**
```bash
# Fix line endings
git config core.autocrlf input

# Fix existing files
dos2unix .githooks/*.sh
dos2unix .githooks/lib/*.sh

# Or with Git
git add --renormalize .
```

**Issue: Path Issues**
```bash
# Windows paths don't work
```

**Solution:**
```bash
# Use Git Bash paths
# C:\Users\... becomes /c/Users/...

# Use pwd -W for Windows path
WINPATH=$(pwd -W)

# Convert path
cygpath -w "/c/Users/name/project"
```

**Issue: Slow Execution**
```bash
# Hooks very slow on Windows
```

**Solution:**
```bash
# Disable Windows Defender scanning for repo
# Add repository to exclusions

# Use WSL2 instead of Git Bash
# Much faster for Git operations
```

### macOS

**Issue: Old Bash Version**
```bash
# macOS includes Bash 3.2 (2007)
```

**Solution:**
```bash
# Install modern Bash
brew install bash

# Verify version
/usr/local/bin/bash --version
# GNU bash, version 5.x

# Update shebang in hooks
#!/usr/bin/env bash
# This uses first bash in PATH
```

**Issue: BSD vs GNU Tools**
```bash
# sed, grep behave differently
```

**Solution:**
```bash
# Install GNU tools
brew install coreutils grep gnu-sed

# Use explicitly
gsed instead of sed
ggrep instead of grep

# Or add to PATH
export PATH="/usr/local/opt/gnu-sed/libexec/gnubin:$PATH"
```

### Linux

**Issue: Permission Denied (SELinux)**
```bash
# SELinux prevents execution
```

**Solution:**
```bash
# Check SELinux status
getenforce

# Temporarily disable
sudo setenforce 0

# Or fix contexts
sudo restorecon -Rv .githooks/

# Or add policy
sudo semanage fcontext -a -t bin_t ".githooks/.*\.sh"
sudo restorecon -Rv .githooks/
```

---

## Recovery Procedures

### Complete Reset

**When:** Everything is broken, start fresh.

```bash
# Step 1: Uninstall hooks
bash .githooks/uninstall-hooks.sh

# Step 2: Clean artifacts
rm -rf .githooks/logs/*
rm -f .githooks/.installed
rm -f .githooks/.rollback

# Step 3: Clean Git configuration
git config --remove-section hooks 2>/dev/null || true

# Step 4: Clean environment
unset BYPASS_HOOKS
unset ALLOW_DIRECT_PROTECTED
unset GITHOOKS_TESTS_ENABLED

# Step 5: Reinstall
bash .githooks/install-hooks.sh

# Step 6: Verify
git config core.hooksPath
git config --get-regexp hooks.
```

### Fix Corrupted Installation

**When:** Hooks partially installed or corrupted.

```bash
# Check what's configured
git config --get-regexp hooks.
git config core.hooksPath

# Fix core hooks path
git config core.hooksPath .githooks

# Reinstall (idempotent, safe to run)
bash .githooks/install-hooks.sh

# Fix permissions
chmod +x .githooks/*.sh
chmod +x .githooks/lib/*.sh

# Test
bash .githooks/pre-commit
```

### Recover from Blocked Commit

**When:** Can't commit due to hook error, need to bypass.

```bash
# Option 1: Fix the issue (recommended)
# - Fix branch name
# - Fix commit message  
# - Remove secrets
# Then retry commit

# Option 2: Bypass this commit (use sparingly)
BYPASS_HOOKS=1 git commit -m "..."

# Option 3: Use --no-verify (skips commit hooks)
git commit --no-verify -m "..."

# Option 4: Temporarily disable hooks
git config core.hooksPath /dev/null
git commit -m "..."
git config core.hooksPath .githooks
```

### Recover from Bad Push

**When:** Pushed something that shouldn't have been pushed.

```bash
# If just pushed (not pulled by others)
git reset --hard HEAD~1
git push --force-with-lease

# If others have pulled
# Option 1: Revert
git revert HEAD
git push

# Option 2: Filter-branch (removes from history)
git filter-branch --force --index-filter \
  'git rm --cached --ignore-unmatch path/to/secret' \
  --prune-empty --tag-name-filter cat -- --all

# Push
git push origin --force --all
git push origin --force --tags

# Tell team to re-clone
```

### Manual Cleanup

**When:** Automated cleanup doesn't work.

```bash
# Remove all hook configurations
git config --remove-section hooks 2>/dev/null

# Remove hooks path
git config --unset core.hooksPath

# Remove test branches
git branch | grep -E "test-|feat-TEST-|bugfix-TEST-" | xargs git branch -D

# Clear logs
rm -rf .githooks/logs/*

# Clear state files
rm -f .githooks/.installed
rm -f .githooks/.rollback
rm -f .githooks/test/.test-state

# Remove from .gitignore
# Edit manually and remove .githooks section
```

---

## Debugging Guide

### Enable Verbose Logging

```bash
# Method 1: Environment variable
export GITHOOKS_LOG_LEVEL=debug
git commit ...

# Method 2: Git config
git config hooks.logLevel debug
git commit ...

# Method 3: Edit common.sh
# Change: LOG_LEVEL="info"
# To: LOG_LEVEL="debug"
```

### Trace Hook Execution

```bash
# Run with bash -x for full trace
bash -x .githooks/pre-commit

# Trace specific function
bash -x .githooks/lib/common.sh

# With Git trace
GIT_TRACE=1 git commit ...

# Trace only hook execution
GIT_TRACE=1 GIT_TRACE_PERFORMANCE=1 git commit ...
```

### Analyze Logs

```bash
# View complete log
cat .githooks/logs/complete.log

# View specific hook log
cat .githooks/logs/hooks/pre-commit.log

# View recent entries
tail -n 50 .githooks/logs/complete.log

# Search for errors
grep -i error .githooks/logs/complete.log
grep -i warning .githooks/logs/complete.log

# View by date
grep "2025-01-04" .githooks/logs/complete.log

# Follow log in real-time
tail -f .githooks/logs/complete.log
```

### Test Individual Components

```bash
# Test library functions
bash << 'EOF'
source .githooks/lib/common.sh
validate_branch_name "feat-ABC-123-test"
echo $?  # 0 = valid, 1 = invalid
EOF

# Test secret scanning
bash << 'EOF'
source .githooks/lib/common.sh
echo "AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG" > test-file
scan_for_secrets "test-file"
rm test-file
EOF

# Test base branch validation
bash << 'EOF'
source .githooks/lib/common.sh
validate_branch_base "feat" "develop"
echo $?  # 0 = valid, 1 = invalid
EOF
```

### Debug Custom Commands

```bash
# Test command parsing
bash << 'EOF'
source .githooks/lib/runner.sh
parse_commands_conf "pre-commit"
EOF

# Test command execution
bash << 'EOF'
source .githooks/lib/common.sh
source .githooks/lib/runner.sh
execute_command "100" "yes" "30" "Test" "echo Hello"
EOF

# Manual run with verbose
bash -x .githooks/lib/runner.sh
```

---

## FAQ

### Q: Can I disable specific hooks?

**A:** Yes, several methods:

```bash
# Method 1: Rename hook to disable
mv .githooks/pre-commit .githooks/pre-commit.disabled

# Method 2: Bypass via environment
BYPASS_HOOKS=1 git commit

# Method 3: Use --no-verify (for commit hooks)
git commit --no-verify

# Method 4: Unset hooks path temporarily
git config core.hooksPath /dev/null
# Do commits
git config core.hooksPath .githooks
```

### Q: How do I allow commits to main/develop?

**A:** Use the bypass mechanism:

```bash
# For one commit
ALLOW_DIRECT_PROTECTED=1 git commit -m "..."

# Set in environment
export ALLOW_DIRECT_PROTECTED=1
git commit -m "..."
unset ALLOW_DIRECT_PROTECTED

# Note: This is logged for audit
```

### Q: Can I customize branch name format?

**A:** Yes, edit validation in `lib/common.sh`:

```bash
# Find function:
validate_branch_name() {
    local branch_name="$1"
    
    # Modify this regex:
    if [[ ! "$branch_name" =~ ^[a-z]+-[A-Z]+-[0-9]+-[a-z0-9-]+$ ]]; then
        return 1
    fi
    return 0
}

# Example: Allow underscores
if [[ ! "$branch_name" =~ ^[a-z]+-[A-Z]+-[0-9]+-[a-z0-9_-]+$ ]]; then
```

### Q: How do I add more commit types?

**A:** Edit validation in `lib/common.sh`:

```bash
# Find:
VALID_TYPES="feat|fix|chore|break|tests|refactor|docs|style|perf"

# Add yours:
VALID_TYPES="feat|fix|chore|break|tests|refactor|docs|style|perf|build|ci"
```

### Q: How do I test hooks without committing?

**A:** Run hooks manually:

```bash
# Stage files first
git add .

# Run hook
bash .githooks/pre-commit

# Or with trace
bash -x .githooks/pre-commit

# Test specific hook
bash .githooks/commit-msg .git/COMMIT_EDITMSG

# Test with environment
BYPASS_HOOKS=1 bash .githooks/pre-commit
```

### Q: Can hooks run on CI/CD?

**A:** Yes:

```bash
# In CI/CD pipeline:
# 1. Install hooks
bash .githooks/install-hooks.sh

# 2. Enable tests
git config hooks.tests.enabled true

# 3. Run comprehensive tests
bash .githooks/test/run-comprehensive-tests.sh

# See GITHOOKS_TESTING.md for details
```

### Q: How do I share hooks with team?

**A:** Hooks are in Git:

```bash
# Hooks are committed in .githooks/
git add .githooks/
git commit -m "feat: PROJ-001 Add Git hooks framework"
git push

# Team members run:
git pull
bash .githooks/install-hooks.sh

# Document in README:
echo "## Setup" >> README.md
echo "bash .githooks/install-hooks.sh" >> README.md
```

### Q: What if I disagree with a hook's validation?

**A:** You have options:

```bash
# 1. Discuss with team (maybe validation is wrong)

# 2. Bypass once (use sparingly)
BYPASS_HOOKS=1 git commit

# 3. Modify hook if you have consensus
# Edit .githooks/hook-name
# Commit change
# Team gets update on next pull

# 4. Local modification (not recommended)
# Edit hook
# Don't commit change
# Warning: Will be overwritten on pull
```

### Q: Hooks slow down my workflow!

**A:** Optimize:

```bash
# 1. Review custom commands
cat .githooks/commands.conf
# Remove unnecessary checks
# Reduce scope (lint only staged files)

# 2. Increase timeouts
# Edit commands.conf, increase timeout field

# 3. Make checks optional
# Change 'yes' to 'no' in mandatory field

# 4. Run expensive checks in CI only
# Remove from hooks, add to CI pipeline

# 5. Use --no-verify for WIP commits
git commit --no-verify -m "wip: work in progress"
# Run hooks later with --amend
```

### Q: How do I update hooks?

**A:**

```bash
# Get latest changes
git pull origin main

# Reinstall (safe, idempotent)
bash .githooks/install-hooks.sh

# Verify
git config --get-regexp hooks.
```

---

**Last Updated:** 2025-01-04  
**Version:** 3.0

For more information:
- **Installation & Usage:** See GITHOOKS_README.md
- **Development Guide:** See GITHOOKS_CONTRIBUTING.md
- **Testing Guide:** See GITHOOKS_TESTING.md
