# Git Hooks - Complete Documentation

## 📚 Table of Contents

1. [Overview](#overview)
2. [Quick Start](#quick-start)
3. [Installation](#installation)
4. [Uninstallation](#uninstallation)
5. [Features](#features)
6. [Hook Details](#hook-details)
7. [Configuration](#configuration)
8. [Custom Commands](#custom-commands)
9. [Bypass Mechanisms](#bypass-mechanisms)
10. [Logging & Monitoring](#logging--monitoring)
11. [Related Documentation](#related-documentation)

---

## Overview

This Git Hooks framework provides enterprise-grade validation and automation for your Git workflow. It enforces:

- **Branch Naming Conventions** - Structured naming with JIRA integration
- **Base Branch Enforcement** - Ensures branches are created from correct bases
- **Commit Message Standards** - Conventional commits with JIRA ID tracking
- **Security Scanning** - Prevents secrets and sensitive files from being committed
- **History Curation** - Enforces clean, rebased history with commit limits
- **Custom Command Execution** - Extensible framework for project-specific checks

### Key Benefits

✅ **Consistent Code Review Process** - Standardized naming and messaging  
✅ **Security by Default** - Automated secret scanning before commits  
✅ **Clean Git History** - Enforced rebasing and squashing  
✅ **JIRA Integration** - Automatic linking of commits to issues  
✅ **Flexible & Extensible** - Custom commands and bypass options  
✅ **Comprehensive Logging** - Full audit trail of all hook executions  

---

## Quick Start

### Installation (3 Steps)

```bash
# 1. Navigate to repository root
cd /path/to/your/repo

# 2. Run installation script
bash .githooks/install-hooks.sh

# 3. Verify installation
git config core.hooksPath
# Should output: .githooks
```

### First Commit Test

```bash
# Create a feature branch
git checkout -b feat-ABC-123-test-hooks

# Make changes and commit
echo "test" > test.txt
git add test.txt
git commit -m "feat: ABC-123 Test commit"

# Push (validates branch name, commit count, etc.)
git push origin feat-ABC-123-test-hooks
```

---

## Installation

### Prerequisites

- Git 2.13+ (for `core.hooksPath` support)
- Bash 4.0+ (for script execution)
- Repository initialized with Git

### Automated Installation

Run the installation script:

```bash
bash .githooks/install-hooks.sh
```

#### What Installation Does

The installer performs these steps automatically:

1. **Validates Git Repository** - Ensures you're in a valid Git repo
2. **Manages .gitignore** - Adds/updates hook log patterns
3. **Configures Git Settings**:
   - Sets `core.hooksPath` to `.githooks`
   - Enables `rebase.autosquash` for interactive rebases
   - Enables `fetch.prune` for automatic remote cleanup
   - Sets `hooks.maxCommits` (default: 5)
   - Configures `hooks.autoAddAfterFix` (default: false)
4. **Configures Branch Mappings** - Sets up base branch rules:
   - `hotfix` → `origin/main`
   - `feat, feature, bugfix, fix, etc.` → `origin/develop`
5. **Makes Hooks Executable** - Sets execute permissions on all hook files
6. **Creates Log Infrastructure** - Sets up `.git/hook-logs/` directory
7. **Excludes Logs from Git** - Adds patterns to `.git/info/exclude`
8. **Sets Up Test Infrastructure** - Creates test directories and config
9. **Creates Command Files** - Generates `commands.conf` and `run-commands.sh`
10. **Creates Rollback Scripts** - Tracks changes for potential rollback

#### Interactive Prompts

During installation, you'll be asked:

1. **Create/Update .gitignore?** (if missing hook patterns)
   - Recommended: Yes
   - Adds patterns for hook logs and test artifacts

2. **Enable Tests?** (optional)
   - Recommended for development: Yes
   - Recommended for CI/CD: No (configure separately)
   - Tests can be enabled later

#### Installation Output

Successful installation shows:

```
╔════════════════════════════════════════════════════════════════════╗
║                 ✓ Installation Complete!                          ║
╚════════════════════════════════════════════════════════════════════╝

📋 Enforced Rules:
  1. Branch Naming: <type>-<JIRA>-<description>
  2. Base Branch: feat/bugfix → develop, hotfix → main
  3. Commit Messages: <type>: <JIRA-ID> <description>
  4. Security: Secret scanning, sensitive file blocking
  5. History: Max 5 commits, rebase-only, no merge commits

🔓 Bypass Options:
   BYPASS_HOOKS=1             Skip all hooks
   ALLOW_DIRECT_PROTECTED=1   Allow commit to protected branch

⚙️  Configuration:
   git config hooks.maxCommits <number>
   git config hooks.autoAddAfterFix true
   git config hooks.branchMapping.<type> <base>

📝 Log Locations:
   .git/hook-logs/complete.log     # All hook executions
   .git/hook-logs/<hook-name>.log  # Individual hook logs
   .githooks/logs/install-*.log    # Installation logs
   .githooks/test/logs/            # Test execution logs
```

### Installation Logs

All installation activities are logged to:
```
.githooks/logs/install-YYYYMMDD_HHMMSS.log
```

### Rollback on Failure

If installation fails, **automatic rollback** restores your previous state:

- Git configurations are reverted
- Created files/directories are removed
- Original .gitignore is restored (if modified)
- Rollback log saved to: `.githooks/logs/.rollback-*.sh`

### Manual Installation (Alternative)

If you prefer manual setup:

```bash
# 1. Set hooks path
git config core.hooksPath .githooks

# 2. Make hooks executable
chmod +x .githooks/*
chmod +x .githooks/lib/*
chmod +x .githooks/test/*.sh

# 3. Configure settings
git config hooks.maxCommits 5
git config hooks.autoAddAfterFix false
git config rebase.autosquash true
git config fetch.prune true

# 4. Set branch mappings
git config hooks.branchMapping.hotfix "origin/main"
git config hooks.branchMapping.feat "origin/develop"
git config hooks.branchMapping.feature "origin/develop"
git config hooks.branchMapping.bugfix "origin/develop"
git config hooks.branchMapping.fix "origin/develop"
git config hooks.branchMapping.techdebt "origin/develop"
git config hooks.branchMapping.perf "origin/develop"
git config hooks.branchMapping.refactor "origin/develop"
git config hooks.branchMapping.revert "origin/develop"
git config hooks.branchMapping.style "origin/develop"
git config hooks.branchMapping.test "origin/develop"
git config hooks.branchMapping.build "origin/develop"
git config hooks.branchMapping.chore "origin/develop"
git config hooks.branchMapping.ci "origin/develop"
git config hooks.branchMapping.docs "origin/develop"

# 5. Create log directories
mkdir -p .git/hook-logs
echo "hook-logs/" >> .git/info/exclude
```

### Post-Installation Verification

```bash
# Check hooks path
git config core.hooksPath
# Expected: .githooks

# Check hook executability
ls -la .githooks/pre-commit
# Expected: -rwxr-xr-x (executable)

# Check configurations
git config --get-regexp hooks
# Expected: Multiple hooks.* entries

# View installation log
cat .githooks/logs/install-*.log | tail -20

# Test with dry run
BYPASS_HOOKS=1 git commit --allow-empty -m "test: TEST-001 Dry run"
```

---

## Uninstallation

### Automated Uninstallation

```bash
bash .githooks/uninstall-hooks.sh
```

#### What Uninstallation Does

The uninstaller performs these cleanup steps:

1. **Archives Hook Logs** - Creates `.git/hook-logs-archive-*.tar.gz`
2. **Handles Test Infrastructure**:
   - Archives test logs if requested
   - Removes test state file
   - Cleans test artifacts
3. **Resets Git Settings**:
   - Unsets `core.hooksPath` (reverts to `.git/hooks`)
   - Removes hook configurations
   - Removes branch mappings (all 15 types)
   - Removes test configurations
4. **Reverts Optional Settings** (if requested):
   - `rebase.autosquash`
   - `fetch.prune`
5. **Cleans .git/info/exclude** - Removes `hook-logs/` entry
6. **Cleans .gitignore** - Removes Git Hooks section (if requested)
7. **Handles Generated Files** - Backs up and removes:
   - `.githooks/commands.conf`
   - `.githooks/run-commands.sh`
8. **Cleans Rollback Files** - Removes `.rollback-*.sh` scripts
9. **Cleans Backup Files** - Removes `*.backup-*` files (if requested)
10. **Archives Installation Logs** - Creates `.githooks/installation-logs-archive-*.tar.gz`

#### Interactive Prompts

During uninstallation, you'll be asked:

1. **Delete hook execution log directory?** (y/N)
   - Logs archived before deletion

2. **Remove test logs?** (y/N)
   - Only if tests are enabled

3. **Reset rebase.autosquash?** (y/N)
   - Reverts to default Git behavior

4. **Reset fetch.prune?** (y/N)
   - Reverts to default Git behavior

5. **Remove entry from .git/info/exclude?** (y/N)
   - Recommended: Yes

6. **Remove Git Hooks section from .gitignore?** (y/N)
   - Caution: Review before confirming

7. **Remove generated files?** (y/N)
   - Backs up before removal

8. **Remove all backup files?** (y/N)
   - Cleans up `*.backup-*` files

9. **Archive and remove installation logs?** (y/N)
   - Creates archive before removal

#### Uninstallation Output

```
✓ Uninstallation complete!

What was removed:
  ✓ Git hook configurations
  ✓ Branch base mappings (15 types)
  ✓ Test configurations (6 settings)
  ✓ Hook execution logs (archived)
  ✓ Test logs (archived)
  ✓ Installation logs (archived)
  ✓ Rollback files
  ✓ Backup files
  ✓ .git/info/exclude entry
  ✓ .gitignore patterns (if selected)

What was kept:
  • Hook scripts (.githooks/ directory)
  • Test infrastructure (.githooks/test/)
  • Documentation files
  • Archived logs (*-archive-*.tar.gz)

To completely remove hooks:
  rm -rf .githooks  (deletes all hook files)

To reinstall:
  bash .githooks/install-hooks.sh
```

### Manual Uninstallation

If you prefer manual cleanup:

```bash
# 1. Reset hooks path
git config --unset core.hooksPath

# 2. Remove configurations
git config --unset hooks.maxCommits
git config --unset hooks.autoAddAfterFix
git config --unset hooks.parallelExecution

# 3. Remove branch mappings
for type in hotfix feat feature bugfix fix techdebt perf refactor revert style test build chore ci docs; do
    git config --unset hooks.branchMapping.$type
done

# 4. Remove test configurations
for config in enabled baseBranch logVerbosity autoCleanup categories preserveState; do
    git config --unset hooks.tests.$config
done

# 5. Optional: Remove log directories
rm -rf .git/hook-logs
rm -rf .githooks/test/logs
rm -rf .githooks/logs

# 6. Optional: Remove the entire .githooks directory
rm -rf .githooks
```

### Verify Uninstallation

```bash
# Check hooks path (should show nothing or .git/hooks)
git config core.hooksPath

# Check for remaining configs
git config --get-regexp hooks
# Should output nothing

# Check for log directories
ls -la .git/hook-logs
# Should not exist

# Check archives
ls -la .git/hook-logs-archive-*.tar.gz
# May exist if you chose to archive
```

---

## Features

### 1. Branch Naming Enforcement

**Supported Branch Types:**

#### Long-Lived Branches
- `main` - Production-ready code
- `develop` - Integration branch for features
- `release/*` - Release preparation branches

#### Short-Lived Branches
Format: `<type>-<JIRA-ID>-<description>`

**Allowed Types:**
- `feat`, `feature` - New features
- `bugfix`, `fix` - Bug fixes
- `hotfix` - Critical production fixes
- `techdebt` - Technical debt reduction
- `perf` - Performance improvements
- `refactor` - Code refactoring
- `revert` - Reverts previous changes
- `style` - Code style changes
- `test` - Test additions/modifications
- `build` - Build system changes
- `chore` - Maintenance tasks
- `ci` - CI/CD configuration
- `docs` - Documentation updates

**Examples:**
```bash
✅ feat-ABC-123-add-user-authentication
✅ bugfix-DEF-456-fix-memory-leak
✅ hotfix-GHI-789-security-patch
❌ feature/add-login          # No JIRA ID
❌ feat_ABC_123_add_user     # Wrong separator
❌ Feat-ABC-123-add-user     # Wrong case
```

### 2. Base Branch Enforcement

Ensures branches are created from the correct base:

**Default Mappings:**
- `hotfix` → `origin/main`
- All others → `origin/develop`

**Validation occurs at:**
- Branch creation (post-checkout)
- Push time (pre-push)

**Custom Configuration:**
```bash
# Override default mappings
git config hooks.branchMapping.feat origin/staging
git config hooks.branchMapping.hotfix origin/production
```

### 3. Commit Message Standards

**Format:** `<type>: <JIRA-ID> <description>`

**Allowed Types:**
- `feat` - New feature
- `fix` - Bug fix
- `chore` - Maintenance
- `break` - Breaking change
- `tests` - Test updates

**Auto-Fill Feature:**
- JIRA ID automatically extracted from branch name
- Pre-fills commit message with `feat: <JIRA-ID> `

**Examples:**
```bash
✅ feat: ABC-123 Add OAuth2 login
✅ fix: DEF-456 Resolve memory leak
✅ chore: GHI-789 Update dependencies
❌ Added new feature              # No type
❌ feat: Add feature              # No JIRA ID
❌ feature: ABC-123 Add feature   # Wrong type
```

**Special Cases:**
- Merge commits automatically allowed
- Revert commits automatically allowed

### 4. Security Scanning

**Secret Detection Patterns:**
- AWS Access Keys: `AKIA[0-9A-Z]{16}`
- AWS Secret Keys: `AWS_SECRET_ACCESS_KEY`
- GitHub Tokens: `ghp_[a-zA-Z0-9]{36}`
- GitHub OAuth: `gho_[a-zA-Z0-9]{36}`
- Slack Tokens: `xox[baprs]-[0-9]{10,12}-[a-zA-Z0-9]{24}`
- Google API Keys: `AIza[0-9A-Za-z_-]{35}`
- Stripe Keys: `sk_(test_|live_)[0-9a-zA-Z]{24}`
- Private Keys: `BEGIN.*PRIVATE KEY`
- Passwords: `password\s*=\s*["\']?[^"\']+`
- Azure Connection Strings
- Generic API Keys and Tokens

**Sensitive File Blocking:**
- `.env`, `.env.*` - Environment files
- `*.pem`, `*.p12`, `*.pfx` - Certificates
- `id_rsa*`, `id_dsa*`, `id_ecdsa*`, `id_ed25519*` - SSH keys
- `*.key`, `*.cert`, `*.crt` - Key/certificate files
- `credentials`, `secrets.json`, `secrets.yml` - Credential files

### 5. Protected Branch Controls

**Protected Branches:**
- `main`
- `develop`
- `release/*`

**Restrictions:**
- Direct commits blocked by default
- Bypass available: `ALLOW_DIRECT_PROTECTED=1`
- Merge commits to protected branches blocked
- Must use rebase workflow

### 6. History Curation

**Commit Count Limits:**
- Default: 5 commits per branch
- Configurable: `git config hooks.maxCommits <number>`
- Enforced before push
- Encourages squashing and clean history

**Rebase Requirements:**
- Branches must be rebased on base branch
- No merge commits to protected branches
- Interactive rebase supported with autosquash

**Push Validations:**
- Branch name check
- Merge commit detection
- Base branch verification
- Commit count enforcement
- Rebase status check

### 7. Lock File & IaC Monitoring

**Automatic Detection:**
- **Lock Files:** `package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`, `Gemfile.lock`, etc.
- **Infrastructure:** Terraform (`*.tf`, `*.tfvars`), Docker (`Dockerfile`, `docker-compose.yml`)
- **CI/CD:** GitHub Actions, GitLab CI, Jenkins, Azure Pipelines
- **Build Configs:** Webpack, Vite, Rollup, TypeScript, Babel
- **Environment Files:** `.env.*`
- **Migrations:** Database migrations, Prisma schema

**Smart Hints:**
- Suggests running `npm install` when lock files change
- Reminds to run `terraform init` and `terraform plan`
- Warns about Terraform state files in version control
- Suggests rebuilding Docker containers
- Alerts to review CI/CD changes carefully

### 8. Custom Command Framework

**Configuration File:** `.githooks/commands.conf`

**Format:**
```
HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
```

**Example:**
```conf
# Lint and format
pre-commit:1:true:30:npx lint-staged:Lint and format staged files

# Type checking
pre-commit:2:false:60:npx tsc --noEmit:TypeScript type checking

# Run tests
pre-push:1:true:300:npm test:Run test suite

# Build verification
pre-push:2:false:600:npm run build:Build verification
```

**Features:**
- Priority-based execution
- Mandatory vs. optional commands
- Timeout controls
- Staged file placeholder: `{staged}`
- Parallel execution support

---

## Hook Details

### 1. pre-commit

**Triggers:** Before commit is created  
**Purpose:** Validate staged changes

**Checks:**
1. ✅ Protected branch (blocks direct commits)
2. ✅ Sensitive files (blocks `.env`, `*.pem`, etc.)
3. ✅ Secret scanning (AWS keys, API tokens, etc.)
4. ✅ Lock file notifications
5. ✅ Custom commands from `commands.conf`

**Example Workflow:**
```bash
# Stage changes
git add src/auth.js

# pre-commit runs automatically
# ✓ No protected branch commit
# ✓ No sensitive files
# ✓ No secrets detected
# ✓ Custom linting passed

git commit -m "feat: ABC-123 Add authentication"
```

**Bypass:**
```bash
BYPASS_HOOKS=1 git commit -m "Emergency commit"
ALLOW_DIRECT_PROTECTED=1 git commit -m "Direct to main"
```

### 2. commit-msg

**Triggers:** After commit message is written  
**Purpose:** Validate commit message format

**Checks:**
1. ✅ Format: `<type>: <JIRA-ID> <description>`
2. ✅ Valid type (feat, fix, chore, break, tests)
3. ✅ Valid JIRA ID format
4. ✅ Non-empty description
5. ✅ Custom validations from `commands.conf`

**Example:**
```bash
# Invalid format
git commit -m "added new feature"
# ✗ ERROR: Invalid commit message format!

# Valid format
git commit -m "feat: ABC-123 Add OAuth login"
# ✓ Commit message validated
```

**Special Cases:**
- Merge commits: Auto-allowed
- Revert commits: Auto-allowed

### 3. prepare-commit-msg

**Triggers:** Before commit message editor opens  
**Purpose:** Auto-fill commit message

**Actions:**
1. Extracts JIRA ID from branch name
2. Pre-fills message with `feat: <JIRA-ID> `
3. Preserves existing valid messages

**Example:**
```bash
# On branch: feat-ABC-123-add-feature
git commit
# Editor opens with: "feat: ABC-123 "
# Just add description: "feat: ABC-123 Implement OAuth"
```

**Bypass:**
- Skips for merge/squash commits
- Skips if message already valid

### 4. post-checkout

**Triggers:** After branch switch or creation  
**Purpose:** Validate base branch and provide hints

**Actions:**
1. **Base Branch Validation:**
   - Checks if new short-lived branch was created from correct base
   - Validates against configured mappings
   - Shows error with fix instructions if invalid

2. **Protected Branch Warning:**
   - Alerts when switching to `main`, `develop`, or `release/*`
   - Reminds about commit restrictions

3. **Branch Naming Warning:**
   - Warns about non-compliant branch names
   - Doesn't block checkout, but commits will be blocked

4. **Smart Change Detection:**
   - Lock file changes → suggests running install
   - Terraform changes → suggests init/plan
   - Docker changes → suggests rebuild
   - CI/CD changes → reminds to review
   - Build config changes → suggests cache clear
   - Migration changes → suggests running migrations

**Example:**
```bash
# Creating feat branch from main (invalid)
git checkout main
git checkout -b feat-ABC-123-new-feature

# Output:
# ✗ Invalid Base Branch
# Branch type 'feat' must be created from 'origin/develop'
# Current base: main
# Expected base: origin/develop
#
# To fix this:
#   1. Delete this branch: git branch -D feat-ABC-123-new-feature
#   2. Switch to correct base: git checkout origin/develop
#   3. Pull latest: git pull
#   4. Create branch again: git checkout -b feat-ABC-123-new-feature
```

### 5. pre-push

**Triggers:** Before push to remote  
**Purpose:** Validate branch, history, and commits

**Checks:**
1. ✅ Branch name validation
2. ✅ Merge commit detection (to protected branches)
3. ✅ Base branch verification
4. ✅ Rebase status check
5. ✅ Commit count limit
6. ✅ Custom commands from `commands.conf`

**Example:**
```bash
git push origin feat-ABC-123-feature

# Pre-push validation:
# [1/6] Validating branch name...
# [2/6] Checking for merge commits...
# [3/6] Determining base branch...
# [4/6] Fetching base branch...
# [5/6] Checking rebase status...
# [6/6] Checking commit count...
#
# ℹ Expected base branch: origin/develop
# ℹ Commits ahead of origin/develop: 3 / 5 allowed
# ✓ Branch validation passed
```

**Failure Examples:**
```bash
# Too many commits
# ✗ ERROR: Too many commits in branch!
# Current: 8 commits
# Maximum: 5 commits
#
# Fix by squashing:
#   git rebase -i origin/develop
#   # Mark commits as 'squash' or 's'
#   git push --force-with-lease

# Not rebased
# ✗ ERROR: Branch not rebased on origin/develop
#
# Fix:
#   git fetch origin
#   git rebase origin/develop
#   git push --force-with-lease
```

### 6. post-rewrite

**Triggers:** After commit amend or rebase  
**Purpose:** Remind to force push

**Actions:**
- **After rebase:** Shows force-push reminder with `--force-with-lease`
- **After amend:** Reminds to update remote if already pushed
- **Explains `--force-with-lease`:** Safer than `--force`, prevents overwrites

**Example:**
```bash
git rebase -i origin/develop

# Output:
# ✓ Rebase completed successfully!
#
# Important: Push with lease to update remote:
#   git push --force-with-lease
#
# Why --force-with-lease?
#   It ensures no one else has pushed since your last fetch
#   Safer than --force, prevents accidental overwrites
```

### 7. pre-rebase

**Triggers:** Before rebase starts  
**Purpose:** Warn about rebasing protected branches

**Actions:**
1. Warns when rebasing protected branches
2. Suggests correct base for short-lived branches
3. Reminds to coordinate with team

**Example:**
```bash
git rebase origin/develop

# On protected branch 'main':
# ⚠ Warning: You are rebasing a protected branch: 'main'
# Note: This may affect other developers. Coordinate with your team.
# Tip: After rebase, force push with: git push --force-with-lease

# On feature branch with wrong base:
# [Notice] Expected base for this branch type: origin/develop
# Current: Rebasing onto main
```

### 8. applypatch-msg

**Triggers:** During `git am` (applying patches)  
**Purpose:** Validate patch commit messages

**Checks:**
- Same validation as `commit-msg`
- Ensures patch messages follow standards

**Example:**
```bash
git am feature.patch

# Validates each commit message in patch
# ✓ All patch messages validated
```

---

## Configuration

### Core Settings

```bash
# Hooks directory (set during installation)
git config core.hooksPath .githooks

# Maximum commits per branch
git config hooks.maxCommits 5

# Auto-restage files after fixes
git config hooks.autoAddAfterFix false

# Enable parallel command execution
git config hooks.parallelExecution true

# Enable interactive rebase autosquash
git config rebase.autosquash true

# Enable automatic remote pruning
git config fetch.prune true
```

### Branch Mapping Configuration

Override default base branch mappings:

```bash
# Default mappings (configured during installation)
git config hooks.branchMapping.hotfix "origin/main"
git config hooks.branchMapping.feat "origin/develop"
git config hooks.branchMapping.feature "origin/develop"
git config hooks.branchMapping.bugfix "origin/develop"
git config hooks.branchMapping.fix "origin/develop"
git config hooks.branchMapping.techdebt "origin/develop"
git config hooks.branchMapping.perf "origin/develop"
git config hooks.branchMapping.refactor "origin/develop"
git config hooks.branchMapping.revert "origin/develop"
git config hooks.branchMapping.style "origin/develop"
git config hooks.branchMapping.test "origin/develop"
git config hooks.branchMapping.build "origin/develop"
git config hooks.branchMapping.chore "origin/develop"
git config hooks.branchMapping.ci "origin/develop"
git config hooks.branchMapping.docs "origin/develop"

# Custom mappings for your workflow
git config hooks.branchMapping.feat "origin/staging"
git config hooks.branchMapping.hotfix "origin/production"
```

### Test Configuration

```bash
# Enable test infrastructure
git config hooks.tests.enabled true

# Set base branch for tests
git config hooks.tests.baseBranch develop

# Set log verbosity (quiet, normal, verbose, debug)
git config hooks.tests.logVerbosity verbose

# Enable automatic cleanup after tests
git config hooks.tests.autoCleanup true

# Set test categories (all, branch, commit, security, etc.)
git config hooks.tests.categories all

# Preserve state during tests
git config hooks.tests.preserveState true
```

### View Current Configuration

```bash
# View all hook configurations
git config --get-regexp hooks

# View specific setting
git config hooks.maxCommits

# View branch mappings
git config --get-regexp hooks.branchMapping
```

### Reset to Defaults

```bash
# Remove all hook configurations
git config --remove-section hooks

# Re-run installation
bash .githooks/install-hooks.sh
```

---

## Custom Commands

### Configuration File

**Location:** `.githooks/commands.conf`

**Format:**
```
HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION
```

**Fields:**
- `HOOK` - Hook name (pre-commit, commit-msg, pre-push)
- `PRIORITY` - Execution order (lower runs first)
- `MANDATORY` - true=block on failure, false=warn only
- `TIMEOUT` - Max seconds to run (0=no timeout)
- `COMMAND` - Shell command to execute
- `DESCRIPTION` - Human-readable description

### Examples

```conf
# Linting and formatting
pre-commit:1:true:30:npx lint-staged:Lint and format staged files
pre-commit:2:false:60:npx prettier --check {staged}:Check code formatting

# Type checking
pre-commit:3:true:60:npx tsc --noEmit:TypeScript type checking

# File case checking
pre-commit:4:true:10:node scripts/check-casing.js:Validate file casing

# Testing
pre-push:1:true:300:npm test:Run test suite
pre-push:2:false:120:npm run test:e2e:End-to-end tests

# Build verification
pre-push:3:false:600:npm run build:Verify production build

# Commit message validation
commit-msg:1:false:10:node scripts/validate-ticket.js:Validate ticket format
```

### Placeholders

Use `{staged}` for staged file names:

```conf
pre-commit:1:true:30:eslint {staged}:Lint staged files
pre-commit:2:true:20:prettier --write {staged}:Format staged files
```

### Environment Variables

Available in commands:

- `STAGED_FILES` - Space-separated list of staged files
- `GIT_HOOK_NAME` - Name of current hook
- `GIT_USER_NAME` - Git user name
- `GIT_USER_EMAIL` - Git user email

**Example:**
```conf
pre-commit:1:true:30:./scripts/notify.sh $GIT_USER_NAME:Notify user
```

### Priority & Execution

**Priority Order:**
- Lower numbers run first
- Same priority = run in order listed

**Execution Modes:**
- `parallel=false` (default): Sequential execution
- `parallel=true`: Parallel execution within same priority

```bash
# Enable parallel execution
git config hooks.parallelExecution true
```

### Mandatory vs Optional

**Mandatory (true):**
- Blocks commit/push on failure
- Shows error message
- Returns exit code 1

**Optional (false):**
- Shows warning on failure
- Allows commit/push to continue
- Useful for informational checks

### Auto-Restage After Fixes

If commands modify files (e.g., auto-formatting):

```bash
# Enable auto-restage
git config hooks.autoAddAfterFix true
```

Modified files will be automatically re-staged.

### Testing Commands

```bash
# Dry run with bypass
BYPASS_HOOKS=1 git commit -m "test: TEST-001 Test"

# View command output
tail -f .git/hook-logs/pre-commit.log

# Test specific command manually
bash -c "npx lint-staged"
```

---

## Bypass Mechanisms

### Global Bypass

Skip **all** hooks:

```bash
BYPASS_HOOKS=1 git commit -m "Emergency fix"
BYPASS_HOOKS=1 git push origin main
```

**Use cases:**
- Emergency hotfixes
- Automated scripts
- CI/CD pipelines
- Debugging

**Logged:** All bypasses are logged to audit trail.

### Protected Branch Bypass

Allow direct commit to protected branches:

```bash
ALLOW_DIRECT_PROTECTED=1 git commit -m "feat: ADMIN-001 Direct commit"
```

**Use cases:**
- Administrative changes
- Release commits
- Critical fixes by leads

**Warning:** Use sparingly, defeats branch protection purpose.

### Hook-Specific Bypass

Bypass individual hooks:

```bash
# Skip pre-commit only (not recommended)
git commit --no-verify -m "feat: ABC-123 Bypass pre-commit"

# Note: This skips ALL client-side hooks (pre-commit, commit-msg, prepare-commit-msg)
```

**Not recommended:** Use `BYPASS_HOOKS=1` instead for clarity.

### Command-Level Control

Mark commands as optional in `commands.conf`:

```conf
# Won't block commit if fails
pre-commit:2:false:60:npm run lint:Lint code (optional)
```

### Temporary Disable

Temporarily disable hooks:

```bash
# Unset hooks path
git config --unset core.hooksPath

# Your commits now skip hooks

# Re-enable
git config core.hooksPath .githooks
```

### CI/CD Configuration

For CI/CD pipelines, use environment variables:

```yaml
# GitHub Actions example
- name: Commit changes
  env:
    BYPASS_HOOKS: 1
  run: |
    git commit -m "chore: Automated update"
    git push
```

### Bypass Logging

All bypasses are logged:

```bash
# View bypass events
grep "bypassed\|BYPASS_HOOKS" .git/hook-logs/complete.log

# Example output:
# [2025-01-04 10:30:45] [WARNING] [pre-commit] Hook bypassed via BYPASS_HOOKS=1
```

---

## Logging & Monitoring

### Log Locations

```bash
# Complete log (all hooks)
.git/hook-logs/complete.log

# Hook-specific logs
.git/hook-logs/pre-commit.log
.git/hook-logs/commit-msg.log
.git/hook-logs/prepare-commit-msg.log
.git/hook-logs/post-checkout.log
.git/hook-logs/pre-push.log
.git/hook-logs/post-rewrite.log
.git/hook-logs/pre-rebase.log
.git/hook-logs/applypatch-msg.log

# Installation logs
.githooks/logs/install-YYYYMMDD_HHMMSS.log

# Test execution logs
.githooks/test/logs/test-run-YYYYMMDD_HHMMSS.log
```

### Log Levels

- `EMERGENCY` - System failure
- `FATAL` - Critical error
- `CRITICAL` - Critical condition
- `ERROR` - Error condition
- `WARNING` - Warning condition
- `NOTICE` - Notable event
- `INFO` - Informational message
- `DEBUG` - Debug information
- `TRACE` - Detailed trace

**Configure via:**
```bash
export GIT_HOOK_LOG_LEVEL=6  # INFO (default)
```

### Log Format

```
[TIMESTAMP] [LEVEL] [HOOK] [PID:###] [User:Name <email>] [Branch:branch-name] [Commit:hash] MESSAGE
```

**Example:**
```
[2025-01-04 10:30:45] [INFO] [pre-commit] [PID:12345] [User:John Doe <john@example.com>] [Branch:feat-ABC-123-feature] [Commit:a1b2c3d] All pre-commit checks passed
```

### Viewing Logs

```bash
# Tail complete log
tail -f .git/hook-logs/complete.log

# View last 50 entries
tail -50 .git/hook-logs/complete.log

# Search for errors
grep ERROR .git/hook-logs/complete.log

# View today's activity
grep "$(date +%Y-%m-%d)" .git/hook-logs/complete.log

# Filter by hook
grep "\[pre-commit\]" .git/hook-logs/complete.log

# View hook-specific log
cat .git/hook-logs/pre-commit.log

# View with colors (if supported)
less -R .git/hook-logs/complete.log
```

### Log Rotation

Automatic log rotation prevents logs from growing too large:

**Configuration:**
- Max log size: 256KB per file
- Archives kept: 2
- Archive naming: `<hook>.1.log`, `<hook>.2.log`
- Old logs deleted: After 21 days

**Triggered by:**
- `clean.sh` script (runs after each hook)
- Manual execution: `bash .githooks/clean.sh`

### Log Analysis

```bash
# Count hook executions
grep "=== Hook started ===" .git/hook-logs/complete.log | wc -l

# Count errors
grep "\[ERROR\]" .git/hook-logs/complete.log | wc -l

# Count bypasses
grep "bypassed" .git/hook-logs/complete.log | wc -l

# Most active hook
grep "=== Hook started ===" .git/hook-logs/complete.log | \
  awk '{print $4}' | sort | uniq -c | sort -rn

# Failed commands
grep "Command failed" .git/hook-logs/complete.log
```

### Audit Trail

Hooks log comprehensive information for audit purposes:

- User identity
- Timestamp
- Branch name
- Commit hash
- Hook name
- Actions taken
- Results (pass/fail)
- Bypass events
- Configuration changes

**Export for review:**
```bash
# Last week's activity
grep "$(date -d '7 days ago' +%Y-%m-%d)" .git/hook-logs/complete.log > weekly-audit.txt

# All bypasses
grep "BYPASS" .git/hook-logs/complete.log > bypasses.txt

# All failures
grep "failed\|Failed\|ERROR" .git/hook-logs/complete.log > failures.txt
```

### Log Retention

**Automatic Archives:**
- Hook execution logs: `.git/hook-logs-archive-*.tar.gz`
- Test logs: `.githooks/test/test-logs-archive-*.tar.gz`
- Installation logs: `.githooks/installation-logs-archive-*.tar.gz`

**Created by:**
- Uninstallation script
- Manual archiving commands

**Retention Policy:**
- Archives: Keep indefinitely (manual deletion)
- Active logs: Rotate at 256KB
- Old logs: Delete after 21 days

---

## Related Documentation

### Essential Guides

1. **[GITHOOKS_CONTRIBUTING.md](GITHOOKS_CONTRIBUTING.md)**
   - How to add new hooks
   - Extending functionality
   - Development guidelines
   - Code style and standards
   - Pull request process

2. **[GITHOOKS_TESTING.md](GITHOOKS_TESTING.md)**
   - Complete testing guide
   - Running test suites
   - Writing new tests
   - Test configuration
   - CI/CD integration

3. **[GITHOOKS_TROUBLESHOOTING.md](GITHOOKS_TROUBLESHOOTING.md)**
   - Common issues and solutions
   - Error message explanations
   - Debugging techniques
   - Performance optimization
   - Platform-specific issues

### Quick Links

- **Installation Issues:** See [TROUBLESHOOTING - Installation](GITHOOKS_TROUBLESHOOTING.md#installation-issues)
- **Hook Not Running:** See [TROUBLESHOOTING - Execution](GITHOOKS_TROUBLESHOOTING.md#hook-execution-issues)
- **Test Setup:** See [TESTING - Setup](GITHOOKS_TESTING.md#test-setup)
- **Add Custom Hook:** See [CONTRIBUTING - New Hooks](GITHOOKS_CONTRIBUTING.md#adding-new-hooks)

---

## FAQ

**Q: Can I use these hooks with GUI Git clients?**  
A: Yes, hooks run automatically regardless of client (CLI, VS Code, GitKraken, etc.).

**Q: Do hooks run in CI/CD?**  
A: Client-side hooks (pre-commit, pre-push) don't run in CI/CD. Consider server-side hooks or status checks.

**Q: How do I update hooks?**  
A: Pull latest changes, hooks update automatically. No reinstallation needed unless config changes.

**Q: Can I customize for my project?**  
A: Yes! Edit `.githooks/commands.conf` and Git configs. See [Configuration](#configuration).

**Q: What if hooks are too slow?**  
A: Enable parallel execution, increase timeouts, or make commands optional. See [TROUBLESHOOTING - Performance](GITHOOKS_TROUBLESHOOTING.md#performance-issues).

**Q: How do I disable hooks temporarily?**  
A: Use `BYPASS_HOOKS=1` or `git config --unset core.hooksPath`.

**Q: Are hooks shared with the team?**  
A: Yes, committed in `.githooks/`. All team members run same hooks after installation.

**Q: Can I run hooks on existing commits?**  
A: Use `git rebase -i` with `--exec` to run hooks on multiple commits.

---

## Support

**Issues:** Report bugs and request features in your repository's issue tracker.

**Logs:** Always include relevant logs from `.git/hook-logs/` and `.githooks/logs/` when reporting issues.

**Version:** Check hook version in installation logs or at top of hook files.

---

## License

This hook framework is part of your repository. License follows your project's license.

---

**Last Updated:** 2025-01-04  
**Version:** 3.0  
**Compatibility:** Git 2.13+, Bash 4.0+
