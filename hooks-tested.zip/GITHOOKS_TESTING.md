# Git Hooks - Testing Guide

## 📚 Table of Contents

1. [Overview](#overview)
2. [Test Infrastructure](#test-infrastructure)
3. [Test Configuration](#test-configuration)
4. [Running Tests](#running-tests)
5. [Test Categories](#test-categories)
6. [Writing Tests](#writing-tests)
7. [Test Fixtures](#test-fixtures)
8. [Continuous Integration](#continuous-integration)
9. [Troubleshooting Tests](#troubleshooting-tests)

---

## Overview

The Git Hooks framework includes a comprehensive testing infrastructure to verify all functionality works correctly. Tests cover:

- ✅ Hook execution and validation
- ✅ Branch naming enforcement
- ✅ Commit message validation
- ✅ Security scanning (secrets and sensitive files)
- ✅ Base branch enforcement
- ✅ Protected branch controls
- ✅ Custom command execution
- ✅ Logging and audit trails
- ✅ Bypass mechanisms
- ✅ Installation and uninstallation

### Test Philosophy

- **Comprehensive:** Cover all features and edge cases
- **Fast:** Quick feedback for developers
- **Reliable:** Consistent results across environments
- **Isolated:** Tests don't affect working directory
- **Documented:** Clear purpose and expected outcomes

---

## Test Infrastructure

### Directory Structure

```
.githooks/test/
├── test-config.sh                     # Test configuration management
├── setup-test-environment.sh          # Environment setup
├── cleanup-test-environment.sh        # Environment cleanup
├── run-all-tests.sh                   # Legacy test runner
├── run-comprehensive-tests.sh         # Main test runner
├── test-suite.sh                      # Core test suite
├── test-rollback.sh                   # Installation rollback tests
├── test-scenarios/                    # Test scenario files
│   ├── hook-execution-tests.sh       # Direct hook execution tests
│   ├── security-tests.sh             # Security scanning tests
│   ├── branch-tests.sh               # Branch validation tests
│   └── base-branch-tests.sh          # Base branch enforcement tests
├── test-fixtures/                     # Test data files
│   ├── branch-names.txt              # Branch name examples
│   ├── commit-messages.txt           # Commit message examples
│   ├── secret-patterns.txt           # Secret detection patterns
│   ├── sensitive-files.txt           # Sensitive file patterns
│   └── sample-commands.conf          # Sample command configurations
└── logs/                              # Test execution logs
    ├── test-run-YYYYMMDD_HHMMSS.log
    └── .gitignore
```

### Key Components

**1. Test Configuration (`test-config.sh`)**
- Manages test enablement
- Controls log verbosity
- Handles cleanup settings
- Provides quick setup commands

**2. Environment Management**
- `setup-test-environment.sh` - Prepares test environment
- `cleanup-test-environment.sh` - Restores original state
- State preservation for branch, stash, and configurations

**3. Test Runners**
- `run-comprehensive-tests.sh` - Full automated test suite
- `run-all-tests.sh` - Legacy runner with detailed logging
- `test-suite.sh` - Core test framework

**4. Test Scenarios**
- Focused test files for specific functionality
- Reusable test functions
- Mock data and fixtures

---

## Test Configuration

### Enabling Tests

Tests are **disabled by default** for safety. Enable them explicitly:

```bash
# Method 1: Using test-config.sh (Recommended)
bash .githooks/test/test-config.sh enable

# Method 2: Using Git config
git config hooks.tests.enabled true

# Method 3: Using environment variable
export GITHOOKS_TESTS_ENABLED=true
```

### Quick Setup for Development

```bash
# Setup everything for development testing
bash .githooks/test/test-config.sh setup-dev

# This configures:
# - Tests enabled: true
# - Base branch: develop
# - Log verbosity: verbose
# - Auto cleanup: enabled
# - Test categories: all
```

### Quick Setup for CI/CD

```bash
# Setup for CI/CD pipelines
bash .githooks/test/test-config.sh setup-ci

# This configures:
# - Tests enabled: true
# - Base branch: main
# - Log verbosity: normal
# - Auto cleanup: enabled
# - Test categories: all
```

### Configuration Options

```bash
# Base branch for tests
git config hooks.tests.baseBranch develop

# Log verbosity (quiet, normal, verbose, debug)
git config hooks.tests.logVerbosity verbose

# Auto cleanup after tests
git config hooks.tests.autoCleanup true

# Test categories to run (all, branch, commit, security, etc.)
git config hooks.tests.categories all

# Preserve state during tests (branch, stash, configs)
git config hooks.tests.preserveState true
```

### View Configuration

```bash
# Show current configuration
bash .githooks/test/test-config.sh show

# Output:
# Git Hooks Test Configuration
# ════════════════════════════════════════
#
# Execution Control:
#   Tests Enabled:        YES
#
# Test Environment:
#   Base Branch:          develop
#   Preserve State:       YES
#
# Logging:
#   Verbosity:            verbose
#   Log Directory:        .githooks/test/logs
#
# Cleanup:
#   Auto-cleanup:         ENABLED
#
# Test Categories:
#   Categories:           all
```

### Reset Configuration

```bash
# Reset all test configurations to defaults
bash .githooks/test/test-config.sh reset
```

### Environment Variables

Override Git config with environment variables:

```bash
# Enable tests
export GITHOOKS_TESTS_ENABLED=true

# Set base branch
export GITHOOKS_TEST_BASE_BRANCH=develop

# Set log level
export GITHOOKS_TEST_LOG_LEVEL=verbose

# Enable cleanup
export GITHOOKS_TEST_CLEANUP=true

# Set categories
export GITHOOKS_TEST_CATEGORIES=all

# Preserve state
export GITHOOKS_TEST_PRESERVE_STATE=true
```

---

## Running Tests

### Comprehensive Test Suite

Run the complete test suite with automatic environment management:

```bash
bash .githooks/test/run-comprehensive-tests.sh
```

**What it does:**
1. Checks if tests are enabled
2. Displays test configuration
3. Sets up test environment (saves state)
4. Runs all test categories
5. Generates test summary
6. Cleans up test environment (restores state)

**Example Output:**
```
╔════════════════════════════════════════════════════════════════════╗
║                                                                    ║
║         Git Hooks - Comprehensive Test Suite Runner               ║
║                                                                    ║
╚════════════════════════════════════════════════════════════════════╝

Step 1: Checking test configuration...
✓ Tests enabled

Step 2: Test configuration...
  Base Branch:       develop
  Log Verbosity:     verbose
  Auto Cleanup:      enabled
  Preserve State:    enabled
  Test Categories:   all

Step 3: Setting up test environment...
...

Step 4: Running test categories...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Running: Branch Naming & Validation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ Long-lived branch: main
✓ Valid feature branch: feat-PROJ-123-test
...
✓ Branch Naming & Validation - PASSED (15s)

...

Step 6: Generating test summary...

═══════════════════════════════════════════════════════════════════
                 COMPREHENSIVE TEST SUMMARY
═══════════════════════════════════════════════════════════════════

Total Test Categories:  9
Passed:                 9
Failed:                 0
Skipped:                0
Total Duration:         125s

Detailed Results:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Category                       Result        Duration
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
branch-naming                  ✓ PASSED     15s
commit-validation              ✓ PASSED     12s
security-checks                ✓ PASSED     18s
protected-branches             ✓ PASSED     10s
hook-commands                  ✓ PASSED     25s
logging-system                 ✓ PASSED     8s
base-branch-enforcement        ✓ PASSED     20s
bypass-mechanism               ✓ PASSED     7s
hook-execution                 ✓ PASSED     10s
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✓ ALL TESTS PASSED!
```

### Legacy Test Runner

Run with detailed logging and step-by-step output:

```bash
bash .githooks/test/run-all-tests.sh
```

Creates comprehensive log file with all output.

### Core Test Suite

Run the core test suite directly:

```bash
bash .githooks/test/test-suite.sh
```

**Options:**
```bash
# Run specific category
bash .githooks/test/test-suite.sh --category branch

# Verbose output
bash .githooks/test/test-suite.sh --verbose

# Strict mode (fail on first error)
bash .githooks/test/test-suite.sh --strict

# Show help
bash .githooks/test/test-suite.sh --help
```

### Individual Test Scenarios

Run specific test scenarios:

```bash
# Branch validation tests
bash .githooks/test/test-scenarios/branch-tests.sh

# Security scanning tests
bash .githooks/test/test-scenarios/security-tests.sh

# Base branch enforcement tests
bash .githooks/test/test-scenarios/base-branch-tests.sh

# Hook execution tests
bash .githooks/test/test-scenarios/hook-execution-tests.sh
```

### Installation Rollback Tests

Test installation rollback functionality:

```bash
bash .githooks/test/test-rollback.sh
```

Tests various installation scenarios and verifies proper rollback.

### Manual Environment Control

For advanced testing, manually control the environment:

```bash
# Setup environment
bash .githooks/test/setup-test-environment.sh

# Run your tests manually
# ...

# Cleanup environment
bash .githooks/test/cleanup-test-environment.sh
```

---

## Test Categories

### 1. Branch Naming Tests

**Location:** `.githooks/test/test-scenarios/branch-tests.sh`

**Tests:**
- Long-lived branch validation (main, develop, release/*)
- Short-lived branch format (<type>-<JIRA>-<description>)
- All valid branch types (feat, bugfix, hotfix, etc.)
- Invalid formats rejection
- Edge cases (min/max lengths, special characters)
- Batch validation with fixtures

**Run:**
```bash
bash .githooks/test/test-scenarios/branch-tests.sh
```

### 2. Commit Message Tests

**Tests:**
- Valid format: `<type>: <JIRA-ID> <description>`
- Valid types (feat, fix, chore, break, tests)
- JIRA ID format validation
- Invalid format rejection
- Auto-fill from branch name
- Merge and revert message handling

**Included in:** `test-suite.sh`

### 3. Security Tests

**Location:** `.githooks/test/test-scenarios/security-tests.sh`

**Tests:**
- AWS Access Key detection
- AWS Secret Key detection
- GitHub Token detection
- Slack Webhook detection
- Google API Key detection
- Private Key detection
- Password detection
- JWT Token detection
- Sensitive file blocking (.env, *.pem, *.key, etc.)
- Performance on large files

**Run:**
```bash
bash .githooks/test/test-scenarios/security-tests.sh
```

### 4. Base Branch Enforcement Tests

**Location:** `.githooks/test/test-scenarios/base-branch-tests.sh`

**Tests:**
- feat branch from develop (valid)
- feat branch from main (invalid)
- hotfix branch from main (valid)
- hotfix branch from develop (invalid)
- Configuration reading
- All branch type mappings
- Custom mapping override
- Long-lived branches (no base requirement)
- Normalized branch matching
- Error message quality
- Success confirmation

**Run:**
```bash
bash .githooks/test/test-scenarios/base-branch-tests.sh
```

### 5. Protected Branch Tests

**Tests:**
- Direct commit blocking to main
- Direct commit blocking to develop
- Bypass with ALLOW_DIRECT_PROTECTED
- Merge commit detection
- Push validation to protected branches

**Included in:** `test-suite.sh`

### 6. Custom Command Tests

**Tests:**
- Command priority ordering
- Mandatory command failure blocks commit
- Optional command failure warns only
- Timeout enforcement
- Staged file placeholder replacement
- Parallel execution
- Auto-restage after fixes

**Included in:** `test-suite.sh`

### 7. Logging Tests

**Tests:**
- Complete log file creation
- Individual hook logs
- Log rotation
- Log format validation
- Audit trail completeness

**Included in:** `test-suite.sh`

### 8. Hook Execution Tests

**Location:** `.githooks/test/test-scenarios/hook-execution-tests.sh`

**Tests each hook:**
- pre-commit: Execution, branch blocking, secrets blocking, bypass
- commit-msg: Execution, format validation, invalid blocking
- prepare-commit-msg: Auto-fill, existing ID preservation
- post-checkout: Execution, base validation, smart hints
- pre-push: Branch validation, commit count, rebase status, bypass
- post-rewrite: Execution on amend, execution on rebase
- pre-rebase: Protected branch warning, base hint
- applypatch-msg: Patch validation
- Integration: Global bypass, log creation

**Run:**
```bash
bash .githooks/test/test-scenarios/hook-execution-tests.sh
```

### 9. Bypass Mechanism Tests

**Tests:**
- BYPASS_HOOKS=1 skips all hooks
- ALLOW_DIRECT_PROTECTED=1 allows protected commits
- Bypass logging
- Hook-specific bypass (--no-verify)

**Included in:** `test-suite.sh`

### 10. Installation & Rollback Tests

**Location:** `.githooks/test/test-rollback.sh`

**Tests:**
- Normal installation
- .gitignore creation
- .gitignore pattern update
- Idempotent installation (run twice)
- Log file creation
- Rollback file cleanup
- Manual interrupt (documented)

**Run:**
```bash
bash .githooks/test/test-rollback.sh
```

---

## Writing Tests

### Test File Template

Create a new test file in `.githooks/test/test-scenarios/`:

```bash
#!/usr/bin/env bash
# Feature Name Tests
# Description of what this tests

set -euo pipefail

# Setup
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FIXTURES_DIR="$SCRIPT_DIR/../test-fixtures"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Helper functions
pass_test() {
    ((TESTS_PASSED++))
    ((TESTS_RUN++))
    echo -e "${GREEN}✓${NC} $1"
}

fail_test() {
    ((TESTS_FAILED++))
    ((TESTS_RUN++))
    echo -e "${RED}✗${NC} $1"
    echo "  Error: $2"
}

# Test repository helpers
setup_test_repo() {
    TEST_DIR=$(mktemp -d)
    ORIGINAL_DIR=$(pwd)
    cd "$TEST_DIR"
    
    git init --initial-branch=main >/dev/null 2>&1
    git config user.name "Test User"
    git config user.email "test@example.com"
    
    # Copy hooks
    cp -r "$ORIGINAL_DIR/.githooks" "$TEST_DIR/"
    
    # Install
    bash .githooks/install-hooks.sh >/dev/null 2>&1
    
    # Initial commit
    echo "initial" > README.md
    git add README.md
    git commit -m "feat: INIT-001 Initial commit" >/dev/null 2>&1
}

cleanup_test_repo() {
    cd "$ORIGINAL_DIR"
    [ -n "$TEST_DIR" ] && [ -d "$TEST_DIR" ] && rm -rf "$TEST_DIR"
}

# Test functions
test_feature_success_case() {
    # Arrange
    setup_test_repo
    
    # Act
    # ... test logic ...
    
    # Assert
    if [ condition ]; then
        pass_test "Feature works correctly"
    else
        fail_test "Feature test" "Expected X, got Y"
    fi
    
    # Cleanup
    cleanup_test_repo
}

test_feature_failure_case() {
    setup_test_repo
    
    # Test that feature correctly fails
    if ! [ condition ]; then
        pass_test "Feature fails correctly"
    else
        fail_test "Feature failure" "Should have failed"
    fi
    
    cleanup_test_repo
}

# Main execution
main() {
    echo "========================================"
    echo "Feature Name Tests"
    echo "========================================"
    echo ""
    
    test_feature_success_case
    test_feature_failure_case
    # Add more tests...
    
    echo ""
    echo "========================================"
    echo "Test Results"
    echo "========================================"
    echo "Tests run: $TESTS_RUN"
    echo -e "Passed: ${GREEN}$TESTS_PASSED${NC}"
    echo -e "Failed: ${RED}$TESTS_FAILED${NC}"
    
    if [[ $TESTS_FAILED -eq 0 ]]; then
        echo -e "${GREEN}All tests passed!${NC}"
        exit 0
    else
        echo -e "${RED}Some tests failed${NC}"
        exit 1
    fi
}

# Run
main "$@"
```

### Test Naming Conventions

**Test Function Names:**
- `test_<feature>_<scenario>` - Descriptive name
- `test_<hook>_<action>` - Hook-specific tests
- `test_<validation>_success` - Positive tests
- `test_<validation>_failure` - Negative tests

**Examples:**
```bash
test_branch_name_valid()
test_branch_name_invalid()
test_precommit_blocks_secrets()
test_commitmsg_validates_format()
test_prepush_enforces_rebase()
```

### Assertion Patterns

**Success Assertions:**
```bash
# Command succeeds
if command; then
    pass_test "Description"
else
    fail_test "Description" "Command failed"
fi

# Output contains expected text
if command 2>&1 | grep -q "expected"; then
    pass_test "Output correct"
else
    fail_test "Output check" "Expected text not found"
fi

# File exists
if [ -f "file.txt" ]; then
    pass_test "File created"
else
    fail_test "File creation" "File not found"
fi

# Variable equals expected
if [[ "$result" == "expected" ]]; then
    pass_test "Value correct"
else
    fail_test "Value check" "Expected 'expected', got '$result'"
fi
```

**Failure Assertions (Negative Tests):**
```bash
# Command should fail
if ! command; then
    pass_test "Correctly rejected"
else
    fail_test "Rejection" "Should have failed"
fi

# Output should contain error
if command 2>&1 | grep -q "error"; then
    pass_test "Error message shown"
else
    fail_test "Error message" "No error shown"
fi
```

### Using Test Fixtures

Create test data in `.githooks/test/test-fixtures/`:

**Example Fixture (`branch-names.txt`):**
```plaintext
# Format: <valid/invalid> <branch-name> <reason>
valid feat-ABC-123-test Valid branch
invalid my-branch No JIRA ID
valid hotfix-CRIT-999-emergency Valid hotfix
```

**Using in Tests:**
```bash
test_batch_validation() {
    local total=0 correct=0
    
    while IFS=' ' read -r expected branch reason; do
        # Skip comments and empty lines
        [[ "$expected" =~ ^# ]] && continue
        [[ -z "$expected" ]] && continue
        
        ((total++))
        
        # Test validation
        if validate_branch "$branch"; then
            is_valid=true
        else
            is_valid=false
        fi
        
        # Check expectation
        if { [[ "$expected" == "valid" ]] && $is_valid; } || \
           { [[ "$expected" == "invalid" ]] && ! $is_valid; }; then
            ((correct++))
        fi
    done < "$FIXTURES_DIR/branch-names.txt"
    
    if [[ $correct -eq $total ]]; then
        pass_test "Batch validation ($correct/$total)"
    else
        fail_test "Batch validation" "$correct/$total correct"
    fi
}
```

### Mocking Git Operations

**Create Test Repository:**
```bash
setup_test_repo() {
    TEST_DIR=$(mktemp -d)
    cd "$TEST_DIR"
    
    # Initialize repo
    git init --initial-branch=main >/dev/null 2>&1
    git config user.name "Test User"
    git config user.email "test@example.com"
    
    # Setup branches
    git checkout -b develop >/dev/null 2>&1
    git checkout main >/dev/null 2>&1
    
    # Initial commit
    echo "test" > README.md
    git add README.md
    git commit -m "feat: INIT-001 Initial" >/dev/null 2>&1
}
```

**Create Remote:**
```bash
setup_remote() {
    REMOTE_DIR=$(mktemp -d)
    git init --bare "$REMOTE_DIR" >/dev/null 2>&1
    git remote add origin "$REMOTE_DIR"
    git push origin main >/dev/null 2>&1
}
```

**Simulate Scenarios:**
```bash
# Simulate merge conflict
create_conflict() {
    git checkout main
    echo "main" > file.txt
    git add file.txt
    git commit -m "feat: MAIN-001 Main change"
    
    git checkout develop
    echo "develop" > file.txt
    git add file.txt
    git commit -m "feat: DEV-001 Develop change"
    
    git checkout main
    git merge develop  # Will conflict
}

# Simulate rebase
perform_rebase() {
    git checkout feature-branch
    git rebase origin/develop
}

# Simulate stash
save_work() {
    echo "wip" > wip.txt
    git add wip.txt
    git stash push -m "Work in progress"
}
```

---

## Test Fixtures

### Purpose

Test fixtures provide consistent, reusable test data:
- Branch name examples
- Commit message examples
- Secret patterns
- Sensitive file patterns
- Configuration samples

### Available Fixtures

**1. Branch Names** (`.githooks/test/test-fixtures/branch-names.txt`)
- Valid/invalid examples
- All branch types
- Edge cases
- Format: `<valid/invalid> <branch-name> <reason>`

**2. Commit Messages** (`.githooks/test/test-fixtures/commit-messages.txt`)
- Valid/invalid formats
- All commit types
- Edge cases
- Format: `<valid/invalid> "<message>" <reason>`

**3. Secret Patterns** (`.githooks/test/test-fixtures/secret-patterns.txt`)
- Real-world secret examples (redacted)
- Various secret types
- Pattern testing

**4. Sensitive Files** (`.githooks/test/test-fixtures/sensitive-files.txt`)
- Sensitive file names
- Pattern matching examples

**5. Sample Commands** (`.githooks/test/test-fixtures/sample-commands.conf`)
- Example command configurations
- Priority demonstrations
- Timeout examples

### Creating New Fixtures

```bash
# Create fixture file
cat > .githooks/test/test-fixtures/new-fixture.txt << 'EOF'
# Comment explaining format
data1 value1 description
data2 value2 description
EOF

# Add to .gitignore if contains sensitive data
echo "test/test-fixtures/sensitive-fixture.txt" >> .gitignore
```

### Using Fixtures in Tests

```bash
# Load fixture
while IFS=' ' read -r field1 field2 field3; do
    # Skip comments
    [[ "$field1" =~ ^# ]] && continue
    
    # Process data
    process_test_data "$field1" "$field2" "$field3"
done < "$FIXTURES_DIR/fixture-file.txt"
```

---

## Continuous Integration

### GitHub Actions

Create `.github/workflows/test-hooks.yml`:

```yaml
name: Git Hooks Tests

on:
  push:
    branches: [ main, develop ]
    paths:
      - '.githooks/**'
  pull_request:
    branches: [ main, develop ]
    paths:
      - '.githooks/**'

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Install Dependencies
      run: |
        sudo apt-get update
        sudo apt-get install -y bash git
    
    - name: Configure Git
      run: |
        git config --global user.name "CI Test"
        git config --global user.email "ci@test.com"
    
    - name: Setup Test Environment
      run: |
        bash .githooks/test/test-config.sh setup-ci
    
    - name: Run Tests
      run: |
        bash .githooks/test/run-comprehensive-tests.sh
    
    - name: Upload Test Results
      if: always()
      uses: actions/upload-artifact@v3
      with:
        name: test-results
        path: .githooks/test/logs/*.log
```

### GitLab CI

Create `.gitlab-ci.yml`:

```yaml
test-hooks:
  stage: test
  image: ubuntu:latest
  
  before_script:
    - apt-get update && apt-get install -y bash git
    - git config --global user.name "CI Test"
    - git config --global user.email "ci@test.com"
  
  script:
    - bash .githooks/test/test-config.sh setup-ci
    - bash .githooks/test/run-comprehensive-tests.sh
  
  artifacts:
    when: always
    paths:
      - .githooks/test/logs/*.log
    expire_in: 1 week
  
  only:
    changes:
      - .githooks/**
```

### Jenkins

Create `Jenkinsfile`:

```groovy
pipeline {
    agent any
    
    stages {
        stage('Setup') {
            steps {
                sh '''
                    git config --global user.name "CI Test"
                    git config --global user.email "ci@test.com"
                '''
            }
        }
        
        stage('Configure Tests') {
            steps {
                sh 'bash .githooks/test/test-config.sh setup-ci'
            }
        }
        
        stage('Run Tests') {
            steps {
                sh 'bash .githooks/test/run-comprehensive-tests.sh'
            }
        }
    }
    
    post {
        always {
            archiveArtifacts artifacts: '.githooks/test/logs/*.log', allowEmptyArchive: true
        }
    }
}
```

### Local Pre-Push Hook

Run tests before pushing:

```bash
# Add to .githooks/pre-push or personal pre-push script
if git diff --name-only origin/develop...HEAD | grep -q "^\.githooks/"; then
    echo "Git hooks changed, running tests..."
    bash .githooks/test/run-comprehensive-tests.sh
fi
```

---

## Troubleshooting Tests

### Tests Not Running

**Issue:** "Tests are not enabled"

**Solution:**
```bash
# Enable tests
bash .githooks/test/test-config.sh enable

# Or
git config hooks.tests.enabled true

# Verify
bash .githooks/test/test-config.sh show
```

### Tests Failing

**Issue:** Tests fail unexpectedly

**Diagnosis:**
```bash
# Run with verbose logging
GITHOOKS_TEST_LOG_LEVEL=debug bash .githooks/test/run-comprehensive-tests.sh

# Check logs
cat .githooks/test/logs/test-run-*.log

# Run specific failing test
bash .githooks/test/test-scenarios/failing-test.sh
```

### Environment Issues

**Issue:** Test environment setup fails

**Solution:**
```bash
# Check Git installation
git --version

# Check Bash version
bash --version

# Check permissions
ls -la .githooks/test/*.sh

# Make executable
chmod +x .githooks/test/*.sh
chmod +x .githooks/test/test-scenarios/*.sh

# Check disk space
df -h
```

### State Not Restored

**Issue:** Tests don't restore original state

**Solution:**
```bash
# Manually cleanup
bash .githooks/test/cleanup-test-environment.sh

# Check for test branches
git branch | grep test-

# Delete test branches
git branch | grep test- | xargs git branch -D

# Check stash
git stash list

# Restore from state file
if [ -f .githooks/test/.test-state ]; then
    source .githooks/test/.test-state
    git checkout "$CURRENT_BRANCH"
fi
```

### Performance Issues

**Issue:** Tests are too slow

**Optimization:**
```bash
# Run specific category only
bash .githooks/test/test-suite.sh --category branch

# Disable verbose logging
git config hooks.tests.logVerbosity quiet

# Skip cleanup for debugging
git config hooks.tests.autoCleanup false

# Run tests in parallel (if supported)
# Modify test runner to use parallel execution
```

### CI/CD Issues

**Issue:** Tests pass locally but fail in CI

**Diagnosis:**
```bash
# Check CI environment
echo "Git: $(git --version)"
echo "Bash: $(bash --version)"
echo "User: $(whoami)"
echo "Home: $HOME"

# Check Git config
git config --list

# Check file permissions
ls -la .githooks/

# Check for platform-specific issues
uname -a
```

**Common CI Fixes:**
```bash
# Set Git identity
git config --global user.name "CI"
git config --global user.email "ci@example.com"

# Make scripts executable
find .githooks -name "*.sh" -exec chmod +x {} \;

# Use absolute paths
cd "$(git rev-parse --show-toplevel)"

# Set environment variables
export GITHOOKS_TESTS_ENABLED=true
```

### Cleaning Up

**Issue:** Need to completely reset test environment

**Solution:**
```bash
# Delete all test artifacts
rm -rf .githooks/test/logs/*
rm -f .githooks/test/.test-state

# Delete test branches
git branch | grep -E "test-|feat-TEST-|bugfix-TEST-" | xargs git branch -D

# Reset test configuration
bash .githooks/test/test-config.sh reset

# Reinstall hooks
bash .githooks/install-hooks.sh
```

---

## Best Practices

### Writing Effective Tests

✅ **Test One Thing**
- Each test should verify one specific behavior
- Keep tests focused and simple

✅ **Use Descriptive Names**
- Test name should explain what is being tested
- Include expected outcome in name

✅ **Test Both Success and Failure**
- Positive tests: Feature works as expected
- Negative tests: Feature fails correctly

✅ **Isolate Tests**
- Each test should be independent
- Use setup/teardown properly
- Don't rely on test order

✅ **Use Realistic Data**
- Test with realistic examples
- Include edge cases
- Use test fixtures

### Running Tests Regularly

🔄 **During Development**
```bash
# Before committing changes
bash .githooks/test/run-comprehensive-tests.sh

# Run specific tests during development
bash .githooks/test/test-scenarios/your-feature-tests.sh
```

🔄 **Before Pull Requests**
```bash
# Full test suite
bash .githooks/test/run-comprehensive-tests.sh

# Check test coverage
# Ensure new features have tests
```

🔄 **In CI/CD**
```bash
# Automated testing on every push
# See CI/CD section for setup
```

### Maintaining Tests

🔧 **Update Regularly**
- Add tests for new features
- Update tests when behavior changes
- Remove obsolete tests

🔧 **Keep Tests Fast**
- Mock expensive operations
- Parallelize where possible
- Skip unnecessary setup

🔧 **Document Complex Tests**
- Explain what is being tested
- Document expected behavior
- Add comments for complex logic

---

**Last Updated:** 2025-01-04  
**Version:** 3.0
