# Git Hooks - Contributing Guide

## 📚 Table of Contents

1. [Overview](#overview)
2. [Development Setup](#development-setup)
3. [Architecture](#architecture)
4. [Adding New Hooks](#adding-new-hooks)
5. [Extending Existing Hooks](#extending-existing-hooks)
6. [Adding Custom Commands](#adding-custom-commands)
7. [Modifying Library Functions](#modifying-library-functions)
8. [Writing Tests](#writing-tests)
9. [Code Style Guidelines](#code-style-guidelines)
10. [Testing Your Changes](#testing-your-changes)
11. [Pull Request Process](#pull-request-process)
12. [Best Practices](#best-practices)

---

## Overview

This guide helps you contribute to the Git Hooks framework. Whether you're adding new hooks, extending functionality, or fixing bugs, follow these guidelines to maintain consistency and quality.

### What You Can Contribute

✅ **New Hooks** - Add support for additional Git hooks  
✅ **Enhanced Validation** - Improve existing validation logic  
✅ **New Commands** - Add custom command examples  
✅ **Tests** - Add test cases and scenarios  
✅ **Documentation** - Improve guides and examples  
✅ **Bug Fixes** - Fix issues and improve reliability  
✅ **Performance** - Optimize hook execution speed  

---

## Development Setup

### Prerequisites

```bash
# Required
- Git 2.13+
- Bash 4.0+

# Optional (for testing)
- Node.js (if testing npm commands)
- Python (if testing Python tools)
- Docker (if testing container workflows)
```

### Clone and Setup

```bash
# 1. Clone repository
git clone <repository-url>
cd <repository>

# 2. Install hooks in development mode
bash .githooks/install-hooks.sh

# 3. Enable test infrastructure
bash .githooks/test/test-config.sh setup-dev

# 4. Verify setup
git config core.hooksPath
# Should output: .githooks

# 5. Run initial tests
bash .githooks/test/run-comprehensive-tests.sh
```

### Development Branch

Always create a feature branch:

```bash
# Create feature branch from develop
git checkout develop
git pull origin develop
git checkout -b feat-<JIRA-ID>-<description>

# Example
git checkout -b feat-HOOKS-001-add-pre-merge-hook
```

---

## Architecture

### Directory Structure

```
.githooks/
├── pre-commit                  # Hook: Before commit
├── commit-msg                  # Hook: Validate commit message
├── prepare-commit-msg          # Hook: Auto-fill commit message
├── post-checkout               # Hook: After branch switch
├── pre-push                    # Hook: Before push
├── post-rewrite                # Hook: After rebase/amend
├── pre-rebase                  # Hook: Before rebase
├── applypatch-msg              # Hook: Validate patch message
├── install-hooks.sh            # Installation script
├── uninstall-hooks.sh          # Uninstallation script
├── clean.sh                    # Log cleanup script
├── commands.conf               # Custom commands configuration
├── run-commands.sh             # Legacy extension framework
├── lib/                        # Shared libraries
│   ├── common.sh              # Common functions and constants
│   └── runner.sh              # Command execution framework
├── test/                       # Test infrastructure
│   ├── test-config.sh         # Test configuration
│   ├── setup-test-environment.sh
│   ├── cleanup-test-environment.sh
│   ├── run-all-tests.sh
│   ├── run-comprehensive-tests.sh
│   ├── test-suite.sh
│   ├── test-rollback.sh
│   ├── test-scenarios/        # Test scenario files
│   │   ├── hook-execution-tests.sh
│   │   ├── security-tests.sh
│   │   ├── branch-tests.sh
│   │   └── base-branch-tests.sh
│   └── test-fixtures/         # Test data files
│       ├── branch-names.txt
│       ├── commit-messages.txt
│       ├── secret-patterns.txt
│       └── sensitive-files.txt
└── logs/                       # Installation logs
```

### Hook Execution Flow

```
Git Operation Triggered
        ↓
Hook Script Executed
        ↓
Source common.sh (shared functions)
        ↓
init_hook() - Initialize logging
        ↓
Check BYPASS_HOOKS environment variable
        ↓
Perform Hook-Specific Validations
        ↓
Source runner.sh (if custom commands)
        ↓
run_hook_commands() - Execute custom commands
        ↓
exit_hook() - Log completion and exit
```

### Key Components

**1. Hook Scripts** (`pre-commit`, `commit-msg`, etc.)
- Entry points for Git hooks
- Contain hook-specific logic
- Source shared libraries

**2. Common Library** (`lib/common.sh`)
- Shared functions (logging, branch validation, etc.)
- Constants (regex patterns, colors, etc.)
- Platform detection
- Secret scanning logic

**3. Runner Framework** (`lib/runner.sh`)
- Custom command execution
- Priority-based ordering
- Timeout management
- Parallel execution support
- Auto-restage functionality

**4. Installation Scripts**
- `install-hooks.sh` - Sets up hooks with rollback
- `uninstall-hooks.sh` - Removes hooks with archiving
- `clean.sh` - Log rotation and cleanup

**5. Test Infrastructure**
- Configuration management
- Environment setup/cleanup
- Test scenarios
- Fixtures and mock data

---

## Adding New Hooks

### Step 1: Create Hook File

Create a new file in `.githooks/`:

```bash
touch .githooks/pre-merge-commit
chmod +x .githooks/pre-merge-commit
```

### Step 2: Hook Template

Use this template as a starting point:

```bash
#!/usr/bin/env bash

# ============================================================================
# Pre-Merge-Commit Hook
# Purpose: Validate merge commit messages
# Triggers: Before merge commit is created
# ============================================================================

set -euo pipefail

HOOK_NAME="pre-merge-commit"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
source "$SCRIPT_DIR/lib/runner.sh"

init_hook "$HOOK_NAME"

# Check for bypass
if is_bypassed "$HOOK_NAME"; then
    exit_hook "$HOOK_NAME" 0 "Bypassed"
fi

# Hook-specific logic goes here
show_progress "$HOOK_NAME" 1 3 "Validating merge commit..."

# Example validation
if [ -f ".git/MERGE_HEAD" ]; then
    log_message $LOG_INFO "$HOOK_NAME" "Merge commit detected"
    
    # Your validation logic
    # ...
    
    log_message $LOG_INFO "$HOOK_NAME" "Merge commit validation passed"
else
    log_message $LOG_DEBUG "$HOOK_NAME" "Not a merge commit"
fi

show_progress "$HOOK_NAME" 2 3 "Running custom commands..."

# Run custom commands if configured
if ! run_hook_commands "$HOOK_NAME"; then
    exit_hook "$HOOK_NAME" 1 "Custom command checks failed"
fi

show_progress "$HOOK_NAME" 3 3 "Running legacy extensions..."

# Legacy extension support (optional)
if ! run_extension "$HOOK_NAME" "premerge_extra"; then
    exit_hook "$HOOK_NAME" 1 "Extension checks failed"
fi

# Success
log_message $LOG_INFO "$HOOK_NAME" "All checks passed"
exit_hook "$HOOK_NAME" 0 "Success"
```

### Step 3: Add Hook to Installation

Edit `install-hooks.sh` to include your new hook:

```bash
# Find the section "Make hooks executable"
# Add your hook to the chmod commands

log "${YELLOW}[7/11]${NC} Making hooks executable..."
if command -v chmod >/dev/null 2>&1; then
    chmod +x .githooks/* 2>/dev/null || true
    chmod +x .githooks/pre-merge-commit 2>/dev/null || true  # Add this line
    ...
```

### Step 4: Add Hook to Uninstallation

Edit `uninstall-hooks.sh` if specific cleanup is needed:

```bash
# Usually no changes needed unless hook creates
# special files or configurations
```

### Step 5: Document the Hook

Add documentation to `GITHOOKS_README.md`:

```markdown
### 9. pre-merge-commit

**Triggers:** Before merge commit is created
**Purpose:** Validate merge commit messages

**Checks:**
1. ✅ Merge commit format
2. ✅ Source and target branches
3. ✅ Custom validations

**Example:**
\`\`\`bash
git merge feature-branch

# pre-merge-commit runs automatically
# ✓ Merge validation passed
\`\`\`
```

### Step 6: Write Tests

Create test file in `.githooks/test/test-scenarios/`:

```bash
#!/usr/bin/env bash
# Pre-Merge-Commit Hook Tests

set -euo pipefail

# Test: Hook exists and is executable
test_hook_exists() {
    if [ -f ".githooks/pre-merge-commit" ] && [ -x ".githooks/pre-merge-commit" ]; then
        pass_test "pre-merge-commit hook exists and is executable"
    else
        fail_test "pre-merge-commit hook exists" "File missing or not executable"
    fi
}

# Test: Hook validates merge commits
test_merge_validation() {
    setup_test_repo
    
    # Create branches and merge
    git checkout -b feature >/dev/null 2>&1
    echo "feature" > feature.txt
    git add feature.txt
    BYPASS_HOOKS=1 git commit -m "feat: TEST-001 Feature" >/dev/null 2>&1
    
    git checkout main >/dev/null 2>&1
    
    # Merge should trigger hook
    if git merge feature --no-ff 2>&1 | grep -q "Merge validation"; then
        pass_test "pre-merge-commit validates merge"
    else
        fail_test "pre-merge-commit validates merge" "Hook didn't execute"
    fi
    
    cleanup_test_repo
}

# Run tests
main() {
    echo "Pre-Merge-Commit Hook Tests"
    echo "=============================="
    
    test_hook_exists
    test_merge_validation
    
    # Summary
    # ...
}

main "$@"
```

### Step 7: Test Your Hook

```bash
# Run your specific tests
bash .githooks/test/test-scenarios/pre-merge-tests.sh

# Run full test suite
bash .githooks/test/run-comprehensive-tests.sh

# Manual testing
git checkout -b test-merge-hook
echo "test" > test.txt
git add test.txt
git commit -m "feat: TEST-001 Test"
git checkout main
git merge test-merge-hook --no-ff
```

---

## Extending Existing Hooks

### Modifying Hook Logic

1. **Locate the hook file** (e.g., `.githooks/pre-commit`)

2. **Understand current flow:**
```bash
# Read the hook
cat .githooks/pre-commit

# Check dependencies
grep "source" .githooks/pre-commit
```

3. **Add your validation:**
```bash
# Add new validation step
show_progress "$HOOK_NAME" 5 6 "Checking custom requirement..."

# Your validation logic
if ! check_custom_requirement; then
    log_message $LOG_ERROR "$HOOK_NAME" "Custom requirement failed"
    echo -e "${RED}${BOLD}[Error]${NC} Custom requirement not met!"
    exit_hook "$HOOK_NAME" 1 "Custom check failed"
fi

# Update progress numbers (5 of 6 instead of 5 of 5)
```

4. **Test thoroughly:**
```bash
# Test success case
echo "valid" > test.txt
git add test.txt
git commit -m "feat: TEST-001 Test"

# Test failure case
echo "invalid" > test.txt
git add test.txt
git commit -m "feat: TEST-002 Test"
# Should fail with your error
```

### Adding New Validation Patterns

Add to `lib/common.sh`:

```bash
# Add new secret pattern
SECRET_PATTERNS+=(
    'NEW_API_KEY_PATTERN'
    'ANOTHER_SECRET_PATTERN'
)

# Add new sensitive file pattern
SENSITIVE_FILES+=(
    '*.secret'
    'private-*'
)

# Add new validation function
check_custom_requirement() {
    local hook_name="$1"
    
    # Your validation logic
    if [ condition ]; then
        return 0  # Pass
    else
        return 1  # Fail
    fi
}
```

### Adding New Branch Types

Edit `lib/common.sh`:

```bash
# Update regex pattern
SHORT_LIVED_BRANCHES_REGEX='^(build|chore|ci|docs|feat|feature|techdebt|bugfix|fix|perf|refactor|revert|style|test|hotfix|newtype)-[A-Z]{2,10}-[0-9]+-[a-z0-9-]+$'
#                                                                                                                                      ^^^^^^^ Add here

# Add to commit message types (if applicable)
COMMIT_SUBJECT_REGEX='^(feat|fix|chore|break|tests|newtype): [A-Z]{2,10}-[0-9]+ .+'
#                                                    ^^^^^^^ Add here
```

Edit `install-hooks.sh`:

```bash
# Add branch mapping
if [ -z "$(git config hooks.branchMapping.newtype 2>/dev/null)" ]; then
    save_git_config "hooks.branchMapping.newtype"
    git config hooks.branchMapping.newtype "origin/develop"
    mappings_set=$((mappings_set + 1))
fi
```

Edit `uninstall-hooks.sh`:

```bash
# Add to uninstall list
for branch_type in hotfix feat feature bugfix fix techdebt perf refactor revert style test build chore ci docs newtype; do
#                                                                                                             ^^^^^^^ Add here
    if git config --unset hooks.branchMapping.$branch_type 2>/dev/null; then
        removed_count=$((removed_count + 1))
    fi
done
```

---

## Adding Custom Commands

### Method 1: Via commands.conf (Recommended)

1. **Edit `.githooks/commands.conf`:**

```conf
# Format: HOOK:PRIORITY:MANDATORY:TIMEOUT:COMMAND:DESCRIPTION

# Add your command
pre-commit:5:true:30:./scripts/custom-check.sh:Custom validation script
```

2. **Create your command script:**

```bash
#!/usr/bin/env bash
# scripts/custom-check.sh

set -euo pipefail

# Access environment variables
echo "Running custom check for $GIT_USER_NAME"
echo "Staged files: $STAGED_FILES"

# Your logic
if [ condition ]; then
    echo "✓ Custom check passed"
    exit 0
else
    echo "✗ Custom check failed"
    exit 1
fi
```

3. **Make executable:**

```bash
chmod +x scripts/custom-check.sh
```

4. **Test:**

```bash
echo "test" > test.txt
git add test.txt
git commit -m "feat: TEST-001 Test custom command"
```

### Method 2: Via run-commands.sh (Legacy)

1. **Edit `.githooks/run-commands.sh`:**

```bash
# Uncomment and implement

precommit_extra() {
    local files=("$@")
    echo "[Extension] Running custom pre-commit checks on ${#files[@]} files..."
    
    # Your custom logic
    for file in "${files[@]}"; do
        # Check file
        if ! custom_file_check "$file"; then
            echo "✗ File check failed: $file"
            return 1
        fi
    done
    
    echo "✓ All custom checks passed"
    return 0
}

custom_file_check() {
    local file="$1"
    # Your validation
    return 0
}
```

2. **Test:**

```bash
echo "test" > test.txt
git add test.txt
git commit -m "feat: TEST-001 Test extension"
```

### Method 3: Inline in Hook

1. **Edit hook file directly** (e.g., `.githooks/pre-commit`):

```bash
# Add before run_hook_commands

show_progress "$HOOK_NAME" 5 6 "Running inline custom check..."

# Your inline code
if ! ./scripts/custom-check.sh; then
    echo -e "${RED}✗${NC} Inline check failed"
    exit_hook "$HOOK_NAME" 1 "Inline check failed"
fi
```

---

## Modifying Library Functions

### Common Library (`lib/common.sh`)

**Do's:**
- ✅ Add new utility functions
- ✅ Add new validation patterns
- ✅ Extend existing functions carefully
- ✅ Document changes clearly

**Don'ts:**
- ❌ Break existing function signatures
- ❌ Remove existing functions
- ❌ Change global variable names
- ❌ Modify log formats without updating consumers

### Example: Adding New Function

```bash
# Add to lib/common.sh

# Get branch age in days
get_branch_age() {
    local branch="${1:-$(get_current_branch)}"
    local created_date=$(git log --reverse --format=%ct "$branch" | head -1)
    local current_date=$(date +%s)
    local age_seconds=$((current_date - created_date))
    local age_days=$((age_seconds / 86400))
    echo "$age_days"
}

# Check if branch is stale
is_stale_branch() {
    local branch="${1:-$(get_current_branch)}"
    local max_age_days="${2:-90}"
    local age=$(get_branch_age "$branch")
    [ "$age" -gt "$max_age_days" ]
}
```

### Example: Extending Existing Function

```bash
# Original function in lib/common.sh
get_base_branch() {
    local branch="${1:-$(get_current_branch)}"
    local branch_type=$(get_branch_type "$branch")
    
    # ... existing logic ...
    
    # Add new case
    case "$branch_type" in
        # ... existing cases ...
        experimental)
            echo "origin/sandbox"
            ;;
        *)
            echo ""
            ;;
    esac
}
```

### Runner Framework (`lib/runner.sh`)

**Modify with caution:**
- Used by all hooks
- Breaking changes affect entire system
- Thoroughly test changes

**Example: Adding Feature**

```bash
# Add retry mechanism for failed commands

execute_command() {
    local hook_name="$1"
    local priority="$2"
    local mandatory="$3"
    local timeout="$4"
    local command="$5"
    local description="$6"
    
    # Add retry config
    local max_retries="${COMMAND_MAX_RETRIES:-3}"
    local retry_delay="${COMMAND_RETRY_DELAY:-5}"
    
    for attempt in $(seq 1 $max_retries); do
        # ... existing execution logic ...
        
        if [ $exit_code -eq 0 ]; then
            return 0
        elif [ $attempt -lt $max_retries ]; then
            log_message $LOG_WARNING "$hook_name" "Command failed, retrying in ${retry_delay}s... (attempt $attempt/$max_retries)"
            sleep $retry_delay
        fi
    done
    
    # All retries failed
    return $exit_code
}
```

---

## Writing Tests

### Test Structure

```bash
#!/usr/bin/env bash
# Test File Template

set -euo pipefail

# Setup
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FIXTURES_DIR="$SCRIPT_DIR/../test-fixtures"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

# Counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Helpers
pass_test() {
    ((TESTS_PASSED++))
    ((TESTS_RUN++))
    echo -e "${GREEN}✓${NC} $1"
}

fail_test() {
    ((TESTS_FAILED++))
    ((TESTS_RUN++))
    echo -e "${RED}✗${NC} $1"
    echo "  Error: $2"
}

# Test functions
test_feature_works() {
    # Test logic
    if [ condition ]; then
        pass_test "Feature works as expected"
    else
        fail_test "Feature works" "Expected X, got Y"
    fi
}

test_feature_fails_correctly() {
    # Negative test
    if ! [ condition ]; then
        pass_test "Feature fails correctly"
    else
        fail_test "Feature fails" "Should have failed but didn't"
    fi
}

# Main
main() {
    echo "Feature Tests"
    echo "============="
    echo ""
    
    test_feature_works
    test_feature_fails_correctly
    
    echo ""
    echo "Results: $TESTS_RUN total, ${GREEN}$TESTS_PASSED passed${NC}, ${RED}$TESTS_FAILED failed${NC}"
    
    if [[ $TESTS_FAILED -eq 0 ]]; then
        echo -e "${GREEN}All tests passed!${NC}"
        exit 0
    else
        echo -e "${RED}Some tests failed${NC}"
        exit 1
    fi
}

main "$@"
```

### Test Categories

**1. Unit Tests** - Test individual functions

```bash
test_get_branch_type() {
    local result=$(get_branch_type "feat-ABC-123-test")
    if [[ "$result" == "feat" ]]; then
        pass_test "get_branch_type extracts type correctly"
    else
        fail_test "get_branch_type" "Expected 'feat', got '$result'"
    fi
}
```

**2. Integration Tests** - Test hook execution

```bash
test_pre_commit_blocks_secrets() {
    setup_test_repo
    
    git checkout -b feat-TEST-001-security >/dev/null 2>&1
    echo "AWS_KEY=AKIAIOSFODNN7EXAMPLE" > config.txt
    git add config.txt
    
    if git commit -m "feat: TEST-001 Test" 2>&1 | grep -q "secret"; then
        pass_test "pre-commit blocks secrets"
    else
        fail_test "pre-commit blocks secrets" "Secret not detected"
    fi
    
    cleanup_test_repo
}
```

**3. Scenario Tests** - Test complete workflows

```bash
test_complete_feature_workflow() {
    setup_test_repo
    
    # Create feature branch
    git checkout develop >/dev/null 2>&1
    git checkout -b feat-TEST-002-workflow >/dev/null 2>&1
    
    # Make commits
    echo "test" > test.txt
    git add test.txt
    git commit -m "feat: TEST-002 Add feature" >/dev/null 2>&1
    
    # Push
    if git push origin feat-TEST-002-workflow 2>&1; then
        pass_test "Complete feature workflow"
    else
        fail_test "Complete feature workflow" "Push failed"
    fi
    
    cleanup_test_repo
}
```

### Test Fixtures

Create test data files in `.githooks/test/test-fixtures/`:

```plaintext
# branch-names.txt
valid feat-ABC-123-test Valid branch
invalid my-branch Invalid (no JIRA)
valid hotfix-CRIT-999-emergency Valid hotfix
invalid feat_ABC_123_test Invalid (underscores)
```

Use in tests:

```bash
test_batch_validation() {
    while IFS=' ' read -r expected branch reason; do
        [[ "$expected" =~ ^# ]] && continue
        
        if validate_branch_name "$branch"; then
            is_valid=true
        else
            is_valid=false
        fi
        
        if [[ "$expected" == "valid" ]] && $is_valid; then
            ((correct++))
        elif [[ "$expected" == "invalid" ]] && ! $is_valid; then
            ((correct++))
        fi
    done < "$FIXTURES_DIR/branch-names.txt"
    
    # Assert all correct
}
```

### Running Tests

```bash
# Run all tests
bash .githooks/test/run-comprehensive-tests.sh

# Run specific scenario
bash .githooks/test/test-scenarios/branch-tests.sh

# Run with specific configuration
GITHOOKS_TEST_LOG_LEVEL=debug bash .githooks/test/run-comprehensive-tests.sh

# Run and save results
bash .githooks/test/run-comprehensive-tests.sh > test-results.log 2>&1
```

---

## Code Style Guidelines

### Bash Style

**Indentation:**
- Use 4 spaces (no tabs)
- Consistent indentation throughout

**Variables:**
```bash
# Use UPPER_CASE for constants
readonly MAX_COMMITS=5
readonly LOG_DIR=".git/hook-logs"

# Use lower_case for variables
local branch_name="feat-ABC-123-test"
local commit_count=3

# Use descriptive names
local staged_files=$(get_staged_files)  # Good
local files=$(get_staged_files)          # Less clear
```

**Functions:**
```bash
# Use verb_noun naming
get_branch_type() { }
validate_commit_message() { }
is_protected_branch() { }

# Add comments
# Get the type from branch name
# Args: $1 - branch name (optional, defaults to current)
# Returns: branch type or empty string
get_branch_type() {
    local branch="${1:-$(get_current_branch)}"
    echo "$branch" | sed -E 's/^([^-]+)-.*/\1/'
}
```

**Error Handling:**
```bash
# Use set flags
set -euo pipefail  # Exit on error, undefined var, pipe failure

# Handle errors explicitly
if ! command; then
    log_message $LOG_ERROR "$HOOK_NAME" "Command failed"
    exit_hook "$HOOK_NAME" 1 "Failure"
fi

# Use return codes consistently
if validate_something; then
    return 0  # Success
else
    return 1  # Failure
fi
```

**Quoting:**
```bash
# Always quote variables
echo "$variable"
command "$file_path"

# Arrays
local files=("$@")
for file in "${files[@]}"; do
    process "$file"
done
```

**Conditionals:**
```bash
# Use [[ ]] for tests
if [[ "$var" == "value" ]]; then
    # ...
fi

# Pattern matching
if [[ "$branch" =~ $PATTERN ]]; then
    # ...
fi

# Check file/directory
if [[ -f "$file" ]]; then
    # ...
fi

if [[ -d "$dir" ]]; then
    # ...
fi
```

### Comments

**File Headers:**
```bash
#!/usr/bin/env bash

# ============================================================================
# Hook Name
# Purpose: Brief description
# Triggers: When this hook runs
# Checks: List of validations
# ============================================================================

set -euo pipefail
```

**Function Comments:**
```bash
#######################################
# Brief function description
# Globals:
#   GLOBAL_VAR
# Arguments:
#   $1 - First argument description
#   $2 - Second argument (optional)
# Returns:
#   0 on success, 1 on failure
# Outputs:
#   Writes status to stdout
#######################################
function_name() {
    # Implementation
}
```

**Inline Comments:**
```bash
# Extract JIRA ID from branch name
local jira_id=$(echo "$branch" | grep -oE "$JIRA_ID_REGEX" | head -1)

# Skip if already valid
if is_valid_commit_message "$current_msg"; then
    return 0
fi
```

### Logging

**Use appropriate levels:**
```bash
log_message $LOG_ERROR "$HOOK_NAME" "Critical error occurred"
log_message $LOG_WARNING "$HOOK_NAME" "Warning: potential issue"
log_message $LOG_INFO "$HOOK_NAME" "Operation completed"
log_message $LOG_DEBUG "$HOOK_NAME" "Debug: variable=$value"
```

**Use helper functions:**
```bash
show_progress "$HOOK_NAME" 1 5 "Starting validation..."
pass_test "Test description"
fail_test "Test description" "Reason for failure"
```

### Output Messages

**User-facing messages:**
```bash
# Use colors for clarity
echo -e "${RED}${BOLD}[Error]${NC} Something went wrong"
echo -e "${YELLOW}[Warning]${NC} Potential issue"
echo -e "${GREEN}✓${NC} Success"
echo -e "${CYAN}[Info]${NC} Information"

# Provide actionable guidance
echo -e "\n${GREEN}${BOLD}Fix:${NC}"
echo -e "  1. Do this first"
echo -e "  2. Then do this"
echo -e "  3. Finally do this"

# Include examples
echo -e "\n${CYAN}${BOLD}Example:${NC}"
echo -e "  ${BOLD}git commit -m \"feat: ABC-123 Description\"${NC}"
```

---

## Testing Your Changes

### Local Testing

```bash
# 1. Test installation
bash .githooks/install-hooks.sh

# 2. Verify configuration
git config --get-regexp hooks

# 3. Test specific hook
echo "test" > test.txt
git add test.txt
git commit -m "feat: TEST-001 Test changes"

# 4. Check logs
tail -f .git/hook-logs/complete.log

# 5. Test failure cases
echo "SECRET_KEY=test123" > config.txt
git add config.txt
git commit -m "feat: TEST-002 Should fail"

# 6. Test bypass
BYPASS_HOOKS=1 git commit -m "feat: TEST-003 Bypassed"
```

### Test Suite Execution

```bash
# Run full test suite
bash .githooks/test/run-comprehensive-tests.sh

# Run specific category
bash .githooks/test/test-scenarios/branch-tests.sh
bash .githooks/test/test-scenarios/security-tests.sh

# Run with verbose logging
GITHOOKS_TEST_LOG_LEVEL=verbose bash .githooks/test/run-comprehensive-tests.sh

# Run and save results
bash .githooks/test/run-comprehensive-tests.sh | tee test-results.txt
```

### Manual Test Scenarios

**Scenario 1: Branch Creation**
```bash
# From develop (should pass)
git checkout develop
git checkout -b feat-TEST-101-new-feature
# Expected: ✓ Base branch validated

# From main (should fail)
git checkout main
git checkout -b feat-TEST-102-wrong-base
# Expected: ✗ Invalid Base Branch
```

**Scenario 2: Commit Message**
```bash
# Valid message
git commit --allow-empty -m "feat: TEST-201 Valid message"
# Expected: ✓ Commit message validated

# Invalid message
git commit --allow-empty -m "added feature"
# Expected: ✗ Invalid commit message format!
```

**Scenario 3: Secret Detection**
```bash
# Create file with secret
echo "AWS_KEY=AKIAIOSFODNN7EXAMPLE" > config.txt
git add config.txt
git commit -m "feat: TEST-301 Config"
# Expected: ✗ Security Alert! Potential secrets detected

# Remove secret and retry
echo "AWS_KEY=\${AWS_KEY}" > config.txt
git add config.txt
git commit -m "feat: TEST-301 Config"
# Expected: ✓ No secrets detected
```

**Scenario 4: Custom Commands**
```bash
# Add command to commands.conf
echo "pre-commit:1:true:5:echo \"Custom check passed\":Custom Check" >> .githooks/commands.conf

# Test
git commit --allow-empty -m "feat: TEST-401 Custom command"
# Expected: [1] Running: Custom check
#           ✓ Custom check (0s)
```

### Edge Case Testing

```bash
# Test with no staged files
git commit --allow-empty -m "feat: TEST-501 Empty commit"

# Test with large files
dd if=/dev/zero of=large.bin bs=1M count=100
git add large.bin
git commit -m "feat: TEST-502 Large file"

# Test with binary files
cp /bin/ls binary-file
git add binary-file
git commit -m "feat: TEST-503 Binary file"

# Test with special characters in file names
touch "file with spaces.txt"
touch "file-with-émojis-🎉.txt"
git add "file with spaces.txt" "file-with-émojis-🎉.txt"
git commit -m "feat: TEST-504 Special characters"
```

### Rollback Testing

```bash
# Test installation rollback
bash .githooks/test/test-rollback.sh

# Manual rollback test
# 1. Save current state
git config --get-regexp hooks > /tmp/hooks-before.txt

# 2. Cause installation failure (simulate)
# 3. Verify rollback restored state
git config --get-regexp hooks > /tmp/hooks-after.txt
diff /tmp/hooks-before.txt /tmp/hooks-after.txt
```

### Performance Testing

```bash
# Time hook execution
time git commit --allow-empty -m "feat: TEST-601 Performance"

# Profile custom commands
bash -x .githooks/pre-commit 2>&1 | grep "^+"

# Check log sizes
du -sh .git/hook-logs/

# Test with many staged files
for i in {1..100}; do
    echo "file $i" > "file-$i.txt"
done
git add file-*.txt
time git commit -m "feat: TEST-602 Many files"
```

---

## Pull Request Process

### Before Submitting

**1. Code Quality:**
- ✅ Follows style guidelines
- ✅ No syntax errors (run `bash -n <file>`)
- ✅ No shellcheck warnings
- ✅ Functions have comments
- ✅ User-facing messages are clear

**2. Testing:**
- ✅ All tests pass
- ✅ New tests added for new features
- ✅ Edge cases covered
- ✅ Manual testing completed

**3. Documentation:**
- ✅ README updated (if needed)
- ✅ CONTRIBUTING updated (if needed)
- ✅ Inline comments added
- ✅ Examples provided

**4. Git History:**
- ✅ Clean commit history (squashed if needed)
- ✅ Descriptive commit messages
- ✅ Follows branch naming convention

### Submission Checklist

```bash
# 1. Ensure on feature branch
git branch
# Should show: feat-<JIRA-ID>-<description>

# 2. Sync with latest develop
git fetch origin
git rebase origin/develop

# 3. Run tests
bash .githooks/test/run-comprehensive-tests.sh

# 4. Check for uncommitted changes
git status

# 5. Review your changes
git diff origin/develop...HEAD

# 6. Squash if needed
git rebase -i origin/develop

# 7. Force push (if rebased)
git push --force-with-lease origin feat-<JIRA-ID>-<description>

# 8. Create PR via GitHub/GitLab UI
```

### PR Template

```markdown
## Description
Brief description of changes.

## Type of Change
- [ ] Bug fix (non-breaking)
- [ ] New feature (non-breaking)
- [ ] Breaking change
- [ ] Documentation update

## Related Issue
Closes #<issue-number>

## Changes Made
- Added X
- Modified Y
- Fixed Z

## Testing
- [ ] Unit tests added/updated
- [ ] Integration tests pass
- [ ] Manual testing completed
- [ ] Edge cases covered

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-reviewed code
- [ ] Added comments for complex logic
- [ ] Updated documentation
- [ ] No breaking changes (or documented)
- [ ] Tests pass locally

## Screenshots (if applicable)
```

### PR Review Process

**As Author:**
1. Respond to all review comments
2. Make requested changes promptly
3. Re-request review after updates
4. Keep PR scope focused

**As Reviewer:**
1. Check code quality and style
2. Verify tests are adequate
3. Test changes locally
4. Provide constructive feedback
5. Approve when satisfied

### After Merge

```bash
# 1. Switch to develop
git checkout develop

# 2. Pull merged changes
git pull origin develop

# 3. Delete feature branch
git branch -d feat-<JIRA-ID>-<description>

# 4. Delete remote branch
git push origin --delete feat-<JIRA-ID>-<description>

# 5. Update changelog (if applicable)
```

---

## Best Practices

### General Guidelines

✅ **Keep Changes Focused**
- One feature/fix per PR
- Don't mix refactoring with features
- Small, reviewable changes

✅ **Backward Compatibility**
- Don't break existing functionality
- Provide migration path for breaking changes
- Version major changes

✅ **Error Messages**
- Clear and actionable
- Include fix suggestions
- Provide examples

✅ **Performance**
- Minimize hook execution time
- Avoid unnecessary operations
- Use parallel execution where appropriate

✅ **Testing**
- Test both success and failure paths
- Include edge cases
- Automate where possible

### Security Considerations

🔒 **Secret Scanning**
- Keep patterns up-to-date
- Test with real (redacted) examples
- Balance security vs. false positives

🔒 **Bypass Mechanisms**
- Document when to use
- Log all bypass events
- Never bypass security checks in production

🔒 **File Permissions**
- Hooks must be executable
- Don't commit sensitive data
- Validate file paths

### Maintenance

🔧 **Regular Updates**
- Review and update patterns
- Remove deprecated code
- Keep dependencies current
- Archive old logs

🔧 **Documentation**
- Keep docs in sync with code
- Add examples for complex features
- Document breaking changes

🔧 **Monitoring**
- Review logs periodically
- Track bypass usage
- Monitor performance metrics

### Community

🤝 **Communication**
- Discuss major changes beforehand
- Be respectful in reviews
- Help newcomers
- Share knowledge

🤝 **Code Ownership**
- No single owner, team responsibility
- Review others' PRs
- Maintain code you touch

---

## Getting Help

**Questions?**
- Check existing documentation
- Search closed issues/PRs
- Ask in team chat
- Create issue if needed

**Found a Bug?**
- Check if already reported
- Provide reproduction steps
- Include logs and environment details
- Submit PR with fix if possible

**Feature Request?**
- Describe use case
- Explain benefits
- Consider implementation complexity
- Discuss before implementing

---

## Resources

### Git Hooks Documentation
- [Git Hooks Official Docs](https://git-scm.com/docs/githooks)
- [Pro Git Book - Customizing Git](https://git-scm.com/book/en/v2/Customizing-Git-Git-Hooks)

### Bash Scripting
- [Bash Guide](https://mywiki.wooledge.org/BashGuide)
- [ShellCheck](https://www.shellcheck.net/)
- [Google Shell Style Guide](https://google.github.io/styleguide/shellguide.html)

### Testing
- [BATS - Bash Automated Testing System](https://github.com/bats-core/bats-core)
- [shunit2](https://github.com/kward/shunit2)

---

**Last Updated:** 2025-01-04  
**Version:** 3.0
